"""Seeded GSM8K capture and separate in-model timing passes, one TP8 server."""
import argparse
import json
import os
from pathlib import Path
import random
import socket
import subprocess
import sys
import time
from benchmarks.serve import arguments,stop
from benchmarks.routing_experiment import request,save
from .protocol import LAYERS


def main():
    p=argparse.ArgumentParser()
    for name in ('model','data','output'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--mode',choices=['capture','timing'],default='capture')
    p.add_argument('--backend',choices=['aiter','port_ew'],default='aiter')
    p.add_argument('--batches',nargs='+',type=int,default=[1,2,4,8,16,32,64])
    p.add_argument('--steps',type=int,default=16)
    p.add_argument('--speculative',action='store_true')
    p.add_argument('--speculative-num-steps',type=int,default=3)
    p.add_argument('--speculative-num-draft-tokens',type=int,default=4)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    assert os.environ.get('SLURM_JOB_ID')
    train,test=[[json.loads(l) for l in (a.data/name).read_text().splitlines()]
                for name in ('gsm8k-train.jsonl','gsm8k-test.jsonl')]
    prefix=''.join(f"Question: {x['question']}\nAnswer: {x['answer']}\n\n" for x in train[:24])
    selected=random.Random(355052).sample(range(len(test)),64)
    sampling=dict(temperature=0,max_new_tokens=128,ignore_eos=False,stop=['\nQuestion:','<|user|>'])
    forward_mode='target_verify' if a.speculative else 'decode'
    draft_tokens=a.speculative_num_draft_tokens if a.speculative else 1
    manifest=dict(seed=355052,shots=24,layers=LAYERS,steps=a.steps,mode=a.mode,backend=a.backend,
                  forward_mode=forward_mode,speculative_num_steps=a.speculative_num_steps if a.speculative else 0,
                  speculative_num_draft_tokens=draft_tokens,
                  sampling=sampling,runs=[dict(run_id=(f'c{b}-d{draft_tokens}-s355052' if a.speculative else f'b{b}-s355052'),
                    batch=b,moe_rows=b*draft_tokens,prompt_ids=selected[:b]) for b in a.batches])
    save(a.output/'manifest.json',manifest)
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    base=f'http://127.0.0.1:{port}'
    env=os.environ.copy();env.update(MARLOWE_REPLAY_OUTPUT=str(a.output),MARLOWE_REPLAY_MODE=a.mode,
        MARLOWE_REPLAY_STEPS=str(a.steps),SGLANG_USE_MARLOWE_KERNELS='1' if a.backend=='port_ew' else '0',
        MARLOWE_REPLAY_FORWARD_MODE=forward_mode,MARLOWE_REPLAY_MAX_ROWS=str(max(a.batches)*draft_tokens),
        MARLOWE_KERNELS_BENCHMARK_ALL='1',MARLOWE_KERNELS_VALIDATE='0',
        MARLOWE_KERNELS_AUDIT_DIR=str(a.output/'backend-audit'),
        SGLANG_USE_AITER='1',SGLANG_MOE_PADDING='1',SGLANG_SET_CPU_AFFINITY='1',SGLANG_USE_ROCM700A='1',
        SGLANG_INT4_WEIGHT='0',SGLANG_ALLOW_OVERWRITE_LONGER_CONTEXT_LEN='1',SGLANG_DISABLE_CUDNN_CHECK='1',
        SGLANG_ROCM_FUSED_DECODE_MLA='1',SGLANG_ROCM_DISABLE_LINEARQUANT='0',
        TOKENIZERS_PARALLELISM='false',HF_HUB_OFFLINE='1')
    command=[sys.executable,'-B','-m','benchmarks.moe_replay.capture']+arguments(a.model,max(a.batches),port,'mi355x')
    if a.speculative:
        command += ['--speculative-algorithm','EAGLE','--speculative-num-steps',str(a.speculative_num_steps),
                    '--speculative-eagle-topk','1','--speculative-num-draft-tokens',str(draft_tokens)]
    command[command.index('--max-running-requests')+1]='128'
    i=command.index('--cuda-graph-bs-decode')
    command[i+1:i+2]=[str(b) for b in [1,2,4,8,16,32,64] if b<=max(a.batches)]
    save(a.output/'launch.json',dict(command=command,job=os.environ['SLURM_JOB_ID'],environment={k:v for k,v in env.items() if k.startswith(('MARLOWE_','SGLANG_','PYTHONPATH'))}))
    proc=None
    try:
        with (a.output/'server.log').open('w') as log:
            proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
            deadline=time.monotonic()+2400
            while time.monotonic()<deadline:
                if proc.poll() is not None:raise RuntimeError(f'Server exited {proc.returncode}')
                try:
                    info=request(base,'/get_server_info',timeout=10)
                    request(base,'/health_generate',timeout=30);break
                except Exception:time.sleep(3)
            else:raise TimeoutError('Server startup')
            save(a.output/'server-info.json',info)
            for run in manifest['runs']:
                target=a.output/run['run_id'];target.mkdir(exist_ok=True)
                texts=[prefix+f"Question: {test[i]['question']}\nAnswer:" for i in run['prompt_ids']]
                result=request(base,'/generate',dict(text=texts,sampling_params=sampling,
                    rid=[f"moereplay:{run['run_id']}:{i}" for i in range(run['batch'])]))
                save(target/'responses.json',result)
                for _ in range(30):
                    try:request(base,'/flush_cache',timeout=600)
                    except Exception:
                        if proc.poll() is not None:raise
                    if (target/'capture.json').exists():break
                    time.sleep(1)
                else:raise RuntimeError('Missing capture export')
                meta=json.loads((target/'capture.json').read_text())
                assert meta['captured_steps']>0
                print(json.dumps(dict(run=run['run_id'],steps=meta['captured_steps'],
                    live_counts=sorted({s['actual_token_count'] for s in meta['steps']}))),flush=True)
            save(a.output/'completed.json',dict(runs=len(manifest['runs']),passed=True))
    finally:stop(proc)


if __name__=='__main__':main()
