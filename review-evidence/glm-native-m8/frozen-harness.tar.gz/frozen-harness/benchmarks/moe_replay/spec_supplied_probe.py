"""Check the experimental 128-row supplied-route program on MTP inputs."""
import argparse
import json
import os
from pathlib import Path

from .upgrade_state import save


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--model',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--source-digest',required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    assert os.environ.get('SLURM_JOB_ID')
    import torch
    from marlowe_kernels._runtime import source_digest
    from .backend import Layer
    from .reference import compare,expert_reference
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    from sglang.srt.layers.moe.utils import initialize_moe_config
    assert torch.cuda.device_count()==1 and source_digest()==a.source_digest
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    set_global_server_args_for_scheduler(ServerArgs(model_path=str(a.model),tp_size=8,ep_size=1,
        dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    initialize_moe_config()
    init_distributed_environment(world_size=1,rank=0,local_rank=0,
        distributed_init_method='file://'+str(a.output/f'rendezvous-{os.getpid()}'),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    context=get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,
                                    tp_size=8,moe_tp_size=8,moe_ep_size=1)
    context.__enter__();rows=[]
    try:
        source=a.capture/'c32-d4-s355052'
        meta=json.loads((source/'capture.json').read_text())
        data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
        for layer_id in (3,40,77):
            layer=Layer(torch.load(a.capture/'weights'/f'layer-{layer_id}.pt',weights_only=True),layer_id)
            layer.port.warmup((128,),routing='supplied')
            program=layer.port._native_programs[128]
            for step in (0,1):
                x=data['input'][step,meta['layers'].index(layer_id),:128]
                logits=layer.gate(x);weights,ids=layer.routes(x,logits)
                eager=layer.port.forward_routed(x,ids.contiguous(),weights.contiguous()).clone()
                route_ids,route_weights=(v.clone() for v in layer.port.routing(128,routing='supplied'))
                reference=expert_reference(layer.weights,x,route_ids,route_weights,program.fp32_middle)
                eager_check=compare(eager,reference)
                graph=torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):
                    output=layer.port.forward_routed(x,ids.contiguous(),weights.contiguous()).clone()
                for _ in range(3):graph.replay()
                torch.cuda.synchronize();graph_check=compare(output,reference)
                row=dict(layer=layer_id,step=step,eager=eager_check,graph=graph_check,
                         routes_exact=bool(torch.equal(route_ids[:,:8],ids) and
                                           torch.equal(route_weights[:,:8],weights)),
                         program=program.info)
                rows.append(row)
                if not eager_check['passed'] or not graph_check['passed'] or not row['routes_exact']:
                    save(a.output/'failure.json',dict(row=row))
                    raise RuntimeError(f'Supplied-route B128 reference failure layer{layer_id}/step{step}')
                del graph,output
        save(a.output/'summary.json',dict(job=os.environ['SLURM_JOB_ID'],source_digest=source_digest(),
                                          cases=len(rows),passed=True,rows=rows))
    finally:
        context.__exit__(None,None,None);torch.distributed.destroy_process_group()


if __name__=='__main__':main()
