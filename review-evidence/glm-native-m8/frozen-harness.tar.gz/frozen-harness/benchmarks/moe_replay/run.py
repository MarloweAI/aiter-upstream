"""Paired AITER/Port-EW replay with untimed input preloads and native events."""
import argparse
import hashlib
from functools import lru_cache
import importlib
import json
import os
from pathlib import Path
import random
import statistics as st
import torch
import triton as tr
from .backend import Layer
from .events import Event
from .kernels import touch_input
from .protocol import cases,load_metadata,mxfp4_intermediate_is_fused


@lru_cache(maxsize=128)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda:f.read(8*1024*1024),b''):h.update(data)
    return h.hexdigest()


def reference(layer,x,ids,rw,fused):
    from .reference import expert_reference
    return expert_reference(layer.weights,x,ids,rw,fused)


def prepare_graph(sequence,layers,tensors,variant,preload,markers,retain_outputs=False):
    outputs=[];events=[]
    sink=torch.empty((tr.cdiv(64*6144,1024),),device='cuda')
    for _ in sequence:events.append((Event(),Event()) if markers else None)
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        for case,pair in zip(sequence,events):
            x=tensors['input'][case['slot'],case['layer_index'],:case['graph_rows']]
            if preload:touch_input[(tr.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
            if pair:pair[0].record()
            out=layers[case['layer']](x,variant)
            if pair:pair[1].record()
            if retain_outputs:outputs.append((out.clone(),layers[case['layer']].last_logits.clone(),
                layers[case['layer']].last_ids.clone(),layers[case['layer']].last_weights.clone()))
    return dict(graph=graph,pairs=events,sink=sink,outputs=outputs)


def timings(graphs,samples,warmups):
    for item in graphs.values():
        for _ in range(warmups):item['graph'].replay()
    torch.cuda.synchronize()
    outer=[torch.cuda.Event(enable_timing=True) for _ in range(2)]
    result={k:dict(graph_samples_us=[],interval_samples_us=[]) for k in graphs}
    rng=random.Random(355052)
    for _ in range(samples):
        order=list(graphs);rng.shuffle(order)
        for name in order:
            item=graphs[name]
            outer[0].record();item['graph'].replay();outer[1].record();outer[1].synchronize()
            result[name]['graph_samples_us'].append(outer[0].elapsed_time(outer[1])*1000)
            if item['pairs'][0] is not None:
                result[name]['interval_samples_us'].append([s.elapsed_us(e) for s,e in item['pairs']])
    for name,r in result.items():
        r['graph_median_us']=st.median(r['graph_samples_us'])
        if r['interval_samples_us']:
            r['interval_medians_us']=[st.median(row[i] for row in r['interval_samples_us']) for i in range(len(r['interval_samples_us'][0]))]
            r['sum_interval_median_us']=st.median(sum(row) for row in r['interval_samples_us'])
    return result


def main(argv=None, *, layer_factory=Layer, runtime_identity=None, dispatch_validator=None, result_cache=None, port_variants=("port_ew",), native_reference_variants=(), stage_profiler=None, state_validator=None, independent_routing_variants=(), routing_validator=None):
    variants=("aiter", *port_variants)
    if independent_routing_variants and routing_validator is None:
        raise ValueError('Independent routing requires an explicit routing validator')
    p=argparse.ArgumentParser()
    for name in ('capture','output','model'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--research',type=Path,help=argparse.SUPPRESS)  # Legacy launch-script compatibility.
    p.add_argument('--batches',nargs='+',type=int,default=[1,2,4,8,16,32,64])
    p.add_argument('--samples',type=int,default=40);p.add_argument('--warmups',type=int,default=10)
    p.add_argument('--steps',type=int);p.add_argument('--layer-limit',type=int)
    p.add_argument('--skip-reference',action='store_true',help='Pilot only; not a qualified result')
    p.add_argument('--profile-stages',action='store_true',help='Extra diagnostic graph; requires a backend-specific stage profiler')
    p.add_argument('--diagnostic-on-reference-failure',action='store_true',
                   help='Preserve every numerical failure and still measure; results are ALWAYS unqualified')
    a=p.parse_args(argv);a.output.mkdir(parents=True,exist_ok=True)
    if a.profile_stages and stage_profiler is None:raise ValueError('No stage profiler supplied')
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_num_threads(4);torch.set_grad_enabled(False);torch.backends.cuda.matmul.allow_tf32=False
    from .reference import compare
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    set_global_server_args_for_scheduler(ServerArgs(model_path=str(a.model),tp_size=8,ep_size=1,
        dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    if runtime_identity is not None:
        from sglang.srt.layers.moe.utils import initialize_moe_config
        initialize_moe_config()
    layers={}
    for b in a.batches:
        if not a.diagnostic_on_reference_failure and any((a.output/f'b{b}-{kind}-validation-failure.json').exists() for kind in ('graph','eager')):
            raise RuntimeError(f'Preserved numerical failure at B{b}; investigate it rather than retrying to qualify the same run')
        source=a.capture/f'b{b}-s355052'
        meta=load_metadata(source)
        if a.steps:meta['steps']=meta['steps'][:a.steps]
        if a.layer_limit:meta['layers']=meta['layers'][:a.layer_limit]
        from marlowe_kernels._runtime import source_digest
        identity=dict(library_source=source_digest(),torch=torch.__version__,hip=torch.version.hip,
            weight_hashes={str(l):sha(a.capture/'weights'/f'layer-{l}.pt') for l in meta['layers']},
            capture_sha256=sha(source/'tensors.pt'),metadata_sha256=sha(source/'capture.json'),
            sources={name:sha(Path(__file__).parent/name) for name in ('run.py','backend.py','events.py','kernels.py','protocol.py','reference.py')},samples=a.samples,warmups=a.warmups,
            steps=a.steps,layer_limit=a.layer_limit,skip_reference=a.skip_reference,variants=list(variants), native_reference_variants=list(native_reference_variants),profile_stages=a.profile_stages,
            diagnostic_on_reference_failure=a.diagnostic_on_reference_failure,
            independent_routing_variants=list(independent_routing_variants))
        # EOS/live-row corrections can change through responses.json even when
        # the raw capture metadata and tensor files are unchanged.
        from .upgrade_state import digest
        identity['effective_cases_sha256']=digest(list(cases(meta)))
        if runtime_identity is not None:identity['runtime']=runtime_identity(b) if callable(runtime_identity) else runtime_identity
        result_path=a.output/f'b{b}.json'
        if result_path.exists():
            saved=json.loads(result_path.read_text())
            if saved.get('identity')==identity and saved.get('qualified'):
                print(json.dumps(dict(batch=b,reused=True)),flush=True);continue
        cache_path=None
        if result_cache is not None:
            from .upgrade_state import digest,file_digest,save
            import shutil
            cache_path=Path(result_cache)/digest(identity)
            receipt=cache_path/'receipt.json';stored=cache_path/'result.json'
            if receipt.exists():
                r=json.loads(receipt.read_text())
                if file_digest(stored)!=r['sha256']:raise RuntimeError('Cached replay evidence changed')
                saved=json.loads(stored.read_text())
                if saved.get('identity')==identity and saved.get('qualified') and saved.get('dispatch_checks'):
                    shutil.copy2(stored,result_path)
                    print(json.dumps(dict(batch=b,reused=True,source=str(stored))),flush=True);continue
        sequence=list(cases(meta))
        assert all(c['actual_token_count']==c['scheduled_rows']==c['graph_rows'] for c in sequence), (
            'Padded captures require native valid-token masking; this replay currently qualifies unpadded windows only')
        data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
        for layer_id in meta['layers']:
            if layer_id not in layers:
                layers[layer_id]=layer_factory(torch.load(a.capture/'weights'/f'layer-{layer_id}.pt',weights_only=True),layer_id)
            for rows in {c['graph_rows'] for c in sequence}:layers[layer_id].warmup(rows)
        dispatch_checks=[]
        if dispatch_validator is not None:
            for layer_id in meta['layers']:
                j=meta['layers'].index(layer_id)
                dispatch_checks.append(dispatch_validator(layers[layer_id],data['input'][0,j,:b],b))
        checks=[];reference_cache=[];numerical_failures=[]
        native_modes={}
        for c in sequence:
            layer=layers[c['layer']];slot,j,n=c['slot'],c['layer_index'],c['graph_rows']
            x=data['input'][slot,j,:n]
            live=torch.tensor(c['live_rows']+[False]*(n-c['scheduled_rows']),device='cuda',dtype=torch.bool)
            if not bool(live.any()):continue
            modes=[];orig=layer.fm.get_2stage_cfgs
            def observe(*args,**kw):
                cfg=orig(*args,**kw);modes.append(cfg);return cfg
            layer.fm.get_2stage_cfgs=observe
            fresh=layer.gate(x).clone()
            fixed=data['logits'][slot,j,:n].to(fresh.dtype).contiguous()
            drift=[]
            for _ in range(3):
                current=layer.gate(x)
                wr,ir=layer.routes(x,current)
                drift.append(dict(logit_max_abs=float((current-fixed).abs().max()),
                    route_slots_changed=int((ir[live]!=data['ids'][slot,j,:n][live,:8]).sum())))
            try:native=layer.from_logits(x,fixed,'aiter').clone()
            finally:layer.fm.get_2stage_cfgs=orig
            assert modes
            cfg=modes[-1]
            fused_intermediate=mxfp4_intermediate_is_fused(cfg)
            native_modes[str(n)]=dict(fuse_quant=cfg.fuse_quant,skip_inter_quant=getattr(cfg,'skip_inter_quant',False),stage1=str(getattr(cfg.stage1,'keywords',{})),stage2=str(getattr(cfg.stage2,'keywords',{})))
            captured=compare(native[live],data['output'][slot,j,:n][live])
            route_check=bool(torch.equal(layer.last_ids[live],data['ids'][slot,j,:n][live]))
            weight_error=float((layer.last_weights[live]-data['routing_weights'][slot,j,:n][live]).abs().max())
            logit_error=float((layer.last_logits[live]-data['logits'][slot,j,:n][live]).abs().max())
            if runtime_identity is None:
                assert captured['passed'] and route_check and weight_error<=2e-6,(c,captured,route_check,weight_error,logit_error)
            ids,rw=layer.last_ids.clone(),layer.last_weights.clone()
            ports={};port_routes={};route_checks={};supplied_route_checks={}
            for variant in port_variants:
                ports[variant]=layer.from_logits(x,fixed,variant).clone()
                port_routes[variant]=(layer.last_ids.clone(),layer.last_weights.clone())
                if variant in independent_routing_variants:
                    route_checks[variant]=routing_validator(layer,x,fixed,*port_routes[variant],ids,rw)
                    assert route_checks[variant]['passed'], (variant,c,route_checks[variant])
                else:
                    assert torch.equal(layer.last_ids[live],ids[live]), (variant,c,'routes')
                    assert float((layer.last_weights[live]-rw[live]).abs().max())<=2e-6, (variant,c,'route weights')
                    supplied_route_checks[variant]=dict(exact_ids=True,exact_weights=bool(torch.equal(layer.last_weights[live],rw[live])))
                    if variant=='port_native_combine':assert supplied_route_checks[variant]['exact_weights'], (variant,c,'native weights changed')
            port=ports[port_variants[0]]
            row=dict(layer=c['layer'],decode_step=c['decode_step'],actual_token_count=c['actual_token_count'],
                     graph_rows=n,native_capture=captured,exact_routes=all(torch.equal(vi,ids) for vi,vw in port_routes.values()),routing_weight_error=weight_error,logit_error=logit_error,
                     native_router_repeats=drift,router_dtype=str(fresh.dtype),independent_routing=route_checks,supplied_route_checks=supplied_route_checks)
            if native_reference_variants:
                row['paired_aiter']={v:compare(value[live],native[live]) for v,value in ports.items()}
            if not a.skip_reference:
                rn=reference(layer,x,ids,rw,fused_intermediate)
                rp=rn if fused_intermediate==(n in (1,4,8,32)) else reference(layer,x,ids,rw,n in (1,4,8,32))
                port_refs={v:(rn if v in native_reference_variants else rp) for v in port_variants}
                for v in independent_routing_variants:
                    vi,vw=port_routes[v]
                    if not (torch.equal(vi,ids) and torch.equal(vw,rw)):
                        port_refs[v]=reference(layer,x,vi,vw,fused_intermediate if v in native_reference_variants else n in (1,4,8,32))
                row['aiter_reference']=compare(native[live],rn[live]);row['port_reference']=compare(port[live],rp[live])
                row['port_references']={v:compare(value[live],port_refs[v][live]) for v,value in ports.items()}
                if not (row['aiter_reference']['passed'] and all(check['passed'] for check in row['port_references'].values())):
                    from .upgrade_state import save
                    suffix=f"-l{c['layer']}-s{c['decode_step']}" if a.diagnostic_on_reference_failure else ''
                    path=a.output/f'b{b}-eager-validation-failure{suffix}.pt'
                    torch.save({k:v.detach().cpu() for k,v in dict(input=x,ids=ids,weights=rw,logits=fixed,
                        aiter=native,**ports,aiter_reference=rn,port_reference=rp).items()},path)
                    failure=dict(case=c,checks=row,tensors=str(path),tensors_sha256=sha(path))
                    save(a.output/f'b{b}-eager-validation-failure{suffix}.json',failure)
                    numerical_failures.append(dict(kind='eager',**failure))
                    if not a.diagnostic_on_reference_failure:
                        raise RuntimeError(f"Independent reference failure at B{b}, layer {c['layer']}, step {c['decode_step']}; see b{b}-eager-validation-failure.json")
                reference_cache.append(dict(ids=ids,weights=rw,aiter=rn,**port_refs,native_fused=fused_intermediate,routes_by_variant=port_routes,
                    alternates=[dict(mode=fused_intermediate if v in native_reference_variants else n in (1,4,8,32),
                                     ids=port_routes[v][0],weights=port_routes[v][1],reference=port_refs[v])
                                for v in independent_routing_variants]))
            hist=torch.bincount(ids[live].flatten().long(),minlength=257).cpu().tolist()
            assert sum(hist[:256])==8*c['actual_token_count'] and hist[256]==c['actual_token_count']
            row['expert_counts']=hist
            checks.append(row)
            if c['layer']==meta['layers'][-1]:print(json.dumps(dict(batch=b,validated_step=c['decode_step'])),flush=True)
        # A separate graph checks every output; clones occur after END and are
        # absent from performance graphs, so validation traffic is not timed.
        from .upgrade_state import save
        save(a.output/f'b{b}-eager-validation.json',dict(identity=identity,checks=checks))
        graph_checks={};graph_validation={}
        for variant in variants:
            graph=prepare_graph(sequence,layers,data,variant,True,False,True)
            for _ in range(3):graph['graph'].replay()
            torch.cuda.synchronize()
            validation=[]
            for case_index,(c,(out,logits,ids,weights)) in enumerate(zip(sequence,graph['outputs'])):
                x=data['input'][c['slot'],c['layer_index'],:c['graph_rows']]
                layer=layers[c['layer']]
                expected=layer.expert_routed(x,ids,weights,variant)
                check=compare(out,expected)
                detail=dict(layer=c['layer'],decode_step=c['decode_step'],graph_vs_eager=check)
                if a.skip_reference:
                    assert check['passed'],(variant,c,check)
                else:
                    cached=reference_cache[case_index]
                    cached_ids,cached_weights=cached['routes_by_variant'].get(variant,(cached['ids'],cached['weights']))
                    same_routes=torch.equal(ids,cached_ids) and torch.equal(weights,cached_weights)
                    mode=cached['native_fused'] if variant=='aiter' or variant in native_reference_variants else c['graph_rows'] in (1,4,8,32)
                    reused=same_routes
                    if same_routes:
                        graph_ref=cached[variant]
                    else:
                        match=next((r for r in cached['alternates'] if r['mode']==mode and
                                    torch.equal(ids,r['ids']) and torch.equal(weights,r['weights'])),None)
                        if match is None:
                            graph_ref=reference(layer,x,ids,weights,mode)
                            cached['alternates'].append(dict(mode=mode,ids=ids.clone(),weights=weights.clone(),reference=graph_ref))
                        else:
                            graph_ref=match['reference'];reused=True
                    detail.update(reference_reused=reused,graph_reference=compare(out,graph_ref),
                                  eager_reference=compare(expected,graph_ref))
                    # Two independently rounded atomic sums can differ by more
                    # than either differs from the reference. Keep the pairwise
                    # delta as evidence; qualify BOTH against the unchanged
                    # independent-reference thresholds instead.
                    passed=detail['graph_reference']['passed'] and detail['eager_reference']['passed']
                    if not passed:
                        suffix=f"-{variant}-l{c['layer']}-s{c['decode_step']}" if a.diagnostic_on_reference_failure else ''
                        failure_tensors=a.output/f'b{b}-graph-validation-failure{suffix}.pt'
                        torch.save({name:value.detach().cpu() for name,value in dict(input=x,logits=logits,
                            ids=ids,weights=weights,graph=out,eager=expected,reference=graph_ref).items()},failure_tensors)
                        failure=dict(variant=variant,case=c,detail=detail,
                            tensors=str(failure_tensors),tensors_sha256=sha(failure_tensors))
                        save(a.output/f'b{b}-graph-validation-failure{suffix}.json',failure)
                        numerical_failures.append(dict(kind='graph',**failure))
                    if not passed and not a.diagnostic_on_reference_failure:
                        raise RuntimeError(f"Numerical reference check failed: {variant}, B{b}, layer {c['layer']}, step {c['decode_step']}; see b{b}-graph-validation-failure.json")
                validation.append(detail)
                rw,ri=layer.routes(x,logits)
                if variant in independent_routing_variants:
                    detail['independent_routing']=routing_validator(layer,x,logits,ids,weights,ri,rw)
                    assert detail['independent_routing']['passed'], (variant,c,'graph routing',detail)
                else:
                    assert torch.equal(ids[:,:8],ri) and float((weights[:,:8]-rw).abs().max())<=2e-6,(variant,c,'graph routing')
                    detail['native_routes_exact']=bool(torch.equal(ids[:,:8],ri) and torch.equal(weights[:,:8],rw))
                    if variant=='port_native_combine':assert detail['native_routes_exact'], (variant,c,'native graph weights changed')
            graph_checks[variant]=a.skip_reference or all(c['graph_reference']['passed'] and c['eager_reference']['passed'] for c in validation)
            graph_validation[variant]=validation
            # Preserve completed validation even if a later optional control
            # fails. This does not qualify the failed paired experiment.
            save(a.output/f'b{b}-{variant}-graph-validation.json',
                 dict(identity=identity,variant=variant,passed=graph_checks[variant],checks=validation))
            del graph
        del reference_cache
        state_checks=[]
        if state_validator is not None:
            state_checks=[state_validator(layer,b) for layer in layers.values()]
            save(a.output/f'b{b}-state-validation.json',state_checks)
            if not all(c['passed'] for c in state_checks):raise RuntimeError(f'Backend state validation failed at B{b}')
        graphs={}
        for variant in variants:
            for preload,markers,label in [(True,True,'preload_events'),(True,False,'preload_plain'),(False,True,'no_preload_events')]:
                graphs[variant+'_'+label]=prepare_graph(sequence,layers,data,variant,preload,markers)
        result=timings(graphs,a.samples,a.warmups)
        if state_validator is not None:
            post=[dict(phase='after_timing',**state_validator(layer,b)) for layer in layers.values()]
            state_checks.extend(post)
            save(a.output/f'b{b}-state-validation.json',state_checks)
            if not all(c['passed'] for c in post):raise RuntimeError(f'Backend state changed incorrectly during B{b} timing')
        stage_profile=stage_profiler(sequence,layers,data,variants) if a.profile_stages else None
        record=dict(batch=b,identity=identity,scope='router GEMM through local combine, shared included; TP collective/residual excluded',
            sequence=sequence,checks=checks,graph_checks=graph_checks,graph_validation=graph_validation,dispatch_checks=dispatch_checks,timing=result,native_selection=native_modes,
            qualified=not a.skip_reference and not a.diagnostic_on_reference_failure and not numerical_failures,
            numerical_failures=numerical_failures,samples=a.samples,warmups=a.warmups,job=os.environ['SLURM_JOB_ID'],
            capture_sha256=sha(source/'tensors.pt'),metadata_sha256=sha(source/'capture.json'),
            weight_hashes={str(l):sha(a.capture/'weights'/f'layer-{l}.pt') for l in meta['layers']},
            torch=torch.__version__,hip=torch.version.hip,stage_profile=stage_profile,state_checks=state_checks)
        result_path.write_text(json.dumps(record,indent=2)+'\n')
        if cache_path is not None:
            cache_path.mkdir(parents=True,exist_ok=True)
            shutil.copy2(result_path,cache_path/'result.json')
            save(cache_path/'receipt.json',dict(sha256=file_digest(cache_path/'result.json')))
        print(json.dumps(dict(batch=b,done=True,latency={k:v['graph_median_us']/len(sequence) for k,v in result.items()})),flush=True)
        del graphs,data
        torch.cuda.empty_cache()


if __name__=='__main__':main()
