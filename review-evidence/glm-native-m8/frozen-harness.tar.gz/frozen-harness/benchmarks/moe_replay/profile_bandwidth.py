"""Profile only AITER G1/G2 microbenchmarks using audited TP8 rank-local operands.

Counter runs preserve the full 30-layer working set and preload inputs. ROCTx
ranges delimit only completed replay graphs; warmup/validation is excluded by
the report reader. Counter-instrumented durations are not benchmark results.
"""
import argparse
import ctypes
import hashlib
import functools
import statistics
import json
import os
from pathlib import Path
import subprocess


def probes(pairs, routes, references, setup, output, batch):
    """Small causal probes; route-count oracle is explicitly offline-only."""
    import random
    import torch
    import triton
    from .events import Event
    from .kernels import touch_input
    from .reference import compare
    from .upgrade_state import save
    names = ['baseline', 'g1_cacheable']
    if batch in (8, 64): names.append('g1_bn128')
    if batch in (32, 64): names.append('g2_exact_grid_oracle')
    graphs = {}
    checks = {}
    for name in names:
        try:
            modified = []
            for pair, route in zip(pairs, routes):
                fn1, kw1 = pair['calls']['g1']; fn2, kw2 = pair['calls']['g2']
                kw1, kw2 = dict(kw1), dict(kw2)
                if name == 'g1_cacheable': kw1['use_nt'] = False
                if name == 'g1_bn128': kw1['BN'] = 128
                if name == 'g2_exact_grid_oracle':
                    rows = int(kw2['cumsum_tensor'][0].item())
                    assert rows == route['padded_rows'], (rows, route['padded_rows'])
                    kw2['n_sorted_padded'] = rows
                fn1(**kw1); fn2(**kw2)
                modified.append((fn1,kw1,fn2,kw2,pair['x']))
            torch.cuda.synchronize()
            events = [[Event() for _ in range(3)] for _ in pairs]
            sink = torch.empty((384,), device='cuda')
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                for (fn1,kw1,fn2,kw2,x),es in zip(modified,events):
                    touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                    for key in ('sorted_expert_ids','cumsum_tensor','m_indices'):
                        v=kw1.get(key)
                        if isinstance(v,torch.Tensor) and v.numel():
                            touch_input[(triton.cdiv(v.numel(),1024),)](v,sink,v.numel(),1024)
                    es[0].record();fn1(**kw1);es[1].record();fn2(**kw2);es[2].record()
            setup.replay();graph.replay();torch.cuda.synchronize()
            checks[name] = [compare(pair['out'].reshape_as(ref),ref) for pair,ref in zip(pairs,references)]
            save(output/f'probe-validation-b{batch}-{name}.json', checks[name])
            assert all(r['passed'] for r in checks[name]), (name,checks[name])
            graphs[name]=(graph,events,sink,modified)
        except NotImplementedError as exc:
            save(output/f'probe-unsupported-b{batch}-{name}.json',dict(probe=name,error=str(exc)))
            continue
    names=list(graphs)
    for graph,*_ in graphs.values():
        for _ in range(5):setup.replay();graph.replay()
    torch.cuda.synchronize()
    rng=random.Random(355052)
    samples={name:[] for name in names}
    for _ in range(30):
        order=list(names);rng.shuffle(order)
        for name in order:
            graph,events,*_=graphs[name]
            setup.replay();graph.replay();torch.cuda.synchronize()
            samples[name].append([es[i].elapsed_us(es[i+1]) for es in events for i in range(2)])
    result={name:dict(interval_samples_us=rows,
        interval_medians_us=[statistics.median(r[i] for r in rows) for i in range(len(rows[0]))])
        for name,rows in samples.items()}
    save(output/f'probes-b{batch}.json',dict(batch=batch,sequence=routes,checks=checks,timing=result,
        scope='Paired G1/G2 microbenchmark only. Exact-grid probe uses precomputed actual padded row count and is an offline oracle, not a deployable runtime selector.'))
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--lock', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--batches', nargs='+', type=int, default=[8, 32, 64])
    p.add_argument('--steps', type=int, default=2)
    p.add_argument('--repeats', type=int, default=3)
    p.add_argument('--mode', choices=['counters', 'timing', 'probes'], default='counters')
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    import torch
    import triton
    from .sglang_adapter import SGLangLayer
    from .dispatch_audit import capture_dispatch, compare_dispatch
    from .protocol import cases, load_metadata
    from .kernels import touch_input
    from .run import timings
    from .events import Event
    from .upgrade_state import file_digest, save
    from sglang.srt.server_args import ServerArgs, set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment, initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    from sglang.srt.layers.moe.utils import initialize_moe_config
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count() == 1
    torch.set_num_threads(4)
    torch.set_grad_enabled(False)
    lock = json.loads(a.lock.read_text())
    c = lock['config']
    audit = Path(lock['run_root']) / 'native-audit'
    capture = Path(c['capture'])
    runtime = json.loads((Path(lock['runtime_root']) / 'runtime.json').read_text())
    for component in ('sglang', 'aiter'):
        directory = runtime['image']['source_dirs'][component]
        actual = subprocess.check_output(['git', '-C', directory, 'rev-parse', 'HEAD'], text=True).strip()
        assert actual == runtime['requested'][component], (component, actual)
    receipt = json.loads((audit / 'validated.json').read_text())
    assert receipt['passed']
    for name, expected in receipt['files'].items():
        assert file_digest(audit / name) == expected, name
    set_global_server_args_for_scheduler(ServerArgs(model_path=c['model'], tp_size=8, ep_size=1,
        dtype='bfloat16', quantization='quark', moe_a2a_backend='none'))
    initialize_moe_config()
    init_distributed_environment(world_size=1, rank=0, local_rank=0,
        distributed_init_method='file://' + str(a.output / f'rendezvous-{os.getpid()}'), backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1, expert_model_parallel_size=1, enable_symm_mem=False)
    roctx = ctypes.CDLL('/opt/rocm/lib/librocprofiler-sdk-roctx.so')
    roctx.roctxRangePushA.argtypes = [ctypes.c_char_p]
    layers = {}
    identity = dict(runtime_versions=runtime['versions'], commits=runtime['requested'],
        image_sha256=runtime['image']['image_sha256'], script_sha256=file_digest(Path(__file__)),
        job=os.environ['SLURM_JOB_ID'], node=os.environ.get('SLURMD_NODENAME'),
        gpu=str(torch.cuda.get_device_properties(0)), torch=torch.__version__, hip=torch.version.hip,
        lock_sha256=file_digest(a.lock), steps=a.steps, repeats=a.repeats, mode=a.mode,
        routing_source='captured_ids_and_routing_weights')
    save(a.output / 'identity.json', identity)
    try:
        with get_parallel().override(moe_ep_rank=0, moe_tp_rank=0, tp_rank=0, world_rank=0,
                                     tp_size=8, moe_tp_size=8, moe_ep_size=1):
            for b in a.batches:
                source = capture / f'b{b}-s355052'
                meta = load_metadata(source)
                meta['steps'] = meta['steps'][:a.steps]
                sequence = list(cases(meta))
                assert all(r['actual_token_count'] == r['scheduled_rows'] == r['graph_rows'] == b for r in sequence)
                data = torch.load(source / 'tensors.pt', map_location='cuda', weights_only=True)
                checks, selections, routes = [], {}, []
                stream = torch.cuda.graph(torch.cuda.CUDAGraph()).capture_stream
                for layer_id in meta['layers']:
                    if layer_id not in layers:
                        payload = torch.load(capture / 'weights' / f'layer-{layer_id}.pt', weights_only=True)
                        spec = json.loads((audit / f'layer-{layer_id}.json').read_text())
                        for key, expected in spec['weight_content_sha256'].items():
                            raw = payload[key].detach().contiguous().view(torch.uint8).numpy()
                            assert hashlib.sha256(memoryview(raw)).hexdigest() == expected
                        payload.update(torch.load(audit / f'gate-{layer_id}.pt', weights_only=True))
                        layer = SGLangLayer(payload, layer_id, spec)
                        for field, key in {'w13_weight':'w1', 'w2_weight':'w2', 'w13_scale':'w1_scale', 'w2_scale':'w2_scale'}.items():
                            expected = spec['weights'][key]
                            value = layer.weights[key]
                            dtype = getattr(torch, expected['dtype'].removeprefix('torch.'))
                            if value.dtype != dtype:
                                attributes = dict(value.__dict__)
                                value = value.view(dtype)
                                value.__dict__.update(attributes)
                            assert list(value.shape) == expected['shape'] and list(value.stride()) == expected['stride']
                            setattr(layer.quant_info, field, value)
                        layers[layer_id] = layer
                    layer = layers[layer_id]
                    x = data['input'][0, meta['layers'].index(layer_id), :b]
                    stream.wait_stream(torch.cuda.current_stream())
                    with torch.cuda.stream(stream):
                        for _ in range(2): layer(x, 'aiter')
                    torch.cuda.synchronize()
                    observed, _, check_graph = capture_dispatch(lambda: layer(x, 'aiter'))
                    native = json.loads((audit / f'dispatch-l{layer_id}-b{b}.json').read_text())
                    check = compare_dispatch(native, observed)
                    save(a.output / f'dispatch-b{b}-l{layer_id}.json', dict(check=check, observed=observed))
                    assert check['passed'], (b, layer_id, check)
                    checks.append(dict(layer=layer_id, passed=True))
                    del check_graph
                fm = next(iter(layers.values())).fm
                original_cfg = fm.get_2stage_cfgs
                import aiter.ops.flydsl.mxfp4_gemm1_kernels as mod1
                import aiter.ops.flydsl.mxfp4_gemm2_kernels as mod2
                import aiter.ops.flydsl.kernels.mxmoe_dispatcher as modv2
                from .reference import compare, expert_reference
                from .protocol import mxfp4_intermediate_is_fused
                targets = [(mod1,'flydsl_mxfp4_gemm1','g1'),
                           (mod2,'flydsl_mxfp4_gemm2','g2'),
                           (modv2,'mxfp4_moe_gemm2','g2')]
                pairs = []
                references = []
                for case in sequence:
                    layer = layers[case['layer']]
                    x = data['input'][case['slot'], case['layer_index'], :b]
                    selected = []
                    def picker(*args, **kwargs):
                        cfg = original_cfg(*args, **kwargs)
                        selected.append(cfg)
                        return cfg
                    observed_calls = {}
                    originals = []
                    for module, name, which in targets:
                        fn = getattr(module, name)
                        originals.append((module, name, fn))
                        def intercept(*args, _fn=fn, _which=which, **kwargs):
                            assert not args
                            observed_calls[_which] = (_fn, dict(kwargs))
                            return _fn(**kwargs)
                        setattr(module, name, intercept)
                    fm.get_2stage_cfgs = picker
                    try:
                        ids = data['ids'][case['slot'],case['layer_index'],:b].contiguous()
                        rw = data['routing_weights'][case['slot'],case['layer_index'],:b].contiguous()
                        assert ids.shape == rw.shape == (b,9)
                        native = layer.expert_routed(x, ids, rw, 'aiter').clone()
                    finally:
                        fm.get_2stage_cfgs = original_cfg
                        for module, name, fn in originals: setattr(module, name, fn)
                    assert set(observed_calls) == {'g1','g2'}, observed_calls.keys()
                    # Freeze each case's metadata/output independently; AITER's
                    # preparation workspaces may otherwise alias across calls.
                    clones = {}
                    calls = {}
                    for which, (fn, kwargs) in observed_calls.items():
                        for name, value in list(kwargs.items()):
                            if isinstance(value, torch.Tensor) and name not in ('w1_u8','w1_scale_u8','w2_u8','w2_scale_u8','hidden_states'):
                                key = (value.data_ptr(),str(value.dtype),tuple(value.shape),tuple(value.stride()))
                                if key not in clones: clones[key] = value.clone()
                                kwargs[name] = clones[key]
                        calls[which] = (fn, kwargs)
                    k1,k2 = calls['g1'][1],calls['g2'][1]
                    for name in ('inter_sorted_quant','inter_sorted_shuffled_scale'):
                        assert k1[name].data_ptr() == k2[name].data_ptr(), name
                    out = k2.get('flat_out', k2.get('out'))
                    assert out is not None
                    def pair_call(calls=calls):
                        calls['g1'][0](**calls['g1'][1])
                        calls['g2'][0](**calls['g2'][1])
                    out.zero_()
                    observed_pair, _, pair_graph = capture_dispatch(pair_call)
                    native_trace = json.loads((audit/f'dispatch-l{case["layer"]}-b{b}.json').read_text())
                    expected_nodes = [n for n in native_trace['nodes'] if any(t in ' '.join(n['label']) for t in ('gemm1_a4w4_','gemm2_a4w4_'))]
                    assert len(expected_nodes)==2 and observed_pair['nodes']==expected_nodes
                    del pair_graph
                    pairs.append(dict(calls=calls, out=out, x=x, launch=pair_call))
                    references.append(expert_reference(layer.weights,x,ids,rw,
                        mxfp4_intermediate_is_fused(selected[-1])))
                    cfg = selected[-1]
                    bm = cfg.block_m
                    selections[str(case['layer'])] = dict(block_m=bm, stage1=str(cfg.stage1), stage2=str(cfg.stage2))
                    counts = torch.bincount(ids.flatten().long(), minlength=257).cpu().tolist()
                    assert sum(counts[:256]) == 8*b and counts[256] == b
                    active = sum(n > 0 for n in counts)
                    tiles = sum((n+bm-1)//bm for n in counts)
                    routes.append(dict(**case, counts=counts, active_experts=active, tiles=tiles,
                        useful_rows=9*b, padded_rows=bm*tiles, block_m=bm,
                        g1_weight_bytes=active*1671168, g2_weight_bytes=active*835584))
                # Only the two selected expert kernels execute in each timed
                # interval. Preparation/router run once above, outside profiling.
                sink = torch.empty((384,), device='cuda')
                setup = torch.cuda.CUDAGraph()
                with torch.cuda.graph(setup):
                    for pair in pairs: pair['out'].zero_()
                events = [[Event() for _ in range(3)] for _ in sequence] if a.mode == 'timing' else []
                graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):
                    for index, pair in enumerate(pairs):
                        x=pair['x']
                        touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                        # Routing would have just been produced by preparation.
                        for name in ('sorted_expert_ids','cumsum_tensor','m_indices'):
                            value=pair['calls']['g1'][1].get(name)
                            if isinstance(value,torch.Tensor) and value.numel():
                                touch_input[(triton.cdiv(value.numel(),1024),)](value,sink,value.numel(),1024)
                        if events: events[index][0].record()
                        pair['calls']['g1'][0](**pair['calls']['g1'][1])
                        if events: events[index][1].record()
                        pair['calls']['g2'][0](**pair['calls']['g2'][1])
                        if events: events[index][2].record()
                for _ in range(3): setup.replay(); graph.replay()
                torch.cuda.synchronize()
                numerical=[compare(pair['out'].reshape_as(ref),ref) for pair,ref in zip(pairs,references)]
                save(a.output/f'validation-b{b}.json', numerical)
                assert all(r['passed'] for r in numerical), [(i,r) for i,r in enumerate(numerical) if not r['passed']]
                record = dict(batch=b, identity=identity, sequence=routes, selection=selections,
                    dispatch_checks=checks, pair_dispatch_checks=len(pairs), reference_checks=numerical,
                    scope='G1 + fused activation/quantization; G2 + weighted atomic combine only. Router and preparation excluded. 30 real layer weights, original step/layer order. Input/metadata preloads before timers; clearing in separate setup graph.',
                    capture_sha256=file_digest(source/'tensors.pt'), metadata_sha256=file_digest(source/'capture.json'))
                if a.mode == 'probes':
                    probes(pairs, routes, references, setup, a.output, b)
                elif events:
                    samples=[]
                    for _ in range(5): setup.replay();graph.replay()
                    torch.cuda.synchronize()
                    for _ in range(20):
                        setup.replay();graph.replay();torch.cuda.synchronize()
                        samples.append([es[i].elapsed_us(es[i+1]) for es in events for i in range(2)])
                    record['timing']=dict(interval_samples_us=samples,
                        interval_medians_us=[statistics.median(r[i] for r in samples) for i in range(len(samples[0]))])
                    record['stages']=['g1_and_intermediate','g2_and_combine']
                else:
                    setup.replay();graph.replay();torch.cuda.synchronize()
                    for repetition in range(a.repeats):
                        setup.replay();torch.cuda.synchronize()
                        roctx.roctxRangePushA(f'marlowe_bw_b{b}_r{repetition}'.encode())
                        graph.replay(); torch.cuda.synchronize()
                        roctx.roctxRangePop()
                save(a.output / f'b{b}.json', record)
                print(json.dumps(dict(batch=b, cases=len(sequence), mode=a.mode, complete=True)), flush=True)
                del graph, setup, data, out, events, pairs, references
    finally:
        torch.distributed.destroy_process_group()


if __name__ == '__main__':
    main()
