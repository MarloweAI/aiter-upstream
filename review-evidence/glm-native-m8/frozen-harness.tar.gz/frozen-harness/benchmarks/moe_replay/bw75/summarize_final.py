"""Join qualified full-pipeline and stage records without mixing their scopes."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path

from .report import G1_BYTES, G2_BYTES, read, summarize


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--stages', type=Path, required=True)
    parser.add_argument('--expected-library-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.manifest.parent
    entries = read(args.manifest)
    stage_paths = read(args.stages)
    rows = []
    for entry in entries:
        row = summarize(entry, root)
        batch = row['batch']
        replay = read(root / entry['path'])
        stage_path = root / stage_paths[str(batch)]
        stage = read(stage_path)
        assert row['identity']['library_source'] == args.expected_library_source
        assert stage['identity']['library_source'] == args.expected_library_source
        assert row['cases'] == stage['cases'] == 480 and stage['steps'] == 16
        for arm in ('selected_correctness', 'control_correctness'):
            assert all(row[arm][key] for key in
                       ('eager_passed', 'graph_passed', 'graph_eager_passed'))
        assert len(replay['dispatch_checks']) == 30
        assert all(check['passed'] for check in replay['dispatch_checks'])
        assert len(stage['checks']) == len(stage['staged_reference_checks']) == 480
        assert all(check['full_reference']['passed'] for check in stage['checks'])
        assert all(check['passed'] for check in stage['staged_reference_checks'])
        assert stage['stage_intermediates_bitwise']
        assert len(stage['layer_signature_checks']) == 30
        for left, right in zip(stage['sequence'], replay['checks']):
            assert (left['layer'], left['step']) == (right['layer'], right['decode_step'])
            assert left['experts'] == [i for i, count in enumerate(right['expert_counts']) if count]
        row['aiter_us'] = statistics.mean(
            replay['timing']['aiter_preload_events']['interval_medians_us'])
        row['stage_source_path'] = stage_paths[str(batch)]
        row['stage_source_sha256'] = hashlib.sha256(stage_path.read_bytes()).hexdigest()
        row['stage_metrics'] = {}
        for name in ('g1', 'g2'):
            measured = stage['timing'][name + '_coupled_preconditioned']
            isolated = stage['timing'][name + '_isolated_steady']
            row['stage_metrics'][name] = dict(
                interpretation='Useful weight throughput in a coupled-preconditioned stage sweep; not physical HBM',
                us=measured['amortized_case_us'],
                effective_weight_TBs=measured['effective_weight_TBs'],
                percent_peak=measured['effective_weight_TBs'] / 8 * 100,
                isolated_us=isolated['amortized_case_us'],
                isolated_TBs=isolated['effective_weight_TBs'],
                footprint=stage['footprint'][name])
        row['final_source_commit'] = stage['identity']['source_commit']
        rows.append(row)
    assert [row['batch'] for row in rows] == [1, 2, 4, 8, 16, 32, 64]
    assert len({row['final_source_commit'] for row in rows}) == 1
    result = dict(
        metric='Distinct active expert weights and scales / full router-through-combine interval',
        stage_metric='Same 480 cases, coupled-preconditioned isolated G1/G2 sweeps',
        peak_TBs=8, g1_bytes_per_expert=G1_BYTES, g2_bytes_per_expert=G2_BYTES,
        library_source=args.expected_library_source,
        source_commit=rows[0]['final_source_commit'], rows=rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    for row in rows:
        print(row['batch'], row['control_us'], row['selected_us'],
              row['latency_reduction_percent'], row['percent_peak'])


if __name__ == '__main__':
    main()
