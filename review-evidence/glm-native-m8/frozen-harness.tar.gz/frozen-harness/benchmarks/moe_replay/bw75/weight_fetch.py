"""Compare selected B16 G1 with a checked loader on the same physical layout.

One outer event pair covers 60 ordered real-weight cases. This is a simpler
kernel comparison, not a hard roofline or attainable full-MoE bandwidth claim.
Run this external driver against an immutable selected-library source tree.
"""
import argparse,hashlib,json,os,random,statistics
from pathlib import Path


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
 p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,required=True);p.add_argument('--expected-library-source',required=True)
 p.add_argument('--output',type=Path,required=True);p.add_argument('--steps',type=int,default=2);p.add_argument('--samples',type=int,default=40);p.add_argument('--warmups',type=int,default=10)
 a=p.parse_args();assert not a.output.exists()
 import torch
 import marlowe_kernels
 from marlowe_kernels import create_moe,MoEConfig,MoEWeights
 from marlowe_kernels._runtime import jit,source_digest,cache_identity
 from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import create_bandwidth_program,BANDWIDTH_CONFIGS
 from marlowe_kernels._kernels.amd.glm52_moe.block_fused import pointer
 from marlowe_kernels._kernels.amd.glm52_moe.fixed_bins import resolve_fixed_routes
 from benchmarks.moe_replay.protocol import cases,load_metadata
 from benchmarks.moe_replay.reference import expert_reference,compare
 from benchmarks.moe_replay.events import Event
 from benchmarks.moe_replay.dispatch_audit import capture_dispatch,graph_dot,ordered_span
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 assert Path(marlowe_kernels.__file__).resolve().is_relative_to(a.source_root.resolve())
 assert source_digest()==a.expected_library_source
 torch.set_num_threads(4);torch.set_grad_enabled(False)
 version=sha(__file__)[:20]

 @jit()
 def fetch_g1(J,VERSION,BN,DEPTH,NT,W:'void*',WS:'void*',IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',OUT:'void*',B:'int'):
  assert J.gfx==950 and BN==64 and DEPTH==2
  expert,token,slot,_=resolve_fixed_routes(J,IDS,RW,EXP,STATE,B,True)
  lane=J.gpr(J.threadIdx.x[0]);route=J.gpr(token[0]*9+slot[0])
  wp,sp=pointer(J,W),pointer(J,WS)
  wp[:]+=J.s_mul_u32_u64(expert,512*6144//2);sp[:]+=expert*(512*192)
  bv=J.gpr(DEPTH,2,4,4,'vu32');bs=J.gpr(DEPTH,4,'vu32')
  qb=[];sb=[]
  for n in range(4):
   col=J.gpr('vu32',J.blockIdx.x[0]*32+(n%2)*16+(256 if n>=2 else 0))
   qb.append(J.gpr(col[0]*3072+lane[0]*16));sb.append(J.gpr((col[0]//32)*6144+lane[0]*4))
  wh=J.gpr('vu32',0);sh=J.gpr('vu32',0);cursor=J.gpr('su32',0)
  def load(unit,step):
   for half in range(2):
    offset=J.gpr('su32',(step*2+half)*1024)
    for n in range(4):J.global_load_dwordx4(bv[unit,half,n],qb[n][0]+offset[0],wp,mod='sc0 nt' if NT else '')
   offset=J.gpr('su32',step*256)
   for n in range(4):J.global_load_dword(bs[unit,n],sb[n][0]+offset[0],sp)
  def consume(unit):
   # All four destination registers stay live until their request is ready.
   for half in range(2):
    for n in range(4):
     mix=J.gpr('vu32')
     J.v_xor_b32(mix,bv[unit,half,n,0],bv[unit,half,n,1])
     J.v_xor_b32(mix,mix,bv[unit,half,n,2])
     J.v_xor_b32(mix,mix,bv[unit,half,n,3])
     J.v_xor_b32(wh,mix,wh)
   for n in range(4):sh[:]+=bs[unit,n][0]*(n+1)
  for unit in range(DEPTH):load(unit,unit)
  with J.While(cursor[0]<24-DEPTH):
   for unit in range(DEPTH):
    J.s_waitcnt(mod=f'vmcnt({(DEPTH-1)*12})');consume(unit);load(unit,cursor[0]+DEPTH+unit)
   cursor[:]+=DEPTH
  for unit in range(DEPTH):
   J.s_waitcnt(mod=f'vmcnt({(DEPTH-unit-1)*12})');consume(unit)
  value=J.gpr('vu32');J.v_xor_b32(value,wh,sh);J.v_xor_b32(value,value,route)
  dst=J.gpr('vu32',((J.blockIdx.y[0]*8+J.blockIdx.x[0])*64+lane[0])*4)
  J.global_store_dword(dst,value,OUT)

 root=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2');b=16
 cfg=BANDWIDTH_CONFIGS[b];assert cfg['family']=='safe_fixed'
 cc=cfg['config'];assert cc['gate_n']==64 and cc['gate_waves']==1 and cc['split_k']==1 and cc['pair_depth']==2 and cc['non_temporal']
 meta=load_metadata(root/f'b{b}-s355052');meta['steps']=meta['steps'][:a.steps];sequence=list(cases(meta));assert len(meta['layers'])==30
 data=torch.load(root/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
 owners={};payloads={};checksums={};items=[];checks=[];routes=[]
 def reference_table(owner):
  assert owner.w13.is_contiguous() and owner.weights.w13_scale.is_contiguous()
  raw=owner.w13.view(torch.int32).reshape(257,32,48,64,4)
  value=raw[...,0]^raw[...,1]^raw[...,2]^raw[...,3]
  while value.shape[2]>1:
   n=value.shape[2];half=n//2;reduced=value[:,:,:half]^value[:,:,half:2*half]
   if n%2:reduced[:,:,0]^=value[:,:,-1]
   value=reduced
  value=value[:,:,0]
  weight=value[:,0:16:2]^value[:,1:16:2]^value[:,16:32:2]^value[:,17:32:2]
  scale=owner.weights.w13_scale.view(torch.int32).reshape(257,16,24,64).sum(dim=2,dtype=torch.int64)
  scale=((3*scale[:,:8]+7*scale[:,8:])&0xffffffff).to(torch.int32)
  return weight^scale
 def expected(case):
  pr=case['program'];state=pr.state.cpu();bank=int(state[1]);count=int(state[2+bank])//16
  encoded=pr.p['experts'][:count].long();expert=encoded&511;chunk=encoded>>9;row=torch.arange(16,device='cuda')[None,:]
  available=pr.state[4+bank*257+expert].long()-chunk*16;valid=row<available[:,None]
  ix=bank*pr.maximum+expert[:,None]*(b*8)+chunk[:,None]*16+row
  ix=torch.where(valid,ix,ix[:,:1]);packed=pr.p['sorted_ids'][ix]
  packed=torch.where(valid,packed,torch.full_like(packed,(9<<24)|b))
  route=((packed&0xffffff)*9+(packed>>24)).repeat(1,4)
  return checksums[case['layer']][expert]^route[:,None,:],count,expert
 def fetch(case):
  pr=case['program'];owner=pr.owner
  fetch_g1([8,pr.grid],[64],version,64,2,True,owner.w13.data_ptr(),owner.weights.w13_scale.data_ptr(),
   pr.p['sorted_ids'].data_ptr(),pr.p['sorted_weights'].data_ptr(),pr.p['experts'].data_ptr(),pr.state.data_ptr(),case['checksum'].data_ptr(),b)
 def full(case):
  pr=case['program'];pr._stage(pr.p['packed'],pr.p['workspace'].data_ptr()+256,pr.partial,True)
 for c in sequence:
  lid,j,slot=c['layer'],c['layer_index'],c['slot']
  if lid not in owners:
   w=torch.load(root/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True);payloads[lid]=w
   owners[lid]=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
   checksums[lid]=reference_table(owners[lid])
  owner=owners[lid];pr=create_bandwidth_program(owner,b);assert pr.grid==129
  x=data['input'][slot,j];logits=data['logits'][slot,j].bfloat16().contiguous();bias=payloads[lid]['bias'].bfloat16()
  actual=pr.run(x,logits,bias).clone();ids=pr.p['ids'].clone();rw=pr.p['weights'].clone()
  ref=expert_reference(payloads[lid],x,ids,rw,pr.fp32_middle);check=compare(actual,ref);assert check['passed'] and pr.state_check()['passed']
  item=dict(layer=lid,step=c['decode_step'],program=pr,checksum=torch.empty((pr.grid,8,64),device='cuda',dtype=torch.int32),mid=pr.partial.clone(),scales=pr.mid_scale.clone())
  target,count,experts=expected(item);item.update(expected=target,active_groups=count)
  fetch(item);torch.cuda.synchronize();assert torch.equal(item['checksum'][:count],target),(lid,slot,'checksum')
  routes.append(dict(layer=lid,step=c['decode_step'],experts=sorted(set(ids.flatten().cpu().tolist())),active_groups=count,grid=[8,pr.grid,1]))
  checks.append(dict(layer=lid,step=c['decode_step'],full_reference=check,checksum_exact=True,active_groups=count));items.append(item)
 assert len({i['program'].p['sorted_ids'].data_ptr() for i in items})==len(items)
 # Checked sensitivity and restoration, on a known loaded word in expert256.
 case=items[0];raw=case['program'].owner.w13.view(torch.int32).reshape(257,-1);saved=raw[256,0].clone()
 raw[256,0].bitwise_xor_(1);fetch(case);torch.cuda.synchronize();changed=int((case['checksum'][:case['active_groups']]!=case['expected']).sum())
 assert changed==1,changed
 raw[256,0].copy_(saved);fetch(case);torch.cuda.synchronize();assert torch.equal(case['checksum'][:case['active_groups']],case['expected'])
 graphs={};events={};spans={}
 for arm,fn in [('full_g1',full),('weight_fetch',fetch)]:
  lo,hi=Event(),Event();g=torch.cuda.CUDAGraph()
  with torch.cuda.graph(g):
   lo.record();before=graph_dot()
   for case in items:fn(case)
   after=graph_dot();hi.record()
  span=ordered_span(before,after);assert len(span['nodes'])==len(items) and all(x['kind']=='kernel' for x in span['nodes'])
  graphs[arm]=g;events[arm]=(lo,hi);spans[arm]=span
 for g in graphs.values():g.replay()
 torch.cuda.synchronize()
 for case in items:
  pr=case['program'];assert torch.equal(pr.partial,case['mid']) and torch.equal(pr.mid_scale,case['scales'])
  assert torch.equal(case['checksum'][:case['active_groups']],case['expected']) and pr.state_check()['passed']
 rng=random.Random(355052);samples={k:[] for k in graphs}
 for repeat in range(a.warmups+a.samples):
  order=list(graphs);rng.shuffle(order)
  for arm in order:
   graphs[arm].replay();torch.cuda.synchronize()
   if repeat>=a.warmups:samples[arm].append(events[arm][0].elapsed_us(events[arm][1]))
 for case in items:assert torch.equal(case['checksum'][:case['active_groups']],case['expected'])
 useful=sum(len(x['experts'])*1671168 for x in routes)
 timing={k:dict(samples_us=v,sweep_median_us=statistics.median(v),amortized_case_us=statistics.median(v)/len(items),effective_useful_weight_TBs=useful/statistics.median(v)/1e6) for k,v in samples.items()}
 cache=Path(os.environ['PYHIP_CACHE_DIR']);prefix=f'mk_{cache_identity()}_fetch_g1-VERSION={version}'
 assembly=list(cache.glob(prefix+'*.s'));assert len(assembly)==1,assembly
 text=assembly[0].read_text();loads=[line.split(';',1)[0].strip() for line in text.splitlines() if 'global_load_dwordx4 ' in line]
 assert loads and all(('sc0' in line and 'nt' in line) for line in loads)
 metadata=[line.strip() for line in text.splitlines() if any(k in line for k in ('.amdhsa_next_free_vgpr','.vgpr_count:', '.sgpr_count:'))]
 result=dict(batch=b,cases=len(items),steps=a.steps,config=cfg,scope='Simpler-kernel comparison with one outer event pair per ordered G1 sweep; fixed case-specific prepared metadata and input buffers; separate from coupled MoE, per-case event intervals and physical HBM bandwidth.',
  identity=dict(library_source=source_digest(),driver_sha256=sha(__file__),jit_namespace=cache_identity(),source_root=str(a.source_root),job=os.environ['SLURM_JOB_ID'],gpu=str(torch.cuda.get_device_properties(0)),torch=torch.__version__,hip=torch.version.hip),
  checks=checks,graph_checksums_exact=True,full_g1_graph_intermediates_exact=True,checksum_perturbation_changed_words=changed,checksum_weight_restored=True,
  sequence=routes,unique_weight_owners=len(owners),distinct_case_metadata=len(items),graph_event_pairs_per_sweep=1,timing=timing,useful_weight_bytes_per_sweep=useful,
  checksum_work='Four integer XOR instructions consume all four words of every128-bit weight load; weighted uint32 additions consume every32-bit scale load; output also includes route identity. One32-bit checksum is stored perlane peractiveCTA.',
  assembly=dict(path=str(assembly[0]),sha256=sha(assembly[0]),static_dwordx4_instructions=len(loads),all_weight_loads_nt=True,emitted_metadata=metadata),sweep_dispatch=spans)
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2));print('WEIGHT_FETCH',json.dumps(timing),flush=True)

if __name__=='__main__':main()
