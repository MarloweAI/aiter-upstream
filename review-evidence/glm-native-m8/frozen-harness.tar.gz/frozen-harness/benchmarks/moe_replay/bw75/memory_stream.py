"""Standalone read-stream calibration; never substituted for MoE timing."""
import argparse,hashlib,json,os,statistics
from pathlib import Path
import torch
from marlowe_kernels._runtime import jit,source_digest

@jit()
def read_stream_bw75_v1(J,GRID,THREADS,LOOPS,NT,X:'void*',Y:'void*'):
    base=J.gpr('su32',J.blockIdx.x[0]*THREADS)
    index=J.gpr(base[0]+J.threadIdx.x[0]);offset=J.gpr(index[0]*16)
    stride=J.gpr('su32',GRID*THREADS*16);cursor=J.gpr('su32',0)
    accum=J.gpr('vu32',0);values=J.gpr(4,'vu32')
    with J.While(cursor[0]<LOOPS):
        J.global_load_dwordx4(values,offset,X,mod='sc0 nt' if NT else '')
        J.s_waitcnt(mod='vmcnt(0)')
        for i in range(4):J.v_xor_b32(accum,accum,values[i])
        offset[:]+=stride[0];cursor[:]+=1
    J.global_store_dword(index[0]*4,accum,Y)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists() and os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_grad_enabled(False);torch.set_num_threads(4);torch.manual_seed(355052)
    nbytes=1<<30;repeats=8;threads=256
    x=torch.randint(-(1<<30),1<<30,(nbytes//4,),device='cuda',dtype=torch.int32)
    rows=[]
    for grid in (256,512,1024,2048,4096):
        y=torch.empty(grid*threads,device='cuda',dtype=torch.int32);loops=nbytes//(grid*threads*16)
        for nt in (False,True):
            call=lambda:read_stream_bw75_v1([grid],[threads],grid,threads,loops,nt,x.data_ptr(),y.data_ptr())
            call();torch.cuda.synchronize();before=int(y[0]);x[0]^=1;call();torch.cuda.synchronize();assert (int(y[0])^before)==1;x[0]^=1
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                for _ in range(repeats):call()
            for _ in range(4):graph.replay()
            torch.cuda.synchronize();events=[torch.cuda.Event(enable_timing=True) for _ in range(2)];samples=[]
            for _ in range(12):
                events[0].record();graph.replay();events[1].record();events[1].synchronize();samples.append(events[0].elapsed_time(events[1]))
            us=statistics.median(samples)*1000/repeats
            row=dict(grid=grid,threads=threads,loops=loops,non_temporal=nt,read_bytes=nbytes,output_bytes=y.numel()*4,us_per_read=us,read_TBs=nbytes/us/1e6,samples_ms=samples)
            rows.append(row);print(json.dumps(row),flush=True)
    result=dict(scope='standalone1GiB read stream, eight complete reads per timed graph; not MoE performance',rows=rows,
        best=max(rows,key=lambda r:r['read_TBs']),identity=dict(job=os.environ['SLURM_JOB_ID'],source=source_digest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),gpu=str(torch.cuda.get_device_properties(0)),torch=torch.__version__,hip=torch.version.hip))
    a.output.write_text(json.dumps(result,indent=2))

if __name__=='__main__':main()
