"""Bitwise check of paired G1 input-scale words against native G1 partials."""
import json,os
from pathlib import Path
import torch
from marlowe_kernels import MoEConfig,MoEWeights,create_moe
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedProgram,CoalescedConfig
from marlowe_kernels._kernels.amd.glm52_moe.native_pairprefetch import packed_input_projection

def main():
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 torch.set_grad_enabled(False);torch.set_num_threads(4)
 root=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
 w=torch.load(root/'weights/layer-3.pt',map_location='cuda',weights_only=True)
 owner=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
 rows=[]
 for b in [1,2,4,8]:
  d=torch.load(root/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
  c=CoalescedConfig(direct=True,gate_n=64,gate_waves=1,split_k=6,depth=4,down_n=256,down_waves=4,non_temporal=True)
  program=CoalescedProgram(owner,b,c);out=torch.empty_like(program.partial)
  for slot in range(16):
   x=d['input'][slot,0].contiguous();logits=d['logits'][slot,0].bfloat16().contiguous()
   program.run(x,logits,w['bias'].bfloat16());p=program.p
   packed_input_projection([8,b*9,6],[64],6144,512,64,True,6,program.fp32_middle,1,True,True,True,4,'wave',
    p['packed'].data_ptr(),p['workspace'].data_ptr()+256,owner.w13.data_ptr(),owner.weights.w13_scale.data_ptr(),out.data_ptr(),program.mid_scale.data_ptr(),
    p['ids'].data_ptr(),p['weights'].data_ptr(),p['ids'].data_ptr(),p['ids'].data_ptr(),b)
   torch.cuda.synchronize();assert torch.equal(out,program.partial),(b,slot,float((out-program.partial).abs().max()))
  rows.append(dict(batch=b,cases=16,bitwise_g1_partials=True));print(rows[-1],flush=True)
 Path(os.environ['PERSIST_ROOT'],'input-scale-probe.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':main()
