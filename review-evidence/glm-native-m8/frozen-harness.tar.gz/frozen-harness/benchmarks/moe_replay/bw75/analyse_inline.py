"""Validate small-batch Port-EW ROIs and summarize counters; trace durations are diagnostic only."""
import argparse,csv,gzip,hashlib,json,statistics
from collections import defaultdict
from pathlib import Path

EXPECTED={'baseline':['native_phase1','prefetch_projection','middle_packed','coalesced_down'],
          'inline':['inline_gate','overlap_down']}

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--batch',type=int,default=1);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 if a.batch==2:EXPECTED['baseline']=['native_phase1','prefetch_g1','middle_packed','prefetch_g2']
 if a.batch==4:EXPECTED['baseline']=['native_phase1','native_projection','middle_packed','coalesced_down']
 result={'batch':a.batch,'scope':'30 layers x 2 steps x 3 repeats; hardware counters separate from benchmark timing','arms':{}}
 sources=set()
 for arm,names in EXPECTED.items():
  result['arms'][arm]={}
  for group in ['memory','scheduling','compute','trace']:
   root=a.root/arm/group
   if not (root/'replay.json').exists():continue
   replay=json.loads((root/'replay.json').read_text());assert replay['batch']==a.batch and len(replay['sequence'])==60 and len(replay['checks'])==60
   assert all(x['passed'] for x in replay['checks'])
   sources.add(replay['identity']['source'])
   markers=list(csv.DictReader((root/'counters_marker_api_trace.csv').open()))
   ranges=[(int(r['Start_Timestamp']),int(r['End_Timestamp'])) for r in markers if r['Function'].startswith(f'bw75_b{a.batch}_r')];assert len(ranges)==3
   path=root/('counters_kernel_trace.csv' if group=='trace' else 'counters_counter_collection.csv')
   counters=defaultdict(lambda:defaultdict(list));dispatches=defaultdict(set);signatures={};kept=[]
   for row in csv.DictReader(path.open()):
    start,end=int(row['Start_Timestamp']),int(row['End_Timestamp'])
    roi=next((i for i,(lo,hi) in enumerate(ranges) if lo<=start and end<=hi),None)
    if roi is None or 'mk_' not in row['Kernel_Name']:continue
    if a.batch==2 and arm=='baseline' and '_prefetch_projection(' in row['Kernel_Name']:
     grid=int(row['Grid_Size']) if 'Grid_Size' in row else int(row['Grid_Size_X'])*int(row['Grid_Size_Y'])*int(row['Grid_Size_Z'])
     name={147456:'prefetch_g1',110592:'prefetch_g2'}.get(grid)
    else:name=next((n for n in names if '_'+n+'(' in row['Kernel_Name']),None)
    assert name,row['Kernel_Name']
    dispatches[name].add(row['Dispatch_Id']);kept.append(dict(roi=roi,stage=name,**row))
    if group=='trace':counters[name]['trace_duration_us'].append((end-start)/1000)
    else:
     counters[name][row['Counter_Name']].append(float(row['Counter_Value']))
     signatures[name]={k:row[k] for k in ['Grid_Size','Workgroup_Size','LDS_Block_Size','Scratch_Size','VGPR_Count','SGPR_Count']}
   assert set(dispatches)==set(names)
   for n in names:assert len(dispatches[n])==180,(arm,group,n,len(dispatches[n]))
   summary={n:{'dispatches':len(dispatches[n]),'signature':signatures.get(n),'values':{k:{'n':len(v),'mean':statistics.mean(v),'median':statistics.median(v),'sum':sum(v)} for k,v in counters[n].items()}} for n in names}
   for n in names:
    for k,v in summary[n]['values'].items():assert v['n']==180,(arm,group,n,k,v['n'])
   dst=a.output/f'{arm}-{group}-roi.csv.gz'
   with gzip.open(dst,'wt',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(kept[0]));writer.writeheader();writer.writerows(kept)
   result['arms'][arm][group]={'exit_code':int((root/'exit-code.txt').read_text()),'kernels':summary,'roi_archive':dst.name,'raw_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'replay_identity':replay['identity'],'mean_active_experts':statistics.mean(v['active_experts'] for v in replay['sequence']),'sequence_sha256':hashlib.sha256(json.dumps(replay['sequence'],sort_keys=True).encode()).hexdigest()}
 assert len(sources)==1,sources
 result['library_source']=next(iter(sources));(a.output/'hardware.json').write_text(json.dumps(result,indent=2))
 for arm,groups in result['arms'].items():
  for n in EXPECTED[arm]:
   line={'arm':arm,'kernel':n}
   for g,k,as_name in [('memory','TCC_EA0_RDREQ_DRAM_32B_sum','dram_read_bytes'),('scheduling','MeanOccupancyPerCU','waves_per_cu'),('compute','SQ_INSTS_VMEM','vmem_insts'),('compute','SQ_INSTS_VALU','valu_insts'),('trace','trace_duration_us','trace_us')]:
    if g in groups:
     v=groups[g]['kernels'][n]['values'][k]['mean'];line[as_name]=v*32 if g=='memory' else v
   print(json.dumps(line))
if __name__=='__main__':main()
