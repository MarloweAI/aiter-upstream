"""Adversarial supplied-route and changing-input checks for wave route merge."""
import argparse,json,os
from pathlib import Path
import torch
from marlowe_kernels import MoEConfig,MoEWeights,create_moe
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedConfig,CoalescedProgram
from marlowe_kernels._kernels.amd.glm52_moe.safe_fixed_program import SafeFixedProgram,SafeFixedConfig
from benchmarks.moe_replay.reference import compare,expert_reference
from benchmarks.moe_replay.persistent_fp4.provenance import validate_source


def duplicate_slot_reference(weights,x,ids,rw,fused):
    """The established reference formula with duplicate-row scatter addition.

    expert_reference assumes each token selects an expert once: its indexed
    assignment overwrites repeated rows. This stress-only variant handles the
    deliberately repeated supplied expert slots using FP32 index_add_.
    """
    from benchmarks.moe_replay.reference import quantize_mxfp4,dequant_weight,bf16_atomic_operand_reference
    p={}
    for key in ('w1','w2'):
        t=weights[key];e,n,width=t.shape
        p[key]=t.view(torch.uint8).view(e,n//16,width//32,2,16,16).permute(0,1,4,2,3,5).contiguous().view(t.shape)
        s=weights[key+'_scale'];m,sn=e*n,s.shape[-1]
        p[key+'_scale']=s.view(torch.uint8).view(m//32,sn//8,4,16,2,2).permute(0,5,3,1,4,2).contiguous().view(e,n,sn)
    qx,_=quantize_mxfp4(x.float(),scale_rounding='hip_round_up')
    out=torch.zeros_like(x,dtype=torch.float32)
    for expert in range(257):
        rows,choices=torch.where(ids==expert)
        if not len(rows):continue
        w1=dequant_weight(p['w1'][expert],p['w1_scale'][expert],format='mxfp4')
        gate,up=(qx[rows]@w1.T).chunk(2,-1)
        mid=gate*torch.sigmoid(gate)*up
        if not fused:mid=mid.bfloat16()
        mid,_=quantize_mxfp4(mid,scale_rounding='flydsl_fused_0x400000' if fused else 'hip_round_up')
        w2=dequant_weight(p['w2'][expert],p['w2_scale'][expert],format='mxfp4')
        out.index_add_(0,rows,bf16_atomic_operand_reference((mid@w2.T)*rw[rows,choices,None]))
    return out.bfloat16()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--batch',type=int,default=4)
    ap.add_argument('--config',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--layer-id',type=int);ap.add_argument('--expert-id',type=int,default=17)
    a=ap.parse_args();assert not a.output.exists()
    from marlowe_kernels._runtime import source_digest
    assert source_digest()=='c58f8f7cfffbfe57aaf508ba600e097b3a10bae52b2e445febba9c30a649e599'
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_grad_enabled(False);torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False
    cap=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    meta=json.loads((cap/f'b{a.batch}-s355052/capture.json').read_text())
    lid=a.layer_id if a.layer_id is not None else meta['layers'][0]
    layer_index=meta['layers'].index(lid)
    assert 0<=a.expert_id<256
    payload=torch.load(cap/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
    data=torch.load(cap/f'b{a.batch}-s355052/tensors.pt',map_location='cuda',weights_only=True)
    owner=create_moe(MoEConfig(),MoEWeights(*(payload[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
    entry=json.loads(a.config.read_text());entry=entry.get(str(a.batch),entry);cfg=entry.get('config',entry)
    cls,cc={'safe_fixed':(SafeFixedProgram,SafeFixedConfig),'coalesced':(CoalescedProgram,CoalescedConfig)}[entry.get('family','coalesced')]
    program=cls(owner,a.batch,cc(**cfg))
    x=data['input'][0,layer_index].clone();logits=data['logits'][0,layer_index].bfloat16().contiguous();bias=payload['bias'].bfloat16()
    ids=torch.empty((a.batch,8),device='cuda',dtype=torch.int32)
    weights=torch.empty((a.batch,8),device='cuda',dtype=torch.float32)
    supplied=[]
    for name,expert_values,routing_values,scale in [
        ('all_same_expert',torch.full_like(ids,a.expert_id),torch.full_like(weights,2.5/8),1.),
        ('identical_top8',torch.arange(8,device='cuda',dtype=torch.int32).expand_as(ids).clone(),torch.full_like(weights,2.5/8),1.),
        ('all_zero_weights',torch.full_like(ids,251),torch.zeros_like(weights),1.),
        ('all_zero_inputs',torch.full_like(ids,a.expert_id),torch.full_like(weights,2.5/8),0.),
        ('changed_inputs_routes',torch.arange(a.batch*8,device='cuda',dtype=torch.int32).remainder(256).reshape_as(ids),torch.linspace(.1,.5,a.batch*8,device='cuda').reshape_as(weights),-.75),
    ]:supplied.append((name,expert_values,routing_values,data['input'][0,layer_index]*scale))
    ids.copy_(supplied[0][1]);weights.copy_(supplied[0][2])
    call=lambda:program.run(x,logits,bias,supplied_ids=ids,supplied_weights=weights)
    for _ in range(3):call()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):out=call()
    checks=[]
    for repeat in range(2):
        for name,ii,ww,xx in supplied:
            assert int(ii.min())>=0 and int(ii.max())<256
            ids.copy_(ii);weights.copy_(ww);x.copy_(xx)
            eager=call().clone();i9=program.p['ids'].clone();w9=program.p['weights'].clone()
            ref=(duplicate_slot_reference if name=='all_same_expert' else expert_reference)(payload,x,i9,w9,program.fp32_middle)
            graph.replay();captured=out.clone();torch.cuda.synchronize()
            row=dict(name=name,repeat=repeat,reference='duplicate_slot_reference' if name=='all_same_expert' else 'expert_reference',
                eager=compare(eager,ref),graph=compare(captured,ref),
                routes_exact=bool(torch.equal(program.p['ids'][:,:8],ids)),
                weights_exact=bool(torch.equal(program.p['weights'][:,:8],weights)))
            row['passed']=row['eager']['passed'] and row['graph']['passed'] and row['routes_exact'] and row['weights_exact']
            if hasattr(program,'state_check'):
                row['state']=program.state_check();row['passed']=row['passed'] and row['state']['passed']
            checks.append(row)
    # Capture all three mode transitions on the same persistent workspace.
    # Internal routes must be freshly recomputed rather than retaining supplied IDs.
    program.run(x,logits,bias);call();program.run(x,logits,bias)
    torch.cuda.synchronize();mixed_graph=torch.cuda.CUDAGraph();snapshots=[]
    with torch.cuda.graph(mixed_graph):
        for supplied_mode in (False,True,False):
            value=call() if supplied_mode else program.run(x,logits,bias)
            snapshots.append((value.clone(),program.p['ids'].clone(),program.p['weights'].clone()))
    mixed_checks=[]
    for repetition in range(2):
        slot=repetition%len(meta['steps'])
        x.copy_(data['input'][slot,layer_index]*(1. if repetition==0 else -.75))
        logits.copy_(data['logits'][slot,layer_index].bfloat16())
        ids.fill_(a.expert_id);weights.fill_(2.5/8)
        mixed_graph.replay();torch.cuda.synchronize()
        for index,(value,ii,ww) in enumerate(snapshots):
            ref=(duplicate_slot_reference if index==1 else expert_reference)(payload,x,ii,ww,program.fp32_middle)
            check=compare(value,ref)
            exact=bool(torch.equal(ii[:,:8],ids)) if index==1 else bool(torch.equal(ii,data['ids'][slot,layer_index]))
            weight_error=float((ww[:,:8]-weights).abs().max()) if index==1 else float((ww-data['routing_weights'][slot,layer_index]).abs().max())
            mixed_checks.append(dict(repetition=repetition,index=index,mode='supplied' if index==1 else 'internal',
                check=check,routes_exact=exact,weight_error=weight_error,passed=check['passed'] and exact and weight_error<=2e-6))
        if hasattr(program,'state_check'):mixed_checks.append(dict(kind='state',**program.state_check()))
    result=dict(batch=a.batch,layer=lid,expert_id=a.expert_id,config=cfg,source_paths=validate_source(),checks=checks,
        mixed_checks=mixed_checks,passed=all(r['passed'] for r in checks+mixed_checks))
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)
    assert result['passed']

if __name__=='__main__':main()
