"""Compile supported legacy tile shapes and retain numerical/assembly evidence."""
import argparse,dataclasses,json,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--capture',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--expected-source',required=True);a=p.parse_args();assert not a.output.exists();a.output.mkdir(parents=True)
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._runtime import source_digest,cache_identity
from marlowe_kernels._kernels.amd.glm52_moe.selected_program import SELECTED_CONFIGS
from marlowe_kernels._kernels.amd.glm52_moe.prefetch_program import PrefetchProgram,PrefetchConfig
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedProgram,CoalescedConfig
from benchmarks.moe_replay.reference import expert_reference,compare
from benchmarks.moe_replay.protocol import load_metadata
assert source_digest()==a.expected_source and os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
torch.set_num_threads(4);torch.set_grad_enabled(False)
w=torch.load(a.capture/'weights/layer-3.pt',map_location='cuda',weights_only=True);owner=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale'))));rows=[]
for b,family in ((2,'prefetch'),(16,'coalesced')):
 root=a.capture/f'b{b}-s355052';meta=load_metadata(root);data=torch.load(root/'tensors.pt',map_location='cuda',weights_only=True);j=meta['layers'].index(3);x=data['input'][0,j,:b].contiguous();logits=data['logits'][0,j,:b].bfloat16().contiguous();bias=w['bias'].bfloat16().contiguous()
 config=SELECTED_CONFIGS[b]['config'];cls,cfg=(PrefetchProgram,PrefetchConfig) if family=='prefetch' else (CoalescedProgram,CoalescedConfig)
 shapes=[(64,4),(64,2),(64,1),(128,1)] if family=='prefetch' else [(64,1),(64,2),(128,1),(128,2),(128,4),(256,2),(256,4),(256,8)]
 configs=[dict(config,down_n=n,down_waves=nw) for n,nw in shapes]
 if family=='coalesced':configs += [dict(config,gate_n=128,gate_waves=1),dict(config,gate_n=256,gate_waves=1),dict(config,gate_n=128,gate_waves=2)]
 for config in configs:
  program=cls(owner,b,cfg(**config));actual=program.run(x,logits,bias).clone();ids,rw=(program.p[k].clone() for k in ('ids','weights'));ref=expert_reference(w,x,ids,rw,program.fp32_middle)
  checks=[compare(actual,ref)]
  for _ in range(2):checks.append(compare(program.run(x,logits,bias),ref))
  row=dict(batch=b,family=family,config=config,checks=checks,passed=all(c['passed'] for c in checks))
  if hasattr(program,'state'):
   s=program.state.cpu();row['state_clean']=int(s[-1])==0 and not bool(s[4:-1].any());row['passed'] &= row['state_clean']
  rows.append(row);print(json.dumps(row),flush=True)
  if not row['passed']:torch.save(dict(input=x.cpu(),ids=ids.cpu(),weights=rw.cpu(),actual=actual.cpu(),reference=ref.cpu()),a.output/f'failure-{len(rows)}.pt')
  (a.output/'result.json').write_text(json.dumps(dict(source=source_digest(),namespace=cache_identity(),job=os.environ['SLURM_JOB_ID'],rows=rows),indent=2))
assert all(r['passed'] for r in rows)
