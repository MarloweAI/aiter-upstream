"""Validate the opt-in public factory against unchanged independent references.

Run this driver outside a git-archive source tree. It never mutates selectors,
serving code, numerical tolerances, or the source being validated.
"""
import argparse,dataclasses,gzip,hashlib,io,json,os,sys,time,traceback
from pathlib import Path


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return h.hexdigest()


def save_json(path,value):
 path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2));tmp.replace(path)


def main():
 p=argparse.ArgumentParser()
 p.add_argument('--capture',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--source-root',type=Path,required=True);p.add_argument('--source-commit',required=True)
 p.add_argument('--expected-library-source',required=True);p.add_argument('--archive',type=Path,required=True);p.add_argument('--archive-sha256',required=True)
 p.add_argument('--batches',type=int,nargs='+',default=[1,2,4,8]);p.add_argument('--layers',type=int,nargs='+',default=[3,40,77])
 p.add_argument('--steps',type=int,nargs='+',default=[0,1,7,15]);p.add_argument('--graph-repeats',type=int,default=7)
 p.add_argument('--include-b1-layer16',action=argparse.BooleanOptionalAction,default=True)
 p.add_argument('--repeat-expert255',action=argparse.BooleanOptionalAction,default=True)
 a=p.parse_args();assert not a.output.exists(),a.output;a.output.mkdir(parents=True)
 import torch
 import marlowe_kernels
 from marlowe_kernels import MoEConfig,MoEWeights,create_moe,UnsupportedConfiguration
 from marlowe_kernels._runtime import source_digest
 from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS,BANDWIDTH_REVISION
 from marlowe_kernels._kernels.amd.glm52_moe.selected_program import SELECTED_CONFIGS
 from benchmarks.moe_replay import reference
 from benchmarks.moe_replay.reference import expert_reference,compare,TOLERANCES
 from benchmarks.moe_replay.protocol import load_metadata
 from benchmarks.moe_replay.bw75 import route_stress
 from benchmarks.moe_replay.bw75.route_stress import duplicate_slot_reference
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 torch.set_num_threads(4);torch.set_grad_enabled(False)
 frozen=a.source_root.resolve()
 for module in [marlowe_kernels,reference,route_stress]:assert Path(module.__file__).resolve().is_relative_to(frozen),(module.__name__,module.__file__)
 assert source_digest()==a.expected_library_source,(source_digest(),a.expected_library_source)
 assert sha(a.archive)==a.archive_sha256
 assert TOLERANCES==dict(rtol=.02,atol=.02,nrmse=.01)
 identity=dict(source_commit=a.source_commit,library_source=source_digest(),git_archive_sha256=a.archive_sha256,
  frozen_root=str(frozen),library_import=str(Path(marlowe_kernels.__file__).resolve()),reference_import=str(Path(reference.__file__).resolve()),
  reference_sha256=sha(reference.__file__),duplicate_reference_sha256=sha(route_stress.__file__),driver_sha256=sha(__file__),job=os.environ['SLURM_JOB_ID'],
  gpu=str(torch.cuda.get_device_properties(0)),torch=torch.__version__,hip=torch.version.hip,selection_revision=BANDWIDTH_REVISION,
  selectors={str(b):BANDWIDTH_CONFIGS.get(b,SELECTED_CONFIGS[b]) for b in a.batches},tolerances=TOLERANCES)
 save_json(a.output/'identity.json',identity)
 owners={};controls={};peers={};weights={};biases={};checks=[];instance_checks=[];alias_checks=[];guards=[];artifacts=[];failure_context={}
 lids=set(a.layers)|({16} if a.include_b1_layer16 and 1 in a.batches else set())
 weight_hashes={}
 for lid in sorted(lids):
  path=a.capture/'weights'/f'layer-{lid}.pt';weight_hashes[str(lid)]=sha(path)
  payload=torch.load(path,map_location='cuda',weights_only=True);w={k:payload[k] for k in ('w1','w2','w1_scale','w2_scale')}
  weights[lid]=w;biases[lid]=payload['bias'].bfloat16().contiguous()
  packed=MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale')))
  owners[lid]=create_moe(MoEConfig(),packed,implementation='port_ew_bw')
  controls[lid]=create_moe(MoEConfig(),packed)
  peers[lid]=create_moe(MoEConfig(),packed,implementation='port_ew_bw')
  assert owners[lid].implementation==peers[lid].implementation=='port_ew_bw'
  assert controls[lid].implementation=='port_ew','public default changed'
 identity['weight_file_sha256']=weight_hashes;identity['capture_sha256']={}
 def state_check(owner,b):
  program=owner._programs[b]
  if callable(getattr(program,'state_check',None)):
   return bool(program.state_check()['passed'])
  if getattr(getattr(program,'cc',None),'dispatch',False):
   state=program.state.cpu();return int(state[-1])==0 and not bool(state[4:-1].any())
  return True
 def record_failure():
  payload={k:(v.detach().cpu() if isinstance(v,torch.Tensor) else v) for k,v in failure_context.items()}
  torch.save(payload,a.output/'failure.pt')
  save_json(a.output/'failure.json',dict(context={k:v for k,v in payload.items() if not isinstance(v,torch.Tensor)},traceback=traceback.format_exc(),identity=identity))
 try:
  for b in a.batches:
   capture=a.capture/f'b{b}-s355052';identity['capture_sha256'][str(b)]=sha(capture/'tensors.pt')
   meta=load_metadata(capture);data=torch.load(capture/'tensors.pt',map_location='cuda',weights_only=True)
   batch_outputs=[];batch_layers=a.layers+([16] if b==1 and a.include_b1_layer16 and 16 not in a.layers else [])
   for lid in batch_layers:
    owner,control,peer=owners[lid],controls[lid],peers[lid];j=meta['layers'].index(lid)
    for handle in (owner,peer):
     handle.warmup((b,),routing='internal');handle.warmup((b,),routing='supplied')
    control.warmup((b,),routing='internal')
    program=owner._programs[b];expected=BANDWIDTH_CONFIGS.get(b,SELECTED_CONFIGS[b]);cfg=expected['config']
    matching=[dataclasses.asdict(v) for v in vars(program).values() if dataclasses.is_dataclass(v) and all(hasattr(v,k) and getattr(v,k)==value for k,value in cfg.items())]
    assert matching,(b,type(program).__name__,cfg)
    assert program.fp32_middle==(b in (1,4,8,32))
    assert Path(sys.modules[type(program).__module__].__file__).resolve().is_relative_to(frozen)
    for mode in ('internal','supplied'):
     x=torch.empty((b,6144),device='cuda',dtype=torch.bfloat16);logits=torch.empty((b,256),device='cuda',dtype=torch.bfloat16)
     bias=biases[lid].clone();ids=torch.empty((b,8),device='cuda',dtype=torch.int32);rw=torch.empty((b,8),device='cuda',dtype=torch.float32);out=torch.empty_like(x)
     def update(slot):
      x.copy_(data['input'][slot,j,:b]);logits.copy_(data['logits'][slot,j,:b].bfloat16());bias.copy_(biases[lid])
      ids.copy_(data['ids'][slot,j,:b,:8]);rw.copy_(data['routing_weights'][slot,j,:b,:8])
     def call(custom):
      if mode=='internal':return owner(x,logits,bias,out=out if custom else None)
      return owner.forward_routed(x,ids,rw,out=out if custom else None)
     def expected_routes():
      if mode=='internal':
       control(x,logits,bias);ei,ew=control.routing(b);return ei.clone(),ew.clone()
      return torch.cat((ids,torch.full((b,1),256,device='cuda',dtype=torch.int32)),1),torch.cat((rw,torch.ones((b,1),device='cuda',dtype=torch.float32)),1)
     def routes_equal(ei,ew):
      ai,aw=owner.routing(b);return bool(torch.equal(ai,ei) and torch.equal(aw,ew))
     update(a.steps[0]);default_buffer=call(False);call(True);torch.cuda.synchronize()
     custom_graph=torch.cuda.CUDAGraph()
     with torch.cuda.graph(custom_graph):graph_out=call(True)
     default_graph=torch.cuda.CUDAGraph()
     with torch.cuda.graph(default_graph):graph_default=call(False)
     assert graph_out.data_ptr()==out.data_ptr() and graph_default.data_ptr()==default_buffer.data_ptr()
     assert graph_out.data_ptr()!=graph_default.data_ptr()
     tasks=[(slot,False) for slot in a.steps]
     if a.repeat_expert255 and lid==77 and mode=='supplied':tasks += [(slot,True) for slot in a.steps]
     for slot,repeated in tasks:
      step=meta['steps'][slot];assert step['actual_token_count']==step['scheduled_rows']==step['graph_rows']==b
      update(slot)
      if repeated:ids.fill_(255);rw.fill_(2.5/8)
      ei,ew=expected_routes()
      oracle=duplicate_slot_reference if repeated else expert_reference
      ref=oracle(weights[lid],x,ei,ew,program.fp32_middle)
      failure_context=dict(batch=b,layer=lid,step=slot,routing=mode,repeated_expert255=repeated,input=x,logits=logits,bias=bias,expected_ids=ei,expected_weights=ew,reference=ref)
      out.fill_(float('nan'));eager=call(True).clone();assert routes_equal(ei,ew)
      default_buffer.fill_(float('nan'));default_eager=call(False).clone();assert routes_equal(ei,ew)
      for _ in range(a.graph_repeats):out.fill_(float('nan'));custom_graph.replay()
      torch.cuda.synchronize();graph_value=out.clone();custom_routes=routes_equal(ei,ew)
      for _ in range(a.graph_repeats):default_buffer.fill_(float('nan'));default_graph.replay()
      torch.cuda.synchronize();default_value=default_buffer.clone();default_routes=routes_equal(ei,ew)
      row=dict(batch=b,layer=lid,step=slot,routing=mode,repeated_expert255=repeated,reference='duplicate_slot_reference' if repeated else 'expert_reference',program=type(program).__name__,selection=expected,
       eager=compare(eager,ref),default_eager=compare(default_eager,ref),custom_graph=compare(graph_value,ref),default_graph=compare(default_value,ref),
       exact_routes=True,custom_graph_routes=custom_routes,default_graph_routes=default_routes,state_clean=state_check(owner,b),output_override=True,default_storage_reused=True)
      failure_context.update(eager=eager,default_eager=default_eager,custom_graph=graph_value,default_graph=default_value)
      saved=dict(batch=b,layer=lid,step=slot,routing=mode,repeated_expert255=repeated,input=x.cpu(),logits=logits.cpu(),bias=bias.cpu(),ids=ei.cpu(),routing_weights=ew.cpu(),
       output_names=['eager','default_eager','custom_graph','default_graph','reference'],outputs=torch.stack([eager,default_eager,graph_value,default_value,ref],-1).cpu())
      # Zero/tie inputs change all data in the same captured buffers.
      x.zero_();logits.zero_();bias.zero_()
      if mode=='supplied':ids.copy_(torch.arange(8,device='cuda',dtype=torch.int32).expand(b,8));rw.fill_(2.5/8)
      zi,zw=expected_routes()
      out.fill_(float('nan'));custom_graph.replay();default_buffer.fill_(float('nan'));default_graph.replay();torch.cuda.synchronize()
      row.update(zero_custom_cleared=bool((out==0).all()),zero_default_cleared=bool((default_buffer==0).all()),zero_routes=routes_equal(zi,zw),zero_state_clean=state_check(owner,b))
      saved.update(zero_custom=out.cpu(),zero_default=default_buffer.cpu(),zero_ids=zi.cpu(),zero_weights=zw.cpu())
      row['passed']=all(v['passed'] for k,v in row.items() if k in ('eager','default_eager','custom_graph','default_graph')) and all(row[k] for k in ('exact_routes','custom_graph_routes','default_graph_routes','state_clean','zero_custom_cleared','zero_default_cleared','zero_routes','zero_state_clean'))
      checks.append(row);batch_outputs.append(saved);save_json(a.output/'checks.json',checks);assert row['passed'],row
     # One layer per batch checks separate scratch, interleaving, and streams.
     if lid==a.layers[0]:
      update(a.steps[0]);ei,ew=expected_routes();ref_a=expert_reference(weights[lid],x,ei,ew,program.fp32_middle)
      xa=x.clone();la=logits.clone();ba=bias.clone();ia=ids.clone();wa=rw.clone()
      xb=data['input'][a.steps[1],j,:b].contiguous().clone();lb=data['logits'][a.steps[1],j,:b].bfloat16().contiguous();ib=data['ids'][a.steps[1],j,:b,:8].contiguous();wb=data['routing_weights'][a.steps[1],j,:b,:8].contiguous()
      ya=call(False);saved_a=ya.clone();saved_i,saved_w=(t.clone() for t in owner.routing(b))
      if mode=='internal':yb=peer(xb,lb,ba)
      else:yb=peer.forward_routed(xb,ib,wb)
      if mode=='internal':
       control(xb,lb,ba);pi,pw=(t.clone() for t in control.routing(b))
      else:
       pi=torch.cat((ib,torch.full((b,1),256,device='cuda',dtype=torch.int32)),1)
       pw=torch.cat((wb,torch.ones((b,1),device='cuda',dtype=torch.float32)),1)
      assert torch.equal(peer.routing(b)[0],pi) and torch.equal(peer.routing(b)[1],pw)
      ref_b=expert_reference(weights[lid],xb,pi,pw,program.fp32_middle)
      failure_context=dict(kind='separate_instances',batch=b,layer=lid,routing=mode,input_a=xa,input_b=xb,reference_a=ref_a,reference_b=ref_b)
      assert ya.data_ptr()!=yb.data_ptr() and owner.routing(b)[0].data_ptr()!=peer.routing(b)[0].data_ptr()
      preserved=bool(torch.equal(ya,saved_a) and torch.equal(owner.routing(b)[0],saved_i) and torch.equal(owner.routing(b)[1],saved_w))
      out_a=torch.full_like(xa,float('nan'));out_b=torch.full_like(xb,float('nan'))
      sa,sb=torch.cuda.Stream(),torch.cuda.Stream();sa.wait_stream(torch.cuda.current_stream());sb.wait_stream(torch.cuda.current_stream())
      with torch.cuda.stream(sa):
       if mode=='internal':owner(xa,la,ba,out=out_a)
       else:owner.forward_routed(xa,ia,wa,out=out_a)
      with torch.cuda.stream(sb):
       if mode=='internal':peer(xb,lb,ba,out=out_b)
       else:peer.forward_routed(xb,ib,wb,out=out_b)
      torch.cuda.synchronize();ai,aw=owner.routing(b);bi,bw=peer.routing(b)
      failure_context.update(output_a=out_a,output_b=out_b)
      entry=dict(batch=b,routing=mode,interleaving_preserves_first=preserved,distinct_storage=True,
       stream_a=compare(out_a,ref_a),stream_b=compare(out_b,ref_b),stream_a_routes=bool(torch.equal(ai,ei) and torch.equal(aw,ew)),stream_b_routes=bool(torch.equal(bi,pi) and torch.equal(bw,pw)))
      entry['passed']=preserved and entry['stream_a']['passed'] and entry['stream_b']['passed'] and entry['stream_a_routes'] and entry['stream_b_routes']
      instance_checks.append(entry);save_json(a.output/'instances.json',instance_checks);assert entry['passed'],entry
      batch_outputs.append(dict(kind='separate_instances',batch=b,routing=mode,output_names=['stream_a','reference_a','stream_b','reference_b'],outputs=torch.stack([out_a,ref_a,out_b,ref_b],-1).cpu()))
      # The implicit reusable output must obey the same alias contract as
      # explicit out. A distinct output still permits borrowed x as input.
      update(a.steps[0]);ei,ew=expected_routes();borrowed=call(False);borrowed_value=borrowed.clone()
      def reject_alias(label,fn):
       before_value=borrowed.view(torch.uint8).clone()
       try:fn()
       except UnsupportedConfiguration as error:
        assert 'overlap' in str(error).lower(),(label,str(error))
        unchanged=bool(torch.equal(borrowed.view(torch.uint8),before_value));assert unchanged
        return dict(case=label,rejected=True,input_unchanged=True,error=str(error))
       raise AssertionError(('alias was accepted',b,mode,label))
      if mode=='internal':
       reject=lambda **kw:owner(kw.get('x',x),kw.get('logits',logits),kw.get('bias',bias),out=kw.get('out'))
      else:
       reject=lambda **kw:owner.forward_routed(kw.get('x',x),kw.get('ids',ids),kw.get('weights',rw),out=kw.get('out'))
      alias_row=dict(batch=b,routing=mode,rejections=[])
      alias_row['rejections'].append(reject_alias('borrowed_x_default_out',lambda:reject(x=borrowed)))
      alias_row['rejections'].append(reject_alias('borrowed_x_explicit_same_out',lambda:reject(x=borrowed,out=borrowed)))
      distinct=torch.full_like(borrowed,float('nan'))
      ref_borrowed=expert_reference(weights[lid],borrowed_value,ei,ew,program.fp32_middle)
      allowed=reject(x=borrowed,out=distinct)
      alias_row['distinct_output']=compare(allowed,ref_borrowed)
      alias_row['distinct_output_pointer']=allowed.data_ptr()==distinct.data_ptr()
      alias_row['borrowed_input_preserved']=bool(torch.equal(borrowed.view(torch.uint8),borrowed_value.view(torch.uint8)))
      alias_row['distinct_output_routes']=routes_equal(ei,ew)
      if mode=='internal':
       alias_logits=borrowed.flatten()[:b*256].view(b,256);alias_logits.copy_(logits)
       alias_row['rejections'].append(reject_alias('borrowed_logits_default_out',lambda:reject(logits=alias_logits)))
       alias_bias=borrowed.flatten()[:256];alias_bias.copy_(bias)
       alias_row['rejections'].append(reject_alias('borrowed_bias_default_out',lambda:reject(bias=alias_bias)))
      else:
       alias_ids=borrowed.view(torch.int32).flatten()[:b*8].view(b,8);alias_ids.copy_(ids)
       alias_row['rejections'].append(reject_alias('borrowed_ids_default_out',lambda:reject(ids=alias_ids)))
       alias_weights=borrowed.view(torch.float32).flatten()[:b*8].view(b,8);alias_weights.copy_(rw)
       alias_row['rejections'].append(reject_alias('borrowed_weights_default_out',lambda:reject(weights=alias_weights)))
      alias_row['passed']=alias_row['distinct_output']['passed'] and all(alias_row[k] for k in ('distinct_output_pointer','borrowed_input_preserved','distinct_output_routes'))
      alias_checks.append(alias_row);save_json(a.output/'aliases.json',alias_checks);assert alias_row['passed'],alias_row
      batch_outputs.append(dict(kind='borrowed_input_distinct_output',batch=b,routing=mode,input=borrowed_value.cpu(),output_names=['actual','reference'],outputs=torch.stack([allowed,ref_borrowed],-1).cpu()))
     print(json.dumps(dict(batch=b,layer=lid,routing=mode,passed=True)),flush=True)
     del custom_graph,default_graph
   # Preserve actual tensors, not only comparison summaries.
   artifact=a.output/f'b{b}-outputs.pt.gz'
   with gzip.open(artifact,'wb',compresslevel=6) as f:torch.save(batch_outputs,f)
   artifacts.append(dict(batch=b,path=artifact.name,sha256=sha(artifact),records=len(batch_outputs),bytes=artifact.stat().st_size))
   del data,batch_outputs;torch.cuda.empty_cache()
  for lid,owner in owners.items():
   before=(owner.prepared_batches,set(owner._prepared_modes))
   for routing in ('internal','supplied'):
    for invalid in (0,3,128,True):
     try:owner.warmup((invalid,),routing=routing)
     except UnsupportedConfiguration as error:guards.append(dict(layer=lid,batch=invalid,routing=routing,passed=True,error=str(error)))
     else:raise AssertionError(('unsupported batch accepted',invalid,routing))
   assert before==(owner.prepared_batches,set(owner._prepared_modes))
  save_json(a.output/'guards.json',guards);save_json(a.output/'identity.json',identity)
  summary=dict(passed=True,identity=identity,batches=a.batches,layers=a.layers,extra_b1_layer16=a.include_b1_layer16,steps=a.steps,
   cases=len(checks),repeated_expert255_cases=sum(bool(v.get('repeated_expert255')) for v in checks),graph_repeats=a.graph_repeats,instance_checks=len(instance_checks),alias_checks=len(alias_checks),alias_rejections=sum(len(v['rejections']) for v in alias_checks),guard_checks=len(guards),output_artifacts=artifacts,
   max_nrmse={key:max(v[key]['nrmse'] for v in checks) for key in ('eager','default_eager','custom_graph','default_graph')},
   coverage='Opt-in public factory, unchanged default, selected configuration, exact internal/supplied routes and weights, unchanged independent references, eager/custom/default outputs, repeated/changing graphs, NaN clearing, zero/tie inputs, layer77 repeated supplied expert255, distinct/interleaved/concurrent instances, implicit/explicit output alias guards and distinct-output borrowed-input correctness, and unsupported-batch guards. No serving or timing claim.')
  save_json(a.output/'summary.json',summary);print(json.dumps({k:v for k,v in summary.items() if k not in ('identity','output_artifacts')}),flush=True)
 except BaseException:
  if 'batch_outputs' in locals() and batch_outputs:
   with gzip.open(a.output/f'b{b}-partial-outputs.pt.gz','wb') as f:torch.save(batch_outputs,f)
  record_failure();raise

if __name__=='__main__':main()
