import csv,gzip,hashlib,json,re,shutil
from pathlib import Path
root=Path('/workspace/home/mishas/results/marlowe-kernels/bw75-20260920/b1/public-api-774541b7/counters60')
out=root/'bundle';out.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for data in iter(lambda:f.read(4*1024*1024),b''):h.update(data)
 return h.hexdigest()
def csv_rows(p):
 with p.open() as f:return list(csv.DictReader(f))
manifest=[];pairs=[]
for b in (1,2,4):
 arms={}
 for arm in ('baseline','candidate'):
  src=root/f'b{b}'/arm;dst=out/f'b{b}'/arm;dst.mkdir(parents=True,exist_ok=True)
  summary=json.loads((src/'summary.json').read_text());parity=json.loads((src/'public-dispatch-parity.json').read_text());assert summary['validation']['passed'] and parity['passed']
  for name in ('summary.json','per-case.json.gz','public-dispatch-parity.json'):shutil.copy2(src/name,dst/name)
  records=[]
  for group in ('memory','scheduling','atomics','compute'):
   folder=src/group;target=dst/group;target.mkdir(exist_ok=True)
   replay=json.loads((folder/'replay.json').read_text());assert len(replay['checks'])==60 and all(c['passed'] for c in replay['checks']);records.append(replay)
   with gzip.open(target/'replay.json.gz','wb') as f:f.write((folder/'replay.json').read_bytes())
   marks=csv_rows(folder/'counters_marker_api_trace.csv');bounds=[(int(m['Start_Timestamp']),int(m['End_Timestamp'])) for m in marks if re.fullmatch(r'bw75_b\d+_r\d+',m['Function'])];assert len(bounds)==3
   calls=[r for r in csv_rows(folder/'counters_kernel_trace.csv') if 'mk_' in r['Kernel_Name'] and any(lo<=int(r['Start_Timestamp'])<=int(r['End_Timestamp'])<=hi for lo,hi in bounds)]
   ids={r['Dispatch_Id'] for r in calls};counter=[r for r in csv_rows(folder/'counters_counter_collection.csv') if r['Dispatch_Id'] in ids];assert {r['Dispatch_Id'] for r in counter}==ids
   for name,rows in [('kernel-roi.csv.gz',calls),('counter-roi.csv.gz',counter)]:
    with gzip.open(target/name,'wt',newline='') as f:
     writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
   shutil.copy2(folder/'counters_marker_api_trace.csv',target/'markers.csv')
   for name in ('exit-code.txt','run.log'):
    p=folder/name
    if name.endswith('.log'):
     with gzip.open(target/(name+'.gz'),'wb') as f:f.write(p.read_bytes())
    else:shutil.copy2(p,target/name)
   for name in ('replay.json','counters_marker_api_trace.csv','counters_kernel_trace.csv','counters_counter_collection.csv','exit-code.txt','run.log'):
    p=folder/name;manifest.append(dict(batch=b,arm=arm,group=group,remote_path=str(p),sha256=sha(p),bytes=p.stat().st_size))
  assert all(r['sequence']==records[0]['sequence'] and r['identity']==records[0]['identity'] and r['config']==records[0]['config'] for r in records)
  arms[arm]=dict(summary=summary,sequence=records[0]['sequence'])
 assert arms['baseline']['sequence']==arms['candidate']['sequence']
 row=dict(batch=b,mean_active_experts=sum(c['active_experts'] for c in arms['baseline']['sequence'])/60,stages={})
 for stage in ('g1','g2'):
  part={}
  for arm in ('baseline','candidate'):
   v=arms[arm]['summary']['stages'][stage];c=v['counters_per_call'];useful=row['mean_active_experts']*(1671168 if stage=='g1' else 835584)
   part[arm]=dict(read_request_MB=v['tcc_hbm_read_request_MB'],useful_weight_MB=useful/1e6,read_amplification=v['tcc_hbm_read_request_MB']*1e6/useful,
    vmem_instructions=c.get('SQ_INSTS_VMEM'),valu_instructions=c.get('SQ_INSTS_VALU'),salu_instructions=c.get('SQ_INSTS_SALU'),waves_per_CU=c.get('MeanOccupancyPerCU'),mfma_fp4_instructions=c.get('SQ_INSTS_VALU_MFMA_F6F4'),mfma_fp16_instructions=c.get('SQ_INSTS_VALU_MFMA_F16'),resources=v['resources'])
  part['vmem_reduction_percent']=100*(1-part['candidate']['vmem_instructions']/part['baseline']['vmem_instructions'])
  row['stages'][stage]=part
 pairs.append(row)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(dict(source_commit='774541b7255c77729b86414cf75537eba996356d',source_digest='19bf60e4bcacf61d4904f8169935cbd4417576746122cae1be5c94ea4d41f2e5',scope='Matched 30 layers × 2 steps × 3 ROIs, fixed captured BF16 logits, final private programs with exact public kernel/order/grid/block parity. All 60 outputs checked against independent reference in every pass. Profiled durations excluded. L2 destination requests may hit Infinity Cache and are not physical HBM traffic.',batches=pairs),indent=2)+'\n')
print(json.dumps(pairs,indent=2))
