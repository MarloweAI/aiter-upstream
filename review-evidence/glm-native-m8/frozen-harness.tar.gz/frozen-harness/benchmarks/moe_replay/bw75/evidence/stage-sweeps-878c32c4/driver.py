"""Effective stage throughput with one outer event pair per ordered sweep.

This deliberately differs from the headline router-through-combine boundary.
Stage isolation changes cache reuse; neither timings nor TB/s are HBM claims.
"""
import argparse,contextlib,dataclasses,hashlib,json,os,statistics
from pathlib import Path


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return h.hexdigest()


def footprint(sequence,bytes_per_expert):
 keys=[set((c['layer'],int(e)) for e in c['experts']) for c in sequence];n=len(keys)
 universe=set().union(*keys);positions={key:[i for i,row in enumerate(keys) if key in row] for key in universe}
 distances=[];gaps=[]
 for key,where in positions.items():
  for i,start in enumerate(where):
   end=where[(i+1)%len(where)]
   if end<=start:end+=n
   between=set().union(*(keys[j%n] for j in range(start+1,end))) if end>start+1 else set()
   between.discard(key);distances.append(len(between)*bytes_per_expert);gaps.append(end-start)
 def summary(v):return dict(min=min(v),median=statistics.median(v),max=max(v),mean=statistics.mean(v))
 per_step={str(step):len(set().union(*(keys[i] for i,c in enumerate(sequence) if c['step']==step)))*bytes_per_expert for step in sorted(set(c['step'] for c in sequence))}
 return dict(unique_weight_objects=len(universe),unique_weight_bytes=len(universe)*bytes_per_expert,
  useful_bytes_per_sweep=sum(map(len,keys))*bytes_per_expert,per_step_unique_weight_bytes=per_step,
  cyclic_reuse_transitions=len(distances),reuse_gap_cases=summary(gaps),intervening_distinct_weight_bytes=summary(distances),
  fraction_reuse_distances_below_256MiB=sum(d<256*1024*1024 for d in distances)/len(distances),
  cache_capacity_reference_bytes=256*1024*1024,
  reuse_distance_definition='Distinct (layer,expert) weight-object bytes in intervening cases between consecutive cyclic uses; excludes endpoint cases and intra-kernel cache-line ordering. This is a logical reuse-distance diagnostic, not a hardware cache-hit measurement.')


@contextlib.contextmanager
def stage_adapter(items,stage):
 """Suppress other launches, then restore every patched callable."""
 from marlowe_kernels._kernels.amd.glm52_moe import inline_program,overlap_consumer,preloaded_prepare,fixed_bins
 changes=[]
 def patch(obj,name,value):
  own=name in vars(obj);old=getattr(obj,name);changes.append((obj,name,old,own));setattr(obj,name,value)
 def noop(*a,**kw):return None
 try:
  families={c['family'] for c in items};assert len(families)==1
  if families=={'inline'}:
   assert all(c['handle']._programs[c['batch']].ic.overlap_weights for c in items)
   patch(overlap_consumer,'overlap_down',noop) if stage=='g1' else patch(inline_program,'inline_gate',noop)
  elif families in ({'pair'},{'safe_fixed'}):
   assert all(c['handle']._programs[c['batch']].c.split_k==1 for c in items)
   if families=={'pair'}:
    assert all(c['handle']._programs[c['batch']].pc.route_preload for c in items)
    patch(preloaded_prepare,'preloaded_phase1',noop)
   else:
    assert all(not c['handle']._programs[c['batch']].sc.ordered_all for c in items)
    patch(fixed_bins,'fixed_prepare',noop)
   for case in items:
    pr=case['handle']._programs[case['batch']];original=pr._stage
    def only(inp,scale,out,first,original=original):
     if first==(stage=='g1'):return original(inp,scale,out,first)
    patch(pr,'_stage',only)
  else:raise ValueError(f'Unreviewed stage boundary: {families}')
  yield
 finally:
  for obj,name,old,own in reversed(changes):
   if own:setattr(obj,name,old)
   else:delattr(obj,name)


def main():
 p=argparse.ArgumentParser();p.add_argument('--capture',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--source-root',type=Path,required=True);p.add_argument('--source-commit',required=True);p.add_argument('--expected-library-source',required=True)
 p.add_argument('--batches',type=int,nargs='+',default=[1,2,4,8,16,32,64]);p.add_argument('--steps',type=int,default=2)
 p.add_argument('--samples',type=int,default=40);p.add_argument('--warmups',type=int,default=10)
 a=p.parse_args();assert not a.output.exists();a.output.mkdir(parents=True)
 import torch
 import marlowe_kernels
 from marlowe_kernels import MoEConfig,MoEWeights,create_moe
 from marlowe_kernels._runtime import source_digest
 from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS
 from benchmarks.moe_replay import reference
 from benchmarks.moe_replay.reference import expert_reference,compare
 from benchmarks.moe_replay.protocol import cases,load_metadata
 from benchmarks.moe_replay.events import Event
 from benchmarks.moe_replay.dispatch_audit import capture_dispatch,graph_dot,ordered_span
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 assert set(a.batches)<={1,2,4,8,16,32,64},'Only reviewed selected batch paths are supported'
 torch.set_num_threads(4);torch.set_grad_enabled(False)
 assert source_digest()==a.expected_library_source
 for module in (marlowe_kernels,reference):assert Path(module.__file__).resolve().is_relative_to(a.source_root.resolve())
 identity=dict(source_commit=a.source_commit,library_source=source_digest(),driver_sha256=sha(__file__),
  frozen_root=str(a.source_root.resolve()),job=os.environ['SLURM_JOB_ID'],gpu=str(torch.cuda.get_device_properties(0)),torch=torch.__version__,hip=torch.version.hip)
 payloads={};weights={};controls={};biases={}
 for b in a.batches:
  root=a.capture/f'b{b}-s355052';meta=load_metadata(root);meta['steps']=meta['steps'][:a.steps];sequence=list(cases(meta))
  assert len(meta['layers'])==30 and len(sequence)==30*a.steps
  data=torch.load(root/'tensors.pt',map_location='cuda',weights_only=True)
  items=[];routes=[];checks=[];references=[];intermediates=[]
  for case in sequence:
   lid,j,slot=case['layer'],case['layer_index'],case['slot'];assert case['actual_token_count']==case['graph_rows']==b
   if lid not in payloads:
    payloads[lid]=torch.load(a.capture/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
    payload=payloads[lid];weights[lid]=MoEWeights(*(payload[k] for k in ('w1','w2','w1_scale','w2_scale')));biases[lid]=payload['bias'].bfloat16().contiguous()
    controls[lid]=create_moe(MoEConfig(),weights[lid])
   control=controls[lid];control.warmup((b,),routing='internal')
   handle=create_moe(MoEConfig(),weights[lid],implementation='port_ew_bw').warmup((b,),routing='internal')
   pr=handle._programs[b]
   if BANDWIDTH_CONFIGS[b]['family']=='safe_fixed':assert callable(pr.state_check) and not pr.sc.ordered_all
   else:assert not getattr(pr.cc,'dispatch',False) and not hasattr(pr,'state')
   x=data['input'][slot,j,:b].contiguous();logits=data['logits'][slot,j,:b].bfloat16().contiguous();bias=biases[lid]
   actual=handle(x,logits,bias).clone();ids,rw=(t.clone() for t in handle.routing(b))
   if hasattr(pr,'state_check'):assert pr.state_check()['passed']
   control(x,logits,bias);ci,cw=control.routing(b);assert torch.equal(ids,ci) and torch.equal(rw,cw)
   expected=expert_reference(payloads[lid],x,ids,rw,pr.fp32_middle);check=compare(actual,expected);assert check['passed'],(b,lid,slot,check)
   experts=sorted(set(ids.flatten().cpu().tolist()));routes.append(dict(layer=lid,step=case['decode_step'],experts=experts))
   checks.append(dict(layer=lid,step=slot,exact_routes=True,full_reference=check));references.append(expected)
   intermediates.append((pr.partial.clone(),pr.mid_scale.clone()) if pr.c.split_k==1 else (pr.partial.clone(),None))
   items.append(dict(handle=handle,batch=b,family=BANDWIDTH_CONFIGS[b]['family'],x=x,logits=logits,bias=bias))
  assert len({c['handle']._programs[b].p['output'].data_ptr() for c in items})==len(items)
  def invoke(case):return case['handle'](case['x'],case['logits'],case['bias'])
  # Exact captured signature equality is checked for every real layer.
  signatures=[]
  for case in items[:30]:
   full,_,g=capture_dispatch(lambda case=case:invoke(case));del g
   names=('inline_gate','overlap_down') if case['family']=='inline' else ('paired_projection','coalesced_down')
   if case['family']=='safe_fixed':assert len(full['nodes'])==3 and 'fixed_prepare' in '\n'.join(full['nodes'][0]['label'])
   record={'full':full,'stages':{}}
   for index,(stage,name) in enumerate(zip(('g1','g2'),names),1):
    with stage_adapter([case],stage):observed,_,g=capture_dispatch(lambda case=case:invoke(case))
    wanted=[full['nodes'][index]] if case['family']=='safe_fixed' else [node for node in full['nodes'] if name in '\n'.join(node['label'])]
    assert len(wanted)==1 and observed['nodes']==wanted,(b,stage,full,observed)
    record['stages'][stage]=observed;del g
   signatures.append(record)
  # One pair of events covers the whole ordered stage sweep.
  graphs={};events={};sweep_dispatch={}
  for stage in ('g1','g2'):
   lo,hi=Event(),Event();g=torch.cuda.CUDAGraph()
   with stage_adapter(items,stage):
    with torch.cuda.graph(g):
     lo.record();before=graph_dot()
     for case in items:invoke(case)
     after=graph_dot();hi.record()
   span=ordered_span(before,after);assert len(span['nodes'])==len(items) and all(n['kind']=='kernel' for n in span['nodes'])
   graphs[stage]=g;events[stage]=(lo,hi);sweep_dispatch[stage]=span
  reset=torch.cuda.CUDAGraph()
  with torch.cuda.graph(reset):
   for case in items:case['handle']._programs[b].p['output'].zero_()
  coupled=torch.cuda.CUDAGraph()
  with torch.cuda.graph(coupled):
   for case in items:invoke(case)
  # Verify staged execution reproduces both intermediates and complete outputs.
  graphs['g1'].replay();torch.cuda.synchronize()
  for i,case in enumerate(items):
   pr=case['handle']._programs[b];assert torch.equal(pr.partial,intermediates[i][0]),(b,i,'G1 partial/mid mismatch')
   if intermediates[i][1] is not None:assert torch.equal(pr.mid_scale,intermediates[i][1]),(b,i,'G1 scales mismatch')
  reset.replay();graphs['g2'].replay();torch.cuda.synchronize()
  staged=[compare(c['handle']._programs[b].p['output'],ref) for c,ref in zip(items,references)];assert all(x['passed'] for x in staged),staged
  def state_checks():
   values=[c['handle']._programs[b].state_check() for c in items if hasattr(c['handle']._programs[b],'state_check')]
   assert all(v['passed'] for v in values),values
   return values
  staged_state=state_checks();timing={};timed_states={}
  for stage in ('g1','g2'):
   for condition in ('isolated_steady','coupled_preconditioned'):
    samples=[]
    for repeat in range(a.warmups+a.samples):
     if condition=='coupled_preconditioned':coupled.replay()
     if stage=='g2':reset.replay()
     graphs[stage].replay();torch.cuda.synchronize()
     if repeat>=a.warmups:samples.append(events[stage][0].elapsed_us(events[stage][1]))
    timed_states[f'{stage}_{condition}']=state_checks()
    median=statistics.median(samples);per_expert=1671168 if stage=='g1' else 835584
    useful=sum(len(c['experts']) for c in routes)*per_expert
    timing[f'{stage}_{condition}']=dict(samples_us=samples,sweep_median_us=median,amortized_case_us=median/len(items),effective_weight_TBs=useful/median/1e6)
  result=dict(batch=b,identity=identity,config=BANDWIDTH_CONFIGS[b],cases=len(items),steps=a.steps,sequence=routes,checks=checks,staged_reference_checks=staged,
   stage_intermediates_bitwise=True,staged_state_checks=staged_state,timed_state_checks=timed_states,layer_signature_checks=signatures,sweep_dispatch=sweep_dispatch,timing=timing,
   footprint={stage:footprint(routes,bytes_) for stage,bytes_ in [('g1',1671168),('g2',835584),('coupled_weights',2506752)]},
   graph_event_pairs_per_sweep=1,output_reset_inside_timing=False,
   scope='Diagnostic effective stage throughput over ordered real-weight cases. Fixed captured logits; routes/intermediates prepared outside isolated regions. Inline G1 includes its fused routing/input packing/output clear; Pair and SafeFixed G1 exclude preparation. SafeFixed consumes prepared current-bank metadata and G2 idempotently clears the next bank. All stages use internal routing; SafeFixed supplied-route ordered combination is outside this diagnostic boundary. G2 includes fused local intermediate reduction where implemented. Cache reuse differs from the coupled workload. These are not physical HBM utilization or replacement headline timings.')
  (a.output/f'b{b}.json').write_text(json.dumps(result,indent=2));print('SWEEP',b,{k:dict(case_us=v['amortized_case_us'],TBs=v['effective_weight_TBs']) for k,v in timing.items()},flush=True)
  del items,references,intermediates,graphs,coupled,reset,data;torch.cuda.empty_cache()

if __name__=='__main__':main()
