"""Paired full-pipeline replay using the public bandwidth and default factories.

Run outside a frozen git archive with its source first on PYTHONPATH. Reuse the
unchanged replay protocol, pinned SGLang/AITER audit, gates and marker boundary.
The two Port-EW arms use public factories without injecting private programs.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--expected-library-source', required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--archive-sha256', required=True)
    args, replay_args = parser.parse_known_args()

    import torch
    import marlowe_kernels
    from marlowe_kernels import create_moe
    from marlowe_kernels._runtime import source_digest
    from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS
    from marlowe_kernels._kernels.amd.glm52_moe.selected_program import SELECTED_CONFIGS
    from benchmarks.moe_replay import run, reference
    from benchmarks.moe_replay.native_fp4 import replay as base
    from benchmarks.moe_replay.sglang_adapter import SGLangLayer
    from benchmarks.moe_replay.dispatch_audit import capture_dispatch, compare_dispatch

    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count() == 1
    frozen = args.source_root.resolve()
    for module in (marlowe_kernels, run, reference, base):
        assert Path(module.__file__).resolve().is_relative_to(frozen)
    assert source_digest() == args.expected_library_source
    assert file_sha(args.archive) == args.archive_sha256
    assert reference.TOLERANCES == dict(rtol=.02, atol=.02, nrmse=.01)

    class PublicLayer(SGLangLayer):
        def __init__(self, *positional, **kwargs):
            super().__init__(*positional, implementation='port_ew', **kwargs)
            self.candidate = create_moe(self.port.config, self.port.weights,
                                        implementation='port_ew_bw')
            assert self.port.implementation == 'port_ew'
            assert self.candidate.implementation == 'port_ew_bw'

        def warmup(self, batch):
            super().warmup(batch)
            for owner in (self.port, self.candidate):
                owner.warmup((batch,), routing='internal')
                owner.warmup((batch,), routing='supplied')

        def from_logits(self, x, logits, variant):
            if variant != 'candidate':
                return super().from_logits(x, logits, variant)
            if logits.dtype == torch.bfloat16:
                out = self.candidate(x, logits, self.bias_by_dtype[logits.dtype])
            else:
                weights, ids = self.routes(x, logits)
                out = self.candidate.forward_routed(x, ids, weights)
            self.last_logits = logits
            self.last_ids, self.last_weights = self.candidate.routing(len(x))
            return out

        def expert_routed(self, x, ids, weights, variant):
            if variant != 'candidate':
                return super().expert_routed(x, ids, weights, variant)
            return self.candidate.forward_routed(x, ids[:, :8].contiguous(),
                                                  weights[:, :8].contiguous())

    def verify(layer, x, batch):
        context = torch.cuda.graph(torch.cuda.CUDAGraph())
        stream = context.capture_stream
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for variant in ('aiter', 'port_ew', 'candidate'):
                for _ in range(2):
                    layer(x, variant)
        torch.cuda.synchronize()
        observed, _, graph = capture_dispatch(lambda: layer(x, 'aiter'))
        native = json.loads((base.AUDIT / f'dispatch-l{layer.layer_id}-b{batch}.json').read_text())
        parity = compare_dispatch(native, observed)
        del graph
        if not parity['passed']:
            path = base.ROOT / f'public-dispatch-failure-l{layer.layer_id}-b{batch}.json'
            path.write_text(json.dumps(parity, indent=2))
            raise RuntimeError(f'Pinned AITER dispatch differs; evidence: {path}')
        signatures = {}
        for variant in ('port_ew', 'candidate'):
            signature, _, graph = capture_dispatch(lambda variant=variant: layer(x, variant))
            signatures[variant] = signature
            del graph
        return dict(layer=layer.layer_id, batch=batch, **parity,
                    public_dispatch=signatures)

    def state_validator(layer, batch):
        results = {}
        for name, owner in (('port_ew', layer.port), ('candidate', layer.candidate)):
            program = owner._programs[batch]
            if callable(getattr(program, 'state_check', None)):
                value = program.state_check()
            elif hasattr(program, 'state'):
                state = program.state.cpu()
                value = dict(passed=int(state[-1]) == 0 and not bool(state[4:-1].any()),
                             error=int(state[-1]), metadata_reset=not bool(state[4:-1].any()))
            else:
                value = dict(passed=True, stateless_dispatch=True)
            results[name] = value
        return dict(layer=layer.layer_id, batch=batch,
                    passed=all(value['passed'] for value in results.values()), arms=results)

    original = run.main

    def paired(argv, **kwargs):
        kwargs.update(port_variants=('port_ew', 'candidate'),
                      native_reference_variants=(), state_validator=state_validator)
        kwargs['runtime_identity'].update(
            public_factories=dict(port_ew='port_ew', candidate='port_ew_bw'),
            candidate_configs=BANDWIDTH_CONFIGS, previous_configs=SELECTED_CONFIGS,
            source_commit=args.source_commit, library_source=source_digest(),
            source_root=str(frozen), archive_sha256=args.archive_sha256,
            public_replay_sha256=file_sha(__file__),
            reference_sha256=file_sha(reference.__file__),
            public_source_paths={name: str(Path(module.__file__).resolve())
                                 for name, module in [('library', marlowe_kernels),
                                                      ('protocol', run), ('reference', reference)]})
        return original(argv, **kwargs)

    old_layer, old_verify, old_argv = base.NativeLayer, base.verify, sys.argv
    try:
        base.NativeLayer, base.verify, run.main = PublicLayer, verify, paired
        sys.argv = [__file__, *replay_args]
        base.main()
    finally:
        base.NativeLayer, base.verify, run.main, sys.argv = old_layer, old_verify, original, old_argv


if __name__ == '__main__':
    main()
