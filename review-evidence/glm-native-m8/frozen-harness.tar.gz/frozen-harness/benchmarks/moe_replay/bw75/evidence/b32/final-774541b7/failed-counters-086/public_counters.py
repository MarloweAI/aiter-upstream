"""Matched hardware-counter ROI using the two actual public factories.

Fixed captured logits; profile durations are never performance results.
"""
import argparse,ctypes,hashlib,json,os,re,subprocess
from pathlib import Path


# Keep the parent GPU workload profiled, but not CPU compiler/inspection tools.
# The unmodified driver failure is preserved in command083/run.log.
_original_popen=subprocess.Popen
class _CompilerChildPopen(_original_popen):
 def __init__(self,*args,**kwargs):
  env=dict(os.environ if kwargs.get('env') is None else kwargs['env'])
  for key in list(env):
   if key.startswith(('ROCP','ROCTRACER','HSA_TOOLS_')):env.pop(key)
  for key in ('LD_PRELOAD','LD_AUDIT'):
   if key in env:
    kept=[x for x in re.split(r'[ :]+',env[key]) if x and 'rocprof' not in x and 'roctracer' not in x]
    if kept:env[key]=':'.join(kept)
    else:env.pop(key)
  kwargs['env']=env
  super().__init__(*args,**kwargs)
subprocess.Popen=_CompilerChildPopen


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return h.hexdigest()


def main():
 p=argparse.ArgumentParser();p.add_argument('--batch',type=int,required=True);p.add_argument('--arm',choices=['baseline','candidate'],required=True);p.add_argument('--routing',choices=['internal','supplied'],default='internal')
 p.add_argument('--steps',type=int,default=2);p.add_argument('--repeats',type=int,default=3);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--source-root',type=Path,required=True);p.add_argument('--expected-library-source',required=True);p.add_argument('--source-commit',required=True)
 p.add_argument('--mode',choices=['validate','counters'],default='counters');p.add_argument('--reference-cache',type=Path,required=True)
 a=p.parse_args();assert not a.output.exists();a.output.parent.mkdir(parents=True,exist_ok=True)
 import torch,triton,marlowe_kernels
 from marlowe_kernels import MoEConfig,MoEWeights,create_moe
 from marlowe_kernels._runtime import source_digest,cache_identity
 from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS
 from marlowe_kernels._kernels.amd.glm52_moe.selected_program import SELECTED_CONFIGS
 from benchmarks.moe_replay.protocol import load_metadata,cases
 from benchmarks.moe_replay.reference import expert_reference,compare,TOLERANCES
 from benchmarks.moe_replay.kernels import touch_input
 from benchmarks.moe_replay.dispatch_audit import capture_dispatch
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 assert source_digest()==a.expected_library_source and Path(marlowe_kernels.__file__).resolve().is_relative_to(a.source_root.resolve())
 assert TOLERANCES==dict(rtol=.02,atol=.02,nrmse=.01)
 torch.set_num_threads(4);torch.set_grad_enabled(False);torch.backends.cuda.matmul.allow_tf32=False
 for fn in (expert_reference,load_metadata,cases,create_moe):assert Path(fn.__code__.co_filename).resolve().is_relative_to(a.source_root.resolve())
 root=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2');b=a.batch
 meta=load_metadata(root/f'b{b}-s355052');meta['steps']=meta['steps'][:a.steps];sequence=list(cases(meta));assert len(sequence)==30*a.steps
 data=torch.load(root/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
 impl='port_ew' if a.arm=='baseline' else 'port_ew_bw';cfg=(SELECTED_CONFIGS if a.arm=='baseline' else BANDWIDTH_CONFIGS)[b]
 cache_identity_record=dict(batch=b,steps=a.steps,routing=a.routing,effective_cases_sha256=hashlib.sha256(json.dumps(sequence,sort_keys=True).encode()).hexdigest(),source_commit=a.source_commit,source=source_digest(),implementation=impl,config=cfg,driver_sha256=sha(__file__),reference_sha256=sha(Path(expert_reference.__code__.co_filename)),capture_sha256=sha(root/f'b{b}-s355052/tensors.pt'),weight_file_sha256={str(l):sha(root/'weights'/f'layer-{l}.pt') for l in meta['layers']})
 cached=None
 if a.mode=='counters':
  receipt=json.loads(a.reference_cache.with_suffix('.json').read_text());assert receipt['passed'] and receipt['identity']==cache_identity_record and receipt['cache_sha256']==sha(a.reference_cache)
  cached=torch.load(a.reference_cache,map_location='cpu',weights_only=True);assert len(cached)==len(sequence)
 else:assert not a.reference_cache.exists()
 cache_rows=[]
 owners={};payloads={};biases={};logits={};supplied={};checks=[];routes=[];dispatch=[]
 for j,lid in enumerate(meta['layers']):
  w=torch.load(root/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
  owners[lid]=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation=impl).warmup((b,),routing=a.routing)
  payloads[lid]=w;biases[lid]=w['bias'].bfloat16().contiguous()
  for slot in range(a.steps):
   logits[slot,j]=data['logits'][slot,j,:b].bfloat16().contiguous()
   if a.routing=='supplied':supplied[slot,j]=(data['ids'][slot,j,:b,:8].contiguous(),data['routing_weights'][slot,j,:b,:8].contiguous())
 def invoke(case):
  lid,j,slot=case['layer'],case['layer_index'],case['slot'];x=data['input'][slot,j,:b]
  if a.routing=='supplied':return owners[lid].forward_routed(x,*supplied[slot,j])
  return owners[lid](x,logits[slot,j],biases[lid])
 for index,case in enumerate(sequence):
  lid,j,slot=case['layer'],case['layer_index'],case['slot'];x=data['input'][slot,j,:b];owner=owners[lid];pr=owner._programs[b]
  value=invoke(case).cpu();ids_gpu,rw_gpu=owner.routing(b);ids,rw=ids_gpu.cpu(),rw_gpu.cpu();hist=torch.bincount(ids.flatten().long(),minlength=257).tolist()
  assert sum(hist[:256])==8*b and hist[256]==b
  if cached is None:
   ref=expert_reference(payloads[lid],x,ids_gpu,rw_gpu,pr.fp32_middle).cpu();cache_rows.append(dict(ids=ids,weights=rw,reference=ref))
  else:
   entry=cached[index];assert torch.equal(ids,entry['ids']) and torch.equal(rw,entry['weights']);ref=entry['reference']
  check=compare(value,ref)
  if not check['passed']:
   torch.save(dict(case=case,input=x.cpu(),ids=ids,weights=rw,actual=value,reference=ref),a.output.parent/f'failure-case{index}.pt')
   a.output.write_text(json.dumps(dict(passed=False,case=case,check=check,identity=cache_identity_record),indent=2));raise AssertionError((case,check))
  checks.append(check);routes.append(dict(layer=lid,step=case['decode_step'],active_experts=sum(v>0 for v in hist),expert_counts=hist,
   ids_sha256=hashlib.sha256(ids.cpu().numpy().tobytes()).hexdigest(),weights_sha256=hashlib.sha256(rw.cpu().numpy().tobytes()).hexdigest()))
 if a.mode=='validate':
  a.reference_cache.parent.mkdir(parents=True,exist_ok=True);torch.save(cache_rows,a.reference_cache)
  receipt=dict(passed=True,identity=cache_identity_record,cases=len(sequence),checks=checks,sequence=routes,cache_sha256=sha(a.reference_cache))
  a.reference_cache.with_suffix('.json').write_text(json.dumps(receipt,indent=2));a.output.write_text(json.dumps(receipt,indent=2));print('VALIDATED_CACHE',b,a.arm,len(sequence),flush=True);return
 for case in sequence[:30]:
  sig,_,g=capture_dispatch(lambda case=case:invoke(case));dispatch.append(sig);del g
 expected=len(dispatch[0]['nodes']);assert expected in (2,3,4,5)
 assert all(sig==dispatch[0] for sig in dispatch)
 names=[re.search(r'mk_[0-9a-f]+_(\w+?)Pv','\n'.join(node['label'])).group(1) for node in dispatch[0]['nodes']]
 stages=[]
 for name in names:
  if name in ('native_phase1','preloaded_phase1','fixed_prepare','dispatch_prepare'):stage='prep'
  elif name=='middle_packed':stage='middle'
  elif name=='ordered_combine':stage='combine'
  elif name in ('inline_gate','overlap_gate'):stage='g1'
  elif name in ('overlap_down','ordered_overlap_down','coalesced_down','ordered_fixed_down'):stage='g2'
  elif 'projection' in name or name=='dispatched_native':stage='g2' if 'g1' in stages else 'g1'
  else:raise AssertionError(('unknown public dispatch kernel',name))
  stages.append(stage)
 assert stages.count('g1')==stages.count('g2')==1
 graph=torch.cuda.CUDAGraph();sink=torch.empty(384,device='cuda')
 with torch.cuda.graph(graph):
  for case in sequence:
   x=data['input'][case['slot'],case['layer_index'],:b]
   touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
   invoke(case)
 for _ in range(8):graph.replay()
 torch.cuda.synchronize()
 roctx=ctypes.CDLL('/opt/rocm/lib/librocprofiler-sdk-roctx.so');roctx.roctxRangePushA.argtypes=[ctypes.c_char_p]
 for rep in range(a.repeats):
  roctx.roctxRangePushA(f'bw75_b{b}_r{rep}'.encode());graph.replay();torch.cuda.synchronize();roctx.roctxRangePop()
 state_checks={}
 for lid,owner in owners.items():
  pr=owner._programs[b]
  if callable(getattr(pr,'state_check',None)):state_checks[str(lid)]=pr.state_check()
  elif hasattr(pr,'state'):
   state=pr.state.cpu();state_checks[str(lid)]=dict(passed=int(state[-1])==0 and not bool(state[4:-1].any()))
 assert all(r['passed'] for r in state_checks.values()),state_checks
 result=dict(state_checks=state_checks,child_profiling='Disabled only for compiler/inspection subprocesses; parent Python process remains profiled',batch=b,arm=a.arm,routing=a.routing,implementation=impl,config=cfg,sequence=routes,checks=checks,dispatch=dispatch,
  stages=stages,kernel_names=names,
  identity=dict(source_commit=a.source_commit,source=source_digest(),namespace=cache_identity(),driver_sha256=sha(__file__),source_root=str(a.source_root.resolve()),
   reference_cache_sha256=receipt['cache_sha256'],reference_sha256=sha(Path(expert_reference.__code__.co_filename)),job=os.environ['SLURM_JOB_ID'],torch=torch.__version__,hip=torch.version.hip,
   capture_sha256=sha(root/f'b{b}-s355052/tensors.pt'),weight_file_sha256={str(l):sha(root/'weights'/f'layer-{l}.pt') for l in meta['layers']}),
  scope='Fixed captured BF16 logits (internal) or captured expert IDs/weights (supplied) through local combine, input preloads; hardware counters only. Exact-source independent references computed once outside profiling; all profiled-pass cases checked against that immutable reference cache on CPU. Profiler durations are excluded from performance claims.')
 a.output.write_text(json.dumps(result,indent=2));print('COUNTERS_COMPLETE',b,a.arm,len(sequence),a.repeats,flush=True)

if __name__=='__main__':main()
