import argparse,csv,json,re,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--replay',type=Path,required=True);p.add_argument('--arm',choices=['baseline','candidate'],required=True);a=p.parse_args()
replay=json.loads(a.replay.read_text());variant='port_ew' if a.arm=='baseline' else 'candidate';wanted={}
for entry in replay['dispatch_checks']:
 nodes=[]
 for node in entry['public_dispatch'][variant]['nodes']:
  text='\n'.join(node['label']);name=re.search(r'mk_[0-9a-f]+_(\w+?)Pv',text)
  if not name:continue
  shape=re.search(r'\((\d+),(\d+),(\d+)\),\((\d+),(\d+),(\d+)\)',text);assert shape,text
  grid=tuple(map(int,shape.groups()[:3]));block=tuple(map(int,shape.groups()[3:]));nodes.append((name.group(1),grid,block))
 wanted[entry['layer']]=nodes
coverage={};reference=None
for group in ('memory','scheduling','atomics','compute'):
 root=a.root/group;assert (root/'exit-code.txt').read_text().strip()=='0'
 record=json.loads((root/'replay.json').read_text());assert len(record['checks'])==60 and all(c['passed'] for c in record['checks'])
 identity={k:record[k] for k in ('batch','config','sequence','identity')}
 if reference is None:reference=identity
 else:assert identity==reference,group
 def read(name):
  with (root/name).open() as f:return list(csv.DictReader(f))
 marks=[r for r in read('counters_marker_api_trace.csv') if re.fullmatch(r'bw75_b\d+_r\d+',r['Function'])];assert len(marks)==3
 trace=read('counters_kernel_trace.csv');ids=set();checked=0
 for mark in marks:
  lo,hi=int(mark['Start_Timestamp']),int(mark['End_Timestamp'])
  calls=sorted((r for r in trace if 'mk_' in r['Kernel_Name'] and lo<=int(r['Start_Timestamp'])<=int(r['End_Timestamp'])<=hi),key=lambda r:int(r['Start_Timestamp']))
  expected=[sig for case in record['sequence'] for sig in wanted[case['layer']]];assert len(calls)==len(expected),(group,len(calls),len(expected))
  for call,(name,grid,block) in zip(calls,expected):
   assert f'_{name}(' in call['Kernel_Name'] or f'_{name}Pv' in call['Kernel_Name'],(name,call['Kernel_Name'])
   actual_block=tuple(int(call['Workgroup_Size_'+axis]) for axis in 'XYZ');actual_grid=tuple(int(call['Grid_Size_'+axis]) for axis in 'XYZ')
   assert actual_block==block and actual_grid==tuple(g*b for g,b in zip(grid,block)),(name,grid,block,actual_grid,actual_block)
   ids.add(call['Dispatch_Id']);checked+=1
 counts={r['Dispatch_Id'] for r in read('counters_counter_collection.csv') if r['Dispatch_Id'] in ids};assert counts==ids
 coverage[group]=dict(markers=3,dispatches=checked,signature_checks=checked,counter_dispatches=len(counts))
result=dict(passed=True,source=reference['identity']['source'],scope='30 layers × 2 steps × 3 ROIs; exact kernel/order/grid/block match to final public replay. Counter durations are not used as timings.',coverage=coverage,public_replay_sha256=hashlib.sha256(a.replay.read_bytes()).hexdigest())
(a.root/'public-dispatch-parity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
