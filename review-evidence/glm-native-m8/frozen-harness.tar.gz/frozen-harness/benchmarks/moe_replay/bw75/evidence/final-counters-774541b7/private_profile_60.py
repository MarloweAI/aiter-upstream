"""Selected Port-EW stage timing and separately marked hardware counters.

Fixed captured logits; full router-inclusive qualification is separate.
Use 30 real weight sets and ordered steps. Never use profiled durations as latency.
"""
import argparse, ctypes, hashlib, json, os, statistics
from pathlib import Path
import torch
import triton
from marlowe_kernels import MoEConfig, MoEWeights, create_moe
from marlowe_kernels._runtime import source_digest
from marlowe_kernels._kernels.amd.glm52_moe.selected_program import SELECTED_CONFIGS, create_selected_program
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedProgram, CoalescedConfig
from marlowe_kernels._kernels.amd.glm52_moe.prefetch_program import PrefetchProgram, PrefetchConfig
def family(name):
    if name=='overlap_g1':
        from marlowe_kernels._kernels.amd.glm52_moe.overlap_gate import OverlapG1Program,OverlapG1Config
        return OverlapG1Program,OverlapG1Config
    if name=='inline':
        from marlowe_kernels._kernels.amd.glm52_moe.safe_inline_program import SafeInlineProgram,InlineConfig
        return SafeInlineProgram,InlineConfig
    if name=='coalesced':return CoalescedProgram,CoalescedConfig
    if name=='prefetch':return PrefetchProgram,PrefetchConfig
    if name=='safe_fixed':
        from marlowe_kernels._kernels.amd.glm52_moe.safe_fixed_program import SafeFixedProgram,SafeFixedConfig
        return SafeFixedProgram,SafeFixedConfig
    raise ValueError(name)

from benchmarks.moe_replay.events import Event
from benchmarks.moe_replay.kernels import touch_input
from benchmarks.moe_replay.protocol import cases, load_metadata
from benchmarks.moe_replay.reference import compare, expert_reference
from benchmarks.moe_replay.persistent_fp4.provenance import validate_source


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--batch',type=int,required=True);p.add_argument('--steps',type=int,default=2)
    p.add_argument('--samples',type=int,default=20);p.add_argument('--repeats',type=int,default=3)
    p.add_argument('--mode',choices=['timing','counters'],default='timing')
    p.add_argument('--config',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();assert not a.output.exists(),a.output
    assert source_digest()=='19bf60e4bcacf61d4904f8169935cbd4417576746122cae1be5c94ea4d41f2e5'
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    root=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    b=a.batch;meta=load_metadata(root/f'b{b}-s355052');meta['steps']=meta['steps'][:a.steps]
    sequence=list(cases(meta));data=torch.load(root/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
    cfg=json.loads(a.config.read_text()) if a.config else SELECTED_CONFIGS[b]
    if str(b) in cfg:cfg=cfg[str(b)]
    programs={};owners={};payloads={};logits={};biases={}
    for j,lid in enumerate(meta['layers']):
        w=torch.load(root/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
        o=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
        cls,cc=family(cfg['family'])
        programs[lid]=cls(o,b,cc(**cfg['config']));owners[lid]=o;payloads[lid]=w;biases[lid]=w['bias'].bfloat16()
        for slot in range(len(meta['steps'])):logits[slot,j]=data['logits'][slot,j].bfloat16().contiguous()
    checks=[];routes=[]
    for case in sequence:
        lid,j,slot=case['layer'],case['layer_index'],case['slot'];pr=programs[lid];x=data['input'][slot,j]
        y=pr.run(x,logits[slot,j],biases[lid]).clone()
        ids=pr.p['ids'].clone();rw=pr.p['weights'].clone()
        hist=torch.bincount(ids.flatten().long(),minlength=257).cpu().tolist()
        assert sum(hist[:256])==8*b and hist[256]==b
        ref=expert_reference(payloads[lid],x,ids,rw,pr.fp32_middle)
        check=compare(y,ref);assert check['passed'],(case,check)
        if hasattr(pr,'state_check'):
            state=pr.state_check();assert state['passed'],(case,state);check['state']=state
        checks.append(check);routes.append(dict(layer=lid,step=case['decode_step'],expert_counts=hist,
            active_experts=sum(v>0 for v in hist)))
    torch.cuda.synchronize()
    result=dict(batch=b,config=cfg,sequence=routes,checks=checks,scope='fixed captured logits through local combine; one timed region per graph',
        identity=dict(source=source_digest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_paths=validate_source(),
            job=os.environ['SLURM_JOB_ID'],torch=torch.__version__,hip=torch.version.hip,gpu=str(torch.cuda.get_device_properties(0)),
            capture_sha256=hashlib.sha256((root/f'b{b}-s355052/tensors.pt').read_bytes()).hexdigest()))
    originals={lid:pr._stage for lid,pr in programs.items()}
    regions=['full'] if cfg['family'] in ('inline','overlap_g1') else ['full','prep','g1','g2']+(['middle'] if cfg['family']=='prefetch' and cfg['config']['split_k']>1 else [])
    if a.mode!='timing':regions=['counters']
    graphs={};sink=torch.empty(384,device='cuda')
    for region in regions:
        markers=[(Event(),Event()) for _ in sequence] if a.mode=='timing' else None
        current=[None]
        for lid,pr in programs.items():
            original=originals[lid]
            def hooked(inp,scale,out,first,original=original,region=region,current=current):
                pair=current[0]
                if region=='prep' and first:pair[1].record()
                if region==('g1' if first else 'g2'):pair[0].record()
                if region=='middle' and not first:pair[1].record()
                r=original(inp,scale,out,first)
                if region==('g1' if first else 'g2'):pair[1].record()
                if region=='middle' and first:pair[0].record()
                return r
            pr._stage=hooked
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for i,case in enumerate(sequence):
                lid,j,slot=case['layer'],case['layer_index'],case['slot'];x=data['input'][slot,j]
                touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                if markers:current[0]=markers[i]
                if region in ('full','prep'):current[0][0].record()
                programs[lid].run(x,logits[slot,j],biases[lid])
                if region=='full':current[0][1].record()
        graphs[region]=(graph,markers)
    for graph,_ in graphs.values():
        for _ in range(8):graph.replay()
    torch.cuda.synchronize()
    if a.mode=='timing':
        import random
        rng=random.Random(355052);samples={k:[] for k in regions}
        for _ in range(a.samples):
            order=regions.copy();rng.shuffle(order)
            for region in order:
                graph,markers=graphs[region];graph.replay();torch.cuda.synchronize()
                samples[region].append([lo.elapsed_us(hi) for lo,hi in markers])
        result['timing']={k:dict(samples_us=v,case_medians_us=[statistics.median(col) for col in zip(*v)]) for k,v in samples.items()}
        result['mean_us']={k:statistics.mean(v['case_medians_us']) for k,v in result['timing'].items()}
        result['effective_weight_TBs']={k:sum(r['active_experts'] for r in routes)*size/sum(result['timing'][k]['case_medians_us'])/1e6 for k,size in [('g1',1671168),('g2',835584),('full',2506752)] if k in result['timing']}
        print('STAGES',json.dumps(result['mean_us']), 'BW',json.dumps(result['effective_weight_TBs']),flush=True)
    else:
        roctx=ctypes.CDLL('/opt/rocm/lib/librocprofiler-sdk-roctx.so');roctx.roctxRangePushA.argtypes=[ctypes.c_char_p]
        graph=graphs['counters'][0]
        for rep in range(a.repeats):
            roctx.roctxRangePushA(f'bw75_b{b}_r{rep}'.encode());graph.replay();torch.cuda.synchronize();roctx.roctxRangePop()
        print('COUNTERS_COMPLETE',b,len(sequence),a.repeats,flush=True)
    result['post_state_checks']={str(lid):pr.state_check() for lid,pr in programs.items() if hasattr(pr,'state_check')}
    assert all(c['passed'] for c in result['post_state_checks'].values())
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2))

if __name__=='__main__':main()
