import pathlib,re,json,sys,hashlib
root=pathlib.Path(sys.argv[1]);prefix=sys.argv[2]
def regs(token):
 token=token.strip()
 m=re.match(r'v\[(\d+):(\d+)\]',token)
 if m:return set(range(int(m[1]),int(m[2])+1))
 m=re.match(r'v(\d+)\b',token)
 return {int(m[1])} if m else set()
records=[]
for p in sorted(root.glob(prefix+'*.s')):
 clock=0;last={};failures=[];mfmas=0;result_dependencies=[]
 for lineno,line in enumerate(p.read_text().splitlines(),1):
  stripped=line.split(';',1)[0].strip()
  if not stripped or stripped.startswith(('.', '//')) or stripped.endswith(':'):continue
  parts=stripped.split(None,1);op=parts[0]
  if not re.match(r'(s_|v_|ds_|global_|flat_|buffer_)',op):continue
  args=parts[1].split(',') if len(parts)>1 else []
  if op.startswith('v_mfma'):
   mfmas+=1
   for operand,arg in enumerate(args[1:6],1):
    for reg in regs(arg):
     if reg in last and last[reg][0]=='valu':
      kind,t,ln,definition=last[reg];gap=clock-t-1
      if gap<2:failures.append(dict(mfma_line=lineno,operand=operand,register=reg,gap=gap,definition_line=ln,definition=definition,consumer=stripped))
   for reg in regs(args[0]):last[reg]=('mfma',clock,lineno,stripped)
  elif op.startswith('v_'):
   for reg in set().union(*(regs(arg) for arg in args)) if args else set():
    if reg in last and last[reg][0]=='mfma':
     kind,t,ln,definition=last[reg];gap=clock-t-1
     result_dependencies.append(dict(consumer_line=lineno,register=reg,gap=gap,definition_line=ln,definition=definition,consumer=stripped,passed=gap>=8))
   for reg in regs(args[0]) if args else []:last[reg]=('valu',clock,lineno,stripped)
  elif op.startswith(('global_load','buffer_load','flat_load','ds_read')):
   for reg in regs(args[0]) if args else []:last[reg]=('memory',clock,lineno,stripped)
  if op.startswith(('global_store','ds_write','flat_store','buffer_store')):
   for reg in set().union(*(regs(arg) for arg in args)) if args else set():
    if reg in last and last[reg][0]=='mfma':
     kind,t,ln,definition=last[reg];gap=clock-t-1
     result_dependencies.append(dict(consumer_line=lineno,register=reg,gap=gap,definition_line=ln,definition=definition,consumer=stripped,passed=gap>=8))
  if op=='s_nop':clock+=int(args[0].strip(),0)+1
  else:clock+=1
 if mfmas:records.append(dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),mfmas=mfmas,immediate_valu_dependency_findings=failures,result_dependencies=result_dependencies))
print(json.dumps(dict(scope='Conservative straight-line emitted-assembly audit: all MFMA VGPR operands require at least two intervening wait states after latest non-MFMA VALU definition; memory wait correctness audited separately.',records=records),indent=2))
