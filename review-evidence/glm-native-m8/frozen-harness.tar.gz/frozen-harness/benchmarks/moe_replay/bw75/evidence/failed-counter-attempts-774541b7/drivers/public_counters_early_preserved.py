"""Matched hardware-counter ROI using the two actual public factories.

Fixed captured logits; profile durations are never performance results.
"""
import argparse,ctypes,hashlib,json,os
from pathlib import Path


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return h.hexdigest()


def main():
 p=argparse.ArgumentParser();p.add_argument('--batch',type=int,required=True);p.add_argument('--arm',choices=['baseline','candidate'],required=True)
 p.add_argument('--steps',type=int,default=2);p.add_argument('--repeats',type=int,default=3);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--source-root',type=Path,required=True);p.add_argument('--expected-library-source',required=True);p.add_argument('--source-commit',required=True)
 p.add_argument('--mode',choices=['validate','counters'],default='counters');p.add_argument('--reference-cache',type=Path,required=True)
 a=p.parse_args();assert not a.output.exists();a.output.parent.mkdir(parents=True,exist_ok=True)
 import torch,triton,marlowe_kernels
 from marlowe_kernels import MoEConfig,MoEWeights,create_moe
 from marlowe_kernels._runtime import source_digest,cache_identity
 from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS
 from marlowe_kernels._kernels.amd.glm52_moe.selected_program import SELECTED_CONFIGS
 from benchmarks.moe_replay.protocol import load_metadata,cases
 from benchmarks.moe_replay.reference import expert_reference,compare,TOLERANCES
 from benchmarks.moe_replay.kernels import touch_input
 from benchmarks.moe_replay.dispatch_audit import capture_dispatch
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 assert source_digest()==a.expected_library_source and Path(marlowe_kernels.__file__).resolve().is_relative_to(a.source_root.resolve())
 assert TOLERANCES==dict(rtol=.02,atol=.02,nrmse=.01)
 torch.set_num_threads(4);torch.set_grad_enabled(False);torch.backends.cuda.matmul.allow_tf32=False
 for fn in (expert_reference,load_metadata,cases,create_moe):assert Path(fn.__code__.co_filename).resolve().is_relative_to(a.source_root.resolve())
 root=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2');b=a.batch
 meta=load_metadata(root/f'b{b}-s355052');meta['steps']=meta['steps'][:a.steps];sequence=list(cases(meta));assert len(sequence)==30*a.steps
 data=torch.load(root/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
 impl='port_ew' if a.arm=='baseline' else 'port_ew_bw';cfg=(SELECTED_CONFIGS if a.arm=='baseline' else BANDWIDTH_CONFIGS)[b]
 cache_identity_record=dict(batch=b,steps=a.steps,source_commit=a.source_commit,source=source_digest(),implementation=impl,config=cfg,driver_sha256=sha(__file__),reference_sha256=sha(Path(expert_reference.__code__.co_filename)),capture_sha256=sha(root/f'b{b}-s355052/tensors.pt'),weight_file_sha256={str(l):sha(root/'weights'/f'layer-{l}.pt') for l in meta['layers']})
 cached=None
 if a.mode=='counters':
  receipt=json.loads(a.reference_cache.with_suffix('.json').read_text());assert receipt['passed'] and receipt['identity']==cache_identity_record and receipt['cache_sha256']==sha(a.reference_cache)
  cached=torch.load(a.reference_cache,map_location='cpu',weights_only=True);assert len(cached)==len(sequence)
 else:assert not a.reference_cache.exists()
 cache_rows=[]
 owners={};payloads={};biases={};logits={};checks=[];routes=[];dispatch=[]
 for j,lid in enumerate(meta['layers']):
  w=torch.load(root/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
  owners[lid]=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation=impl).warmup((b,),routing='internal')
  payloads[lid]=w;biases[lid]=w['bias'].bfloat16().contiguous()
  for slot in range(a.steps):logits[slot,j]=data['logits'][slot,j,:b].bfloat16().contiguous()
 def invoke(case):
  lid,j,slot=case['layer'],case['layer_index'],case['slot'];return owners[lid](data['input'][slot,j,:b],logits[slot,j],biases[lid])
 for index,case in enumerate(sequence):
  lid,j,slot=case['layer'],case['layer_index'],case['slot'];x=data['input'][slot,j,:b];owner=owners[lid];pr=owner._programs[b]
  value=invoke(case).cpu();ids_gpu,rw_gpu=owner.routing(b);ids,rw=ids_gpu.cpu(),rw_gpu.cpu();hist=torch.bincount(ids.flatten().long(),minlength=257).tolist()
  assert sum(hist[:256])==8*b and hist[256]==b
  if cached is None:
   ref=expert_reference(payloads[lid],x,ids_gpu,rw_gpu,pr.fp32_middle).cpu();cache_rows.append(dict(ids=ids,weights=rw,reference=ref))
  else:
   entry=cached[index];assert torch.equal(ids,entry['ids']) and torch.equal(rw,entry['weights']);ref=entry['reference']
  check=compare(value,ref)
  if not check['passed']:
   torch.save(dict(case=case,input=x.cpu(),ids=ids,weights=rw,actual=value,reference=ref),a.output.parent/f'failure-case{index}.pt')
   a.output.write_text(json.dumps(dict(passed=False,case=case,check=check,identity=cache_identity_record),indent=2));raise AssertionError((case,check))
  checks.append(check);routes.append(dict(layer=lid,step=case['decode_step'],active_experts=sum(v>0 for v in hist),expert_counts=hist,
   ids_sha256=hashlib.sha256(ids.cpu().numpy().tobytes()).hexdigest(),weights_sha256=hashlib.sha256(rw.cpu().numpy().tobytes()).hexdigest()))
 if a.mode=='validate':
  a.reference_cache.parent.mkdir(parents=True,exist_ok=True);torch.save(cache_rows,a.reference_cache)
  receipt=dict(passed=True,identity=cache_identity_record,cases=len(sequence),checks=checks,sequence=routes,cache_sha256=sha(a.reference_cache))
  a.reference_cache.with_suffix('.json').write_text(json.dumps(receipt,indent=2));a.output.write_text(json.dumps(receipt,indent=2));print('VALIDATED_CACHE',b,a.arm,len(sequence),flush=True);return
 for case in sequence[:30]:
  sig,_,g=capture_dispatch(lambda case=case:invoke(case));dispatch.append(sig);del g
 expected=len(dispatch[0]['nodes']);assert expected in (2,4)
 assert all(len(sig['nodes'])==expected for sig in dispatch)
 graph=torch.cuda.CUDAGraph();sink=torch.empty(384,device='cuda')
 with torch.cuda.graph(graph):
  for case in sequence:
   x=data['input'][case['slot'],case['layer_index'],:b]
   touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
   invoke(case)
 for _ in range(8):graph.replay()
 torch.cuda.synchronize()
 roctx=ctypes.CDLL('/opt/rocm/lib/librocprofiler-sdk-roctx.so');roctx.roctxRangePushA.argtypes=[ctypes.c_char_p]
 for rep in range(a.repeats):
  roctx.roctxRangePushA(f'bw75_b{b}_r{rep}'.encode());graph.replay();torch.cuda.synchronize();roctx.roctxRangePop()
 result=dict(batch=b,arm=a.arm,implementation=impl,config=cfg,sequence=routes,checks=checks,dispatch=dispatch,
  stages=['g1','g2'] if expected==2 else ['prep','g1','middle','g2'],
  identity=dict(source_commit=a.source_commit,source=source_digest(),namespace=cache_identity(),driver_sha256=sha(__file__),source_root=str(a.source_root.resolve()),
   reference_cache_sha256=receipt['cache_sha256'],reference_sha256=sha(Path(expert_reference.__code__.co_filename)),job=os.environ['SLURM_JOB_ID'],torch=torch.__version__,hip=torch.version.hip,
   capture_sha256=sha(root/f'b{b}-s355052/tensors.pt'),weight_file_sha256={str(l):sha(root/'weights'/f'layer-{l}.pt') for l in meta['layers']}),
  scope='Fixed captured logits through local combine, input preloads; hardware counters only. Exact-source independent references computed once outside profiling; all profiled-pass cases checked against that immutable reference cache on CPU. Profiler durations are excluded from performance claims.')
 a.output.write_text(json.dumps(result,indent=2));print('COUNTERS_COMPLETE',b,a.arm,len(sequence),a.repeats,flush=True)

if __name__=='__main__':main()
