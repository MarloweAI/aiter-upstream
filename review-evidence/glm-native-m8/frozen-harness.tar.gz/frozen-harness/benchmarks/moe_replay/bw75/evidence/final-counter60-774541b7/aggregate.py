"""Validate marked profiler exports and aggregate hardware counts per stage."""
import argparse,collections,csv,gzip,json,re,statistics
from pathlib import Path

def rows(path):
    with path.open() as f:yield from csv.DictReader(f)

def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args()
    merged={};groups={};identities=[];workloads=[]
    for folder in sorted(a.root.iterdir()):
        if not (folder/'replay.json').exists():continue
        evidence=json.loads((folder/'replay.json').read_text());identities.append(evidence['identity'])
        workloads.append((evidence['config'],evidence['sequence']))
        assert all(c['passed'] for c in evidence['checks']),'Failed numerical reference in profiler workload'
        b=evidence['batch'];marks=[r for r in rows(folder/'counters_marker_api_trace.csv') if re.fullmatch(r'bw75_b\d+_r\d+',r['Function'])]
        assert len(marks)==3 and {m['Function'] for m in marks}=={f'bw75_b{b}_r{r}' for r in range(3)}
        calls=[]
        bounds=[(int(m['Start_Timestamp']),int(m['End_Timestamp'])) for m in marks]
        for row in rows(folder/'counters_kernel_trace.csv'):
            if 'mk_' not in row['Kernel_Name']:continue
            lo,hi=int(row['Start_Timestamp']),int(row['End_Timestamp'])
            if any(start<=lo<=hi<=end for start,end in bounds):calls.append(row)
        ids={r['Dispatch_Id'] for r in calls};counts=collections.defaultdict(dict)
        for row in rows(folder/'counters_counter_collection.csv'):
            if row['Dispatch_Id'] in ids:counts[row['Dispatch_Id']][row['Counter_Name']]=float(row['Counter_Value'])
        assert set(counts)==ids,(folder,len(counts),len(ids))
        expected=['prep','g1','middle','g2']
        cfg=evidence['config']['config']
        if cfg.get('split_k',1)==1:expected.remove('middle')
        if evidence['config']['family'] in ('consumer','inline','overlap_g1'):expected.remove('middle')
        if evidence['config']['family'] in ('inline','overlap_g1'):expected.remove('prep')
        if not cfg.get('direct',False) and not cfg.get('dispatch',False):expected.insert(1,'group')
        for repetition,(start,end) in enumerate(bounds):
            current=sorted((r for r in calls if start<=int(r['Start_Timestamp'])<=int(r['End_Timestamp'])<=end),key=lambda r:int(r['Start_Timestamp']))
            assert len(current)==len(evidence['sequence'])*len(expected),(folder,len(current))
            for index,row in enumerate(current):
                stage=expected[index%len(expected)];case=index//len(expected)
                item=merged.setdefault((case,stage),dict(case=evidence['sequence'][case],stage=stage,samples=collections.defaultdict(list),
                    resources={k:row[k] for k in ('Kernel_Name','Grid_Size_X','Grid_Size_Y','Grid_Size_Z','Workgroup_Size_X','LDS_Block_Size','VGPR_Count','SGPR_Count','Scratch_Size')}))
                for name,value in counts[row['Dispatch_Id']].items():item['samples'][name].append(value)
        groups[folder.name]=dict(markers=len(marks),calls=len(calls),counter_dispatches=len(counts))
    assert set(groups)=={'memory','scheduling','atomics','compute'},('Missing required counter passes',groups)
    assert all(w==workloads[0] for w in workloads),'Changed workload across counter passes'
    assert groups and all(v['source']==identities[0]['source'] and v['script_sha256']==identities[0]['script_sha256'] for v in identities)
    result=[]
    for (index,stage),item in merged.items():
        item['counters']={k:statistics.median(v) for k,v in item.pop('samples').items()};result.append(item)
    summary={}
    for stage in sorted({r['stage'] for r in result}):
        rr=[r for r in result if r['stage']==stage]
        names=set().union(*(r['counters'].keys() for r in rr))
        c={k:statistics.mean(r['counters'][k] for r in rr) for k in names}
        summary[stage]=dict(counters_per_call=c,resources=rr[0]['resources'],tcc_hbm_read_request_MB=c.get('TCC_EA0_RDREQ_DRAM_32B_sum',0)*32/1e6,
             tcc_hbm_write_request_MB=c.get('TCC_EA0_WRREQ_WRITE_DRAM_32B_sum',0)*32/1e6,
             l2_hit_fraction=c.get('TCC_HIT_sum',0)/(c.get('TCC_HIT_sum',0)+c.get('TCC_MISS_sum',1)))
    record=dict(counter_scope='L2 requests directed toward HBM; Infinity Cache may serve these; not physical HBM traffic',validation=dict(passed=True,groups=groups),stages=summary,identity=identities[0])
    (a.root/'summary.json').write_text(json.dumps(record,indent=2))
    with gzip.open(a.root/'per-case.json.gz','wt') as f:json.dump(result,f)
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
