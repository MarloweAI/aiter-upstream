"""Independent repeated-slot reference shared from the B4/B32 stress probe."""
import torch

def duplicate_slot_reference(weights,x,ids,rw,fused):
    """The established reference formula with duplicate-row scatter addition.

    expert_reference assumes each token selects an expert once: its indexed
    assignment overwrites repeated rows. This stress-only variant handles the
    deliberately repeated supplied expert slots using FP32 index_add_.
    """
    from benchmarks.moe_replay.reference import quantize_mxfp4,dequant_weight,bf16_atomic_operand_reference
    p={}
    for key in ('w1','w2'):
        t=weights[key];e,n,width=t.shape
        p[key]=t.view(torch.uint8).view(e,n//16,width//32,2,16,16).permute(0,1,4,2,3,5).contiguous().view(t.shape)
        s=weights[key+'_scale'];m,sn=e*n,s.shape[-1]
        p[key+'_scale']=s.view(torch.uint8).view(m//32,sn//8,4,16,2,2).permute(0,5,3,1,4,2).contiguous().view(e,n,sn)
    qx,_=quantize_mxfp4(x.float(),scale_rounding='hip_round_up')
    out=torch.zeros_like(x,dtype=torch.float32)
    for expert in range(257):
        rows,choices=torch.where(ids==expert)
        if not len(rows):continue
        w1=dequant_weight(p['w1'][expert],p['w1_scale'][expert],format='mxfp4')
        gate,up=(qx[rows]@w1.T).chunk(2,-1)
        mid=gate*torch.sigmoid(gate)*up
        if not fused:mid=mid.bfloat16()
        mid,_=quantize_mxfp4(mid,scale_rounding='flydsl_fused_0x400000' if fused else 'hip_round_up')
        w2=dequant_weight(p['w2'][expert],p['w2_scale'][expert],format='mxfp4')
        out.index_add_(0,rows,bf16_atomic_operand_reference((mid@w2.T)*rw[rows,choices,None]))
    return out.bfloat16()
