"""Separate intermediate arithmetic from atomic-combine error on repeated routes."""
import argparse,json,os
from pathlib import Path
import torch
from marlowe_kernels import MoEConfig,MoEWeights,create_moe
from marlowe_kernels._kernels.amd.glm52_moe.fixed_bins import FixedBinProgram,FixedBinConfig
from benchmarks.moe_replay.reference import compare,dequant_weight,bf16_atomic_operand_reference
from benchmarks.moe_replay.bw75.route_stress import duplicate_slot_reference

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists()
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 torch.set_num_threads(4);torch.set_grad_enabled(False);torch.backends.cuda.matmul.allow_tf32=False
 root=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
 payload=torch.load(root/'weights/layer-3.pt',map_location='cuda',weights_only=True)
 data=torch.load(root/'b64-s355052/tensors.pt',map_location='cuda',weights_only=True)
 owner=create_moe(MoEConfig(),MoEWeights(*(payload[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
 config=json.loads((Path(os.environ['PERSIST_ROOT'])/'candidate-fixed64.json').read_text())['64']['config']
 pr=FixedBinProgram(owner,64,FixedBinConfig(**config));x=data['input'][0,0].clone()
 ids=torch.full((64,8),17,device='cuda',dtype=torch.int32);rw=torch.full((64,8),2.5/8,device='cuda')
 y=pr.run(x,x,x,supplied_ids=ids,supplied_weights=rw).clone();torch.cuda.synchronize()
 i9=pr.p['ids'].clone();w9=pr.p['weights'].clone();mid=dequant_weight(pr.mid,pr.mid_scale,format='mxfp4')
 full=duplicate_slot_reference(payload,x,i9,w9,pr.fp32_middle)
 packed=payload['w2'];e,n,width=packed.shape
 w2=packed.view(torch.uint8).view(e,n//16,width//32,2,16,16).permute(0,1,4,2,3,5).contiguous().view(packed.shape)
 scales=payload['w2_scale'];m,sn=e*n,scales.shape[-1]
 ws=scales.view(torch.uint8).view(m//32,sn//8,4,16,2,2).permute(0,5,3,1,4,2).contiguous().view(e,n,sn)
 terms=torch.empty((64,9,6144),device='cuda');fp32=torch.zeros_like(x,dtype=torch.float32)
 for expert in (17,256):
  rows,slots=torch.where(i9==expert);weight=dequant_weight(w2[expert],ws[expert],format='mxfp4')
  value=bf16_atomic_operand_reference((mid[rows,slots].float()@weight.T)*w9[rows,slots,None])
  terms[rows,slots]=value;fp32.index_add_(0,rows,value)
 fp32=fp32.bfloat16()
 sequences=[]
 for position in range(9):
  order=list(range(8));order.insert(position,8);s=torch.zeros_like(x)
  for slot in order:s=(s.float()+terms[:,slot]).bfloat16()
  sequences.append(dict(shared_position=position,vs_actual=compare(y,s),vs_reference=compare(s,full)))
 result=dict(config=config,state=pr.state_check(),mid_duplicate_equal=bool((pr.mid[:,:8]==pr.mid[:,:1]).all()),
  scales_duplicate_equal=bool((pr.mid_scale[:,:8]==pr.mid_scale[:,:1]).all()),actual_vs_reference=compare(y,full),
  actual_vs_fp32_combine=compare(y,fp32),fp32_combine_vs_reference=compare(fp32,full),sequences=sequences)
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2))
 torch.save(dict(x=x,ids=i9,weights=w9,actual=y,reference=full,fp32_combine=fp32,terms=terms,mid=pr.mid,mid_scale=pr.mid_scale),a.output.with_suffix('.pt'))
 print(json.dumps(result),flush=True)
if __name__=='__main__':main()
