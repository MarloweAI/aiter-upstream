"""Validate marked counter coverage and summarize per-stage diagnostics."""
import argparse,collections,csv,json,re,statistics
from pathlib import Path

def rows(p):
    with p.open() as f:yield from csv.DictReader(f)

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    merged={};coverage={};reference=None
    for group in ('memory','compute','scheduling','latency'):
        folder=a.root/group;record=json.loads((folder/'replay.json').read_text())
        identity={k:record[k] for k in ('batch','config','sequence','identity')}
        if reference is None:reference=identity
        else:assert identity==reference,('counter pass identity mismatch',group)
        cfg=record['config']['config'];b=record['batch']
        stages=['prep']+(['group'] if not cfg.get('direct') and not cfg.get('dispatch') else [])+['g1']+(['middle'] if cfg['split_k']>1 else [])+['g2']
        marks=[r for r in rows(folder/'counters_marker_api_trace.csv') if re.fullmatch(r'bw75_b\d+_r\d+',r['Function'])]
        assert len(marks)==3
        trace=[r for r in rows(folder/'counters_kernel_trace.csv') if r['Kernel_Name'].startswith('mk_')]
        counters=collections.defaultdict(dict)
        for r in rows(folder/'counters_counter_collection.csv'):
            counters[r['Dispatch_Id']][r['Counter_Name']]=float(r['Counter_Value'])
        total=0
        for mark in marks:
            lo,hi=int(mark['Start_Timestamp']),int(mark['End_Timestamp'])
            calls=sorted([r for r in trace if lo<=int(r['Start_Timestamp'])<=int(r['End_Timestamp'])<=hi],key=lambda r:int(r['Start_Timestamp']))
            assert len(calls)==len(record['sequence'])*len(stages),(group,len(calls),stages)
            total+=len(calls)
            for i,r in enumerate(calls):
                idx=i//len(stages);stage=stages[i%len(stages)];key=(idx,stage)
                item=merged.setdefault(key,dict(index=idx,stage=stage,kernel=r['Kernel_Name'],
                    resources={k:int(r[k]) for k in ('VGPR_Count','LDS_Block_Size','Scratch_Size','Workgroup_Size_X','Grid_Size_X','Grid_Size_Y','Grid_Size_Z')},samples=collections.defaultdict(list)))
                assert item['kernel']==r['Kernel_Name']
                assert r['Dispatch_Id'] in counters
                for name,value in counters[r['Dispatch_Id']].items():item['samples'][name].append(value)
        coverage[group]=total
    per_case=[]
    for item in merged.values():
        item['counters']={k:statistics.median(v) for k,v in item.pop('samples').items()};per_case.append(item)
    summaries={}
    for stage in stages:
        rr=[r for r in per_case if r['stage']==stage]
        mean={k:statistics.mean(r['counters'][k] for r in rr) for k in rr[0]['counters']}
        meanweights=statistics.mean(r['active_experts'] for r in record['sequence'])*{'g1':1671168,'g2':835584}.get(stage,0)
        summaries[stage]=dict(resources=rr[0]['resources'],mean_counters=mean,
            l2_destination_read_MB=mean.get('TCC_EA0_RDREQ_DRAM_32B_sum',0)*32/1e6,
            useful_weight_MB=meanweights/1e6,
            read_amplification=mean.get('TCC_EA0_RDREQ_DRAM_32B_sum',0)*32/meanweights if meanweights else None,
            l2_hit_fraction=mean.get('TCC_HIT_sum',0)/max(1,mean.get('TCC_HIT_sum',0)+mean.get('TCC_MISS_sum',0)),
            waves_per_CU=mean.get('MeanOccupancyPerCU'),
            wait_wave_fraction=mean.get('SQ_WAIT_ANY',0)/max(1,mean.get('SQ_WAVE_CYCLES',0)))
    result=dict(coverage=coverage,identity=reference,stages=summaries,per_case=per_case,
        note='L2 destination bytes may hit Infinity Cache. No physical HBM claim. Profiler durations excluded.')
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2))
    print(json.dumps(dict(coverage=coverage,stages=summaries),indent=2))
if __name__=='__main__':main()
