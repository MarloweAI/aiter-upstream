"""Measure the unchanged benchmark's empty interval; never subtract this cost."""
import argparse,json,os,statistics
from pathlib import Path
import torch,triton
from benchmarks.moe_replay.events import Event
from benchmarks.moe_replay.kernels import touch_input

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 assert not a.output.exists() and os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 torch.set_num_threads(4);torch.set_grad_enabled(False)
 xs=torch.zeros((60,8,6144),device='cuda',dtype=torch.bfloat16);sink=torch.empty(384,device='cuda')
 result={}
 for mode in ('empty','one_kernel'):
  events=[(Event(),Event()) for _ in range(60)];g=torch.cuda.CUDAGraph()
  with torch.cuda.graph(g):
   for i,(lo,hi) in enumerate(events):
    x=xs[i];touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
    lo.record()
    if mode=='one_kernel':x.add_(1)
    hi.record()
  for _ in range(10):g.replay()
  torch.cuda.synchronize();samples=[]
  for _ in range(40):
   g.replay();torch.cuda.synchronize();samples.append([lo.elapsed_us(hi) for lo,hi in events])
  medians=[statistics.median(v) for v in zip(*samples)]
  result[mode]=dict(mean_us=statistics.mean(medians),case_medians_us=medians,samples_us=samples)
 result['job']=os.environ['SLURM_JOB_ID'];result['note']='Same native timing flags; diagnostic floor only. No subtraction from headline timing.'
 a.output.write_text(json.dumps(result,indent=2));print({k:v['mean_us'] for k,v in result.items() if isinstance(v,dict)})
if __name__=='__main__':main()
