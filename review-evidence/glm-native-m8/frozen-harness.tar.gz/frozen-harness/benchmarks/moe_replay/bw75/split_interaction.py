"""Screen paired-load/split-K interactions against the frozen inline control.

Fixed-logit screening only; numerical gates and the selected public configuration
are unchanged. Every measured candidate is paired with the current inline graph.
"""
import argparse, dataclasses, hashlib, json, os, statistics
from pathlib import Path


def main():
 p=argparse.ArgumentParser();p.add_argument('--capture',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--source-root',type=Path,required=True);p.add_argument('--expected-library-source',required=True)
 p.add_argument('--batches',nargs='+',type=int,default=[1]);p.add_argument('--steps',type=int,default=2)
 p.add_argument('--samples',type=int,default=24);p.add_argument('--warmups',type=int,default=8)
 a=p.parse_args();assert not a.output.exists();a.output.mkdir(parents=True)
 import torch,marlowe_kernels
 from marlowe_kernels import create_moe,MoEConfig,MoEWeights
 from marlowe_kernels._runtime import source_digest
 from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS
 from marlowe_kernels._kernels.amd.glm52_moe.inline_program import InlineProgram,InlineConfig
 from benchmarks.moe_replay.reference import expert_reference,compare
 from benchmarks.moe_replay.native_fp4.tune import ScreenLayer
 from benchmarks.moe_replay.protocol import load_metadata,cases
 from benchmarks.moe_replay.run import prepare_graph,timings
 assert source_digest()==a.expected_library_source and Path(marlowe_kernels.__file__).resolve().is_relative_to(a.source_root.resolve())
 assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
 torch.set_num_threads(4);torch.set_grad_enabled(False)
 identity=dict(source=source_digest(),source_root=str(a.source_root.resolve()),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),job=os.environ['SLURM_JOB_ID'],scope='Fixed captured logits; input-preloaded preparation-through-combine, not router-inclusive headline')
 records=[];owners={};payloads={}
 for b in a.batches:
  assert b in (1,2,4)
  meta=load_metadata(a.capture/f'b{b}-s355052');meta['steps']=meta['steps'][:a.steps];sequence=list(cases(meta));assert len(sequence)==30*a.steps
  data=torch.load(a.capture/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
  control=InlineConfig(**BANDWIDTH_CONFIGS[b]['config']);base={};refs=[];routes=[]
  for j,lid in enumerate(meta['layers']):
   if lid not in owners:
    payloads[lid]=torch.load(a.capture/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
    q=payloads[lid];owners[lid]=create_moe(MoEConfig(),MoEWeights(*(q[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='port_ew_bw')
   logits={data['input'][slot,j].data_ptr():data['logits'][slot,j].bfloat16().contiguous() for slot in range(a.steps)}
   base[lid]=ScreenLayer(owners[lid],InlineProgram(owners[lid],b,control),logits,payloads[lid]['bias'].bfloat16())
  baseline_checks=[]
  for c in sequence:
   x=data['input'][c['slot'],c['layer_index']];layer=base[c['layer']];pr=layer.program
   actual=layer(x,'control').clone();ids,rw=pr.p['ids'].clone(),pr.p['weights'].clone()
   ref=expert_reference(payloads[c['layer']],x,ids,rw,pr.fp32_middle);check=compare(actual,ref);assert check['passed'],check
   refs.append(ref);routes.append((ids,rw));baseline_checks.append(check)
  base_graph=prepare_graph(sequence,base,data,'control',True,True)
  variants=[('same',control),('split12_pair2',dataclasses.replace(control,split_k=12,pair_depth=2)),('split12_pair1',dataclasses.replace(control,split_k=12,pair_depth=1)),('split24_pair1',dataclasses.replace(control,split_k=24,pair_depth=1)),('split8_pair3',dataclasses.replace(control,split_k=8,pair_depth=3))]
  for name,cfg in variants:
   layers={lid:ScreenLayer(owners[lid],InlineProgram(owners[lid],b,cfg),base[lid].logits,base[lid].bias) for lid in meta['layers']};checks=[]
   for i,c in enumerate(sequence):
    x=data['input'][c['slot'],c['layer_index']];layer=layers[c['layer']];out=layer(x,'candidate').clone();ids,rw=routes[i]
    pr=layer.program;route_ok=bool(torch.equal(pr.p['ids'],ids) and torch.equal(pr.p['weights'],rw));check=compare(out,refs[i]);check['exact_routes']=route_ok
    check['passed']=check['passed'] and route_ok;checks.append(check)
    if not check['passed']:
     torch.save(dict(input=x.cpu(),ids=ids.cpu(),weights=rw.cpu(),actual=out.cpu(),reference=refs[i].cpu()),a.output/f'failure-b{b}-{name}-case{i}.pt')
   row=dict(batch=b,name=name,config=dataclasses.asdict(cfg),control_config=dataclasses.asdict(control),identity=identity,cases=len(sequence),checks=checks,baseline_checks=baseline_checks,passed=all(c['passed'] for c in checks))
   if row['passed']:
    graph=prepare_graph(sequence,layers,data,'candidate',True,True)
    tm=timings(dict(control=base_graph,candidate=graph),a.samples,a.warmups);row['timing']=tm
    row['us']={key:value['sum_interval_median_us']/len(sequence) for key,value in tm.items()};row['improvement_percent']=100*(1-row['us']['candidate']/row['us']['control'])
    del graph
   records.append(row);(a.output/'screen.json').write_text(json.dumps(records,indent=2));print(json.dumps({k:v for k,v in row.items() if k not in ('timing','checks','baseline_checks','identity')}),flush=True)
   del layers
  del base_graph,base,data,refs,routes;torch.cuda.empty_cache()

if __name__=='__main__':main()
