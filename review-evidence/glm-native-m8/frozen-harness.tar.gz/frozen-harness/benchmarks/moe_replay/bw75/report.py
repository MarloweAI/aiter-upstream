"""Recompute all-batch useful-weight bandwidth from saved paired replay JSONs.

Input manifest entries: batch, path, selected_arm, control_arm (optional).
The full router-through-combine interval is never replaced by stage timings.
"""
import argparse,gzip,hashlib,json,statistics
from pathlib import Path

G1_BYTES=2*6144*256*(16+1)//32
G2_BYTES=6144*256*(16+1)//32
PEAK_TBS=8.

def read(path):
 with (gzip.open(path,'rt') if path.suffix=='.gz' else path.open()) as f:return json.load(f)

def summarize(entry,root):
 p=(root/entry['path']).resolve();d=read(p);b=entry['batch'];assert b==d['batch']
 arm=entry['selected_arm'];control=entry.get('control_arm');seq=d['sequence'];checks=d['checks'];n=len(seq)
 assert n==len(checks) and n>0
 active=[]
 for s,c in zip(seq,checks):
  assert (s['layer'],s['decode_step'])==(c['layer'],c['decode_step'])
  hist=c['expert_counts'];assert len(hist)==257 and sum(hist[:256])==8*b and hist[256]==b
  active.append(sum(v>0 for v in hist))
 def timing(name):
  tm=d['timing'][name+'_preload_events'];v=tm['interval_medians_us'];assert len(v)==n
  assert len(tm['interval_samples_us'])>=20
  return statistics.mean(v),sum(v)
 def correctness(name):
  eager=[c['port_references'][name] for c in checks]
  validation=d['graph_validation'][name];assert len(validation)==n
  graph=[g['graph_reference'] for g in validation]
  graph_eager=[g['eager_reference'] for g in validation]
  pairwise=[g['graph_vs_eager'] for g in validation]
  return dict(eager_passed=all(x['passed'] for x in eager),graph_passed=all(x['passed'] for x in graph),
    graph_eager_passed=all(x['passed'] for x in graph_eager),
    max_eager_nrmse=max(x['nrmse'] for x in eager),max_graph_nrmse=max(x['nrmse'] for x in graph),
    max_graph_eager_nrmse=max(x['nrmse'] for x in graph_eager),
    pairwise_graph_eager_passed=all(x['passed'] for x in pairwise),
    note='Eager, captured, and graph-counterpart eager must each pass the independent reference; pairwise graph/eager is diagnostic under the unchanged replay protocol.')
 us,total=timing(arm);payload=sum(active)*(G1_BYTES+G2_BYTES);bw=payload/total/1e6
 r=dict(batch=b,cases=n,source_path=str(p),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    selected_arm=arm,selected_us=us,active_experts_mean=statistics.mean(active),
    g1_weight_MB=statistics.mean(active)*G1_BYTES/1e6,g2_weight_MB=statistics.mean(active)*G2_BYTES/1e6,
    effective_weight_TBs=bw,percent_peak=100*bw/PEAK_TBS,target_us=payload/n/6e6,
    study_qualified=d['qualified'],selected_correctness=correctness(arm),
    numerical_failures=len(d.get('numerical_failures',[])),job=d.get('job'),identity=d['identity'])
 if control:
  cu,ct=timing(control);cbw=payload/ct/1e6
  r.update(control_arm=control,control_us=cu,control_TBs=cbw,control_percent_peak=cbw/PEAK_TBS*100,
    latency_reduction_percent=100*(1-us/cu),control_correctness=correctness(control))
 return r

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 entries=json.loads(a.manifest.read_text());rows=[summarize(e,a.manifest.parent) for e in entries]
 a.output.parent.mkdir(parents=True,exist_ok=True)
 a.output.write_text(json.dumps(dict(metric='Distinct active expert weights and scales / full router-through-combine interval',peak_TBs=PEAK_TBS,
    g1_bytes_per_expert=G1_BYTES,g2_bytes_per_expert=G2_BYTES,rows=rows),indent=2))
 for r in rows:print(r['batch'],r.get('control_us'),r['selected_us'],r['effective_weight_TBs'],r['percent_peak'],r['selected_correctness'])
if __name__=='__main__':main()
