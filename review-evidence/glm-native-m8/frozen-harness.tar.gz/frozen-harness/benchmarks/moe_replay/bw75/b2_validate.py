"""Changing-buffer graph, zero input, and supplied-route correctness probes."""
import argparse,json,os
from pathlib import Path
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeProgram
from benchmarks.moe_replay.reference import expert_reference,compare
from benchmarks.moe_replay.protocol import load_metadata
from benchmarks.moe_replay.persistent_fp4.provenance import validate_source

def family(name):
    if name=='inline':
        from marlowe_kernels._kernels.amd.glm52_moe.inline_program import InlineProgram,InlineConfig
        return InlineProgram,InlineConfig
    if name=='consumer':
        from marlowe_kernels._kernels.amd.glm52_moe.consumer_program import ConsumerProgram,ConsumerConfig
        return ConsumerProgram,ConsumerConfig
    if name=='prefetch':
        from marlowe_kernels._kernels.amd.glm52_moe.prefetch_program import PrefetchProgram,PrefetchConfig
        return PrefetchProgram,PrefetchConfig
    raise ValueError(name)

def main():
    p=argparse.ArgumentParser();p.add_argument('--batch',type=int,default=2);p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    assert not a.output.exists();torch.set_grad_enabled(False);torch.set_num_threads(4)
    root=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2');b=a.batch
    meta=load_metadata(root/f'b{b}-s355052');data=torch.load(root/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
    entry=json.loads(a.config.read_text());entry=entry.get(str(b),entry);cls,cfg=family(entry['family']);checks=[]
    for j in (0,len(meta['layers'])//2,len(meta['layers'])-1):
        lid=meta['layers'][j];w=torch.load(root/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
        owner=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
        candidate=cls(owner,b,cfg(**entry['config']));control=NativeProgram(owner,b);bias=w['bias'].bfloat16()
        x=data['input'][0,j].clone();logits=data['logits'][0,j].bfloat16().contiguous();target=torch.empty_like(x)
        candidate.run(x,logits,bias,out=target);torch.cuda.synchronize()
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):out=candidate.run(x,logits,bias,out=target)
        for step in range(min(16,len(meta['steps']))):
            x.copy_(data['input'][step,j]);logits.copy_(data['logits'][step,j]);control.run(x,logits,bias)
            for _ in range(3):graph.replay()
            torch.cuda.synchronize();assert out.data_ptr()==target.data_ptr()
            assert torch.equal(candidate.p['ids'],control.p['ids'])
            assert float((candidate.p['weights']-control.p['weights']).abs().max())==0
            ref=expert_reference(w,x,control.p['ids'],control.p['weights'],candidate.fp32_middle)
            check=compare(out,ref);checks.append(dict(layer=lid,kind='changing_buffer_graph',step=step,check=check));assert check['passed'],checks[-1]
        del graph
        for kind in ('balanced','concentrated','zero'):
            x.copy_(data['input'][0,j]);x.zero_() if kind=='zero' else None
            ids=(torch.arange(b*8,device='cuda').view(b,8)%(8 if kind=='concentrated' else 256)).int()
            rw=torch.full((b,8),.125,device='cuda')
            candidate.run(x,logits,bias,out=target,supplied_ids=ids,supplied_weights=rw);torch.cuda.synchronize()
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):out=candidate.run(x,logits,bias,out=target,supplied_ids=ids,supplied_weights=rw)
            for _ in range(10):graph.replay()
            torch.cuda.synchronize();assert torch.equal(candidate.p['ids'][:,:8],ids)
            assert torch.equal(candidate.p['weights'][:,:8],rw)
            ref=expert_reference(w,x,candidate.p['ids'],candidate.p['weights'],candidate.fp32_middle)
            check=compare(out,ref);checks.append(dict(layer=lid,kind=kind,check=check));assert check['passed'],checks[-1]
            del graph
    result=dict(passed=True,batch=b,config=entry,checks=checks,source_paths=validate_source(),job=os.environ['SLURM_JOB_ID'])
    a.output.write_text(json.dumps(result,indent=2));print('STRESS_PASSED',b,len(checks),flush=True)

if __name__=='__main__':main()
