"""Hardware-guided Port-EW useful-weight bandwidth experiments."""
