"""Adversarial supplied-route and changing-input checks for wave route merge."""
import argparse,hashlib,json,os
from pathlib import Path
import torch
from marlowe_kernels import MoEConfig,MoEWeights,create_moe
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedConfig,CoalescedProgram
from benchmarks.moe_replay.reference import compare,expert_reference
from benchmarks.moe_replay.persistent_fp4.provenance import validate_source


def duplicate_slot_reference(weights,x,ids,rw,fused):
    """The established reference formula with duplicate-row scatter addition.

    expert_reference assumes each token selects an expert once: its indexed
    assignment overwrites repeated rows. This stress-only variant handles the
    deliberately repeated supplied expert slots using FP32 index_add_.
    """
    from benchmarks.moe_replay.reference import quantize_mxfp4,dequant_weight,bf16_atomic_operand_reference
    p={}
    for key in ('w1','w2'):
        t=weights[key];e,n,width=t.shape
        p[key]=t.view(torch.uint8).view(e,n//16,width//32,2,16,16).permute(0,1,4,2,3,5).contiguous().view(t.shape)
        s=weights[key+'_scale'];m,sn=e*n,s.shape[-1]
        p[key+'_scale']=s.view(torch.uint8).view(m//32,sn//8,4,16,2,2).permute(0,5,3,1,4,2).contiguous().view(e,n,sn)
    qx,_=quantize_mxfp4(x.float(),scale_rounding='hip_round_up')
    out=torch.zeros_like(x,dtype=torch.float32)
    for expert in range(257):
        rows,choices=torch.where(ids==expert)
        if not len(rows):continue
        w1=dequant_weight(p['w1'][expert],p['w1_scale'][expert],format='mxfp4')
        gate,up=(qx[rows]@w1.T).chunk(2,-1)
        mid=gate*torch.sigmoid(gate)*up
        if not fused:mid=mid.bfloat16()
        mid,_=quantize_mxfp4(mid,scale_rounding='flydsl_fused_0x400000' if fused else 'hip_round_up')
        w2=dequant_weight(p['w2'][expert],p['w2_scale'][expert],format='mxfp4')
        out.index_add_(0,rows,bf16_atomic_operand_reference((mid@w2.T)*rw[rows,choices,None]))
    return out.bfloat16()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--batch',type=int,default=4)
    ap.add_argument('--layer',type=int,default=3);ap.add_argument('--expert',type=int,default=17)
    ap.add_argument('--config',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();assert not a.output.exists()
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    cap=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    meta=json.loads((cap/f'b{a.batch}-s355052/capture.json').read_text())
    lid=a.layer;j=meta['layers'].index(lid)
    payload=torch.load(cap/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
    data=torch.load(cap/f'b{a.batch}-s355052/tensors.pt',map_location='cuda',weights_only=True)
    owner=create_moe(MoEConfig(),MoEWeights(*(payload[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
    entry=json.loads(a.config.read_text());entry=entry.get(str(a.batch),entry);cfg=entry.get('config',entry)
    cls,cc=CoalescedProgram,CoalescedConfig
    if entry.get('family')=='merge8':
        from marlowe_kernels._kernels.amd.glm52_moe.merge8_program import Merge8Program,Merge8Config
        cls,cc=Merge8Program,Merge8Config
    if entry.get('family')=='pair':
        from marlowe_kernels._kernels.amd.glm52_moe.pair_program import PairProgram,PairConfig
        cls,cc=PairProgram,PairConfig
    if entry.get('family')=='fixed':
        from marlowe_kernels._kernels.amd.glm52_moe.fixed_bins import FixedBinProgram,FixedBinConfig
        cls,cc=FixedBinProgram,FixedBinConfig
    if entry.get('family')=='safe_fixed':
        from marlowe_kernels._kernels.amd.glm52_moe.safe_fixed_program import SafeFixedProgram,SafeFixedConfig
        cls,cc=SafeFixedProgram,SafeFixedConfig
    program=cls(owner,a.batch,cc(**cfg))
    x=data['input'][0,j].clone();logits=data['logits'][0,j].bfloat16().contiguous();bias=payload['bias'].bfloat16()
    ids=torch.empty((a.batch,8),device='cuda',dtype=torch.int32)
    weights=torch.empty((a.batch,8),device='cuda',dtype=torch.float32)
    supplied=[]
    for name,expert_values,routing_values,scale in [
        ('all_same_expert',torch.full_like(ids,a.expert),torch.full_like(weights,2.5/8),1.),
        ('identical_top8',torch.arange(8,device='cuda',dtype=torch.int32).expand_as(ids).clone(),torch.full_like(weights,2.5/8),1.),
        ('all_zero_weights',torch.full_like(ids,251),torch.zeros_like(weights),1.),
        ('all_zero_inputs',torch.full_like(ids,a.expert),torch.full_like(weights,2.5/8),0.),
        ('changed_inputs_routes',torch.arange(a.batch*8,device='cuda',dtype=torch.int32).remainder(256).reshape_as(ids),torch.linspace(.1,.5,a.batch*8,device='cuda').reshape_as(weights),-.75),
    ]:supplied.append((name,expert_values,routing_values,data['input'][0,j]*scale))
    ids.copy_(supplied[0][1]);weights.copy_(supplied[0][2])
    call=lambda:program.run(x,logits,bias,supplied_ids=ids,supplied_weights=weights)
    for _ in range(3):call()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):out=call()
    checks=[]
    for repeat in range(2):
        for name,ii,ww,xx in supplied:
            assert int(ii.min())>=0 and int(ii.max())<256, (name,'invalid routed expert IDs')
            print('STRESS',repeat,name,flush=True)
            ids.copy_(ii);weights.copy_(ww);x.copy_(xx)
            eager=call().clone();i9=program.p['ids'].clone();w9=program.p['weights'].clone()
            ref=(duplicate_slot_reference if name=='all_same_expert' else expert_reference)(payload,x,i9,w9,program.fp32_middle)
            graph.replay();captured=out.clone();torch.cuda.synchronize()
            row=dict(name=name,repeat=repeat,reference='duplicate_slot_reference' if name=='all_same_expert' else 'expert_reference',
                eager=compare(eager,ref),graph=compare(captured,ref),
                routes_exact=bool(torch.equal(program.p['ids'][:,:8],ids)),
                weights_exact=bool(torch.equal(program.p['weights'][:,:8],weights)))
            row['passed']=row['eager']['passed'] and row['graph']['passed'] and row['routes_exact'] and row['weights_exact']
            if hasattr(program,'state_check'):
                row['state']=program.state_check();row['passed'] &= row['state']['passed']
            checks.append(row)
    result=dict(batch=a.batch,layer=lid,expert=a.expert,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),config=cfg,source_paths=validate_source(),checks=checks,passed=all(r['passed'] for r in checks))
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)
    assert result['passed']

if __name__=='__main__':main()
