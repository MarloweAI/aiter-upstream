"""Full replay with a second explicit Port-EW control from a config file."""
import hashlib,json,os
from pathlib import Path
import torch
from marlowe_kernels import create_moe
from benchmarks.moe_replay import run
from benchmarks.moe_replay.persistent_fp4 import replay

ROOT=Path(os.environ['PERSIST_ROOT'])
EXTRA=json.loads((ROOT/os.environ['PERSIST_EXTRA_CONFIGS']).read_text())

class ExtraLayer(replay.CandidateLayer):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw)
  self.selected_ref=create_moe(self.port.config,self.port.weights,implementation='native_fp4')
 def warmup(self,b):
  super().warmup(b)
  if b not in self.selected_ref._programs:
   entry=EXTRA[str(b)];program,config=replay.FAMILIES[entry['family']]
   self.selected_ref._programs[b]=program(self.selected_ref,b,config(**entry['config']))
  self.selected_ref.warmup((b,),routing='internal');self.selected_ref.warmup((b,),routing='supplied')
 def from_logits(self,x,logits,variant):
  if variant!='selected_ref':return super().from_logits(x,logits,variant)
  owner=self.selected_ref
  if logits.dtype==torch.bfloat16:out=owner(x,logits,self.bias_by_dtype[logits.dtype])
  else:
   weights,ids=self.routes(x,logits);out=owner.forward_routed(x,ids,weights)
  self.last_logits=logits;self.last_ids,self.last_weights=owner.routing(len(x))
  return out
 def expert_routed(self,x,ids,weights,variant):
  if variant!='selected_ref':return super().expert_routed(x,ids,weights,variant)
  return self.selected_ref.forward_routed(x,ids[:,:8].contiguous(),weights[:,:8].contiguous())

def main():
 original=run.main
 def add_control(argv,**kw):
  kw['port_variants']+=('selected_ref',)
  kw['runtime_identity']['extra_configs']=EXTRA
  kw['runtime_identity']['extra_adapter_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
  validate=kw['state_validator']
  def all_state(layer,b):
   result=validate(layer,b)
   program=layer.selected_ref._programs[b]
   assert not getattr(getattr(program,'cc',None),'dispatch',False),'extra control supports stateless dispatch only'
   result['selected_ref_stateless_dispatch']=True
   return result
  kw['state_validator']=all_state
  return original(argv,**kw)
 run.main=add_control;replay.CandidateLayer=ExtraLayer
 replay.main()
if __name__=='__main__':main()
