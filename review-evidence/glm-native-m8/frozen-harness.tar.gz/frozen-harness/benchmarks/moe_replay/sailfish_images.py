"""Image acquisition only. Sailfish owns builds; qualification lives here.

Runs on the Slurm host, never inside the image being built. Existing legacy
output can be adopted explicitly, but is never described as a Sailfish image.
"""
import fcntl
import json
import os
from pathlib import Path
import subprocess
from .upgrade_state import digest, file_digest, save


def command(lock, config_path, output):
    tool = lock['config']['runtime']['sailfish']
    args = [tool['uv'], 'run', 'sai', 'build', str(config_path), '--output-image', str(output)]
    for name in ('sglang', 'aiter'):
        args += ['--' + name + '.commit', lock['refs'][name]['sha']]
    return args


def validate_manifest(manifest, refs, required_stack):
    """The full parsed manifest includes patches, not just its first document."""
    for name, ref in refs.items():
        source = manifest[name]
        if source['repository'].removesuffix('.git').rstrip('/') != ref['url'].removesuffix('.git').rstrip('/'):
            raise ValueError(f'{name}: image is from a different repository')
        if source['commit'] != ref['sha']:
            raise ValueError(f'{name}: image does not contain the resolved commit')
        patch = source.get('floating_diff')
        if patch is not None:
            if not isinstance(patch, dict) or len(patch.get('text', '').encode()) != patch['bytes']:
                raise ValueError(f'{name}: missing or incomplete source patch')
        if not source.get('source_dir'):
            raise ValueError(f'{name}: source directory is required for dispatch qualification')
    for key, value in required_stack.items():
        if manifest['stack'].get(key) != value:
            raise ValueError(f'Image stack mismatch: {key}')
    if any(str(v).startswith('UNKNOWN') for v in manifest['stack'].values()):
        raise ValueError('Unresolved runtime version in image manifest')
    return manifest


def read_manifest(image):
    # Use Sailfish's own schema/parser, including its second YAML patch document.
    from common import parse_manifest
    raw = subprocess.check_output(['unsquashfs', '-cat', str(image), '.marlowe/manifest.yaml'], text=True)
    return raw, parse_manifest(raw, with_diffs=True).model_dump(mode='json')


def image_receipt(image, raw, manifest, lock, reused):
    return dict(provider='sailfish', image=str(image), image_sha256=file_digest(image),
                manifest=manifest, manifest_sha256=digest(raw), reused=reused,
                python='python3', source_dirs={k:manifest[k]['source_dir'] for k in lock['refs']},
                sailfish=lock['sailfish_identity'])


def legacy_output(lock):
    legacy = lock['config']['runtime'].get('existing_overlay')
    if not legacy or legacy['refs'] != {k:v['sha'] for k,v in lock['refs'].items()}:
        return None
    root = Path(legacy['root'])
    if not (root/'venv/bin/python').exists():return None
    sources = {}
    for name, ref in lock['refs'].items():
        folder = root/name
        head = subprocess.check_output(['git','-C',str(folder),'rev-parse','HEAD'],text=True).strip()
        if head != ref['sha']:raise RuntimeError('Existing overlay source changed: '+name)
        patch = subprocess.check_output(['git','-C',str(folder),'diff','--binary','HEAD'],text=True)
        sources[name] = dict(repository=ref['url'],commit=head,patch=patch,source_dir=str(folder))
    image = Path(legacy['image'])
    repair=root/'ffi-compatibility-repair/repair.json'
    return dict(provider='legacy-completed-overlay', image=str(image), image_sha256=file_digest(image),
                manifest=None, sources=sources, reused=True, original_build=legacy['build_evidence'],
                dependency_repairs=json.loads(repair.read_text()) if repair.exists() else None,
                python=str(root/'venv/bin/python'), source_dirs={k:v['source_dir'] for k,v in sources.items()},
                overlay_root=str(root), sailfish=None)


def acquire(lock):
    c = lock['config']; root = Path(lock['runtime_root']); root.mkdir(parents=True,exist_ok=True)
    # Independent controllers with different benchmark code share this lock.
    # The lock covers selection, build and publication, preventing duplicate builds.
    with (root/'image.lock').open('w') as guard:
        fcntl.flock(guard, fcntl.LOCK_EX)
        receipt = root/'image.json'
        if receipt.exists():
            old = json.loads(receipt.read_text())
            if file_digest(old['image']) != old['image_sha256']:
                raise RuntimeError('Previously selected image changed; preserving evidence and refusing reuse')
            return dict(old,reused=True)
        legacy = legacy_output(lock)
        if legacy:
            save(receipt,legacy)
            print('Reusing completed overlay; GPU compatibility and paired replay still required',flush=True)
            return legacy
        tool = c['runtime']['sailfish']; output = root/'runtime.sqsh'
        if c['runtime'].get('require_existing_image'):
            candidates = list(map(Path, c['runtime'].get('candidate_images', [])))
        else:
            candidates = [output, *map(Path,c['runtime'].get('candidate_images',[]))]
            candidates += sorted((Path(c['remote']['root'])/'runtimes').glob('*/runtime.sqsh'))
            for directory in c['runtime'].get('image_search_roots',[]):
                candidates += sorted(Path(directory).rglob('*.sqsh'))
        candidates = list(dict.fromkeys(candidates))
        rejected = []
        for image in candidates:
            if not image.exists():continue
            try:
                raw, manifest = read_manifest(image)
                validate_manifest(manifest,lock['refs'],c['runtime']['required_stack'])
            except (ValueError,KeyError,subprocess.CalledProcessError) as exc:
                rejected.append(dict(image=str(image),reason=str(exc)));continue
            (root/'image-manifest.yaml').write_text(raw)
            result = image_receipt(image,raw,manifest,lock,True)
            save(receipt,result);return result
        save(root/'image-candidates.json',rejected)
        if c['runtime'].get('require_existing_image'):
            raise RuntimeError('Required prebuilt image did not match the locked sources/stack; '
                               'refusing a replacement build that would omit its serving integration')
        if output.exists():raise RuntimeError('Unqualified output already exists; refusing to overwrite it')
        import yaml
        config = dict(base_image=c['runtime']['base_image'],stack=None)
        for name, ref in lock['refs'].items():
            config[name] = dict(repository=ref['url'],commit=ref['requested_ref'])
        spec = root/'image_config.yaml';spec.write_text(yaml.safe_dump(config,sort_keys=False))
        args = command(lock,spec,output)
        save(root/'build-command.json',dict(command=args,cwd=tool['directory'],sailfish=lock['sailfish_identity']))
        with (root/'sailfish-build.log').open('a') as log:
            subprocess.run(args,cwd=tool['directory'],stdout=log,stderr=subprocess.STDOUT,check=True)
        raw, manifest = read_manifest(output)
        validate_manifest(manifest,lock['refs'],c['runtime']['required_stack'])
        sidecar = Path(str(output)+'.yaml')
        if not sidecar.exists() or sidecar.read_text()!=raw:
            raise RuntimeError('Sailfish sidecar and embedded manifest differ')
        (root/'image-manifest.yaml').write_text(raw)
        result = image_receipt(output,raw,manifest,lock,False)
        save(receipt,result);return result
