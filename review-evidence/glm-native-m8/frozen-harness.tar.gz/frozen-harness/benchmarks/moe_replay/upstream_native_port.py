"""Source-pinned native stage2 and coupled full-operator candidate factories.

Baseline remains the pristine public operator. Candidate selection is immutable
before graph capture; no global dispatcher switch changes between arms.
"""

import hashlib
import importlib
import json
import subprocess
from pathlib import Path

from .upstream_contract import CONCURRENCIES, QualificationFailure, file_digest


def read_manifest(path):
    value = json.loads(Path(path).read_text())
    required = (
        "schema",
        "unit",
        "aiter_base_sha",
        "aiter_feature_sha",
        "patch_sha256",
        "source_files",
        "concurrencies",
        "fallback",
        "expected_kernel_marker",
        "unchanged_source_files",
        "harness_files",
    )
    if any(key not in value for key in required) or value["schema"] not in (1, 2):
        raise ValueError("Incomplete native-port manifest")
    for key in ("aiter_base_sha", "aiter_feature_sha"):
        if len(value[key]) != 40 or any(
            c not in "0123456789abcdef" for c in value[key]
        ):
            raise ValueError("Source pins must be full commit SHAs")
    if not value["source_files"] or not value["expected_kernel_marker"]:
        raise ValueError("Source/JIT identity cannot be empty")
    if not value["concurrencies"] or any(
        c not in CONCURRENCIES for c in value["concurrencies"]
    ):
        raise ValueError("Invalid native-port domain")
    if len(set(value["concurrencies"])) != len(value["concurrencies"]):
        raise ValueError("Duplicate native-port shape")
    if set(map(int, value["fallback"])) != set(CONCURRENCIES) - set(
        value["concurrencies"]
    ):
        raise ValueError("Every ineligible shape needs explicit fallback evidence")
    mandatory = {
        f"benchmarks/moe_replay/{name}"
        for name in (
            "upstream_campaign.py",
            "upstream_native_port.py",
            "upstream_native_stage2.py",
            "reference.py",
            "upstream_reference.py",
        )
    }
    if not mandatory <= set(value["harness_files"]):
        raise ValueError("Native runner, helpers and oracle must be frozen")
    for name in value["source_files"]:
        if Path(name).is_absolute() or ".." in Path(name).parts:
            raise ValueError("Source paths must stay inside AITER")
    kind = value.get("selection_kind", "stage2")
    if kind not in ("stage2", "full_operator"):
        raise ValueError("Unknown native selection kind")
    factory_key = "operator_factory" if kind == "full_operator" else "stage2_factory"
    kwargs_key = "operator_kwargs" if kind == "full_operator" else "stage2_kwargs"
    if not isinstance(value.get(factory_key), str) or not value[factory_key].startswith(
        "aiter."
    ):
        raise ValueError("Native factory must come from pinned AITER")
    if not isinstance(value.get(kwargs_key), dict):
        raise ValueError("Native static factory kwargs are required")
    if kind == "full_operator":
        if value["schema"] != 2 or not isinstance(
            value.get("reference_contract"), dict
        ):
            raise ValueError("Full operator needs versioned native arithmetic contract")
        if set(value[kwargs_key]) & {"weights", "rows"}:
            raise ValueError(
                "Static kwargs cannot override captured weights or actual rows"
            )
    markers = value.get("expected_kernel_markers", [value["expected_kernel_marker"]])
    if not markers or any(
        not isinstance(marker, str) or not marker for marker in markers
    ):
        raise ValueError("Candidate kernel markers cannot be empty")
    return value


def validate_source(manifest, root):
    root = Path(root).resolve()

    def git(*args):
        return subprocess.check_output(["git", "-C", str(root), *args])

    if git("rev-parse", "HEAD").decode().strip() != manifest["aiter_feature_sha"]:
        raise QualificationFailure("Native feature revision mismatch")
    if git("status", "--porcelain", "--untracked-files=no").strip():
        raise QualificationFailure("Native AITER source has tracked edits")
    patch = git(
        "diff", "--binary", manifest["aiter_base_sha"], manifest["aiter_feature_sha"]
    )
    if hashlib.sha256(patch).hexdigest() != manifest["patch_sha256"]:
        raise QualificationFailure("Native patch identity mismatch")
    for name, expected in manifest["source_files"].items():
        if file_digest(root / name) != expected:
            raise QualificationFailure(f"Native source mismatch: {name}")
    for name in manifest["unchanged_source_files"]:
        pristine = git("show", f"{manifest['aiter_base_sha']}:{name}")
        if (root / name).read_bytes() != pristine:
            raise QualificationFailure(f"Pristine native helper changed: {name}")
    return True


def _factory(manifest, root, key):
    module_name, name = manifest[key].rsplit(".", 1)
    module = importlib.import_module(module_name)
    source = Path(module.__file__).resolve()
    if not source.is_relative_to(Path(root).resolve()):
        raise QualificationFailure("Native override imported outside pinned source")
    relative = str(source.relative_to(Path(root).resolve()))
    if relative not in manifest["source_files"]:
        raise QualificationFailure("Native override source is absent from manifest")
    return getattr(module, name)


def make_callback(manifest, root):
    callback = _factory(manifest, root, "stage2_factory")(**manifest["stage2_kwargs"])
    if not callable(callback):
        raise QualificationFailure("Native factory did not return a callable")
    return callback


class NativeOperator:
    """A coupled candidate consumes complete supplied native routes."""

    native_source_operator = True

    def __init__(self, operator, manifest, rows):
        self.operator = operator
        self.reference_contract = operator.reference_contract
        self.info = {
            **operator.info,
            "backend": "source-pinned coupled native operator",
            "operator_factory": manifest["operator_factory"],
            "static_kwargs": manifest["operator_kwargs"],
            "rows": rows,
            "reference_contract": self.reference_contract,
        }

    def run(self, x, ids, weights):
        return self.operator.run(x, ids, weights)

    def state_check(self):
        state = self.operator.state_check()
        if not isinstance(state, dict) or not isinstance(state.get("passed"), bool):
            raise QualificationFailure("Native operator state receipt is malformed")
        return state


def make_operator(manifest, root, weights, rows, native_reference_contract):
    if manifest["reference_contract"] != native_reference_contract:
        raise QualificationFailure(
            "Manifest differs from observed native arithmetic contract"
        )
    operator = _factory(manifest, root, "operator_factory")(
        weights=weights, rows=rows, **manifest["operator_kwargs"]
    )
    if not callable(getattr(operator, "run", None)) or not callable(
        getattr(operator, "state_check", None)
    ):
        raise QualificationFailure("Coupled native factory lacks run/state interface")
    if not isinstance(getattr(operator, "info", None), dict):
        raise QualificationFailure("Coupled native factory lacks source/dispatch info")
    if getattr(operator, "reference_contract", None) != native_reference_contract:
        raise QualificationFailure(
            "Coupled native operator differs from native arithmetic contract"
        )
    return NativeOperator(operator, manifest, rows)


def coverage(manifest):
    rows = []
    for c in CONCURRENCIES:
        if c in manifest["concurrencies"]:
            continue
        reason = manifest["fallback"][str(c)]
        failed_native = c == 64
        rows.append(
            {
                "group": manifest["unit"],
                "concurrency": c,
                "status": "historical_native_gate_failed"
                if failed_native
                else "not_applicable",
                "identical_dispatch": not failed_native,
                "reason": reason,
                "timing": "not rerun; native dispatch unchanged",
            }
        )
    return rows


def check_engagement(manifest, profiles):
    """Actual full-operator kernels, not canonical metadata, establish execution."""
    markers = manifest.get(
        "expected_kernel_markers", [manifest["expected_kernel_marker"]]
    )
    baseline = [k["name"] for k in profiles["baseline"]["kernels"]]
    candidate = [k["name"] for k in profiles["candidate"]["kernels"]]
    if not baseline or not candidate:
        raise QualificationFailure("No visible GPU kernels for dispatch proof")
    if any(marker in name for marker in markers for name in baseline) or not all(
        any(marker in name for name in candidate) for marker in markers
    ):
        raise QualificationFailure(
            "Native candidate did not engage its distinct kernel"
        )
    return {
        "passed": True,
        "markers": markers,
        "baseline_kernels": baseline,
        "candidate_kernels": candidate,
    }


def validate_harness(manifest, root):
    root = Path(root).resolve()
    for name, expected in manifest["harness_files"].items():
        path = Path(name)
        if (
            path.is_absolute()
            or ".." in path.parts
            or file_digest(root / path) != expected
        ):
            raise QualificationFailure(f"Native harness source mismatch: {name}")
    return True
