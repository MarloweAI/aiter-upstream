"""Replay preselected static/oracle/routing-policy schedules with zero selector cost."""
import argparse
import hashlib
import json
from pathlib import Path
import random
import statistics as st
import sys

PLANS=None


def evaluate(pairs,routes,references,setup,output,batch):
    import torch
    import triton
    from .events import Event
    from .kernels import touch_input
    from .reference import compare
    from .route_tune import baseline,name,variants
    from .route_policy import predict
    from .upgrade_state import save
    plan_path=PLANS/f'policy-b{batch}.json'
    plan=json.loads(plan_path.read_text())
    assert hashlib.sha256(json.dumps(routes,sort_keys=True).encode()).hexdigest()==plan['sequence_sha256']
    n=len(pairs);stock=name(baseline(pairs[0]))
    selections=dict(stock=[stock]*n,static=[plan['static_candidate']]*n,
        trained_static=[plan['policy']['training_static']]*n,
        oracle=plan['oracle_choices'],policy=[predict(plan['policy']['rule'],r) for r in routes])
    assert selections['policy']==plan['policy_choices']
    # Identical schedules share a graph and samples; do not repeat an arm merely
    # because it has a different label (e.g. a constant policy).
    canonical={};aliases={};graphs={};checks={}
    for arm,choices in selections.items():
        key=tuple(choices)
        if key in canonical:aliases[arm]=canonical[key];continue
        canonical[key]=arm
        calls=[variants(p,plan['candidate_configs'][c]) for p,c in zip(pairs,choices)]
        for fn1,k1,fn2,k2 in calls:fn1(**k1);fn2(**k2)
        torch.cuda.synchronize()
        events=[(Event(),Event()) for _ in pairs]
        sink=torch.empty((384,),device='cuda')
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for pair,(fn1,k1,fn2,k2),(start,end) in zip(pairs,calls,events):
                x=pair['x']
                touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                for field in ('sorted_expert_ids','cumsum_tensor','m_indices'):
                    v=k1.get(field)
                    if isinstance(v,torch.Tensor) and v.numel():
                        touch_input[(triton.cdiv(v.numel(),1024),)](v,sink,v.numel(),1024)
                start.record();fn1(**k1);fn2(**k2);end.record()
        setup.replay();graph.replay();torch.cuda.synchronize()
        checks[arm]=[compare(p['out'].reshape_as(r),r) for p,r in zip(pairs,references)]
        save(output/f'validation-b{batch}-{arm}.json',checks[arm])
        assert all(c['passed'] for c in checks[arm]),arm
        graphs[arm]=(graph,events,sink,calls)
    for graph,*_ in graphs.values():
        for _ in range(5):setup.replay();graph.replay()
    torch.cuda.synchronize()
    samples={arm:[] for arm in graphs};rng=random.Random(355052)
    for _ in range(30):
        order=list(graphs);rng.shuffle(order)
        for arm in order:
            graph,events,*_=graphs[arm]
            setup.replay();graph.replay();torch.cuda.synchronize()
            samples[arm].append([s.elapsed_us(e) for s,e in events])
    results={arm:dict(samples_us=rows,medians_us=[st.median(r[i] for r in rows) for i in range(n)])
             for arm,rows in samples.items()}
    for arm,source in aliases.items():results[arm]=dict(alias=source,**results[source])
    report=dict(batch=batch,sequence=routes,plans_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
        worker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),checks=checks,aliases=aliases,
        timing=results,selections=selections,holdout_indices=plan['holdout_indices'],complete=True,
        scope='All selections are made offline before capture. Measures mixed kernel/cache effects but charges zero selection cost. Not a GPU runtime dispatcher.')
    save(output/f'evaluation-b{batch}.json',report)
    return report


def main():
    global PLANS
    p=argparse.ArgumentParser();p.add_argument('--plans',type=Path,required=True)
    a,rest=p.parse_known_args();PLANS=a.plans
    from . import profile_bandwidth
    profile_bandwidth.probes=evaluate
    sys.argv=[sys.argv[0],*rest,'--mode','probes']
    profile_bandwidth.main()


if __name__=='__main__':main()
