"""Replay real GLM-5.2 MTP target-verification MoE inputs.

The target model flattens ``request_batch * draft_tokens`` candidate rows.  This
driver compares the SGLang/AITER path with Port-EW BF16 or FP32 internal routing.
It keeps the router GEMM inside the measured interval and uses each captured
target layer's real TP8 weights.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import statistics

from .upgrade_state import save


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--model',type=Path,required=True)
    p.add_argument('--source-digest',required=True)
    p.add_argument('--request-batches',type=int,nargs='+',default=[1,2,4,8,16,32,64])
    p.add_argument('--draft-tokens',type=int,default=4)
    p.add_argument('--port-router',choices=('fp32','bf16'),default='fp32')
    p.add_argument('--samples',type=int,default=40)
    p.add_argument('--warmups',type=int,default=10)
    p.add_argument('--reference-layers',type=int,nargs='*',default=[])
    p.add_argument('--reference-steps',type=int,nargs='*',default=[])
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    assert os.environ.get('SLURM_JOB_ID') and a.draft_tokens>0
    import torch
    import triton
    from marlowe_kernels._runtime import source_digest
    from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS
    from marlowe_kernels._kernels.amd.glm52_moe.safe_fixed_program import SafeFixedConfig,SafeFixedProgram
    from .backend import Layer
    from .events import Event
    from .kernels import touch_input
    from .reference import compare,expert_reference
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    from sglang.srt.layers.moe.utils import initialize_moe_config
    assert torch.cuda.device_count()==1 and source_digest()==a.source_digest
    torch.set_num_threads(4);torch.set_grad_enabled(False);torch.backends.cuda.matmul.allow_tf32=False
    fp32=a.port_router=='fp32'
    routing='internal_fp32' if fp32 else 'internal'
    def programs(owner):return owner._fp32_programs if fp32 else owner._programs
    set_global_server_args_for_scheduler(ServerArgs(model_path=str(a.model),tp_size=8,ep_size=1,
        dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    initialize_moe_config()
    init_distributed_environment(world_size=1,rank=0,local_rank=0,
        distributed_init_method='file://'+str(a.output/f'rendezvous-{os.getpid()}'),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    parallel=get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,
                                     tp_size=8,moe_tp_size=8,moe_ep_size=1)
    parallel.__enter__()

    def prepare_internal(layer,b):
        owner=layer.port
        if b<=64:
            owner.warmup((b,),routing=routing)
            return programs(owner)[b]
        config=SafeFixedConfig(**BANDWIDTH_CONFIGS[64]['config'])
        program=SafeFixedProgram(owner,b,config);program.router_fp32=fp32
        x=torch.zeros((b,6144),device='cuda',dtype=torch.bfloat16)
        router_dtype=torch.float32 if fp32 else torch.bfloat16
        logits=torch.zeros((b,256),device='cuda',dtype=router_dtype)
        bias=torch.zeros(256,device='cuda',dtype=router_dtype)
        program.run(x,logits,bias)
        programs(owner)[b]=program;owner._prepared_modes.add((b,routing))
        torch.cuda.synchronize()
        return program

    identity=dict(job=os.environ['SLURM_JOB_ID'],source_digest=source_digest(),
                  benchmark_sha256=sha(__file__),capture=str(a.capture),draft_tokens=a.draft_tokens,
                  request_batches=a.request_batches,samples=a.samples,warmups=a.warmups,
                  interval='router GEMM through local combine',experimental_batches=[128,256],
                  port_router=a.port_router)
    save(a.output/'identity.json',identity)
    layers={};rows=[]
    for request_batch in a.request_batches:
        b=request_batch*a.draft_tokens
        source=a.capture/f'c{request_batch}-d{a.draft_tokens}-s355052'
        meta=json.loads((source/'capture.json').read_text())
        assert meta['forward_mode']=='target_verify' and meta['layers']
        assert all(s['draft_token_num']==a.draft_tokens and 0<s['actual_token_count']<=b and
                   s['actual_token_count']==s['graph_rows'] for s in meta['steps']),meta['steps']
        data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
        assert data['input'].shape[2]>=b
        active_moe_rows=sorted({s['actual_token_count'] for s in meta['steps']})
        sequence=[]
        for slot,step in enumerate(meta['steps']):
            for layer_index,lid in enumerate(meta['layers']):
                sequence.append((slot,step['decode_step'],layer_index,lid))
                if lid not in layers:
                    payload=torch.load(a.capture/'weights'/f'layer-{lid}.pt',weights_only=True)
                    layers[lid]=Layer(payload,lid)
                prepare_internal(layers[lid],b)
        checks=[];bundle=[]
        reference_layers=set(a.reference_layers or meta['layers'])
        reference_steps=set(a.reference_steps or [s['decode_step'] for s in meta['steps']])
        for slot,step,layer_index,lid in sequence:
            layer=layers[lid];owner=layer.port
            x=data['input'][slot,layer_index,:b]
            captured_logits=data['logits'][slot,layer_index,:b].contiguous()
            captured_ids=data['ids'][slot,layer_index,:b]
            captured_weights=data['routing_weights'][slot,layer_index,:b]
            captured_output=data['output'][slot,layer_index,:b]
            native_logits=layer.gate(x)
            assert native_logits.dtype==torch.bfloat16 and native_logits.is_contiguous()
            logit_error=float((native_logits.float()-captured_logits).abs().max())
            native=layer.from_logits(x,native_logits,'aiter').clone()
            native_ids,native_weights=layer.last_ids.clone(),layer.last_weights.clone()
            logits=((x.float()@layer.gate.weight.detach().float().T).contiguous()
                    if fp32 else native_logits)
            port=(owner.forward_fp32(x,logits,layer.bias_by_dtype[torch.float32]) if fp32
                  else owner(x,logits,layer.bias_by_dtype[torch.bfloat16])).clone()
            port_ids,port_weights=(v.clone() for v in owner.routing(b,routing=routing))
            native_sorted=native_ids[:,:8].sort(1).values
            captured_sorted=captured_ids[:,:8].sort(1).values
            row=dict(layer=lid,step=step,logit_max_abs=logit_error,
                     captured_native=compare(native,captured_output),
                     captured_routes_exact=bool(torch.equal(native_ids,captured_ids) and
                                                torch.equal(native_weights,captured_weights)),
                     captured_changed_route_slots=int((native_ids!=captured_ids).sum()),
                     captured_changed_route_sets=int((native_sorted!=captured_sorted).any(1).sum()),
                     changed_route_slots=int((native_ids!=port_ids).sum()),
                     changed_route_tokens=int((native_ids!=port_ids).any(1).sum()))
            if lid in reference_layers and step in reference_steps:
                program=programs(owner)[b]
                port_ref=expert_reference(layer.weights,x,port_ids,port_weights,program.fp32_middle)
                row.update(port_reference=compare(port,port_ref))
                if not row['port_reference']['passed']:
                    torch.save(dict(input=x.cpu(),logits=logits.cpu(),native=native.cpu(),port=port.cpu(),
                        native_ids=native_ids.cpu(),native_weights=native_weights.cpu(),
                        port_ids=port_ids.cpu(),port_weights=port_weights.cpu(),
                        port_reference=port_ref.cpu()),
                        a.output/f'failure-c{request_batch}-b{b}-l{lid}-s{step}.pt')
            checks.append(row);bundle.append((x,layer))
        save(a.output/f'c{request_batch}-checks.json',checks)
        save(a.output/f'c{request_batch}-capture-replay-differences.json',
             [r for r in checks if not r['captured_native']['passed'] or not r['captured_routes_exact']])

        def invoke(name,x,layer):
            if name=='aiter':return layer.from_logits(x,layer.gate(x),'aiter')
            if fp32:
                logits=(x.float()@layer.gate.weight.detach().float().T).contiguous()
                return layer.port.forward_fp32(x,logits,layer.bias_by_dtype[torch.float32])
            return layer.port(x,layer.gate(x),layer.bias_by_dtype[torch.bfloat16])

        graph_checks={}
        for name in ('aiter','port_internal'):
            graph=torch.cuda.CUDAGraph();captured=[]
            with torch.cuda.graph(graph):
                for x,layer in bundle:captured.append(invoke(name,x,layer).clone())
            for _ in range(3):graph.replay()
            torch.cuda.synchronize()
            values=[]
            for index,(output,(slot,step,layer_index,lid)) in enumerate(zip(captured,sequence)):
                expected=data['output'][slot,layer_index,:b] if name=='aiter' else None
                if name=='port_internal':
                    layer=layers[lid];x=data['input'][slot,layer_index,:b]
                    owner=layer.port
                    if fp32:
                        logits=(x.float()@layer.gate.weight.detach().float().T).contiguous()
                        eager=owner.forward_fp32(x,logits,layer.bias_by_dtype[torch.float32]).clone()
                    else:eager=owner(x,layer.gate(x),layer.bias_by_dtype[torch.bfloat16]).clone()
                    expected=eager
                check=compare(output,expected);values.append(check)
            graph_checks[name]=values;del graph,captured
        save(a.output/f'c{request_batch}-graph-checks.json',graph_checks)

        graphs={};sink=torch.empty((triton.cdiv(256*6144,1024),),device='cuda')
        for name in ('aiter','port_internal'):
            markers=[(Event(),Event()) for _ in bundle];graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                for (x,layer),(start,end) in zip(bundle,markers):
                    touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                    start.record();invoke(name,x,layer);end.record()
            graphs[name]=dict(graph=graph,pairs=markers,sink=sink)
        for item in graphs.values():
            for _ in range(a.warmups):item['graph'].replay()
        torch.cuda.synchronize();rng=random.Random(355052)
        samples={name:[] for name in graphs}
        for _ in range(a.samples):
            order=list(graphs);rng.shuffle(order)
            for name in order:
                item=graphs[name];item['graph'].replay();torch.cuda.synchronize()
                samples[name].append([s.elapsed_us(e) for s,e in item['pairs']])
        timing={name:[statistics.median(sample[i] for sample in values)
                      for i in range(len(sequence))] for name,values in samples.items()}
        latency={name:statistics.mean(values) for name,values in timing.items()}
        result=dict(request_batch=request_batch,moe_batch=b,active_moe_rows=active_moe_rows,
                    cases=len(sequence),identity=identity,
                    latency_us=latency,timing=timing,checks=checks,
                    graph_checks_passed={k:all(v['passed'] for v in values) for k,values in graph_checks.items()},
                    program=programs(layers[meta['layers'][0]].port)[b].info)
        save(a.output/f'c{request_batch}.json',result);rows.append(result)
        print(json.dumps(dict(request_batch=request_batch,moe_batch=b,latency_us=latency,cases=len(sequence))),flush=True)
        del graphs,data,bundle;torch.cuda.empty_cache()
    save(a.output/'summary.json',dict(identity=identity,rows=[dict(request_batch=r['request_batch'],
        moe_batch=r['moe_batch'],active_moe_rows=r['active_moe_rows'],cases=r['cases'],
        latency_us=r['latency_us'],program=r['program']) for r in rows]))
    parallel.__exit__(None,None,None)
    torch.distributed.destroy_process_group()


if __name__=='__main__':main()
