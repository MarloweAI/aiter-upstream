"""Targeted public-API checks for promoting the selected Port-EW programs.

Reuses captured inputs/weights and the independent numerical reference. No
model server, new capture, performance sweep, or eight-GPU allocation is needed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--layers',type=int,nargs='+',default=[3,40,77])
    p.add_argument('--steps',type=int,nargs='+',default=[0,1,7,15])
    p.add_argument('--batches',type=int,nargs='+',default=[1,2,4,8,16,32,64])
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    import torch
    from marlowe_kernels import MoEConfig,MoEWeights,create_moe
    from marlowe_kernels._runtime import source_digest
    from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS as SELECTED_CONFIGS, BANDWIDTH_REVISION as SELECTION_REVISION
    from .reference import expert_reference,compare
    from .protocol import load_metadata
    from .upgrade_state import save
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    owners={};legacy={};weights={};biases={};results=[]
    for lid in a.layers:
        payload=torch.load(a.capture/'weights'/f'layer-{lid}.pt',weights_only=True)
        w={k:payload[k].cuda() for k in ('w1','w2','w1_scale','w2_scale')}
        weights[lid]=w;biases[lid]=payload['bias'].cuda().bfloat16().contiguous()
        packed=MoEWeights(w['w1'],w['w2'],w['w1_scale'],w['w2_scale'])
        owners[lid]=create_moe(MoEConfig(),packed)
        assert owners[lid].implementation=='port_ew'
        legacy[lid]=create_moe(MoEConfig(),packed,implementation='bf16')
    assert set(a.batches) <= set(SELECTED_CONFIGS)
    for b in a.batches:
        source=a.capture/f'b{b}-s355052'
        meta=load_metadata(source)
        data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
        for lid in a.layers:
            owner=owners[lid];old=legacy[lid];j=meta['layers'].index(lid)
            owner.warmup((b,),routing='internal');owner.warmup((b,),routing='supplied')
            old.warmup((b,),routing='internal')
            program=owner._programs[b]
            expected={'overlap_g1':'OverlapG1Program','pair':'SafePairProgram',
                      'safe_fixed':'SafeFixedProgram'}[SELECTED_CONFIGS[b]['family']]
            assert type(program).__name__==expected
            for mode in ('internal','supplied'):
                x=torch.empty((b,6144),device='cuda',dtype=torch.bfloat16)
                logits=torch.empty((b,256),device='cuda',dtype=torch.bfloat16)
                ids=torch.empty((b,8),device='cuda',dtype=torch.int32)
                rw=torch.empty((b,8),device='cuda',dtype=torch.float32)
                out=torch.empty_like(x)
                def update(slot):
                    x.copy_(data['input'][slot,j,:b])
                    logits.copy_(data['logits'][slot,j,:b].bfloat16())
                    ids.copy_(data['ids'][slot,j,:b,:8]);rw.copy_(data['routing_weights'][slot,j,:b,:8])
                def call(custom_out=True):
                    if mode=='internal':return owner(x,logits,biases[lid],out=out if custom_out else None)
                    return owner.forward_routed(x,ids,rw,out=out if custom_out else None)
                update(0);call();torch.cuda.synchronize()
                graph=torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):call()
                for slot in a.steps:
                    step=meta['steps'][slot]
                    assert step['actual_token_count']==step['scheduled_rows']==step['graph_rows']==b
                    update(slot)
                    out.fill_(float('nan'));eager=call().clone()
                    actual_ids,actual_weights=owner.routing(b,routing=mode)
                    actual_ids,actual_weights=actual_ids.clone(),actual_weights.clone()
                    if mode=='internal':
                        old(x,logits,biases[lid])
                        expected_ids,expected_weights=old.routing(b)
                    else:
                        expected_ids=torch.cat((ids,torch.full((b,1),256,device='cuda',dtype=torch.int32)),1)
                        expected_weights=torch.cat((rw,torch.ones((b,1),device='cuda')),1)
                    assert torch.equal(actual_ids,expected_ids)
                    assert torch.equal(actual_weights,expected_weights)
                    ref=expert_reference(weights[lid],x,actual_ids,actual_weights,b in (1,4,8,32))
                    row=dict(batch=b,layer=lid,step=slot,routing=mode,program=expected,
                             eager=compare(eager,ref),exact_routes=True)
                    for _ in range(7):
                        out.fill_(float('nan'));graph.replay()
                    torch.cuda.synchronize()
                    row['graph']=compare(out,ref)
                    gi,gw=owner.routing(b,routing=mode)
                    row['graph_routes']=bool(torch.equal(gi,actual_ids) and torch.equal(gw,actual_weights))
                    # Both caller-owned and default reusable output buffers work.
                    row['default_output']=compare(call(custom_out=False),ref)
                    state=getattr(program,'state',None)
                    if callable(getattr(program,'state_check',None)):
                        row['dispatch_state_clean']=program.state_check()['passed']
                    elif getattr(getattr(program,'cc',None),'dispatch',False):
                        status=state.cpu()
                        row['dispatch_state_clean']=int(status[-1])==0 and not bool(status[4:-1].any())
                    x.zero_();out.fill_(float('nan'));graph.replay();torch.cuda.synchronize()
                    row['zero_input_clears_output']=bool((out==0).all())
                    if callable(getattr(program,'state_check',None)):
                        row['dispatch_state_clean']=row.get('dispatch_state_clean',True) and program.state_check()['passed']
                    elif getattr(getattr(program,'cc',None),'dispatch',False):
                        status=state.cpu()
                        row['dispatch_state_clean']=row['dispatch_state_clean'] and int(status[-1])==0 and not bool(status[4:-1].any())
                    row['passed']=all(v.get('passed',False) if isinstance(v,dict) else v
                        for k,v in row.items() if k in ('eager','graph','default_output','graph_routes','dispatch_state_clean','zero_input_clears_output'))
                    results.append(row)
                    save(a.output/'checks.json',results)
                    assert row['passed'],row
                print(json.dumps(dict(batch=b,layer=lid,routing=mode,passed=True)),flush=True)
                del graph
        del data
    # Inference guards still reject unsupported batches before launching work.
    for owner in owners.values():
        from marlowe_kernels import UnsupportedConfiguration
        try:owner.warmup((3,))
        except UnsupportedConfiguration:pass
        else:raise AssertionError('Unsupported batch was accepted')
    save(a.output/'summary.json',dict(passed=True,cases=len(results),batches=a.batches,
        layers=a.layers,steps=a.steps,routing_modes=['internal','supplied'],graph_repeats=7,
        implementation='port_ew',selection_revision=SELECTION_REVISION,library_source=source_digest(),
        driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        job=os.environ['SLURM_JOB_ID'],gpu=torch.cuda.get_device_name(),torch=torch.__version__,hip=torch.version.hip,
        coverage='Public factory, selected programs, exact routing, independent outputs, supplied routes, output overrides, changing inputs/routes, repeated graphs, zero input, metadata reset and unsupported-batch guard. Existing full kernel qualification reused. No serving or performance rerun.'))


if __name__=='__main__':main()
