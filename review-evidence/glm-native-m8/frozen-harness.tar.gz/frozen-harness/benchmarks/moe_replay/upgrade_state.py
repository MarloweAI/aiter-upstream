"""CPU-only identities and fail-closed reuse decisions for runtime upgrades."""
import hashlib
import json
from pathlib import Path

SCHEMA = 1
BACKENDS = ('aiter', 'port_ew')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(8*1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def validate_config(c):
    if c.get('schema_version') != SCHEMA:
        raise ValueError('Unsupported configuration schema')
    if tuple(c.get('backends', [])) != BACKENDS:
        raise ValueError('This workflow must compare both aiter and port_ew')
    if c['topology'] != dict(tp=8, ep=1, rank=0, gpu='gfx950'):
        raise ValueError('Only GLM-5.2 MXFP4 MI355X TP8/EP1 rank 0 is qualified')
    if not c['batches'] or any(b not in (1,2,4,8,16,32,64) for b in c['batches']):
        raise ValueError('Unsupported batch sizes')
    if len(set(c['batches'])) != len(c['batches']):
        raise ValueError('Duplicate batches')
    for key in ('model','capture','data'):
        if not Path(c[key]).is_absolute():
            raise ValueError(f'{key} must be an absolute path on the worker')
    if c['samples'] < 2 or c['warmups'] < 1:
        raise ValueError('At least two timing samples and one warmup are required')
    return c


def plan_reuse(previous, current, batches):
    """Reuse only evidence bound to matching executable inputs; no filename heuristics.

    A runtime/source/compiler change invalidates every batch. With identical
    executable source and ABI, a newly audited tuning selection may invalidate
    only the batches it actually changes. Data/case identities remain per batch.
    """
    decisions = {}
    for b in batches:
        key = str(b)
        reason = 'no previously validated evidence'
        reuse = False
        if previous and previous.get('passed'):
            shared = ('execution_source', 'dependencies', 'hardware', 'settings', 'benchmark_source')
            changed = [k for k in shared if previous.get(k) != current.get(k)]
            old, new = previous.get('batches', {}).get(key), current.get('batches', {}).get(key)
            if changed:
                reason = 'shared identity changed: ' + ', '.join(changed)
            elif not old or not old.get('passed') or not new or not new.get('dispatch_verified'):
                reason = 'missing successful dispatch/correctness evidence'
            elif any(old.get(k) != new.get(k) for k in ('data', 'weights', 'dispatch')):
                reason = 'batch inputs, weights or audited dispatch changed'
            elif not old.get('result_path') or not old.get('result_sha256'):
                reason = 'previous result lacks an integrity receipt'
            else:
                reuse = True
                reason = 'same executable source, ABI, hardware, settings, data, weights and audited dispatch'
        decisions[key] = dict(reuse=reuse, reason=reason)
    return decisions
