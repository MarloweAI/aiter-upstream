"""Fit a tiny offline routing policy and estimate its zero-overhead headroom."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics as st


FEATURES=('tiles','active_experts','max_routed_count','singleton_routed_experts','effective_routed_experts')


def features(row):
    counts=row['counts'][:256]
    total=sum(counts)
    return dict(tiles=row['tiles'],active_experts=row['active_experts'],
        max_routed_count=max(counts),singleton_routed_experts=sum(n==1 for n in counts),
        effective_routed_experts=total*total/sum(n*n for n in counts))


def best_static(costs, indices):
    return min(costs,key=lambda k:sum(costs[k][i] for i in indices))


def train_rule(rows, costs, indices, min_leaf=20, min_gain_us=0.1):
    """One threshold, two kernel IDs; directly minimize measured latency."""
    static=best_static(costs,indices)
    best=dict(kind='constant',candidate=static)
    initial=sum(costs[static][i] for i in indices)
    best_total=initial
    xs=[features(r) for r in rows]
    for feature in FEATURES:
        order=sorted(indices,key=lambda i:xs[i][feature])
        totals={k:sum(v[i] for i in order) for k,v in costs.items()}
        prefix={k:0. for k in costs}
        for pos,i in enumerate(order[:-1],1):
            for k in costs:prefix[k]+=costs[k][i]
            if pos<min_leaf or len(order)-pos<min_leaf:continue
            lo,hi=xs[i][feature],xs[order[pos]][feature]
            if lo==hi:continue
            left=min(costs,key=lambda k:prefix[k])
            right=min(costs,key=lambda k:totals[k]-prefix[k])
            total=prefix[left]+totals[right]-prefix[right]
            if total<best_total:
                best_total=total
                best=dict(kind='threshold',feature=feature,threshold=(lo+hi)/2,
                          le=left,gt=right,left_examples=pos,right_examples=len(order)-pos)
    gain=(initial-best_total)/len(indices)
    if gain<min_gain_us:best=dict(kind='constant',candidate=static)
    return dict(rule=best,training_static=static,training_gain_us=gain,
                min_leaf=min_leaf,min_gain_us=min_gain_us)


def predict(rule,row):
    if rule['kind']=='constant':return rule['candidate']
    return rule['le'] if features(row)[rule['feature']]<=rule['threshold'] else rule['gt']


def medians(samples, start, end):
    rows=samples[start:end]
    return [st.median(r[i] for r in rows) for i in range(len(rows[0]))]


def analyze(data):
    assert data['complete'] and data['phase']=='sweep'
    rows=data['sequence']
    valid={k:v for k,v in data['candidates'].items() if v['passed']}
    assert valid and all(len(v['samples_us'])==data['samples'] for v in valid.values())
    half=data['samples']//2
    calibration={k:medians(v['samples_us'],0,half) for k,v in valid.items()}
    evaluation={k:medians(v['samples_us'],half,data['samples']) for k,v in valid.items()}
    all_indices=list(range(len(rows)))
    train=[i for i,r in enumerate(rows) if r['layer_index']%2==0 and r['decode_step']<8]
    holdout=[i for i,r in enumerate(rows) if r['layer_index']%2==1 and r['decode_step']>=8]
    assert train and holdout
    assert not ({rows[i]['layer'] for i in train}&{rows[i]['layer'] for i in holdout})
    static=best_static(calibration,all_indices)
    oracle=[min(calibration,key=lambda k:calibration[k][i]) for i in all_indices]
    fitted=train_rule(rows,calibration,train)
    policy=[predict(fitted['rule'],r) for r in rows]
    stock=json.dumps(data['baseline'],sort_keys=True,separators=(',',':'))
    def score(indices, choices):return st.mean(evaluation[choices[i]][i] for i in indices)
    full=dict(stock_us=score(all_indices,[stock]*len(rows)),
              static_us=score(all_indices,[static]*len(rows)),oracle_us=score(all_indices,oracle))
    full['oracle_headroom_us']=full['static_us']-full['oracle_us']
    full['oracle_reduction_pct']=100*full['oracle_headroom_us']/full['static_us']
    trained_static=fitted['training_static']
    held=dict(cases=len(holdout),trained_static_us=score(holdout,[trained_static]*len(rows)),
              global_static_us=score(holdout,[static]*len(rows)),policy_us=score(holdout,policy),
              oracle_us=score(holdout,oracle))
    held['policy_gain_us']=held['trained_static_us']-held['policy_us']
    held['policy_gain_vs_global_static_us']=held['global_static_us']-held['policy_us']
    held['policy_reduction_pct']=100*held['policy_gain_us']/held['trained_static_us']
    held['oracle_headroom_us']=held['trained_static_us']-held['oracle_us']
    ideal={k:v['medians_us'] for k,v in valid.items()}
    in_sample_static=best_static(ideal,all_indices)
    optimistic=st.mean(ideal[in_sample_static])-st.mean(min(v[i] for v in ideal.values()) for i in all_indices)
    return dict(batch=data['batch'],cases=len(rows),candidates=len(valid),rejected=len(data['candidates'])-len(valid),
        sequence_sha256=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest(),
        static_candidate=static,full=full,holdout=held,policy=fitted,train_indices=train,holdout_indices=holdout,
        oracle_choices=oracle,policy_choices=policy,candidate_configs={k:v['config'] for k,v in valid.items()},
        optimistic_in_sample_oracle_gap_us=optimistic,
        measurement_split=dict(selection_rounds=[0,half-1],evaluation_rounds=[half,data['samples']-1]),
        note='All selector costs assumed zero. Global static and per-case oracle are chosen on calibration rounds and evaluated on separate rounds. Policy learns on even-index layers/steps0-7; holdout is odd-index layers/steps8-15. Oracle is limited to the shortlisted BM16 candidates.')


def main():
    p=argparse.ArgumentParser();p.add_argument('--sweep',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    summaries=[]
    for path in sorted(a.sweep.glob('search-b*.json')):
        d=json.loads(path.read_text())
        if not d.get('complete'):continue
        report=analyze(d)
        (a.output/f'policy-b{d["batch"]}.json').write_text(json.dumps(report,indent=2)+'\n')
        summaries.append({k:report[k] for k in ('batch','cases','candidates','rejected','static_candidate','full','holdout','optimistic_in_sample_oracle_gap_us')})
    (a.output/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
    print(json.dumps(summaries,indent=2))


if __name__=='__main__':main()
