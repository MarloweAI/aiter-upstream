"""Qualify and compare both backends with the established ordered replay."""
import json
import hashlib
from pathlib import Path
import statistics
from .upgrade_state import digest,file_digest,save


def run_replay(lock):
    import torch
    from . import run
    from .dispatch_audit import capture_dispatch,compare_dispatch
    from .sglang_adapter import SGLangLayer
    from sglang.srt.runtime_context import get_parallel
    c=lock['config'];root=Path(lock['run_root']);audit=root/'native-audit'
    runtime=json.loads((Path(lock['runtime_root'])/'runtime.json').read_text())
    receipt=json.loads((audit/'validated.json').read_text())
    if not runtime['passed'] or not receipt['passed']:raise RuntimeError('Missing GPU/dispatch qualification')
    for name,expected in receipt['files'].items():
        if file_digest(audit/name)!=expected:raise RuntimeError('Native audit evidence changed: '+name)
    output=root/'replay';output.mkdir(exist_ok=True)
    def identity(batch):
        files={name:value for name,value in receipt['files'].items()
               if name.startswith(('layer-','gate-')) or name.endswith(f'-b{batch}.json') and name.startswith('dispatch-')}
        return dict(execution_source=runtime['execution_source'],image_sha256=runtime['image']['image_sha256'],
                    dependencies=runtime['dependencies_sha256'],pyhip=runtime['benchmark_dependency'],
                    hardware=runtime['hardware'],config={k:c[k] for k in ('model_revision','topology','environment')},
                    benchmark_sources={k:v for k,v in lock['source_files'].items()
                        if k.startswith('marlowe_kernels/') or k in {
                            'benchmarks/moe_replay/'+n for n in ('run.py','backend.py','events.py','kernels.py',
                            'protocol.py','reference.py','sglang_adapter.py','dispatch_audit.py','upgrade_replay.py')}},
                    native_dispatch_and_specs=files)
    def factory(payload,layer_id):
        payload.update(torch.load(audit/f'gate-{layer_id}.pt',weights_only=True))
        spec=json.loads((audit/f'layer-{layer_id}.json').read_text())
        for key,expected in spec['weight_content_sha256'].items():
            raw=payload[key].detach().contiguous().view(torch.uint8).numpy()
            if hashlib.sha256(memoryview(raw)).hexdigest()!=expected:
                raise RuntimeError(f'Captured weight bytes differ from current native audit: layer {layer_id}, {key}')
        layer=SGLangLayer(payload,layer_id,spec)
        # Native SGLang can expose E8M0 bytes as uint8; preserve its exact
        # dtype/stride descriptors without changing the Port-EW weight views.
        for field,key in {'w13_weight':'w1','w2_weight':'w2','w13_scale':'w1_scale','w2_scale':'w2_scale'}.items():
            expected=spec['weights'][key];value=layer.weights[key]
            dtype=getattr(torch,expected['dtype'].removeprefix('torch.'))
            if value.dtype!=dtype:value=value.view(dtype)
            if list(value.shape)!=expected['shape'] or list(value.stride())!=expected['stride']:
                raise RuntimeError(f'Packed weight descriptor mismatch: layer {layer_id}, {key}')
            setattr(layer.quant_info,field,value)
        return layer
    def verify(layer,x,b):
        # AITER's router GEMM lazily allocates zeroed buffers per stream.
        # SGLang warms the stream it will capture on. Do the same, otherwise
        # first-use initialization incorrectly appears inside the MoE interval.
        context=torch.cuda.graph(torch.cuda.CUDAGraph())
        stream=context.capture_stream
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for variant in ('aiter','port_ew'):
                for _ in range(2):layer(x,variant)
        torch.cuda.synchronize()
        native=json.loads((audit/f'dispatch-l{layer.layer_id}-b{b}.json').read_text())
        observed,out,graph=capture_dispatch(lambda:layer(x,'aiter'))
        result=compare_dispatch(native,observed)
        save(output/f'dispatch-l{layer.layer_id}-b{b}.json',result)
        if not result['passed']:raise RuntimeError(f'SGLang/replay dispatch mismatch: layer {layer.layer_id}, B{b}')
        del graph,out
        return dict(layer=layer.layer_id,batch=b,**result)
    # TopK's disabled symmetric-allocation scope still requests a real TP
    # group. Give it a one-process group for framework bookkeeping, while
    # retaining the audited TP8 logical widths and already-sharded weights.
    # No collective is timed; graph-operation parity gates this local adapter.
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    set_global_server_args_for_scheduler(ServerArgs(model_path=c['model'],tp_size=8,ep_size=1,
        dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    rendezvous=root/'rank-local-rendezvous'
    if rendezvous.exists():rendezvous.unlink()
    init_distributed_environment(world_size=1,rank=0,local_rank=0,
                                 distributed_init_method='file://'+str(rendezvous),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    try:
        with get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,
                                     tp_size=8,moe_tp_size=8,moe_ep_size=1):
            run.main(['--capture',c['capture'],'--output',str(output),'--model',c['model'],
                      '--batches',*map(str,c['batches']),'--samples',str(c['samples']),
                      '--warmups',str(c['warmups'])],layer_factory=factory,runtime_identity=identity,dispatch_validator=verify,result_cache=Path(c['remote']['root'])/'replay-cache')
    finally:
        torch.distributed.destroy_process_group()
    from .upgrade_report import write_report
    return write_report(lock)
