"""Versioned M128 recovery using existing ordered supplied-route kernels.

This does not overwrite the direct-BF16 candidate or its failed evidence. The
output reduction changes from BF16 atomics to a fixed route-slot FP32 sum of
the same BF16-rounded expert operands. Existing SafeFixedProgram also uses its
ordered G2 implementation, so this is a recovery bundle, not a pure atomic-cost
ablation or a same-contract marginal upstream improvement.
"""

import hashlib
import json
from pathlib import Path
from typing import Any

SUPPORTED_ROWS = (128,)
RECOVERY_REVISION = "m128-existing-safefixed-ordered-fp32-v1"


def ordered_contract(rows: int = 128) -> dict[str, Any]:
    """CPU-readable numerical and shape contract; no implicit shape extension."""
    if type(rows) is not int or rows not in SUPPORTED_ROWS:
        raise ValueError("Ordered recovery is qualified for investigation at M128 only")
    return {
        "rows": rows,
        "routing": "supplied native distinct int32 IDs and FP32 weights, contiguous [M,8]",
        "shared": "expert256 with weight1 appended exactly once",
        "input_rounding": "hip_round_up",
        "middle_rounding": "BF16 storage rounding then hip_round_up MXFP4",
        "fp32_middle": False,
        "expert_contributions": "BF16 rounded after FP32 G2 and FP32 route weighting",
        "combination": "ordered_fp32",
        "output": "FP32 sum of nine BF16 operands in route-slot order, rounded once to BF16",
        "contract_change_pair": True,
        "excluded_from_primary_same_contract_ranking": True,
        "implementation_change": "existing ordered G2 projection replaces paired/sparse atomic G2",
        "limitation": "Fresh eager, graph, state and immutable-route gates are mandatory; no correctness claim from factory construction",
    }


class OrderedRecoveryVariant:
    """Prepared, own-scratch wrapper matching the campaign's call interface."""

    def __init__(self, owner: Any, rows: int = 128):
        self.contract = ordered_contract(rows)
        from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import (
            BANDWIDTH_CONFIGS,
            create_bandwidth_program,
        )
        from marlowe_kernels._runtime import source_digest

        self.rows = rows
        self.program = create_bandwidth_program(owner, rows)
        self.fp32_middle = self.program.fp32_middle
        if self.fp32_middle is not False:
            raise ValueError(
                "Ordered recovery changed the historical M128 BF16-middle contract"
            )
        if type(self.program).__name__ != "SafeFixedProgram":
            raise ValueError("Ordered recovery must reuse existing SafeFixedProgram")
        if not self.program.sc.ordered_supplied or self.program.sc.ordered_all:
            raise ValueError("Unexpected ordered supplied-route selection")
        self.info = {
            "group": "m128_ordered_recovery",
            "variant": RECOVERY_REVISION,
            "rows": rows,
            "program_type": type(self.program).__name__,
            "grid": self.program.grid,
            "selected_config": dict(BANDWIDTH_CONFIGS[rows]["config"]),
            "program_info": dict(self.program.info),
            "contract": self.contract,
            "library_source_sha256": source_digest(),
            "recovery_source_sha256": hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
            "reused_sources": [
                "safe_fixed_program.py:SafeFixedProgram and ordered_fixed_down",
                "native_ordered.py:ordered_projection",
                "ordered_program.py:ordered_combine",
                "ordered_epilogue.py:BF16 route stores",
            ],
        }
        identity = json.dumps(self.info, sort_keys=True, separators=(",", ":"))
        self.info["configuration_sha256"] = hashlib.sha256(
            identity.encode()
        ).hexdigest()

    def run(self, x: Any, ids: Any, weights: Any, out: Any = None):
        # Metadata checks are host-only and safe in graph capture. Exact values,
        # uniqueness, immutability and nonaliasing remain the caller's gate.
        if tuple(x.shape) != (self.rows, 6144):
            raise ValueError("Ordered recovery hidden-state shape mismatch")
        if tuple(ids.shape) != (self.rows, 8) or tuple(weights.shape) != (self.rows, 8):
            raise ValueError(
                "Ordered recovery requires eight supplied routes per token"
            )
        if not ids.is_contiguous() or not weights.is_contiguous():
            raise ValueError(
                "Raw-pointer ordered recovery requires contiguous Mx8 routes"
            )
        if str(ids.dtype) != "torch.int32" or str(weights.dtype) != "torch.float32":
            raise ValueError("Ordered recovery requires int32 IDs and FP32 weights")
        return self.program.run(
            x, x, x, out=out, supplied_ids=ids, supplied_weights=weights
        )

    def state_check(self) -> dict[str, Any]:
        return self.program.state_check()


def make_ordered_variant(owner: Any, rows: int = 128) -> OrderedRecoveryVariant:
    return OrderedRecoveryVariant(owner, rows)
