"""Compare BF16 and FP32 internal routing on identical captured MoE inputs.

The primary BF16-vs-FP32 comparison widens the very same captured BF16 router
logits and bias losslessly, outside timing. A second FP32 arm uses a genuine
FP32 router GEMM and is compared with SGLang's native FP32 top-k on those
same logits. All timings start after logits are available.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics

from .upgrade_state import file_digest,save


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--baseline-lock',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--source-digest',required=True)
    p.add_argument('--batches',type=int,nargs='+',default=[1,2,4,8,16,32,64])
    p.add_argument('--layers',type=int,nargs='+',default=[])
    p.add_argument('--steps',type=int,nargs='+',default=[])
    p.add_argument('--samples',type=int,default=40)
    p.add_argument('--warmups',type=int,default=10)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    lock=json.loads(a.baseline_lock.read_text());cfg=lock['config']
    for key in list(os.environ):
        if (key.startswith(('SGLANG_','AITER_')) or key in ('USE_GLUON','USE_GLUON2')) and key not in cfg['environment']:
            del os.environ[key]
    os.environ.update(cfg['environment'])
    import torch
    from marlowe_kernels._runtime import source_digest
    from . import run
    from .dispatch_audit import capture_dispatch
    from .events import Event
    from .kernels import touch_input
    from .protocol import cases,load_metadata
    from .reference import compare,expert_reference
    from .sglang_adapter import SGLangLayer
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    assert source_digest()==a.source_digest
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    audit=Path(lock['run_root'])/'native-audit'
    receipt=json.loads((audit/'validated.json').read_text());assert receipt['passed']
    for name,expected in receipt['files'].items():assert file_digest(audit/name)==expected,name
    set_global_server_args_for_scheduler(ServerArgs(model_path=cfg['model'],tp_size=8,ep_size=1,
        dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    init_distributed_environment(world_size=1,rank=0,local_rank=0,
        distributed_init_method='file://'+str(a.output/'rank-local-rendezvous'),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    identity=dict(job=os.environ['SLURM_JOB_ID'],library_source=source_digest(),
                  benchmark_sha256=file_digest(Path(__file__)),lock_sha256=file_digest(a.baseline_lock),
                  image=lock['config']['runtime']['candidate_images'][0],
                  sglang_sha=lock['refs']['sglang']['sha'],aiter_sha=lock['refs']['aiter']['sha'],
                  samples=a.samples,warmups=a.warmups,interval='logits ready through local combine')
    save(a.output/'identity.json',identity)

    def factory(layer_id):
        payload=torch.load(Path(cfg['capture'])/'weights'/f'layer-{layer_id}.pt',weights_only=True)
        payload.update(torch.load(audit/f'gate-{layer_id}.pt',weights_only=True))
        spec=json.loads((audit/f'layer-{layer_id}.json').read_text())
        for key,expected in spec['weight_content_sha256'].items():
            raw=payload[key].detach().contiguous().view(torch.uint8).numpy()
            assert hashlib.sha256(memoryview(raw)).hexdigest()==expected
        layer=SGLangLayer(payload,layer_id,spec)
        for field,key in {'w13_weight':'w1','w2_weight':'w2','w13_scale':'w1_scale','w2_scale':'w2_scale'}.items():
            expected=spec['weights'][key];value=layer.weights[key]
            dtype=getattr(torch,expected['dtype'].removeprefix('torch.'))
            if value.dtype!=dtype:value=value.view(dtype)
            assert list(value.shape)==expected['shape'] and list(value.stride())==expected['stride']
            setattr(layer.quant_info,field,value)
        return layer

    from triton import cdiv
    try:
        with get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,
                                     tp_size=8,moe_tp_size=8,moe_ep_size=1):
            layers={}
            for b in a.batches:
                meta=load_metadata(Path(cfg['capture'])/f'b{b}-s355052')
                seq=[c for c in cases(meta) if (not a.layers or c['layer'] in a.layers)
                     and (not a.steps or c['decode_step'] in a.steps)]
                assert seq and all(c['actual_token_count']==c['graph_rows']==b for c in seq)
                data=torch.load(Path(cfg['capture'])/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
                for lid in {c['layer'] for c in seq}:
                    if lid not in layers:layers[lid]=factory(lid)
                    layers[lid].port.warmup((b,),routing='internal')
                    layers[lid].port.warmup((b,),routing='internal_fp32')
                    layers[lid].port.warmup((b,),routing='supplied')
                bundle=[];checks=[];references=[]
                for c in seq:
                    layer=layers[c['layer']];owner=layer.port
                    x=data['input'][c['slot'],c['layer_index'],:b]
                    logits16=data['logits'][c['slot'],c['layer_index'],:b].bfloat16().contiguous()
                    bias16=layer.bias_by_dtype[torch.bfloat16]
                    logits32=logits16.float().contiguous();bias32=bias16.float().contiguous()
                    # A distinct FP32 matrix product exposes precision lost in a BF16 router.
                    logits_true=(x.float() @ layer.gate.weight.detach().float().T).contiguous()
                    true_bias=layer.bias_by_dtype[torch.float32]
                    y16=owner(x,logits16,bias16).clone();ids16,rw16=(v.clone() for v in owner.routing(b))
                    y32=owner.forward_fp32(x,logits32,bias32).clone();ids32,rw32=(v.clone() for v in owner.routing(b,routing='internal_fp32'))
                    ytrue=owner.forward_fp32(x,logits_true,true_bias).clone();ti,tw=(v.clone() for v in owner.routing(b,routing='internal_fp32'))
                    native_weights,native_ids=layer.routes(x,logits_true)
                    ynative=owner.forward_routed(x,native_ids,native_weights).clone()
                    ni,nw=(v.clone() for v in owner.routing(b,routing='supplied'))
                    assert torch.equal(ni[:,:8],native_ids) and torch.equal(nw[:,:8],native_weights)
                    reference16=expert_reference(layer.weights,x,ids16,rw16,b in (1,4,8,32))
                    reference32=(reference16 if torch.equal(ids16,ids32) and torch.equal(rw16,rw32)
                                 else expert_reference(layer.weights,x,ids32,rw32,b in (1,4,8,32)))
                    referencetrue=expert_reference(layer.weights,x,ti,tw,b in (1,4,8,32))
                    referencenative=expert_reference(layer.weights,x,ni,nw,b in (1,4,8,32))
                    sorted_ti,torder=ti[:,:8].sort(1);sorted_ni,norder=ni[:,:8].sort(1)
                    matching_sets=(sorted_ti==sorted_ni).all(1)
                    aligned_delta=(tw[:,:8].gather(1,torder)-nw[:,:8].gather(1,norder)).abs()
                    row=dict(layer=c['layer'],step=c['decode_step'],
                        bf16=compare(y16,reference16),fp32_widened=compare(y32,reference32),
                        fp32_true=compare(ytrue,referencetrue),native_fp32=compare(ynative,referencenative),
                        widened_ids_exact=bool(torch.equal(ids16,ids32)),
                        widened_weights_exact=bool(torch.equal(rw16,rw32)),
                        true_native_ids_exact=bool(torch.equal(ti,ni)),
                        true_native_weight_max_abs=float((tw-nw).abs().max()),
                        true_native_changed_set_tokens=int((~matching_sets).sum()),
                        true_native_aligned_weight_max_abs=(float(aligned_delta[matching_sets].max())
                            if bool(matching_sets.any()) else None),
                        fp32_ids=ti.cpu().tolist(),native_ids=ni.cpu().tolist(),
                        fp32_weights=tw.cpu().tolist(),native_weights=nw.cpu().tolist())
                    checks.append(row)
                    if not all(row[k]['passed'] for k in ('bf16','fp32_widened','fp32_true','native_fp32')):
                        save(a.output/f'b{b}-failure.json',dict(case=c,check=row))
                        torch.save(dict(input=x.cpu(),logits16=logits16.cpu(),logits_true=logits_true.cpu(),
                            bias16=bias16.cpu(),true_bias=true_bias.cpu(),ids16=ids16.cpu(),ids32=ids32.cpu(),
                            true_ids=ti.cpu(),native_ids=ni.cpu(),fp32_output=ytrue.cpu()),a.output/f'b{b}-failure.pt')
                        raise RuntimeError(f'Independent output reference failure B{b}, layer{c["layer"]}, step{c["decode_step"]}')
                    bundle.append((x,logits16,bias16,logits32,bias32,logits_true,true_bias,layer))
                    references.append(dict(bf16=(reference16,ids16,rw16),
                                           fp32_widened=(reference32,ids32,rw32),
                                           fp32_true=(referencetrue,ti,tw),
                                           native_fp32=(referencenative,ni,nw)))
                save(a.output/f'b{b}-checks.json',checks)
                x,l16,b16,l32,b32,lt,bt,layer=bundle[0]
                signatures={}
                for name,call in [('bf16',lambda:layer.port(x,l16,b16)),
                                  ('fp32_widened',lambda:layer.port.forward_fp32(x,l32,b32)),
                                  ('fp32_true',lambda:layer.port.forward_fp32(x,lt,bt))]:
                    signature,_,graph=capture_dispatch(call);signatures[name]=signature;del graph
                # PyHIP uses the same mangled graph symbol for differently
                # specialized code objects. Verify the actual selected files
                # and their router-load ISA rather than guessing from DOT.
                family='overlap_gate' if b in (1,2,4) else 'preloaded_phase1' if b==8 else 'fixed_prepare'
                cache=Path(os.environ['PYHIP_CACHE_DIR'])
                selected={}
                for fp32 in (False,True):
                    pattern=(f'*{family}-SUPPLIED=False-FP32_ROUTING={fp32}.s' if b==8 else
                             f'*{family}-B={b}-*-SUPPLIED=False-*-FP32_ROUTING={fp32}.s' if b in (1,2,4) else
                             f'*{family}-B={b}-*-SUPPLIED=False-FP32_ROUTING={fp32}.s')
                    options=list(cache.glob(pattern))
                    if len(options)!=1:
                        save(a.output/f'b{b}-dispatch.json',dict(signatures=signatures,
                            evidence_error=dict(fp32=fp32,files=list(map(str,options)))))
                        raise RuntimeError(f'Expected exactly one B{b} {family} FP32_ROUTING={fp32} code object')
                    asm=options[0];obj=asm.with_suffix('.co')
                    assert obj.is_file()
                    selected[str(fp32)]=dict(assembly=str(asm),code_object=str(obj),
                        code_sha256=hashlib.sha256(obj.read_bytes()).hexdigest(),
                        router_ushort_loads=sum('global_load_ushort' in line for line in asm.read_text().splitlines()),
                        fp32_route_source='prepare_fp32.py' in asm.read_text())
                assert selected['True']['code_sha256']!=selected['False']['code_sha256']
                assert selected['True']['router_ushort_loads']==0,selected
                if b not in (1,2,4):assert selected['True']['fp32_route_source'],selected
                assert signatures['fp32_widened']==signatures['fp32_true']
                save(a.output/f'b{b}-dispatch.json',dict(signatures=signatures,selected_code=selected,
                      fp32_engaged=True))

                def invoke(name,x,l16,b16,l32,b32,lt,bt,layer):
                    owner=layer.port
                    if name=='bf16':
                        result=owner(x,l16,b16);routing='internal'
                    elif name=='fp32_widened':
                        result=owner.forward_fp32(x,l32,b32);routing='internal_fp32'
                    elif name=='fp32_true':
                        result=owner.forward_fp32(x,lt,bt);routing='internal_fp32'
                    else:
                        nw,ni=layer.routes(x,lt)
                        result=owner.forward_routed(x,ni,nw);routing='supplied'
                    ids,weights=owner.routing(b,routing=routing)
                    return result,ids,weights

                for name in ('bf16','fp32_widened','fp32_true','native_fp32'):
                    graph=torch.cuda.CUDAGraph();captured=[]
                    with torch.cuda.graph(graph):
                        for args in bundle:
                            output,ids,weights=invoke(name,*args)
                            captured.append((output.clone(),ids.clone(),weights.clone()))
                    for _ in range(3):graph.replay()
                    torch.cuda.synchronize()
                    for index,((output,ids,weights),expected) in enumerate(zip(captured,references)):
                        ref,expected_ids,expected_weights=expected[name]
                        numerical=compare(output,ref)
                        route_equal=bool(torch.equal(ids,expected_ids) and torch.equal(weights,expected_weights))
                        checks[index][name+'_graph']=dict(output=numerical,exact_routes=route_equal)
                        if not numerical['passed'] or not route_equal:
                            save(a.output/f'b{b}-graph-failure.json',dict(index=index,name=name,
                                check=checks[index][name+'_graph']))
                            raise RuntimeError(f'Graph reference/route failure {name}, B{b}, case{index}')
                    del graph,captured
                save(a.output/f'b{b}-graph-checks.json',checks)
                graphs={}
                sink=torch.empty((cdiv(64*6144,1024),),device='cuda')
                for name in ('bf16','fp32_widened','fp32_true','native_fp32'):
                    markers=[(Event(),Event()) for _ in bundle]
                    graph=torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph):
                        for (x,l16,b16,l32,b32,lt,bt,layer),pair in zip(bundle,markers):
                            touch_input[(cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                            pair[0].record()
                            invoke(name,x,l16,b16,l32,b32,lt,bt,layer)
                            pair[1].record()
                    graphs[name]=dict(graph=graph,pairs=markers,sink=sink)
                timed=run.timings(graphs,a.samples,a.warmups)
                latency={k:statistics.mean(v['interval_medians_us']) for k,v in timed.items()}
                save(a.output/f'b{b}.json',dict(batch=b,identity=identity,cases=len(seq),checks=checks,
                     timing=timed,latency_us=latency,
                     fp32_dispatch_engaged=True,fp32_native_exact_cases=sum(c['true_native_ids_exact'] for c in checks)))
                print(json.dumps(dict(batch=b,latency_us=latency,native_exact=sum(c['true_native_ids_exact'] for c in checks),cases=len(seq))),flush=True)
                del graphs,bundle,data
                torch.cuda.empty_cache()
    finally:torch.distributed.destroy_process_group()


if __name__=='__main__':main()
