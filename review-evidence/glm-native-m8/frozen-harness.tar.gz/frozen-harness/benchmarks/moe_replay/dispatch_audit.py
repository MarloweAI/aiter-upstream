"""Capture the GPU graph's actual native operation sequence, outside timing.

Graph node IDs/addresses are process-local. Kernel names, grid/block geometry,
shared memory and operation order are not normalized away. Unknown DOT formats
fail closed rather than treating an empty trace as parity.
"""
import ctypes as C
import json
import re
from pathlib import Path
import tempfile
from .events import call
from .upgrade_state import digest


def parse_dot(text, allow_empty=False):
    records={}
    for match in re.finditer(r'"([^"\n]+)"\s*\[(.*?)\];',text,re.S):
        node,attrs=match.groups()
        label=re.search(r'label="((?:\\.|[^"\\])*)"',attrs,re.S)
        if not label:raise ValueError('Graph node has no readable label')
        raw=label.group(1).replace('\\n','\n')
        lines=[line.strip() for line in raw.splitlines() if line.strip()]
        if lines and lines[0].isdigit():lines=lines[1:]
        if not lines:raise ValueError('Empty graph node label')
        kind='kernel' if 'octagon' in attrs or 'KERNEL' in lines else 'other'
        # Pointer addresses encode buffer locations, not execution policy.
        normalized=[re.sub(r'\{ID \| \d+ \|', '{ID | <id> |',
                           re.sub(r'0x[0-9a-fA-F]+','<address>',line)) for line in lines]
        records[node]=dict(kind=kind,label=normalized)
    edges=re.findall(r'"([^"\n]+)"\s*->\s*"([^"\n]+)"',text)
    if not records and not allow_empty:raise ValueError('No GPU graph operations observed')
    return records,edges


def ordered_span(before,after):
    old,_=parse_dot(before,allow_empty=True) if before.strip() else ({},[])
    nodes,edges=parse_dot(after);new={k:v for k,v in nodes.items() if k not in old}
    if not new:raise ValueError('No operations were captured for the local MoE interval')
    # HIP DOT node numbers preserve construction order. Verify new nodes have
    # numeric IDs; do not guess when upstream changes the representation.
    def key(node):
        m=re.search(r'_node_(\d+)$',node)
        if not m:raise ValueError('Unsupported HIP DOT node identifier: '+node)
        return int(m.group(1))
    order=sorted(new,key=key);indices={k:i for i,k in enumerate(order)}
    return dict(nodes=[new[k] for k in order],
        edges=sorted([[indices[a],indices[b]] for a,b in edges if a in new and b in new]))


def graph_dot():
    import torch
    stream=C.c_void_p(torch.cuda.current_stream().cuda_stream)
    status,ident=C.c_int(),C.c_ulonglong();graph=C.c_void_p()
    deps,n=C.POINTER(C.c_void_p)(),C.c_size_t()
    call('hipStreamGetCaptureInfo_v2',stream,C.byref(status),C.byref(ident),C.byref(graph),C.byref(deps),C.byref(n))
    if status.value!=1:raise RuntimeError('Dispatch inspection requires active graph capture')
    with tempfile.TemporaryDirectory(prefix='marlowe-graph-') as td:
        path=Path(td)/'graph.dot'
        call('hipGraphDebugDotPrint',graph,str(path).encode(),1) # verbose: kernel launch parameters
        return path.read_text()


def compare_dispatch(native,replay):
    if not native.get('nodes') or not replay.get('nodes'):
        raise ValueError('Empty dispatch evidence cannot pass')
    passed=native==replay
    return dict(passed=passed,native_digest=digest(native),replay_digest=digest(replay),
                native=native if not passed else None,replay=replay if not passed else None)


def capture_dispatch(fn):
    import torch
    for _ in range(2):fn()
    torch.cuda.synchronize()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        before=graph_dot()
        out=fn()
        after=graph_dot()
    graph.replay();torch.cuda.synchronize()
    return ordered_span(before,after),out,graph
