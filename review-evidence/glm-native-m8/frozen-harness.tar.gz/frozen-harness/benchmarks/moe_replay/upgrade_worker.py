"""Slurm stage entry point; write success receipts only after all gates pass."""
import argparse
import json
import os
from pathlib import Path
import time
import traceback
from .upgrade_state import save


def main():
    p=argparse.ArgumentParser();p.add_argument('--lock',type=Path,required=True)
    p.add_argument('--stage',choices=['build','preflight','audit','replay'],required=True);a=p.parse_args()
    if not os.environ.get('SLURM_JOB_ID'):raise SystemExit('Run workers in a Slurm allocation')
    lock=json.loads(a.lock.read_text());root=Path(lock['run_root'])
    configured=lock['config']['environment']
    for key in list(os.environ):
        if (key.startswith(('SGLANG_','AITER_')) or key in ('USE_GLUON','USE_GLUON2')) and key not in configured:
            del os.environ[key]
    os.environ.update(configured)
    result=dict(stage=a.stage,status='running',run_fingerprint=lock['fingerprint'],job_id=os.environ['SLURM_JOB_ID'],started=time.time())
    save(root/(a.stage+'.json'),result)
    try:
        if a.stage=='build':
            from .sailfish_images import acquire
            detail=acquire(lock)
        elif a.stage=='preflight':
            from .runtime_support import preflight
            detail=preflight(lock)
        elif a.stage=='audit':
            from .upgrade_audit import run_audit
            detail=run_audit(lock)
        else:
            from .upgrade_replay import run_replay
            detail=run_replay(lock)
        result.update(status='passed',detail=detail,finished=time.time())
        save(root/(a.stage+'.json'),result)
    except BaseException as exc:
        result.update(status='failed',error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc(),finished=time.time())
        try:
            from .upgrade_report import write_report
            result['report']=write_report(lock,result['error'])['report']
        except Exception as report_error:
            result['report_error']=str(report_error)
        save(root/(a.stage+'.json'),result)
        raise


if __name__=='__main__':main()
