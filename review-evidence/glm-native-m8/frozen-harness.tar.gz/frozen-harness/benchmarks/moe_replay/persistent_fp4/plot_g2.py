"""Plot the matched G2 output-layout experiment from saved evidence."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
    rows={r['arm']:r for r in json.loads((a.evidence/'summary.json').read_text()) if r['batch']==64}
    arms=['native','wave','coalesced'];labels=['Original native','Wave transpose','LDS transpose'];colors=['#2873ad','#df9943','#29a17a']
    fig,axes=plt.subplots(1,2,figsize=(10,4.6),layout='constrained')
    series=[[rows[k]['unprofiled_moe_us'] for k in arms],
            [rows[k]['counters_per_moe']['TCP_TCC_ATOMIC_WITHOUT_RET_REQ_sum']/1000 for k in arms]]
    for ax,values,title,unit in zip(axes,series,['MoE latency without profiler','Output atomic memory requests'],['µs','Thousands / MoE']):
        bars=ax.bar(labels,values,color=colors,width=.65)
        ax.bar_label(bars,labels=[f'{v:.2f}' for v in values],padding=4)
        ax.set_ylim(0,max(values)*1.18);ax.set_ylabel(unit);ax.set_title(title)
        ax.spines[['top','right']].set_visible(False);ax.set_axisbelow(True);ax.grid(axis='y',alpha=.2)
    fig.suptitle('G2 output layout on MI355X · B64 · TP8 rank 0\nSame G1 and routes; 30 layers × 2 steps, captured logits → combine',fontsize=12)
    fig.savefig(a.evidence/'comparison.png',dpi=180);fig.savefig(a.evidence/'comparison.pdf')

if __name__=='__main__':main()
