"""Summarize preserved paired replays without rerunning GPU work."""
import argparse,csv,json,random,re,statistics
from pathlib import Path

LABELS={'aiter':'AITER','port_ew':'BF16 Port-EW','port_fp4':'Native FP4',
        'hybrid':'AITER hybrid','mixed_ref':'Prior mixed','previous':'Previous candidate','candidate':'Candidate'}

def metric(result,arm):
    return result['timing'][arm+'_preload_events']

def confidence(result,control):
    a=[statistics.mean(v) for v in metric(result,control)['interval_samples_us']]
    b=[statistics.mean(v) for v in metric(result,'candidate')['interval_samples_us']]
    assert len(a)==len(b)
    rng=random.Random(355052);values=[]
    for _ in range(2000):
        indices=rng.choices(range(len(a)),k=len(a))
        values.append(100*(1-sum(b[i] for i in indices)/sum(a[i] for i in indices)))
    values.sort();return dict(mean_improvement_percent=100*(1-statistics.mean(b)/statistics.mean(a)),
        bootstrap_95_percent=[values[int(len(values)*p)] for p in (.025,.975)])

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    rows=[]
    for path in sorted(a.root.glob('b*.json')):
        if not re.fullmatch(r'b\d+\.json',path.name):continue
        r=json.loads(path.read_text());arms=[name.removesuffix('_preload_events') for name in r['timing']
            if name.endswith('_preload_events') and not name.endswith('_no_preload_events')]
        latency={arm:statistics.mean(metric(r,arm)['interval_medians_us']) for arm in arms}
        control=min((arm for arm in arms if arm!='candidate'),key=latency.get)
        rows.append(dict(batch=r['batch'],qualified=r['qualified'],latency_us=latency,
            strongest_control=control,improvement_percent=100*(1-latency['candidate']/latency[control]),
            paired_sample_means=confidence(r,control),
            layer_step_cases=len(r['checks']),dispatch_checks=len(r['dispatch_checks']),
            eager_failures=len([v for v in r['numerical_failures'] if v['kind']=='eager']),
            graph_failures=len([v for v in r['numerical_failures'] if v['kind']=='graph']),
            graph_checks=r['graph_checks'],source_sha256=r['identity']['library_source'],
            frozen_source_checked=bool(r['identity']['runtime'].get('source_paths',{}).get('frozen_root')),
            worst_candidate_eager_nrmse=max(c['port_references']['candidate']['nrmse'] for c in r['checks']),
            candidate_eager_elementwise_mismatches=max(c['port_references']['candidate']['mismatch_fraction'] for c in r['checks']),
            source=str(path)))
    rows.sort(key=lambda r:r['batch'])
    (a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
    columns=['batch','qualified',*LABELS,'strongest_control','improvement_percent']
    with (a.output/'summary.csv').open('w') as f:
        w=csv.DictWriter(f,columns);w.writeheader()
        for r in rows:w.writerow({**{k:r[k] for k in ('batch','qualified','strongest_control','improvement_percent')},**r['latency_us']})
    display=[arm for arm in LABELS if any(arm in r['latency_us'] for r in rows)]
    lines=['# Router-through-combine qualification','',
        'One MI355X, rank-0 TP8/EP1 shard, 30 layers × 16 ordered decode steps. '
        'Native HIP event intervals with untimed input preloading; shared expert included. '
        'TP collectives, attention, residual and full serving are outside the measured region.','',
        'Latencies are µs. Each cell is the mean of per-case medians from 40 paired graph samples. '
        'Positive improvement means the candidate is faster than the strongest measured control.','',
        '| '+' | '.join(['B',*[LABELS[v] for v in display],'vs best','Qualified'])+' |',
        '|'+'---:|'*(len(display)+2)+':---:|']
    for r in rows:
        vals=[f"{r['latency_us'][v]:.2f}" if v in r['latency_us'] else '—' for v in display]
        lines.append('| '+ ' | '.join([str(r['batch']),*vals,f"{r['improvement_percent']:+.2f}%",'yes' if r['qualified'] else '**no**'])+' |')
    lines+=['','Qualification uses unchanged independent-reference tolerances (rtol=.02, atol=.02, NRMSE≤.01), '
        'all eager and graph outputs, routing checks and reused native TP8 dispatch fingerprints. '
        'The B1 run is explicitly diagnostic: a prior intermittent AITER reference failure remains unresolved. '
        'Its timing cannot establish a qualified replacement.','',
        'At B2/B16/B64, AITER/hybrid and historical Port-EW use different intermediate rounding contracts. '
        'Each arm is checked against its own independent reference. This is not a claim of bitwise '
        'interchangeability or equal model accuracy. No tolerance was loosened.','',
        'The JSON separately reports mean-of-sample-means improvements and paired bootstrap intervals, '
        'rather than applying those intervals to the table\'s mean-of-case-medians estimator. These describe precision within '
        'this replay, not independent serving trials, other prompts, or other machines.','',
        f"Observed coverage: {sum(r['layer_step_cases'] for r in rows)} layer/step cases, "
        f"{sum(r['dispatch_checks'] for r in rows)} dispatch checks; "
        f"{sum(r['eager_failures'] for r in rows)} eager and {sum(r['graph_failures'] for r in rows)} graph reference failures preserved."]
    if any(not r['frozen_source_checked'] for r in rows):
        lines+=['','Initial qualification used multiple recorded package namespaces as three unused experimental modules were added. '
            'The source audit verified that all active kernel and replay/reference files were unchanged and reconstructed each exact library SHA. '
            'See `../qualification-source-audit.json`; these are paired per-batch results, not one globally frozen package snapshot.']
    else:lines+=['','All runs explicitly entered a frozen source directory and checked both library and benchmark import paths before GPU work.']
    (a.output/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps([{k:v for k,v in r.items() if k not in ('graph_checks','source_sha256','source')} for r in rows],indent=2))

if __name__=='__main__':main()
