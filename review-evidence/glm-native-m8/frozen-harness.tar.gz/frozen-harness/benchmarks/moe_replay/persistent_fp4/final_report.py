"""Select measured arms without rewriting their original replay records."""
import argparse,gzip,hashlib,json,statistics
from pathlib import Path


def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    selection={1:('coalesced','candidate'),2:('initial','candidate'),4:('coalesced','candidate'),
               8:('final','candidate'),16:('final','candidate'),32:('final','candidate'),64:('ordered','previous')}
    rows=[];manifest=[]
    for b,(run,arm) in selection.items():
        path=a.inputs/run/f'b{b}.json';raw=path.read_bytes();r=json.loads(raw)
        dest=a.output/'raw'/run/path.name;dest.parent.mkdir(parents=True,exist_ok=True)
        with gzip.open(dest.with_suffix('.json.gz'),'wb') as f:f.write(raw)
        manifest.append(dict(batch=b,run=run,selected_arm=arm,raw_sha256=hashlib.sha256(raw).hexdigest(),
                             local_archive=str(dest.with_suffix('.json.gz').relative_to(a.output))))
        latency={k.removesuffix('_preload_events'):statistics.mean(v['interval_medians_us']) for k,v in r['timing'].items()
                 if k.endswith('_preload_events') and not k.endswith('_no_preload_events')}
        best=min((v for v in latency if v!=arm),key=latency.get)
        labels={'aiter':'AITER','port_ew':'BF16 Port','port_fp4':'Native FP4','hybrid':'AITER hybrid',
                'mixed_ref':'Prior mixed','previous':'Previous candidate','candidate':'Candidate'}
        if run=='ordered':labels.update(candidate='Ordered FP32 sum',previous='LDS atomic combine')
        cfg=r['identity']['runtime']['previous_configs' if arm=='previous' else 'candidate_configs'][str(b)]
        checks=[v['port_references'][arm] for v in r['checks']]
        graph=r['graph_validation'][arm]
        rows.append(dict(batch=b,run=run,selected_arm=arm,implementation=cfg,latency_us=latency,
            selected_us=latency[arm],best_alternative=best,best_alternative_label=labels[best],
            improvement_vs_alternative_percent=100*(1-latency[arm]/latency[best]),
            improvement_vs_aiter_percent=100*(1-latency[arm]/latency['aiter']),
            qualified_paired_run=r['qualified'],selected_eager_passed=all(c['passed'] for c in checks),
            selected_graph_passed=r['graph_checks'][arm],max_eager_nrmse=max(c['nrmse'] for c in checks),
            max_graph_nrmse=max(c['graph_reference']['nrmse'] for c in graph),
            layer_step_cases=len(r['checks']),dispatch_checks=len(r['dispatch_checks']),
            library_source_sha256=r['identity']['library_source'],reuse=(b==2),
            frozen_source_checked=bool(r['identity']['runtime'].get('source_paths',{}).get('frozen_root'))))
    (a.output/'selected-results.json').write_text(json.dumps(rows,indent=2)+'\n')
    (a.output/'selected-records.json').write_text(json.dumps(manifest,indent=2)+'\n')
    lines=['# Port-EW: hardware-guided MoE optimization','',
        'The investigation within the four-hour budget did not produce a winning G1/G2 megakernel. Hardware counters instead led to a faster G2 output path, combined with fused top-k/dispatch and deeper G1 prefetch. B32 remains slightly slower than the existing AITER hybrid. The public library default was not changed.','',
        'GLM-5.2 MXFP4, one MI355X, TP8/EP1 rank-0 shard. Router GEMM through local combine, shared expert included. Each batch uses 30 layers × 16 ordered decode steps, 40 paired graph samples, untimed input preloading, and native HIP events. Weights rotate naturally through real layers; there is no cache-sweep kernel. TP collectives, residual, attention, and full serving are outside this measurement.','',
        '| B | AITER µs | Best paired alternative µs | New Port-EW µs | vs alternative | Status |',
        '|---:|---:|---|---:|---:|---|']
    for r in rows:
        best=r['best_alternative'];lat=r['latency_us']
        status='passed' if r['qualified_paired_run'] else 'diagnostic'
        if r['batch']==32:status+='; hybrid wins'
        lines.append(f"| {r['batch']} | {lat['aiter']:.2f} | {lat[best]:.2f} ({r['best_alternative_label']}) | {r['selected_us']:.2f} | {r['improvement_vs_alternative_percent']:+.2f}% | {status} |")
    lines+=['','“Best paired alternative” includes other measured experimental implementations. At B64 this is the ordered FP32-sum variant; the established BF16 Port control measured86.69us, versus80.33us for the fast LDS path. Each row uses its own paired controls; no historical timing was substituted.','',
        'B1 is diagnostic because earlier AITER reference failures remain unresolved, even though its later run passed. B2 reuses its completed unchanged mixed-G1 result. B64’s fast LDS arm was validated as the `previous` arm in the separate ordered-combine experiment; the original records/arm names are preserved, not relabeled.','',
        '## What changed','',
        '- B8–64 use one common fused top-k/dispatch representation: per-expert counts allocate BM16 route tiles directly. No separate runtime distribution-analysis pass or grouping launch is added. G1 uses native FP4, deeper prefetch, and split-K=1, fusing SiLU and packed intermediate generation. G2 rearranges outputs in wave-private LDS before coalesced BF16 atomic combine. B64 uses a larger output tile; the per-expert dispatch mechanism is the same.','- B1/B4 retain direct execution with tuned prefetch and a wave-transpose G2 epilogue. B2’s winner uses BF16 G1 with a packed FP4 epilogue and native FP4 G2. All retain FP4 intermediate quantization.','- A separate ordered-combine prototype preserves FP4 intermediate and BF16 expert-contribution rounding, then sums in FP32. It changes accumulator precision and adds a kernel/scratch traffic. At B64 it measured86.05us versus80.33us for the atomic LDS path, with lower numerical error. It is a quality/performance tradeoff, not the fastest result.','',
        '## What the hardware counters showed','',
        '- Persistent fusion read almost the same DRAM volume as separate stages but exposed too little independent work. At B64:1.41 fused waves/CU versus12.07 for separate G2; read rate1.74 versus3.33TB/s. No scratch spills. Increasing workers, changing tile sizes, and coalescing its output did not produce a winner.','- Replicated block-local fusion repeated G1. At B32, DRAM reads and latency both rose about70% versus BF16. Changing replica launch order helped, but remained slower.','- Native G2 scattered its output atomics. A matched B64 test reduced atomic requests442,368→221,184 with wave shuffles, then→110,592 with LDS. Atomic-tag-conflict counts fell to zero. With G1 unchanged, complete fixed-logit MoE time fell79.30→69.50→67.17us. VGPR use stayed40, scratch stayed zero, and G2 occupancy stayed near12 waves/CU. These are separate two-step diagnostic workloads, not the router-inclusive table above.','',
        'See [counter findings](HARDWARE.md), [fusion plot](hardware/comparison.png), and the raw hardware summaries in `hardware/`, `hardware-coalesced/`, and `hardware-lds/`. Counter-instrumented duration is never used as performance latency.','',
        '## Correctness, failures, and coverage','',
        'All selected kernels passed their eager and graph independent-reference checks on the3,360 unique layer/step cases;210 dispatch checks verify the pinned SGLang selections. Thresholds were unchanged:rtol=.02, atol=.02, NRMSE≤.01. B1’s paired comparison remains diagnostic. At B2/B16/B64, historical Port-EW and current AITER have different intermediate rounding contracts; each is checked against its own reference. No bitwise equivalence or full-model accuracy claim follows.','',
        'A previous experimental BF16-dispatch control failed one B64 graph element at layer77/step8. That failure and its tensors were preserved, and the subsequent retry was explicitly diagnostic. It is a different implementation from the final native-FP4/LDS arm. The later ordered-combine comparison independently validated both the final LDS arm and ordered arm with all controls passing. The failed earlier control is not promoted.','',
        'A separate rejected B64/down64 screen showed a pairwise difference between two atomic sums. The diagnostic reproduced it while both outputs passed the unchanged independent reference. This does not erase the separate genuine reference failure above.','',
        'Original full-fusion counter exports contain all8,100 expected dispatches per group, but rocprofiler crashed after export during shutdown. This is recorded separately from export coverage. Both coalescing follow-ups exited cleanly with complete counts (4,860/group for the wave study;2,700/group for LDS).','',
        'Initial qualification’s PYTHONPATH prefix was overridden by its cwd while unused modules were added. An audit verified unchanged active code and reconstructed every exact library SHA. Subsequent runs explicitly entered frozen directories and checked import paths. See [source audit](qualification-source-audit.json).','',
        '## Reuse and reproducibility','',
        'Reused: existing image/runtime, captured inputs, weights, native TP8 dispatch audit, and unchanged B2 qualification. No rebuild, recapture, new serving test, or B200 test was performed. Pinned AITER:34947d4012bec80888581adc035e9ab6156d129b; SGLang:c46bf5e990bdd99e2c200214b04683022100e4df; ROCm7.2.4 image; PyTorch2.11.0+rocm7.2. These are exact comparison pins, not a new claim of latest upstream.','',
        'Raw records are preserved with their original arm names and hashes in `raw/` and `selected-records.json`. Full logs, code snapshots, profiler CSVs, and failure tensors remain at `/workspace/home/mishas/results/marlowe-kernels/persistent-fp4-20260919` on192.168.8.207. [WORK_LOG](../WORK_LOG.md) records every experiment. All code is opt-in research on `codex/port-ew-persistent-fp4`; full serving remains unvalidated.']
    text='\n'.join(lines)+'\n'
    for x,y in [('measured86','measured 86'),('versus80','versus 80'),('B64:1','B64: 1'),('versus12','versus 12'),('rate1','rate 1'),('versus3','versus 3'),('about70','about 70'),('requests442','requests 442'),('fell79','fell 79'),('stayed40','stayed 40'),('near12','near 12'),('the3,360','the 3,360'),(';210','; 210'),('unchanged:rtol','unchanged: rtol'),('layer77/step8','layer 77/step 8'),('all8,100','all 8,100'),(';2,700','; 2,700'),('AITER:349','AITER: 349'),('SGLang:c46','SGLang: c46'),('ROCm7','ROCm 7'),('PyTorch2','PyTorch 2'),('on192','on 192')]:text=text.replace(x,y)
    (a.output/'REPORT.md').write_text(text)
    print(json.dumps([{k:v for k,v in r.items() if k in ('batch','selected_us','qualified_paired_run','best_alternative_label','improvement_vs_alternative_percent')} for r in rows],indent=2))

if __name__=='__main__':main()
