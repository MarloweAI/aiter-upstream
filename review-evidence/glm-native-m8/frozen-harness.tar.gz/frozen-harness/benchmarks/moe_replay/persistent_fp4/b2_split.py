"""Bounded B2 native-G1 split-K experiment; never changes runtime defaults.

Run inside the existing pinned ROCm image with PERSIST_ROOT/NATIVE_ROOT set.
Screen fixed captured logits, then qualify the winner with the existing
router-inclusive replay and the current mixed implementation as `previous`.
"""
import dataclasses
import json
import os
from pathlib import Path
import subprocess
import sys
import statistics


def main():
    from marlowe_kernels._kernels.amd.glm52_moe.native_program import NATIVE_CONFIGS

    root = Path(os.environ['PERSIST_ROOT'])
    root.mkdir(parents=True, exist_ok=True)
    # Refuse to overwrite an earlier experiment or discard its failures.
    assert not (root / 'screen.json').exists(), 'Use a new output directory'
    # Freeze the original control: promoting the winner must not silently
    # change what a later rerun labels as the previous mixed implementation.
    mixed = dict(direct=False, dispatch=False, down_n=64, down_waves=1,
                 down_depth=2, gate_split=1, gate_schedule=1, gate_n=64)
    env = dict(os.environ, PERSIST_FAMILY='prefetch', PERSIST_MIXED_CONTROL=json.dumps(mixed))
    configs = [dict(direct=True, gate_n=bn, gate_waves=nw,
                    down_n=64, down_waves=1, down_depth=2,
                    split_k=sk, non_temporal=True, depth=depth)
               for bn, nw in ((64, 1), (128, 2))
               for sk in (1, 2, 3, 4, 6, 8, 12, 16, 24, 48)
               for depth in (0, 4)
               # The original two-stage pipeline requires an even K-step
               # count; the deeper-prefetch emitter also supports odd counts.
               if depth or (48 // sk) % 2 == 0]
    (root / 'requested-configs.json').write_text(json.dumps(configs, indent=2))

    def screen(candidates, name, steps, samples):
        subprocess.run([sys.executable, '-B', '-m',
                        'benchmarks.moe_replay.persistent_fp4.screen', '2'],
                       env=dict(env, PERSIST_CONFIGS=json.dumps(candidates),
                                PERSIST_RESULT=name, PERSIST_STEPS=str(steps),
                                PERSIST_SAMPLES=str(samples)), check=True)
        return json.loads((root / name).read_text())

    rows = screen(configs, 'screen.json', 2, 12)
    valid = [r for r in rows if not r.get('failed') and all(c['passed'] for c in r['checks'])]
    # Rank paired improvements rather than raw times across the search.
    valid.sort(key=lambda r: r['us']['persistent'] / r['us']['current'])
    # Keep four distinct split counts to avoid a shortlist of near-identical tiles.
    finalists = []
    seen = set()
    for row in valid:
        if row['config']['split_k'] not in seen:
            seen.add(row['config']['split_k'])
            finalists.append(row['config'])
        if len(finalists) == 4:
            break
    assert finalists, 'All candidates failed screening'
    rows = screen(finalists, 'finalists.json', 16, 24)
    valid = [r for r in rows if not r.get('failed') and all(c['passed'] for c in r['checks'])]
    best = min(valid, key=lambda r: r['us']['persistent'] / r['us']['current'])
    (root / 'candidate-configs.json').write_text(json.dumps(
        {'2': dict(family='prefetch', config=best['config'])}, indent=2))
    (root / 'current-configs.json').write_text(json.dumps({'2': dict(family='mixed', config=mixed)}, indent=2))
    (root / 'selected-configs.json').write_text(json.dumps(
        {str(b): dataclasses.asdict(c) for b, c in NATIVE_CONFIGS.items()}, indent=2))
    subprocess.run([sys.executable, '-B', '-m',
                    'benchmarks.moe_replay.persistent_fp4.replay',
                    '--batches', '2', '--steps', '16', '--samples', '40'],
                   env=dict(os.environ, PERSIST_PREVIOUS_CONFIGS='current-configs.json'),
                   check=True)
    result = json.loads((root / 'qualified' / 'b2.json').read_text())
    latency = {v: statistics.mean(result['timing'][v + '_preload_events']['interval_medians_us'])
               for v in ('aiter', 'port_fp4', 'previous', 'candidate')}
    summary = dict(qualified=result['qualified'], config=best['config'],
                   latency_us=latency, cases=len(result['sequence']),
                   dispatch_checks=len(result['dispatch_checks']),
                   improvement_vs_current_percent=100 * (1 - latency['candidate'] / latency['previous']),
                   default_changed=False, source_receipt='mk-b2-receipt.json')
    (root / 'summary.json').write_text(json.dumps(summary, indent=2))
    lines = ['# B2 native FP4 G1 split-K experiment', '',
             'GLM-5.2 MXFP4, MI355X TP8/EP1 rank-0 replay. Existing captures, weights,',
             'image and pinned AITER/SGLang runtime reused; no full serving run.',
             'G2 stays native FP4 BN64/one wave/depth2. No default changed.', '',
             '## Router GEMM through local combine', '',
             '| Implementation | Latency (us) |', '|---|---:|']
    for key, label in [('aiter', 'Pinned stock AITER'), ('port_fp4', 'Prior native FP4'),
                       ('previous', 'Current mixed default'), ('candidate', 'Retuned native FP4')]:
        lines.append(f'| {label} | {latency[key]:.3f} |')
    lines += ['', f'Qualified: {result["qualified"]}; {summary["cases"]} layer/step cases;',
              f'{summary["dispatch_checks"]} dispatch checks. Gain vs current: '
              f'{summary["improvement_vs_current_percent"]:.3f}%.', '',
              'Selected configuration: `' + json.dumps(best['config'], sort_keys=True) + '`.', '',
              'Screening excludes router GEMM; screen.json and finalists.json retain paired',
              'samples and numerical checks. qualified/ retains complete eager/graph reference',
              'validation, routing order, versions, kernel selections and timings.',
              'Different AITER/Port-EW intermediate rounding contracts are checked against',
              'their respective references; this is not a model-accuracy equivalence claim.', '']
    (root / 'REPORT.md').write_text('\n'.join(lines))
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
