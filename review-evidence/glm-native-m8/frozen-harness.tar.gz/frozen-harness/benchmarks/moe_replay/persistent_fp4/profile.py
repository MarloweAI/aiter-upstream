"""Diagnostic per-worker device-clock phases; never headline timing."""
import dataclasses,json,os,statistics
from pathlib import Path
import torch,triton
from marlowe_kernels import MoEConfig,MoEWeights,create_moe
from marlowe_kernels._kernels.amd.glm52_moe.persistent import PersistentProgram,PersistentConfig
from benchmarks.moe_replay.protocol import load_metadata,cases
from benchmarks.moe_replay.kernels import touch_input

def main():
    root=Path(os.environ['PERSIST_ROOT']);capture=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    rows=json.loads((root/'screen-grouped-workers.json').read_text());owners={};payloads={};result=[]
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    for b in (1,8,32,64):
        best=min((r for r in rows if r['batch']==b and 'us' in r),key=lambda r:r['us']['persistent'])
        config=PersistentConfig(**{**best['config'],'profile':True})
        meta=load_metadata(capture/f'b{b}-s355052');meta['steps']=meta['steps'][:16]
        data=torch.load(capture/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
        programs={};biases={};logits={}
        for j,lid in enumerate(meta['layers']):
            if lid not in owners:
                p=torch.load(capture/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
                owners[lid]=create_moe(MoEConfig(),MoEWeights(*(p[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4');payloads[lid]=p
            programs[lid]=PersistentProgram(owners[lid],b,config)
            biases[lid]=payloads[lid]['bias'].bfloat16()
            for slot in range(len(meta['steps'])):logits[slot,j]=data['logits'][slot,j].bfloat16().contiguous()
            programs[lid].run(data['input'][0,j],logits[0,j],biases[lid])
        torch.cuda.synchronize();sequence=list(cases(meta));saved=[]
        graph=torch.cuda.CUDAGraph();sink=torch.empty(384,device='cuda')
        with torch.cuda.graph(graph):
            for case in sequence:
                slot,j,lid=case['slot'],case['layer_index'],case['layer'];x=data['input'][slot,j]
                touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                p=programs[lid];p.run(x,logits[slot,j],biases[lid])
                saved.append((p.profile.clone(),p.p['valid'].clone() if not p.c.direct else None))
        for _ in range(4):graph.replay()
        torch.cuda.synchronize();raw=[];cases_out=[]
        for case,(profile,valid) in zip(sequence,saved):
            n=programs[case['layer']].grid if valid is None else int(valid[0])//16
            t=profile[:n].cpu();raw.append(t)
            d=t[:,:,1:]-t[:,:,:-1]
            assert (d>=0).all()
            median=d.reshape(-1,3).double().median(0).values.tolist()
            total=d.sum((0,1)).double();fraction=(total/total.sum()).tolist()
            cases_out.append(dict(layer=case['layer'],step=case['decode_step'],median_ticks=median,
                worker_time_fraction=fraction,span_ticks=int(t[:,:,3].max()-t[:,:,0].min())))
        torch.save(dict(config=dataclasses.asdict(config),cases=sequence,timestamps=raw),root/f'worker-profile-b{b}.pt')
        summary=dict(batch=b,config=dataclasses.asdict(config),phase_names=['G1','handoff_including_middle','G2'],
            median_worker_ticks=[statistics.median(r['median_ticks'][i] for r in cases_out) for i in range(3)],
            mean_worker_time_fraction=[statistics.mean(r['worker_time_fraction'][i] for r in cases_out) for i in range(3)],cases=cases_out)
        result.append(summary);(root/'worker-profile.json').write_text(json.dumps(result,indent=2))
        print(json.dumps({k:v for k,v in summary.items() if k!='cases'}),flush=True)
        del graph,saved,programs,data;torch.cuda.empty_cache()

if __name__=='__main__':main()
