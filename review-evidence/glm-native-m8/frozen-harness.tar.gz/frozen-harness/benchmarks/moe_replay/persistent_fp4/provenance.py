"""Reject a frozen replay that accidentally imports from the worker's cwd."""
import os
from pathlib import Path
import marlowe_kernels

def validate_source():
    files={'library':str(Path(marlowe_kernels.__file__).resolve()),
           'benchmark':str(Path(__file__).resolve())}
    expected=os.environ.get('PERSIST_SOURCE_ROOT')
    if expected:
        root=Path(expected).resolve()
        for name,path in files.items():
            if not Path(path).is_relative_to(root):
                raise RuntimeError(f'{name} loaded from {path}, outside frozen source {root}; cd to the frozen directory before python -m')
        files['frozen_root']=str(root)
    return files
