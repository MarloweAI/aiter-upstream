"""Plot saved counters/timings; never runs an experiment."""
import argparse,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
    data=json.loads((a.evidence/'summary.json').read_text());stages=json.loads((a.evidence/'stages.json').read_text())
    arms=['native','bf16','persistent','block'];labels=['Native FP4','BF16 Port-EW','Persistent fusion','Block-local fusion']
    colors=['#2873ad','#29a17a','#d16442','#9b73b2'];batches=[8,32,64];x=np.arange(3);width=.19
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    for i,(arm,label,color) in enumerate(zip(arms,labels,colors)):
        values=[next(r for r in data if r['batch']==b and r['arm']==arm) for b in batches]
        for ax,key in [(axes[0,0],'unprofiled_moe_us'),(axes[0,1],'read_TBs')]:
            ax.bar(x+(i-1.5)*width,[v[key] for v in values],width,color=color,label=label)
        ss=[next(r for r in stages if r['batch']==b and r['arm']==arm and r['stage']==('g2' if arm in ('native','bf16') else 'fused')) for b in batches]
        axes[1,0].bar(x+(i-1.5)*width,[v['mean_occupancy_per_cu'] for v in ss],width,color=color,label=label)
        axes[1,1].bar(x+(i-1.5)*width,[v['counters_per_call']['TCP_TCC_ATOMIC_WITHOUT_RET_REQ_sum']/1000 for v in ss],width,color=color,label=label)
    titles=['MoE latency (uninstrumented)','DRAM reads ÷ uninstrumented MoE time',
            'Occupancy: separate G2 or complete fused kernel','Output atomic requests without return']
    units=['µs','TB/s (diagnostic estimate)','Average waves per CU','Thousands of requests / MoE']
    for ax,title,unit in zip(axes.flat,titles,units):
        ax.set_title(title,fontsize=11);ax.set_ylabel(unit);ax.set_xticks(x,[f'B{b}' for b in batches])
        ax.spines[['top','right']].set_visible(False);ax.set_axisbelow(True);ax.grid(axis='y',alpha=.2)
    axes[0,0].legend(fontsize=8)
    fig.suptitle('MI355X · GLM-5.2 TP8 rank-0 MoE\nCaptured logits → combine; 30 layers × 2 ordered decode steps',fontsize=14)
    fig.savefig(a.evidence/'comparison.png',dpi=180)
    fig.savefig(a.evidence/'comparison.pdf')

if __name__=='__main__':main()
