"""Qualify a frozen candidate against AITER and all established local controls."""
import json,os
from pathlib import Path
from marlowe_kernels import create_moe
from benchmarks.moe_replay.native_fp4 import replay as base
from benchmarks.moe_replay import run
from marlowe_kernels._kernels.amd.glm52_moe.hybrid_program import HybridProgram
from marlowe_kernels._kernels.amd.glm52_moe.scheduled_program import ScheduledProgram,ScheduledConfig
from marlowe_kernels._kernels.amd.glm52_moe.prefetch_program import PrefetchProgram,PrefetchConfig
from marlowe_kernels._kernels.amd.glm52_moe.last_split import LastSplitProgram,LastSplitConfig
from marlowe_kernels._kernels.amd.glm52_moe.persistent import PersistentProgram,PersistentConfig
from marlowe_kernels._kernels.amd.glm52_moe.block_fused import BlockProgram,BlockConfig
from marlowe_kernels._kernels.amd.glm52_moe.fused_dispatch import DispatchProgram,DispatchConfig
from marlowe_kernels._kernels.amd.glm52_moe.mixed_packed import MixedProgram,MixedConfig
from marlowe_kernels._kernels.amd.glm52_moe.aiter_bins import AiterBinsProgram,AiterBinsConfig
from marlowe_kernels._kernels.amd.glm52_moe.direct_program import DirectProgram
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedProgram,CoalescedConfig
from marlowe_kernels._kernels.amd.glm52_moe.ordered_program import OrderedProgram,OrderedConfig
from marlowe_kernels._kernels.amd.glm52_moe.pair_program import PairProgram,PairConfig
from marlowe_kernels._kernels.amd.glm52_moe.consumer_program import ConsumerProgram,ConsumerConfig
from marlowe_kernels._kernels.amd.glm52_moe.inline_program import InlineProgram,InlineConfig
from marlowe_kernels._kernels.amd.glm52_moe.fixed_bins import FixedBinProgram,FixedBinConfig
from marlowe_kernels._kernels.amd.glm52_moe.grouped_pair_program import GroupedPairProgram,GroupedPairConfig
from marlowe_kernels._kernels.amd.glm52_moe.overlap_consumer import OverlapProgram
from marlowe_kernels._kernels.amd.glm52_moe.safe_fixed_program import SafeFixedProgram,SafeFixedConfig
from .provenance import validate_source

ROOT=Path(os.environ['PERSIST_ROOT'])
CHOICES=json.loads((ROOT/os.environ.get('PERSIST_CONFIG_FILE','candidate-configs.json')).read_text())
PREVIOUS=json.loads((ROOT/os.environ['PERSIST_PREVIOUS_CONFIGS']).read_text()) if os.environ.get('PERSIST_PREVIOUS_CONFIGS') else None
FAMILIES=dict(safe_fixed=(SafeFixedProgram,SafeFixedConfig),overlap=(OverlapProgram,ConsumerConfig),fixed=(FixedBinProgram,FixedBinConfig),grouped_pair=(GroupedPairProgram,GroupedPairConfig),pair=(PairProgram,PairConfig),inline=(InlineProgram,InlineConfig),consumer=(ConsumerProgram,ConsumerConfig),scheduled=(ScheduledProgram,ScheduledConfig),prefetch=(PrefetchProgram,PrefetchConfig),
              last_split=(LastSplitProgram,LastSplitConfig),persistent=(PersistentProgram,PersistentConfig),
              block=(BlockProgram,BlockConfig),dispatch=(DispatchProgram,DispatchConfig),mixed=(MixedProgram,MixedConfig),
              aiter_bins=(AiterBinsProgram,AiterBinsConfig),coalesced=(CoalescedProgram,CoalescedConfig),ordered=(OrderedProgram,OrderedConfig))

class CandidateLayer(base.NativeLayer):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw)
        self.candidate=create_moe(self.port.config,self.port.weights,implementation='native_fp4')
        self.hybrid=create_moe(self.port.config,self.port.weights,implementation='native_fp4')
        self.mixed_ref=create_moe(self.port.config,self.port.weights,implementation='native_fp4') if os.environ.get('PERSIST_COMPARE_DIRECT8')=='1' else None
        self.previous=create_moe(self.port.config,self.port.weights,implementation='native_fp4') if PREVIOUS else None
    def warmup(self,b):
        super().warmup(b)
        if b not in self.candidate._programs:
            entry=CHOICES[str(b)];program,config=FAMILIES[entry['family']]
            self.candidate._programs[b]=program(self.candidate,b,config(**entry['config']))
            self.hybrid._programs[b]=HybridProgram(self.hybrid,b)
        for owner in (self.candidate,self.hybrid):
            owner.warmup((b,),routing='internal');owner.warmup((b,),routing='supplied')
        if self.mixed_ref is not None:
            assert b==8,'The additional control is needed only at B8'
            if b not in self.mixed_ref._programs:self.mixed_ref._programs[b]=DirectProgram(self.mixed_ref,b,share=True,kernel_batch=None,native_g1=True)
            self.mixed_ref.warmup((b,),routing='internal');self.mixed_ref.warmup((b,),routing='supplied')
        if self.previous is not None:
            if b not in self.previous._programs:
                entry=PREVIOUS[str(b)];program,config=FAMILIES[entry['family']]
                self.previous._programs[b]=program(self.previous,b,config(**entry['config']))
            self.previous.warmup((b,),routing='internal');self.previous.warmup((b,),routing='supplied')
    def from_logits(self,x,logits,variant):
        if variant not in ('candidate','hybrid','mixed_ref','previous'):return super().from_logits(x,logits,variant)
        import torch
        owner={'candidate':self.candidate,'hybrid':self.hybrid,'mixed_ref':self.mixed_ref,'previous':self.previous}[variant]
        if logits.dtype==torch.bfloat16:out=owner(x,logits,self.bias_by_dtype[logits.dtype])
        else:
            weights,ids=self.routes(x,logits);out=owner.forward_routed(x,ids,weights)
        self.last_logits=logits;self.last_ids,self.last_weights=owner.routing(len(x))
        return out
    def expert_routed(self,x,ids,weights,variant):
        if variant not in ('candidate','hybrid','mixed_ref','previous'):return super().expert_routed(x,ids,weights,variant)
        owner={'candidate':self.candidate,'hybrid':self.hybrid,'mixed_ref':self.mixed_ref,'previous':self.previous}[variant]
        return owner.forward_routed(x,ids[:,:8].contiguous(),weights[:,:8].contiguous())

def main():
    source_paths=validate_source()
    original=run.main
    def paired(argv,**kw):
        argv=list(argv);argv[argv.index('--output')+1]=str(ROOT/os.environ.get('PERSIST_REPLAY','qualified'))
        kw['port_variants']=('port_ew','port_fp4','hybrid','candidate')
        if os.environ.get('PERSIST_COMPARE_DIRECT8')=='1':kw['port_variants']+=('mixed_ref',)
        if PREVIOUS:kw['port_variants']+=('previous',)
        kw['native_reference_variants']=('hybrid','candidate') if os.environ.get('PERSIST_NATIVE_REFERENCE')=='1' else ('hybrid',)
        def validate_program(program,layer,b):
            if hasattr(program,'state_check'):return dict(layer=layer.layer_id,batch=b,**program.state_check())
            if isinstance(program,(CoalescedProgram,OrderedProgram)) and not program.cc.dispatch:
                return dict(layer=layer.layer_id,batch=b,passed=True,stateless_dispatch=True)
            if isinstance(program,AiterBinsProgram):return dict(layer=layer.layer_id,batch=b,passed=int(program.state[-1])==0,publication_error=int(program.state[-1]))
            if isinstance(program,DispatchProgram) and not (isinstance(program,MixedProgram) and not program.mc.dispatch):
                status=program.state.cpu()
                return dict(layer=layer.layer_id,batch=b,passed=int(status[-1])==0 and not bool(status[4:-1].any()),
                            publication_error=int(status[-1]),metadata_reset=not bool(status[4:-1].any()))
            return dict(layer=layer.layer_id,batch=b,passed=True,stateless_dispatch=True)
        def validate(layer,b):
            result=validate_program(layer.candidate._programs[b],layer,b)
            if layer.previous is not None:
                previous=validate_program(layer.previous._programs[b],layer,b)
                result.update(previous=previous,passed=result['passed'] and previous['passed'])
            return result
        kw['state_validator']=validate
        kw['runtime_identity']['candidate_configs']=CHOICES
        kw['runtime_identity']['previous_configs']=PREVIOUS
        kw['runtime_identity']['hybrid_reference_commit']='be50fbc'
        kw['runtime_identity']['source_paths']=source_paths
        return original(argv,**kw)
    base.NativeLayer=CandidateLayer;run.main=paired
    base.main()

if __name__=='__main__':main()
