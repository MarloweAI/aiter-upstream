"""Paired ordered-capture screen with untimed input preloading.

Fixed captured logits: excludes the common router GEMM. Only final replay
qualifies the complete router-through-combine comparison.
"""
import dataclasses,gc,json,os,statistics,sys
from pathlib import Path
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeProgram
from marlowe_kernels._kernels.amd.glm52_moe.program import Program
from marlowe_kernels._kernels.amd.glm52_moe.persistent import PersistentConfig,PersistentProgram
from benchmarks.moe_replay.native_fp4.tune import ScreenLayer
from benchmarks.moe_replay.reference import compare,expert_reference
from benchmarks.moe_replay.run import prepare_graph,timings
from benchmarks.moe_replay.protocol import cases,load_metadata
if os.environ.get('PERSIST_FAMILY')=='safe_fixed':
    from marlowe_kernels._kernels.amd.glm52_moe.safe_fixed_program import SafeFixedConfig as PersistentConfig,SafeFixedProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='flat':
    from marlowe_kernels._kernels.amd.glm52_moe.flat_bins import FlatBinConfig as PersistentConfig,FlatBinProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='fixed':
    from marlowe_kernels._kernels.amd.glm52_moe.fixed_bins import FixedBinConfig as PersistentConfig,FixedBinProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='local_split':
    from marlowe_kernels._kernels.amd.glm52_moe.local_split_program import LocalSplitConfig as PersistentConfig,LocalSplitProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='grouped_pair':
    from marlowe_kernels._kernels.amd.glm52_moe.grouped_pair_program import GroupedPairConfig as PersistentConfig,GroupedPairProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='inline':
    from marlowe_kernels._kernels.amd.glm52_moe.inline_program import InlineConfig as PersistentConfig,InlineProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='pair':
    from marlowe_kernels._kernels.amd.glm52_moe.pair_program import PairConfig as PersistentConfig,PairProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='merge8':
    from marlowe_kernels._kernels.amd.glm52_moe.merge8_program import Merge8Config as PersistentConfig,Merge8Program as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='last_producer':
    from marlowe_kernels._kernels.amd.glm52_moe.last_producer import LastProducerConfig as PersistentConfig,LastProducerProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='overlap':
    from marlowe_kernels._kernels.amd.glm52_moe.overlap_consumer import ConsumerConfig as PersistentConfig,OverlapProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='consumer':
    from marlowe_kernels._kernels.amd.glm52_moe.consumer_program import ConsumerConfig as PersistentConfig,ConsumerProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='ordered':
    from marlowe_kernels._kernels.amd.glm52_moe.ordered_program import OrderedConfig as PersistentConfig,OrderedProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='coalesced':
    from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedConfig as PersistentConfig,CoalescedProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='block':
    from marlowe_kernels._kernels.amd.glm52_moe.block_fused import BlockConfig as PersistentConfig,BlockProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='prefetch':
    from marlowe_kernels._kernels.amd.glm52_moe.prefetch_program import PrefetchConfig as PersistentConfig,PrefetchProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='scheduled':
    from marlowe_kernels._kernels.amd.glm52_moe.scheduled_program import ScheduledConfig as PersistentConfig,ScheduledProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='last_split':
    from marlowe_kernels._kernels.amd.glm52_moe.last_split import LastSplitConfig as PersistentConfig,LastSplitProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='dispatch':
    from marlowe_kernels._kernels.amd.glm52_moe.fused_dispatch import DispatchConfig as PersistentConfig,DispatchProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='mixed':
    from marlowe_kernels._kernels.amd.glm52_moe.mixed_packed import MixedConfig as PersistentConfig,MixedProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='aiter_bins':
    from marlowe_kernels._kernels.amd.glm52_moe.aiter_bins import AiterBinsConfig as PersistentConfig,AiterBinsProgram as PersistentProgram

def main():
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    root=Path(os.environ['PERSIST_ROOT'])
    capture=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    owners={};payloads={};records=[]
    cfgs=json.loads(os.environ.get('PERSIST_CONFIGS','[{"workers_per_cu":1},{"workers_per_cu":2},{"workers_per_cu":4}]'))
    for b in map(int,sys.argv[1:] or [1,2,4,8,16,32,64]):
        source=capture/f'b{b}-s355052';meta=load_metadata(source)
        meta['steps']=meta['steps'][:int(os.environ.get('PERSIST_STEPS','16'))]
        # Always use all 30 distinct weight sets; layer locality must remain
        # representative even in the short-step screen.
        sequence=list(cases(meta));data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
        for lid in meta['layers']:
            if lid not in owners:
                p=torch.load(capture/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
                owners[lid]=create_moe(MoEConfig(),MoEWeights(*(p[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
                payloads[lid]=p
        baseline_layers={}
        controls=[('native',NativeProgram)]
        if os.environ.get('PERSIST_ONLY_CURRENT')!='1':controls.append(('bf16',Program))
        if os.environ.get('PERSIST_MIXED_CONTROL'):
            from marlowe_kernels._kernels.amd.glm52_moe.mixed_packed import MixedProgram,MixedConfig
            mixed=MixedConfig(**json.loads(os.environ['PERSIST_MIXED_CONTROL']))
            controls.append(('current',lambda owner,batch:MixedProgram(owner,batch,mixed)))
        elif os.environ.get('PERSIST_CURRENT_CONTROL')=='1':
            from marlowe_kernels._kernels.amd.glm52_moe.selected_program import create_selected_program
            controls.append(('current',create_selected_program))
        for variant,cls in controls:
            baseline_layers[variant]={lid:ScreenLayer(owners[lid],cls(owners[lid],b),
                {data['input'][slot,j].data_ptr():data['logits'][slot,j].bfloat16().contiguous() for slot in range(len(meta['steps']))},
                payloads[lid]['bias'].bfloat16()) for j,lid in enumerate(meta['layers'])}
        baseline_graphs={}
        for variant,layers in baseline_layers.items():
            for j,lid in enumerate(meta['layers']):layers[lid](data['input'][0,j],variant)
            torch.cuda.synchronize()
            baseline_graphs[variant]=prepare_graph(sequence,layers,data,variant,True,True)
        seen=set()
        for cfg in (cfgs[str(b)] if isinstance(cfgs,dict) else cfgs):
            from marlowe_kernels._kernels.amd.glm52_moe.native_program import NATIVE_CONFIGS
            base=NATIVE_CONFIGS[b]
            defaults=dict(direct=base.direct,gate_n=base.gate_n,split_k=base.split_k)
            if os.environ.get('PERSIST_FAMILY')=='block':defaults.update(gate_n=128,split_k=1)
            elif os.environ.get('PERSIST_FAMILY') in ('prefetch','scheduled','last_split','dispatch','coalesced','ordered','last_producer','merge8','pair','inline','grouped_pair','local_split','fixed','flat','safe_fixed'):defaults.update(gate_waves=base.gate_waves,down_n=base.down_n,down_waves=base.down_waves)
            elif os.environ.get('PERSIST_FAMILY')=='mixed':defaults=dict(down_n=base.down_n,down_waves=base.down_waves)
            elif os.environ.get('PERSIST_FAMILY')=='aiter_bins':defaults={}
            cfg={**defaults,**cfg};c=PersistentConfig(**cfg)
            if os.environ.get('PERSIST_FAMILY')=='mixed':
                from marlowe_kernels._kernels.amd.glm52_moe.configs import CONFIGS
                gate=CONFIGS[b]
                c=dataclasses.replace(c,gate_split=c.gate_split or gate.split_k,
                    gate_schedule=gate.gate_schedule if c.gate_schedule<0 else c.gate_schedule,gate_n=c.gate_n or gate.gate_n)
            if os.environ.get('PERSIST_FAMILY')=='prefetch' and c.depth:
                steps=48//c.split_k;blocks=c.gate_n//c.gate_waves//16
                effective=max(d for d in range(1,min(c.depth,steps)+1) if steps%d==0 and (d-1)*(2+2*blocks)<=63)
                c=dataclasses.replace(c,depth=effective)
            if c in seen:continue
            seen.add(c)
            print('BUILD',b,c,flush=True)
            layers={lid:ScreenLayer(owners[lid],PersistentProgram(owners[lid],b,c),
                baseline_layers['native'][lid].logits,payloads[lid]['bias'].bfloat16()) for lid in meta['layers']}
            checks=[]
            for case in (sequence[0],sequence[len(sequence)//2],sequence[-1]):
                x=data['input'][case['slot'],case['layer_index']];lid=case['layer']
                out=layers[lid](x,'persistent').clone()
                if os.environ.get('PERSIST_FAMILY')=='aiter_bins' or (os.environ.get('PERSIST_FAMILY') in ('coalesced','ordered','last_producer','merge8','pair','inline','grouped_pair','local_split','fixed','flat','safe_fixed') and c.combine=='ordered'):
                    p=layers[lid].program
                    w={k:payloads[lid][k] for k in ('w1','w2','w1_scale','w2_scale')}
                    ref=expert_reference(w,x,p.p['ids'],p.p['weights'],True if os.environ.get('PERSIST_FAMILY')=='aiter_bins' else p.fp32_middle)
                else:ref=baseline_layers['native'][lid](x,'native').clone()
                torch.cuda.synchronize();checks.append(compare(out,ref))
                if (os.environ.get('PERSIST_FAMILY') in ('coalesced','ordered','last_producer','merge8','pair','inline','grouped_pair','local_split','fixed','flat','safe_fixed') and c.dispatch) or os.environ.get('PERSIST_FAMILY') in ('dispatch','aiter_bins') or (os.environ.get('PERSIST_FAMILY')=='mixed' and c.dispatch):
                    checks.append(dict(passed=int(layers[lid].program.state[-1])==0,kind='metadata_publication'))
            if not all(r['passed'] for r in checks):
                row=dict(batch=b,config=dataclasses.asdict(c),checks=checks,failed=True)
            else:
                for j,lid in enumerate(meta['layers']):layers[lid](data['input'][0,j],'persistent')
                torch.cuda.synchronize()
                graph=prepare_graph(sequence,layers,data,'persistent',True,True)
                tm=timings({**baseline_graphs,'persistent':graph},int(os.environ.get('PERSIST_SAMPLES','12')),4)
                row=dict(batch=b,config=dataclasses.asdict(c),checks=checks,
                    us={k:statistics.mean(v['interval_medians_us']) for k,v in tm.items()},
                    timing=tm,resource=layers[meta['layers'][0]].program.info)
                if (os.environ.get('PERSIST_FAMILY') in ('coalesced','ordered','last_producer','merge8','pair','inline','grouped_pair','local_split','fixed','flat','safe_fixed') and c.dispatch) or os.environ.get('PERSIST_FAMILY') in ('dispatch','aiter_bins') or (os.environ.get('PERSIST_FAMILY')=='mixed' and c.dispatch):
                    row['metadata_errors']={str(lid):int(layer.program.state[-1]) for lid,layer in layers.items()}
                    if any(row['metadata_errors'].values()):row.update(failed=True,failure_reason='metadata_publication_timeout')
                del graph
            if hasattr(layers[lid].program,'state_check'):
                row['state_checks']={str(key):layer.program.state_check() for key,layer in layers.items()}
                if not all(v['passed'] for v in row['state_checks'].values()):row.update(failed=True,failure_reason='dispatch_state')
            records.append(row)
            print(json.dumps({k:v for k,v in row.items() if k!='timing'}),flush=True)
            (root/os.environ.get('PERSIST_RESULT','screen.json')).write_text(json.dumps(records,indent=2))
            del layers;gc.collect()
        del baseline_graphs,baseline_layers,data;gc.collect();torch.cuda.empty_cache()

if __name__=='__main__':main()
