"""ROI-delimited hardware counters for the same ordered, cold-weight workload.

Counter-instrumented durations are diagnostic only. The timing mode uses native
HIP events without rocprofiler. All 30 layer weight sets are retained.
"""
import argparse,ctypes,hashlib,json,os,statistics
from pathlib import Path
import torch
from marlowe_kernels import MoEConfig,MoEWeights,create_moe
from marlowe_kernels._runtime import source_digest
from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeProgram
from marlowe_kernels._kernels.amd.glm52_moe.program import Program
from marlowe_kernels._kernels.amd.glm52_moe.persistent import PersistentProgram,PersistentConfig
from marlowe_kernels._kernels.amd.glm52_moe.block_fused import BlockProgram,BlockConfig
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedProgram,CoalescedConfig
from marlowe_kernels._kernels.amd.glm52_moe.prefetch_program import PrefetchProgram,PrefetchConfig
from benchmarks.moe_replay.native_fp4.tune import ScreenLayer
from benchmarks.moe_replay.protocol import cases,load_metadata
from benchmarks.moe_replay.run import prepare_graph,timings
from benchmarks.moe_replay.dispatch_audit import capture_dispatch
from benchmarks.moe_replay.reference import compare
from .provenance import validate_source

def main():
    source_paths=validate_source()
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--mode',choices=['timing','counters'],default='counters')
    p.add_argument('--followup',action='store_true',help='Compare added consumers and coalesced G2 to original native/persistent')
    p.add_argument('--arms',nargs='+',help='Limit follow-up profiling to the changed paths and a paired control')
    p.add_argument('--combine',choices=['wave','lds'],default='wave')
    p.add_argument('--batches',nargs='+',type=int,default=[8,32,64]);p.add_argument('--steps',type=int,default=2)
    p.add_argument('--repeats',type=int,default=3);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    root=Path(os.environ['PERSIST_ROOT']);capture=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    choices=json.loads((root/'screen-grouped-workers.json').read_text())
    block_choices=json.loads((root/'screen-lds.json').read_text())
    identity=dict(source_sha256=source_digest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  torch=torch.__version__,hip=torch.version.hip,gpu=str(torch.cuda.get_device_properties(0)),source_paths=source_paths,
                  job=os.environ['SLURM_JOB_ID'],steps=a.steps,repeats=a.repeats,
                  aiter='34947d4012bec80888581adc035e9ab6156d129b',sglang='c46bf5e990bdd99e2c200214b04683022100e4df')
    roctx=ctypes.CDLL('/opt/rocm/lib/librocprofiler-sdk-roctx.so');roctx.roctxRangePushA.argtypes=[ctypes.c_char_p]
    owners={};payloads={}
    for b in a.batches:
        meta=load_metadata(capture/f'b{b}-s355052');meta['steps']=meta['steps'][:a.steps]
        sequence=list(cases(meta));data=torch.load(capture/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=True)
        group=min((r for r in choices if r['batch']==b and 'us' in r),key=lambda r:r['us']['persistent'])['config']
        group['profile']=False
        available=[r for r in block_choices if r['batch']==b and 'us' in r]
        block=min(available,key=lambda r:r['us']['persistent'])['config'] if available else dict(direct=False,gate_n=128,down_n=64,split_k=1,replicas=2,non_temporal=False,lds=True)
        configs=dict(persistent=group,block=block)
        arms=('native','bf16','persistent','block')
        if a.followup:
            arms=('native','persistent','expanded','prefetched','wave','coalesced')
            configs['expanded']=dict(schedule='groups',coherent_intermediate=True,gate_n=128,
                split_k=1,down_n=64,group_parts=4,counter_stride=32,consumer_parts=16,workers_per_cu=8)
            from marlowe_kernels._kernels.amd.glm52_moe.native_program import NATIVE_CONFIGS
            base=NATIVE_CONFIGS[b]
            configs['coalesced']={k:v for k,v in base.__dict__.items() if k not in ('gate_pipeline','down_pipeline')}
            configs['coalesced'].update(depth=0,down_depth=2)
            configs['prefetched']=configs['coalesced'].copy()
            configs['coalesced']['combine']=a.combine
            configs['wave']=dict(configs['coalesced'],combine='wave')
        if a.arms:
            assert 'native' in a.arms and set(a.arms).issubset(arms)
            arms=tuple(a.arms)
        layers={name:{} for name in arms}
        for j,lid in enumerate(meta['layers']):
            if lid not in owners:
                q=torch.load(capture/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
                owners[lid]=create_moe(MoEConfig(),MoEWeights(*(q[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4');payloads[lid]=q
            programs={}
            for name in arms:
                cls,cfg={'native':(NativeProgram,None),'bf16':(Program,None),
                    'persistent':(PersistentProgram,PersistentConfig(**group)),
                    'block':(BlockProgram,BlockConfig(**block)),
                    'expanded':(PersistentProgram,PersistentConfig(**configs.get('expanded',group))),
                    'prefetched':(PrefetchProgram,PrefetchConfig(**configs.get('prefetched',{}))),
                    'wave':(CoalescedProgram,CoalescedConfig(**configs.get('wave',{}))),
                    'coalesced':(CoalescedProgram,CoalescedConfig(**configs.get('coalesced',{})))}[name]
                programs[name]=cls(owners[lid],b) if cfg is None else cls(owners[lid],b,cfg)
            logits={data['input'][slot,j].data_ptr():data['logits'][slot,j].bfloat16().contiguous() for slot in range(len(meta['steps']))}
            for name,program in programs.items():layers[name][lid]=ScreenLayer(owners[lid],program,logits,payloads[lid]['bias'].bfloat16())
        checks=[];routes=[]
        for case in sequence:
            lid,j,slot=case['layer'],case['layer_index'],case['slot'];x=data['input'][slot,j]
            reference=layers['native'][lid](x,'native').clone()
            ids=layers['native'][lid].program.p['ids'].clone();counts=torch.bincount(ids.flatten().long(),minlength=257).cpu().tolist()
            assert sum(counts[:256])==8*b and counts[256]==b
            routes.append(dict(**case,expert_counts=counts,active_experts=sum(v>0 for v in counts),
                useful_weight_bytes=sum(v>0 for v in counts)*2506752))
            for name in (arm for arm in arms if arm!='native'):
                y=layers[name][lid](x,name).clone();torch.cuda.synchronize()
                check=compare(y,reference);assert check['passed'],(b,case,name,check)
                assert torch.equal(layers[name][lid].program.p['ids'],ids)
                checks.append(dict(layer=lid,step=case['decode_step'],variant=name,check=check))
        signatures={};graphs={}
        for name,items in layers.items():
            first=meta['layers'][0];x=data['input'][0,0]
            trace,_,captured=capture_dispatch(lambda:items[first](x,name));signatures[name]=trace['nodes'];del captured
            graphs[name]=prepare_graph(sequence,items,data,name,True,a.mode=='timing')
        record=dict(batch=b,identity=identity,sequence=routes,configs=configs,checks=checks,signatures=signatures,
                    scope='fixed captured logits: preparation through local combine, shared included')
        if a.mode=='timing':
            record['timing']=timings(graphs,30,8)
            print('TIMING',b,{k:statistics.mean(v['interval_medians_us']) for k,v in record['timing'].items()},flush=True)
        else:
            for graph in graphs.values():
                for _ in range(3):graph['graph'].replay()
            torch.cuda.synchronize()
            for repetition in range(a.repeats):
                for name,graph in graphs.items():
                    roctx.roctxRangePushA(f'marlowe_fusion_b{b}_{name}_r{repetition}'.encode())
                    graph['graph'].replay();torch.cuda.synchronize();roctx.roctxRangePop()
            print('COUNTERS',b,'complete',flush=True)
        (a.output/f'b{b}.json').write_text(json.dumps(record,indent=2))
        del graphs,layers,data;torch.cuda.empty_cache()

if __name__=='__main__':main()
