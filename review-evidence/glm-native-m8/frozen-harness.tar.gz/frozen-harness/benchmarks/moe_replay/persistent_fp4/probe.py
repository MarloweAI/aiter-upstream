"""Small correctness screen; never reported as qualified replay performance."""
import json,os,sys
from pathlib import Path
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.persistent import PersistentConfig,PersistentProgram
from benchmarks.moe_replay.reference import expert_reference,compare
if os.environ.get('PERSIST_FAMILY')=='overlap':
    from marlowe_kernels._kernels.amd.glm52_moe.overlap_consumer import ConsumerConfig as PersistentConfig,OverlapProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='inline':
    from marlowe_kernels._kernels.amd.glm52_moe.inline_program import InlineConfig as PersistentConfig,InlineProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='consumer':
    from marlowe_kernels._kernels.amd.glm52_moe.consumer_program import ConsumerConfig as PersistentConfig,ConsumerProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='ordered':
    from marlowe_kernels._kernels.amd.glm52_moe.ordered_program import OrderedConfig as PersistentConfig,OrderedProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='coalesced':
    from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedConfig as PersistentConfig,CoalescedProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='block':
    from marlowe_kernels._kernels.amd.glm52_moe.block_fused import BlockConfig as PersistentConfig,BlockProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='prefetch':
    from marlowe_kernels._kernels.amd.glm52_moe.prefetch_program import PrefetchConfig as PersistentConfig,PrefetchProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='scheduled':
    from marlowe_kernels._kernels.amd.glm52_moe.scheduled_program import ScheduledConfig as PersistentConfig,ScheduledProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='last_split':
    from marlowe_kernels._kernels.amd.glm52_moe.last_split import LastSplitConfig as PersistentConfig,LastSplitProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='dispatch':
    from marlowe_kernels._kernels.amd.glm52_moe.fused_dispatch import DispatchConfig as PersistentConfig,DispatchProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='mixed':
    from marlowe_kernels._kernels.amd.glm52_moe.mixed_packed import MixedConfig as PersistentConfig,MixedProgram as PersistentProgram
elif os.environ.get('PERSIST_FAMILY')=='aiter_bins':
    from marlowe_kernels._kernels.amd.glm52_moe.aiter_bins import AiterBinsConfig as PersistentConfig,AiterBinsProgram as PersistentProgram

def main():
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    root=Path(os.environ['PERSIST_ROOT'])
    capture=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    payload=torch.load(capture/'weights/layer-3.pt',map_location='cuda',weights_only=False)
    w={k:payload[k] for k in ('w1','w2','w1_scale','w2_scale')}
    owner=create_moe(MoEConfig(),MoEWeights(*w.values()),implementation='native_fp4')
    records=[]
    configs=json.loads(os.environ.get('PERSIST_CONFIGS','[{"direct":true,"split_k":2},{"direct":false,"split_k":2}]'))
    for b in map(int,sys.argv[1:] or [1,8,16,32,64]):
        data=torch.load(capture/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=False)
        x=data['input'][0,0].contiguous();logits=data['logits'][0,0].bfloat16().contiguous()
        for cfg in configs:
            print('BUILD',b,cfg,flush=True)
            program=PersistentProgram(owner,b,PersistentConfig(**cfg))
            print('COMPILED',program.info,flush=True)
            y=program.run(x,logits,payload['bias'].bfloat16()).clone();torch.cuda.synchronize()
            if (os.environ.get('PERSIST_FAMILY') in ('coalesced','ordered') and program.cc.dispatch) or os.environ.get('PERSIST_FAMILY')=='dispatch' or (os.environ.get('PERSIST_FAMILY')=='mixed' and program.mc.dispatch):
                assert int(program.state[-1])==0,'dispatch metadata publication timeout'
                assert not bool(program.state[4:-1].any()),'G2 did not reset metadata'
            if os.environ.get('PERSIST_FAMILY')=='aiter_bins':assert int(program.state[-1])==0,'metadata publication timeout'
            ref=expert_reference(w,x,program.p['ids'],program.p['weights'],program.fp32_middle)
            check=compare(y,ref)
            row=dict(batch=b,config=cfg,check=check,resource=program.info,state=program.state.cpu().tolist() if hasattr(program,'state') else None)
            records.append(row);print(json.dumps(row),flush=True)
            (root/'probe.json').write_text(json.dumps(records,indent=2))
            if not check['passed']:
                failure=dict(input=x,logits=logits,out=y,ref=ref)
                for name in ('mid','partial','mid_scale','state'):
                    if hasattr(program,name):failure[name]=getattr(program,name)
                torch.save(failure,root/f'failure-b{b}.pt')
                raise RuntimeError('correctness failed')
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):result=program.run(x,logits,payload['bias'].bfloat16())
            for _ in range(20):graph.replay()
            torch.cuda.synchronize()
            row['graph_check']=compare(result,ref)
            print('GRAPH',row['graph_check'],flush=True)
            assert row['graph_check']['passed']
            if os.environ.get('PERSIST_STRESS'):
                from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeProgram
                if os.environ.get('PERSIST_FAMILY')=='aiter_bins':
                    from marlowe_kernels._kernels.amd.glm52_moe.hybrid_program import HybridProgram
                    base=HybridProgram(owner,b)
                else:base=NativeProgram(owner,b)
                inputs=[];expected=[]
                for step in range(min(16,data['input'].shape[0])):
                    sx=data['input'][step,0].contiguous();sl=data['logits'][step,0].bfloat16().contiguous()
                    inputs.append((sx,sl));baseline=base.run(sx,sl,payload['bias'].bfloat16()).clone()
                    if os.environ.get('PERSIST_FAMILY') in ('coalesced','ordered') and program.cc.combine=='ordered':
                        baseline=expert_reference(w,sx,base.p['ids'],base.p['weights'],base.fp32_middle)
                    expected.append(baseline)
                    if os.environ.get('PERSIST_ROUTE_EXACT'):
                        expected_ids=base.p['ids'].clone();expected_weights=base.p['weights'].clone()
                        program.run(sx,sl,payload['bias'].bfloat16())
                        assert torch.equal(program.p['ids'],expected_ids),'route IDs changed'
                        assert torch.equal(program.p['weights'],expected_weights),'route weights changed'
                stream_graph=torch.cuda.CUDAGraph();outputs=[]
                with torch.cuda.graph(stream_graph):
                    for sx,sl in inputs:outputs.append(program.run(sx,sl,payload['bias'].bfloat16()).clone())
                for _ in range(10):stream_graph.replay()
                torch.cuda.synchronize()
                stress=[compare(y,r) for y,r in zip(outputs,expected)]
                row['changing_input_graph_checks']=stress
                assert all(v['passed'] for v in stress),stress
                routing=[]
                for concentrated in (False,True):
                    ids=(torch.arange(b*8,device='cuda').view(b,8)%(8 if concentrated else 256)).int()
                    rw=torch.full((b,8),.125,device='cuda')
                    baseline=base.run(x,logits,payload['bias'].bfloat16(),supplied_ids=ids,supplied_weights=rw).clone()
                    if os.environ.get('PERSIST_FAMILY') in ('coalesced','ordered') and program.cc.combine=='ordered':
                        baseline=expert_reference(w,x,base.p['ids'],base.p['weights'],base.fp32_middle)
                    y=program.run(x,logits,payload['bias'].bfloat16(),supplied_ids=ids,supplied_weights=rw).clone()
                    torch.cuda.synchronize();check=compare(y,baseline);routing.append(check)
                    assert check['passed'],check
                row['synthetic_route_checks']=routing
                print('STRESS',b,len(stress),'changing inputs, balanced/concentrated routes passed',flush=True)
    (root/'probe.json').write_text(json.dumps(records,indent=2))

if __name__=='__main__':main()
