"""Fail-closed joins of profiler ROIs, dispatch counters, and separate timings."""
import argparse,collections,csv,json,re,statistics
from pathlib import Path

def read(path):
    with path.open() as f:return list(csv.DictReader(f))

def stages(arm,b):
    if arm in ('native','prefetched','wave','coalesced'):return ['prep']+(['group'] if b>=16 else [])+['g1','middle','g2']
    if arm=='bf16':return ['prep','group','g1']+(['middle'] if b!=32 else [])+['g2']
    if arm in ('persistent','expanded'):return ['prep']+(['group'] if b>=16 else [])+['fused']
    return ['prep','group','fused']

def signature(node):
    assert node['kind']=='kernel'
    label=''.join(node['label']).replace('\\','')
    symbol=re.search(r'_Z(\d+)(\w+)',label)
    assert symbol,label
    name=symbol[2][:int(symbol[1])]
    shape=re.search(r'<<<\((\d+),(\d+),(\d+)\),\((\d+),(\d+),(\d+)\)',label)
    assert shape,label
    dims=list(map(int,shape.groups()))
    return name,tuple(dims[i]*dims[i+3] for i in range(3)),tuple(dims[3:])

def collect(folder,timing_root):
    marks=[r for r in read(folder/'counters_marker_api_trace.csv') if re.fullmatch(r'marlowe_fusion_b\d+_\w+_r\d+',r['Function'])]
    expected=set()
    for f in (folder/'replay').glob('b*.json'):
        record=json.loads(f.read_text())
        expected.update(f"marlowe_fusion_b{record['batch']}_{arm}_r{r}" for arm in record['signatures'] for r in range(record['identity']['repeats']))
    assert len(marks)==len(expected) and {r['Function'] for r in marks}==expected,('incomplete ROI markers',folder,len(marks),len(expected))
    bounds=[(int(r['Start_Timestamp']),int(r['End_Timestamp'])) for r in marks]
    trace=[]
    with (folder/'counters_kernel_trace.csv').open() as f:
        for r in csv.DictReader(f):
            if 'mk_' not in r['Kernel_Name'] and not r['Kernel_Name'].startswith('persistent'):continue
            lo,hi=int(r['Start_Timestamp']),int(r['End_Timestamp'])
            if any(a<=lo<=hi<=z for a,z in bounds):trace.append(r)
    counters=collections.defaultdict(lambda:collections.defaultdict(float))
    for r in read(folder/'counters_counter_collection.csv'):counters[r['Dispatch_Id']][r['Counter_Name']]+=float(r['Counter_Value'])
    rows=[]
    for mark in marks:
        b,arm,rep=re.fullmatch(r'marlowe_fusion_b(\d+)_(\w+)_r(\d+)',mark['Function']).groups();b=int(b);rep=int(rep)
        evidence=json.loads((folder/'replay'/f'b{b}.json').read_text());timing=json.loads((timing_root/f'b{b}.json').read_text())
        assert evidence['sequence']==timing['sequence'] and evidence['configs']==timing['configs']
        for key in ('source_sha256','script_sha256','steps','aiter','sglang','torch','hip'):assert evidence['identity'][key]==timing['identity'][key],key
        start,end=int(mark['Start_Timestamp']),int(mark['End_Timestamp'])
        calls=sorted((r for r in trace if start<=int(r['Start_Timestamp'])<=int(r['End_Timestamp'])<=end),key=lambda r:int(r['Start_Timestamp']))
        labels=stages(arm,b);seq=evidence['sequence'];assert len(calls)==len(seq)*len(labels),(folder,b,arm,rep,len(calls),len(seq)*len(labels))
        expected=[signature(node) for node in timing['signatures'][arm]]
        assert len(expected)==len(labels)
        for i,r in enumerate(calls):
            assert r['Dispatch_Id'] in counters,('missing counters',folder,b,arm,rep,i,r['Kernel_Name'])
            name,grid,block=expected[i%len(labels)]
            assert r['Kernel_Name'].split('(')[0]==name,('kernel mismatch',folder,b,arm,rep,i)
            assert tuple(int(r['Grid_Size_'+d]) for d in 'XYZ')==grid,('grid mismatch',folder,b,arm,rep,i)
            assert tuple(int(r['Workgroup_Size_'+d]) for d in 'XYZ')==block,('block mismatch',folder,b,arm,rep,i)
            case=seq[i//len(labels)];stage=labels[i%len(labels)]
            rows.append(dict(batch=b,arm=arm,repetition=rep,index=i//len(labels),layer=case['layer'],step=case['decode_step'],stage=stage,
                kernel=r['Kernel_Name'],counters=dict(counters[r['Dispatch_Id']]),
                resources={k:int(r[k]) for k in ('LDS_Block_Size','Scratch_Size','VGPR_Count','Accum_VGPR_Count','SGPR_Count','Workgroup_Size_X','Grid_Size_X','Grid_Size_Y','Grid_Size_Z')},
                profiled_us=(int(r['End_Timestamp'])-int(r['Start_Timestamp']))/1000))
    return rows

def ratio(a,b):return a/b if b else None

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--required-groups',nargs='+',default=['memory','compute','scheduling','latency','atomics'])
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    grouped={};errors={}
    for group in ('memory','compute','scheduling','latency','atomics'):
        folder=a.root/group
        if not (folder/'counters_counter_collection.csv').exists():continue
        try:grouped[group]=collect(folder,a.root/'timing')
        except Exception as error:errors[group]=repr(error)
    exits={}
    for group in grouped:
        status=a.root/group/'exit-code.txt'
        if status.exists():exits[group]=int(status.read_text().strip())
        elif group=='memory':
            status=a.root.parent/'commands'/'055.done'
            exits[group]=json.loads(status.read_text())['returncode'] if status.exists() else None
        else:exits[group]=None
    complete=not errors and all(g in grouped for g in a.required_groups)
    validation=dict(groups={g:len(r) for g,r in grouped.items()},errors=errors,
        required_groups=a.required_groups,
        passed=complete,export_coverage_complete=complete,profiler_exit_codes=exits,
        profiler_clean_exit=bool(exits) and all(code==0 for code in exits.values()),
        note='passed validates exported ROI coverage and workload identity, not profiler shutdown; timings come from separate unprofiled HIP-event runs')
    (a.output/'validation.json').write_text(json.dumps(validation,indent=2));print('VALIDATION',validation,flush=True)
    merged={}
    for group,rows in grouped.items():
        for r in rows:
            key=(r['batch'],r['arm'],r['index'],r['stage'])
            item=merged.setdefault(key,dict(**{k:v for k,v in r.items() if k not in ('counters','repetition')},samples=collections.defaultdict(list)))
            for name,value in r['counters'].items():item['samples'][name].append(value)
    per_case=[]
    for item in merged.values():
        item['counters']={k:statistics.median(v) for k,v in item.pop('samples').items()};per_case.append(item)
    (a.output/'per-case.json').write_text(json.dumps(per_case,indent=2))
    summary=[];stage_summary=[]
    for timing_file in sorted((a.root/'timing').glob('b*.json')):
        timing=json.loads(timing_file.read_text());b=timing['batch'];n=len(timing['sequence'])
        for arm in timing['signatures']:
            rr=[r for r in per_case if r['batch']==b and r['arm']==arm]
            if not rr:continue
            sums=collections.defaultdict(float)
            for r in rr:
                for k,v in r['counters'].items():sums[k]+=v
            us=statistics.mean(timing['timing'][arm]['interval_medians_us'])
            row=dict(batch=b,arm=arm,unprofiled_moe_us=us,cases=n,
                dram_read_MB=sums.get('TCC_EA0_RDREQ_DRAM_32B_sum',0)*32/n/1e6,
                dram_write_MB=sums.get('TCC_EA0_WRREQ_WRITE_DRAM_32B_sum',0)*32/n/1e6,
                read_TBs=sums.get('TCC_EA0_RDREQ_DRAM_32B_sum',0)*32/n/us/1e6,
                l2_hit_fraction=ratio(sums.get('TCC_HIT_sum',0),sums.get('TCC_HIT_sum',0)+sums.get('TCC_MISS_sum',0)),
                wait_over_active=ratio(sums.get('SQ_WAIT_INST_ANY',0),sums.get('SQ_ACTIVE_INST_ANY',0)),
                tcp_tcc_read_latency_cycles=ratio(sums.get('TCP_TCC_READ_REQ_LATENCY_sum',0),sums.get('TCP_TCC_READ_REQ_sum',0)),
                counters_per_moe={k:v/n for k,v in sums.items()})
            summary.append(row)
            for stage in stages(arm,b):
                ss=[r for r in rr if r['stage']==stage]
                if not ss:continue
                stage_summary.append(dict(batch=b,arm=arm,stage=stage,
                    mean_occupancy_per_cu=statistics.mean(r['counters'].get('MeanOccupancyPerCU',0) for r in ss),
                    resources=ss[0]['resources'],
                    counters_per_call={k:statistics.mean(r['counters'].get(k,0) for r in ss) for k in sums}))
    (a.output/'summary.json').write_text(json.dumps(summary,indent=2));(a.output/'stages.json').write_text(json.dumps(stage_summary,indent=2))
    print(json.dumps([{k:v for k,v in r.items() if k!='counters_per_moe'} for r in summary],indent=2))
    if not validation['passed']:raise SystemExit('Incomplete or mismatched counter exports; see validation.json')

if __name__=='__main__':main()
