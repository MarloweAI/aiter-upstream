"""Preserve a pairwise atomic-sum discrepancy and check both outputs independently."""
import hashlib,json,os
from pathlib import Path
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeProgram
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedProgram,CoalescedConfig
from benchmarks.moe_replay.reference import compare,expert_reference
from benchmarks.moe_replay.persistent_fp4.provenance import validate_source

def main():
    source=validate_source();torch.set_grad_enabled(False);torch.set_num_threads(4)
    root=Path(os.environ['PERSIST_ROOT']);capture=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    q=torch.load(capture/'weights/layer-77.pt',map_location='cuda',weights_only=True)
    data=torch.load(capture/'b64-s355052/tensors.pt',map_location='cuda',weights_only=True)
    weights={k:q[k] for k in ('w1','w2','w1_scale','w2_scale')}
    owner=create_moe(MoEConfig(),MoEWeights(*weights.values()),implementation='native_fp4')
    base=NativeProgram(owner,64);candidate=CoalescedProgram(owner,64,CoalescedConfig(
        direct=False,gate_n=64,gate_waves=1,split_k=1,depth=6,down_depth=2,
        dispatch=True,down_n=64,down_waves=1,combine='lds'))
    x=data['input'][15,-1];logits=data['logits'][15,-1].bfloat16().contiguous();bias=q['bias'].bfloat16()
    base.run(x,logits,bias);ids=base.p['ids'].clone();rw=base.p['weights'].clone()
    reference=expert_reference(weights,x,ids,rw,False)
    rows=[];reproduced=False
    for trial in range(64):
        a=base.run(x,logits,bias).clone();c=candidate.run(x,logits,bias).clone();torch.cuda.synchronize()
        assert torch.equal(ids,candidate.p['ids']) and torch.equal(rw,candidate.p['weights'])
        row=dict(trial=trial,pair=compare(c,a),native_reference=compare(a,reference),candidate_reference=compare(c,reference))
        rows.append(row)
        if not row['pair']['passed']:
            path=root/'pairwise-discrepancy.pt'
            torch.save({k:v.cpu() for k,v in dict(input=x,logits=logits,ids=ids,weights=rw,native=a,candidate=c,reference=reference).items()},path)
            row['tensors_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();reproduced=True;break
        if not row['native_reference']['passed'] or not row['candidate_reference']['passed']:break
    result=dict(batch=64,layer=77,decode_step=15,reproduced=reproduced,trials=rows,source_paths=source,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        all_independent_passed=all(r['native_reference']['passed'] and r['candidate_reference']['passed'] for r in rows))
    (root/'pairwise-diagnostic.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
