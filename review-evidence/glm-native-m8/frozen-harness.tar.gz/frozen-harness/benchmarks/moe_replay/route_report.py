"""Summarize independently replayed static, oracle and route-policy schedules."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics as st


def kernel_names(config):
    g1,g2=config['g1'],config['g2']
    first=f'flydsl_mxmoe_g1_a4w4_16x{g1["BN"]}x256_f16in'
    if g1['prefetch_hidden']:first+='_hpf'
    first+='_nt'
    if g1['xcd_swizzle']:first+=f'_xcd{g1["xcd_swizzle"]}'
    if g2['family']=='legacy':second='flydsl_mxmoe_g2_a4w4_16x256x256_atomic'
    else:second=f'flydsl_moe2_layout_afp4_wfp4_bf16_t16x{g2["BN"]}x{g2["BK"]}_atomic'
    if g2['persist']:second+='_persist'
    if g2['use_nt']:second+='_nt'
    if g2['family']=='layout':second+='_sbm16'
    return dict(g1=first,g2=second)


def main():
    p=argparse.ArgumentParser();p.add_argument('--experiment',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    summary=[];configs={};policies={};validation={}
    for batch in (8,16,32,64):
        path=a.experiment/'evaluate'/f'evaluation-b{batch}.json'
        if not path.exists():continue
        d=json.loads(path.read_text());assert d['complete']
        plan_path=a.experiment/'plans'/f'policy-b{batch}.json'
        assert hashlib.sha256(plan_path.read_bytes()).hexdigest()==d['plans_sha256']
        plan=json.loads(plan_path.read_text())
        assert hashlib.sha256(json.dumps(d['sequence'],sort_keys=True).encode()).hexdigest()==plan['sequence_sha256']
        screen=json.loads((a.experiment/'screen'/f'search-b{batch}.json').read_text())
        sweep=json.loads((a.experiment/'sweep'/f'search-b{batch}.json').read_text())
        assert screen['complete'] and sweep['complete']
        assert d['sequence']==sweep['sequence'] and screen['sequence']==sweep['sequence'][:len(screen['sequence'])]
        assert all(c['passed'] for checks in d['checks'].values() for c in checks)
        n=len(d['sequence']);held=d['holdout_indices']
        means={arm:st.mean(r['medians_us']) for arm,r in d['timing'].items()}
        hmeans={arm:st.mean(r['medians_us'][i] for i in held) for arm,r in d['timing'].items()}
        full=dict(means,static_gain_pct=100*(1-means['static']/means['stock']),
                  oracle_gain_us=means['static']-means['oracle'],
                  oracle_gain_pct=100*(1-means['oracle']/means['static']),
                  policy_gain_us=means['static']-means['policy'])
        holdout=dict(hmeans,policy_gain_us=hmeans['trained_static']-hmeans['policy'],
                     policy_gain_pct=100*(1-hmeans['policy']/hmeans['trained_static']),
                     oracle_gain_us=hmeans['trained_static']-hmeans['oracle'])
        summary.append(dict(batch=batch,cases=n,holdout_cases=len(held),full=full,holdout=holdout,
                            sweep_estimate=plan['full']))
        config=plan['candidate_configs'][plan['static_candidate']]
        configs[str(batch)]=dict(parameters=config,kernels=kernel_names(config))
        policies[str(batch)]=dict(plan['policy'],measured_heldout_gain_us=holdout['policy_gain_us'],
            maximum_additional_overhead_us=max(0.,holdout['policy_gain_us']),
            runtime_selector_implemented=False)
        validation[str(batch)]=dict(screen_candidates=len(screen['candidates']),screen_cases=len(screen['sequence']),
            screen_checks=sum(len(r.get('checks',[])) for r in screen['candidates'].values()),
            sweep_candidates=plan['candidates'],sweep_cases=len(sweep['sequence']),
            sweep_checks=sum(len(r.get('checks',[])) for r in sweep['candidates'].values()),
            evaluated_unique_schedules=len(d['checks']),evaluation_checks=sum(len(v) for v in d['checks'].values()),
            aliases=d['aliases'],checks_passed=True,train_cases=len(plan['train_indices']),holdout_cases=len(held))
    for name,value in [('summary',summary),('static-configs',configs),('policies',policies),('validation',validation)]:
        (a.output/f'{name}.json').write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
