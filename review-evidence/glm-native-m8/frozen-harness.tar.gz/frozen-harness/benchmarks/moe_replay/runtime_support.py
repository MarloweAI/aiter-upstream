"""Runtime inspection and environment, without an image/runtime builder."""
import importlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import subprocess
import sys
from .upgrade_state import digest, file_digest, save


def selected(lock):
    return json.loads((Path(lock['runtime_root'])/'image.json').read_text())


def environment(lock):
    runtime=selected(lock); env=os.environ.copy()
    paths=[str(Path(lock['run_root'])/'source'),str(Path(lock['runtime_root'])/'benchmark-deps')]
    if runtime['provider']=='legacy-completed-overlay':
        paths += [runtime['source_dirs']['sglang']+'/python',runtime['source_dirs']['aiter']]
        env.update(VIRTUAL_ENV=runtime['overlay_root']+'/venv',
                   PATH=str(Path(runtime['python']).parent)+os.pathsep+env['PATH'])
    env.update(PYTHONPATH=os.pathsep.join(paths),PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',
               GPU_ARCHS='gfx950',AMDGPU_TARGET='gfx950',PYHIP_CACHE_DIR=lock['runtime_root']+'/pyhip-cache',
               PYHIP_JIT_LOG='0',PYHIP_SIMPLE_GEN_FILENAME='1')
    return env


def tree_digest(path):
    return digest({str(p.relative_to(path)):file_digest(p) for p in sorted(path.rglob('*'))
                   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'})


def preflight(lock):
    import torch
    runtime=selected(lock); root=Path(lock['runtime_root'])
    if torch.cuda.device_count()!=1 or not torch.version.hip:
        raise RuntimeError('GPU preflight requires one allocated ROCm device')
    props=torch.cuda.get_device_properties(0)
    if not props.gcnArchName.startswith('gfx950'):raise RuntimeError('Expected MI355X / gfx950')
    if runtime['provider']=='legacy-completed-overlay':
        for name, source in runtime['sources'].items():
            folder=source['source_dir']
            head=subprocess.check_output(['git','-C',folder,'rev-parse','HEAD'],text=True).strip()
            patch=subprocess.check_output(['git','-C',folder,'diff','--binary','HEAD'],text=True)
            if head!=source['commit'] or patch!=source['patch']:
                raise RuntimeError('Preserved overlay changed: '+name)
    subprocess.run([sys.executable,'-m','pip','check'],check=True)
    imported={}
    for name in ('sglang','aiter'):
        module=importlib.import_module(name); path=Path(module.__file__).resolve()
        if not path.is_relative_to(Path(runtime['source_dirs'][name]).resolve()):
            raise RuntimeError(f'{name} import shadowed: {path}')
        imported[name]=str(path)
    from sglang.srt.models.deepseek_v2 import DeepseekV2MoE,MoEGate
    from sglang.srt.layers.moe.moe_runner.aiter import AiterMoeQuantInfo
    from sglang.srt.layers.moe.moe_runner.runner import MoeRunner
    from sglang.srt.layers.quantization.quark.schemes.quark_w4a4_mxfp4_moe import QuarkW4A4MXFp4MoE
    import pyhip
    import tilelang
    from sglang.kernels.ops.attention.dsa.tilelang_kernel import act_quant
    from .dispatch_audit import capture_dispatch
    x=torch.zeros(32,device='cuda');span,_,graph=capture_dispatch(lambda:x.add_(1))
    save(root/'graph-inspector-check.json',span)
    del graph,x
    freeze=subprocess.check_output([sys.executable,'-m','pip','freeze','--all'],text=True)
    (root/'requirements.lock.txt').write_text(freeze)
    result=dict(passed=True,requested={k:v['sha'] for k,v in lock['refs'].items()},
        image=runtime,dependencies_sha256=digest(freeze.splitlines()),
        execution_source=digest(runtime.get('manifest') or runtime.get('sources')),
        benchmark_dependency=dict(pyhip_path=str(Path(pyhip.__file__).resolve()),
                                  pyhip_tree_sha256=tree_digest(Path(pyhip.__file__).resolve().parent)),
        versions={name:metadata.version(name) for name in ('sglang','amd-aiter','torch','triton','flydsl','transformers','tilelang','apache-tvm-ffi')},
        hardware=dict(name=props.name,arch=props.gcnArchName,cu_count=props.multi_processor_count),
        torch=torch.__version__,hip=torch.version.hip,imports=imported)
    save(root/'runtime.json',result);return result
