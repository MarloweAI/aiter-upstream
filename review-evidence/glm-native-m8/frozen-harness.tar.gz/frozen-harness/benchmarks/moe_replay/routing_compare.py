"""Same-image AITER, native-supplied Port-EW, and internal Port-EW replay."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics

from .upgrade_state import file_digest, save

VARIANTS = ('aiter', 'port_ew', 'port_internal')


def routing_check(layer, x, logits, ids, weights, native_ids, native_weights):
    """Validate top-k membership/weights independently, allowing boundary ties.

    Historical internal tie ordering is deliberately not forced to match the
    newer native implementation. Full IDs/weights preserve that difference.
    """
    import torch
    selected = ids[:, :8].long()
    valid_ids = bool(((selected >= 0) & (selected < 256)).all())
    if not valid_ids:
        return dict(passed=False, reason='invalid expert id')
    prob = torch.sigmoid(logits.double()).float()
    scores = prob + layer.bias_by_dtype[logits.dtype].float()
    chosen = scores.gather(1, selected)
    excluded = scores.clone().scatter_(1, selected, float('-inf'))
    margin = excluded.max(1).values - chosen.min(1).values
    p = prob.gather(1, selected)
    expected = p / p.sum(1, keepdim=True) * 2.5
    error = float((weights[:, :8] - expected).abs().max())
    ordered, permutation = selected.sort(1)
    ni = native_ids[:, :8].long()
    native_ordered, native_permutation = ni.sort(1)
    distinct = bool((ordered[:, 1:] != ordered[:, :-1]).all())
    shared = bool((ids[:, 8] == 256).all() and (weights[:, 8] == 1).all())
    same_sets = (ordered == native_ordered).all(1)
    aligned_error = (weights[:, :8].gather(1, permutation) -
                     native_weights[:, :8].gather(1, native_permutation)).abs()
    return dict(passed=distinct and shared and float(margin.max()) <= 2e-6 and error <= 2e-6,
                selection_margin_max=float(margin.max()), normalized_weight_max_abs=error,
                changed_slots=int((selected != ni).sum()),
                changed_set_tokens=int((~same_sets).sum()), tokens=len(x),
                same_set_weight_max_abs=float(aligned_error[same_sets].max()) if bool(same_sets.any()) else None,
                internal_active_experts=int(ids.unique().numel()),
                native_active_experts=int(native_ids.unique().numel())+int(not bool((native_ids==256).any())),
                internal_ids=ids.cpu().tolist(), internal_weights=weights.cpu().tolist(),
                native_ids=native_ids.cpu().tolist(), native_weights=native_weights.cpu().tolist())


def diagnostic_stages(sequence, layers, data, variants):
    """Cache-sensitive component timings; never subtract from headline times."""
    import torch
    from .events import Event
    from .run import timings
    graphs = {}
    for name in ('native_topk',):
        pairs = [(Event(), Event()) for _ in sequence]
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for case, pair in zip(sequence, pairs):
                layer = layers[case['layer']]
                x = data['input'][case['slot'], case['layer_index'], :case['graph_rows']]
                layer(x, 'port_ew')  # Untimed full-call preconditioning for this exact case.
                pair[0].record()
                layer.routes(x, layer.last_logits)
                pair[1].record()
        graphs[name] = dict(graph=graph, pairs=pairs)
    return dict(scope='component after its case full-call precondition; cache-sensitive; marker overhead included',
                timing=timings(graphs, 40, 10))


def check_routing_validator():
    """Check that reordering passes, and wrong membership/weights fail."""
    import torch
    from types import SimpleNamespace
    logits=torch.zeros((1,256),device='cuda',dtype=torch.bfloat16)
    bias=torch.arange(256,device='cuda').bfloat16()/256
    layer=SimpleNamespace(bias_by_dtype={torch.bfloat16:bias})
    ids=torch.tensor([[255,254,253,252,251,250,249,248,256]],device='cuda',dtype=torch.int32)
    weights=torch.tensor([[.3125]*8+[1.]],device='cuda')
    x=torch.empty((1,6144),device='cuda',dtype=torch.bfloat16)
    assert routing_check(layer,x,logits,ids,weights,ids,weights)['passed']
    reverse=torch.cat((ids[:,:8].flip(1),ids[:,8:]),1)
    result=routing_check(layer,x,logits,reverse,weights,ids,weights)
    assert result['passed'] and result['changed_slots']==8 and result['changed_set_tokens']==0
    wrong=ids.clone();wrong[0,0]=0
    assert not routing_check(layer,x,logits,wrong,weights,ids,weights)['passed']
    wrong=weights.clone();wrong[0,0]+=.1
    assert not routing_check(layer,x,logits,ids,wrong,ids,weights)['passed']
    duplicate=ids.clone();duplicate[0,0]=duplicate[0,1]
    assert not routing_check(layer,x,logits,duplicate,weights,ids,weights)['passed']


def write_report(root):
    records = [json.loads(p.read_text()) for p in (root/'replay').glob('b*.json') if p.stem[1:].isdigit()]
    records.sort(key=lambda r: r['batch'])
    rows = []
    variants=tuple(records[0]['identity']['variants']) if records and 'identity' in records[0] else VARIANTS
    for r in records:
        latency = {v: statistics.mean(r['timing'][v+'_preload_events']['interval_medians_us']) for v in variants}
        routes = [c['independent_routing'] for c in r['graph_validation']['port_internal']]
        equal_set_indices = [i for i,c in enumerate(routes) if c['changed_set_tokens']==0]
        equal_set_latency = {v: statistics.mean(r['timing'][v+'_preload_events']['interval_medians_us'][i]
                            for i in equal_set_indices) for v in variants} if equal_set_indices else None
        active = {mode:statistics.mean(len({256}|{e for token in c[mode+'_ids'] for e in token})
                                      for c in routes) for mode in ('internal','native')}
        arm_passed = {'aiter':all(c['aiter_reference']['passed'] for c in r['checks']) and r['graph_checks']['aiter']}
        arm_passed.update({v:all(c['port_references'][v]['passed'] for c in r['checks']) and r['graph_checks'][v]
                           for v in variants[1:]})
        stages = {k: statistics.mean(v['interval_medians_us']) for k,v in (r.get('stage_profile') or {}).get('timing',{}).items()}
        rows.append(dict(batch=r['batch'], qualified=r['qualified'], latency_us=latency,
                         reduction_pct={v:100*(1-latency[v]/latency['aiter']) for v in variants[1:]},
                         internal_vs_native_reduction_pct=100*(1-latency['port_internal']/latency['port_ew']),
                         changed_slots=sum(c['changed_slots'] for c in routes),
                         changed_set_tokens=sum(c['changed_set_tokens'] for c in routes),
                         tokens=sum(c['tokens'] for c in routes), stage_diagnostic_us=stages,
                         cases=len(r['sequence']), arm_reference_passed=arm_passed,
                         mean_active_experts_including_shared=active,
                         same_expert_set_subset=dict(cases=len(equal_set_indices),latency_us=equal_set_latency,
                             internal_vs_native_reduction_pct=100*(1-equal_set_latency['port_internal']/equal_set_latency['port_ew']) if equal_set_latency else None),
                         numerical_failures=[dict(kind=f['kind'],variant=f.get('variant'),layer=f['case']['layer'],step=f['case']['decode_step'])
                                             for f in r['numerical_failures']],
                         result_sha256=file_digest(root/'replay'/f"b{r['batch']}.json")))
    save(root/'summary.json', dict(rows=rows, complete=len(rows)==7,
                                 all_qualified=len(rows)==7 and all(r['qualified'] for r in rows)))
    first=records[0] if records else {}
    provenance=first.get('identity',{}).get('runtime',{})
    commit=provenance.get('library_commit','769504ed')[:8]
    display=[v for v in ('aiter','port_internal','port_ew','port_native_combine') if v in variants]
    names=dict(aiter='AITER: native router (`6a9a005b7`)',
               port_ew='Port-EW: native router + direct G2 combine',
               port_internal='Port-EW: internal router (`769504ed` baseline)',
               port_native_combine=f'Port-EW: native router + fused G2 combine (`{commit}`)')
    lines = ['# Same-image routing microbenchmark', '',
             f'SGLang `5f017ffab`; AITER `6a9a005b7`; measurement library commit `{commit}`. Internal Port-EW retains its `769504ed` kernel selection; supplied routing now uses direct G2 combine.',
             f"MI355X, TP8/EP1 rank 0; {len(first.get('sequence',[]))} ordered cases per batch; {first.get('samples',40)} randomized paired samples, {first.get('warmups',10)} warmups.",
             'Mean of per-case median HIP intervals in microseconds: router GEMM through shared/local combine; input preload and TP communication excluded.', '',
             '| Batch | '+' | '.join(names[v] for v in display)+' |',
             '|---:|'+'---:|'*len(display)]
    for r in rows:
        t=r['latency_us'];p=r['reduction_pct']
        cells=[f"{t[v]:.3f}"+(f" ({p[v]:.2f}%)" if v!='aiter' else '') for v in display]
        lines.append(f"| {r['batch']} | "+' | '.join(cells)+' |')
    lines += ['', 'Parentheses are latency reductions versus the same-run AITER control.',
              'B1 is diagnostic: AITER failed the unchanged independent-reference NRMSE limit at layer16/step0 in a preserved earlier run, although it passed in this replay. Both Port-EW arms pass their independent references. A successful repeat does not erase the earlier failure.', '',
              '| Batch | Changed route slots | Tokens with different expert sets / total | Native top-k diagnostic µs |',
              '|---:|---:|---:|---:|']
    for r in rows:
        s=r['stage_diagnostic_us']
        lines.append(f"| {r['batch']} | {r['changed_slots']} | {r['changed_set_tokens']} / {r['tokens']} | {s.get('native_topk',float('nan')):.3f} |")
    lines += ['', 'Component timings include HIP marker overhead and follow full-call preconditioning; they are not additive explanations of the pipeline gap.',
              'Each mode is checked against the unchanged independent numerical reference for its actual routes and intermediate-rounding contract. Native dispatch must match the saved TP8 audit. Routing checks preserve all expert IDs and weights; set differences are reported rather than hidden.', '']
    lines += ['| Batch | Same-expert-set cases / all | Native µs on subset | Internal µs on subset | Reduction | Mean active experts native / internal |',
              '|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        subset=r['same_expert_set_subset'];t=subset['latency_us'];active=r['mean_active_experts_including_shared']
        if t:
            lines.append(f"| {r['batch']} | {subset['cases']} / {r['cases']} | {t['port_ew']:.3f} | {t['port_internal']:.3f} | {subset['internal_vs_native_reduction_pct']:.2f}% | {active['native']:.3f} / {active['internal']:.3f} |")
    lines += ['', 'The subset is computed from the existing per-case timing medians and graph-validation routes; no additional benchmarks. Equal sets can retain different ordering/weight rounding. Active expert counts include shared and are computed across the measured corpus.', '']
    (root/'REPORT.md').write_text('\n'.join(lines))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--baseline-lock',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--batches',type=int,nargs='+',default=[1,2,4,8,16,32,64])
    p.add_argument('--diagnostic-batches',type=int,nargs='*',default=[])
    p.add_argument('--preserved-failure',type=Path)
    p.add_argument('--native-combine',action='store_true')
    p.add_argument('--tuning-configs',type=Path)
    p.add_argument('--screen',action='store_true',help='Unqualified tuning screen; retain all numerical failures')
    p.add_argument('--expected-library-source',required=True)
    p.add_argument('--source-commit',required=True)
    p.add_argument('--steps',type=int)
    p.add_argument('--layer-limit',type=int)
    p.add_argument('--samples',type=int,default=40)
    p.add_argument('--warmups',type=int,default=10)
    p.add_argument('--stage-profile',action=argparse.BooleanOptionalAction,default=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    if a.native_combine or a.tuning_configs:
        p.error('The historical separate-combine fourth arm is archived; supplied routes now use direct G2 combine')
    if a.diagnostic_batches:
        assert a.preserved_failure and a.preserved_failure.is_file()
    lock=json.loads(a.baseline_lock.read_text());c=lock['config']
    # Match upgrade_worker before importing AITER: image defaults can select
    # different kernels even when the image and Git revisions are identical.
    configured=c['environment'];removed=[]
    for key in list(os.environ):
        if (key.startswith(('SGLANG_','AITER_')) or key in ('USE_GLUON','USE_GLUON2')) and key not in configured:
            removed.append(key);del os.environ[key]
    os.environ.update(configured)
    save(a.output/'environment.json',dict(configured=configured,removed_image_default_keys=removed))
    import torch
    from . import run
    from .sglang_adapter import SGLangLayer
    from .dispatch_audit import capture_dispatch, compare_dispatch
    from marlowe_kernels import create_moe
    from marlowe_kernels._runtime import source_digest
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    assert source_digest()==a.expected_library_source, 'Kernel library changed'
    native_candidates={'port_native_combine':{}} if a.native_combine else {}
    if a.tuning_configs:
        assert a.native_combine
        native_candidates.update(json.loads(a.tuning_configs.read_text()))
    variants=(*VARIANTS,*native_candidates)
    check_routing_validator()
    audit=Path(lock['run_root'])/'native-audit'
    receipt=json.loads((audit/'validated.json').read_text())
    assert receipt['passed']
    for name, expected in receipt['files'].items():
        assert file_digest(audit/name)==expected, name
    runtime=json.loads((Path(lock['runtime_root'])/'runtime.json').read_text())
    assert runtime['passed']
    import subprocess, sglang, aiter
    imported={}
    for name,module in [('sglang',sglang),('aiter',aiter)]:
        location=Path(module.__file__).resolve()
        actual=subprocess.check_output(['git','-C',str(location.parent),'rev-parse','HEAD'],text=True).strip()
        assert actual==lock['refs'][name]['sha'], (name,actual)
        imported[name]=dict(path=str(location),commit=actual)

    class RoutingLayer(SGLangLayer):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.internal=create_moe(self.port.config,self.port.weights)
            self.native_candidates={name:create_moe(self.port.config,self.port.weights) for name in native_candidates}

        def warmup(self,b):
            self.port.warmup((b,),routing='supplied')
            self.internal.warmup((b,),routing='internal')
            self.internal.warmup((b,),routing='supplied')
            for name,owner in self.native_candidates.items():
                override=native_candidates[name].get(str(b),{})
                if override:
                    from marlowe_kernels._kernels.amd.glm52_moe.native_combine import create_native_combine_program
                    owner._native_programs[b]=create_native_combine_program(owner,b,override)
                owner.warmup((b,),routing='native')

        def from_logits(self,x,logits,variant):
            if variant in self.native_candidates:
                owner=self.native_candidates[variant]
                weights,ids=self.routes(x,logits)
                out=owner.forward_native_routed(x,ids,weights)
                self.last_logits=logits
                self.last_ids,self.last_weights=owner.routing(len(x),routing='native')
                return out
            if variant!='port_internal':return super().from_logits(x,logits,variant)
            assert logits.dtype==torch.bfloat16, 'Do not silently round FP32 routing'
            out=self.internal(x,logits,self.bias_by_dtype[logits.dtype])
            self.last_logits=logits
            self.last_ids,self.last_weights=self.internal.routing(len(x))
            return out

        def expert_routed(self,x,ids,weights,variant):
            if variant in self.native_candidates:
                return self.native_candidates[variant].forward_native_routed(x,ids[:,:8].contiguous(),weights[:,:8].contiguous())
            if variant!='port_internal':return super().expert_routed(x,ids,weights,variant)
            return self.internal.forward_routed(x,ids[:,:8].contiguous(),weights[:,:8].contiguous())

    def factory(payload,layer_id):
        payload.update(torch.load(audit/f'gate-{layer_id}.pt',weights_only=True))
        spec=json.loads((audit/f'layer-{layer_id}.json').read_text())
        for key,expected in spec['weight_content_sha256'].items():
            raw=payload[key].detach().contiguous().view(torch.uint8).numpy()
            assert hashlib.sha256(memoryview(raw)).hexdigest()==expected
        layer=RoutingLayer(payload,layer_id,spec)
        for field,key in {'w13_weight':'w1','w2_weight':'w2','w13_scale':'w1_scale','w2_scale':'w2_scale'}.items():
            expected=spec['weights'][key];value=layer.weights[key]
            dtype=getattr(torch,expected['dtype'].removeprefix('torch.'))
            if value.dtype!=dtype:value=value.view(dtype)
            assert list(value.shape)==expected['shape'] and list(value.stride())==expected['stride']
            setattr(layer.quant_info,field,value)
        return layer

    def verify(layer,x,b):
        stream=torch.cuda.graph(torch.cuda.CUDAGraph()).capture_stream
        stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(stream):
            for variant in variants:
                for _ in range(2):layer(x,variant)
        torch.cuda.synchronize()
        signatures={}
        for variant in variants:
            signatures[variant],_,graph=capture_dispatch(lambda:layer(x,variant))
            del graph
        expected=json.loads((audit/f'dispatch-l{layer.layer_id}-b{b}.json').read_text())
        result=compare_dispatch(expected,signatures['aiter'])
        save(a.output/f'dispatch-l{layer.layer_id}-b{b}.json',dict(**result,signatures=signatures))
        assert result['passed'], ('native dispatch',layer.layer_id,b)
        return dict(layer=layer.layer_id,batch=b,**result,signatures=signatures)

    def state_check(layer,b):
        states={}
        for name,owner in [('port_ew',layer.port),('port_internal',layer.internal)]:
            program=(owner._native_programs if name=='port_ew' else owner._programs)[b]
            states[name]=program.state_check() if hasattr(program,'state_check') else dict(passed=True,stateless=True)
        for name,owner in layer.native_candidates.items():
            program=owner._native_programs[b]
            states[name]=program.state_check() if hasattr(program,'state_check') else dict(passed=True,stateless=True)
        return dict(layer=layer.layer_id,batch=b,passed=all(v['passed'] for v in states.values()),states=states)

    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    set_global_server_args_for_scheduler(ServerArgs(model_path=c['model'],tp_size=8,ep_size=1,dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    init_distributed_environment(world_size=1,rank=0,local_rank=0,distributed_init_method='file://'+str(a.output/f'rendezvous-{os.getpid()}'),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    identity=dict(library_commit=a.source_commit,baseline_library_commit='769504edf86d8f25a466cde115b3a99d5f762143',library_source=source_digest(),
                  upstream=imported,image_sha256=runtime['image']['image_sha256'],
                  adapter_sha256=file_digest(Path(__file__)),baseline_lock_sha256=file_digest(a.baseline_lock),
                  hardware=str(torch.cuda.get_device_properties(0)),node=os.uname().nodename,
                  native_audit_sha256=file_digest(audit/'validated.json'),native_candidates=native_candidates,screen=a.screen)
    if a.preserved_failure:
        identity['preserved_failure']=dict(path=str(a.preserved_failure),sha256=file_digest(a.preserved_failure))
    save(a.output/'identity.json',identity)
    try:
        with get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,tp_size=8,moe_tp_size=8,moe_ep_size=1):
            for b in a.batches:
                extra=['--diagnostic-on-reference-failure'] if b in a.diagnostic_batches or a.screen else []
                if a.steps:extra+=['--steps',str(a.steps)]
                if a.layer_limit:extra+=['--layer-limit',str(a.layer_limit)]
                if a.stage_profile:extra+=['--profile-stages']
                run.main(['--capture',c['capture'],'--output',str(a.output/'replay'),'--model',c['model'],
                          '--batches',str(b),'--samples',str(a.samples),'--warmups',str(a.warmups),*extra],
                         layer_factory=factory,runtime_identity=identity,dispatch_validator=verify,
                         port_variants=variants[1:],independent_routing_variants=('port_internal',),
                         routing_validator=routing_check,state_validator=state_check,stage_profiler=diagnostic_stages)
                write_report(a.output)
    finally:
        torch.distributed.destroy_process_group()


if __name__=='__main__':main()
