"""Minimal TP8 dispatch probe, cached independently from benchmark timings."""
import json
import os
from pathlib import Path
import random
import shutil
import socket
import subprocess
import sys
import time
from benchmarks.serve import arguments,stop
from benchmarks.routing_experiment import request
from .upgrade_state import digest,file_digest,save
from .runtime_support import environment


def audit_key(lock):
    c=lock['config'];runtime=json.loads((Path(lock['runtime_root'])/'runtime.json').read_text())
    return digest(dict(refs={k:v['sha'] for k,v in lock['refs'].items()},runtime=dict(requested=runtime['requested'],execution_source=runtime['execution_source'],image_sha256=runtime['image']['image_sha256'],hardware=runtime['hardware']),
        deps=runtime['dependencies_sha256'],settings={k:c[k] for k in ('model','model_revision','topology','batches','environment')},
        adapter={name:file_digest(Path(__file__).with_name(name)) for name in
                 ('upgrade_probe.py','sglang_adapter.py','dispatch_audit.py','upgrade_audit.py')}))


def run_audit(lock):
    import torch
    if torch.cuda.device_count()!=8:raise RuntimeError('Dispatch verification requires eight allocated GPUs')
    c=lock['config'];root=Path(lock['run_root']);key=audit_key(lock)
    cache=Path(c['remote']['root'])/'audit-cache'/key
    if (cache/'validated.json').exists():
        receipt=json.loads((cache/'validated.json').read_text())
        for name,expected in receipt['files'].items():
            if file_digest(cache/name)!=expected:raise RuntimeError('Cached dispatch audit was modified: '+name)
        dest=root/'native-audit'
        if not dest.exists():dest.symlink_to(cache,target_is_directory=True)
        return dict(reused=True,key=key,evidence=str(cache),receipt=receipt)
    # Verify graph-node inspection before loading the large model.
    from .dispatch_audit import capture_dispatch
    x=torch.zeros(32,device='cuda');span,out,graph=capture_dispatch(lambda:x.add_(1))
    if not span['nodes']:raise RuntimeError('Native graph inspection is unavailable')
    save(root/'graph-inspector-check.json',span)
    del graph,out,x;torch.cuda.empty_cache()
    dest=root/'native-audit';dest.mkdir(exist_ok=True)
    train=[json.loads(line) for line in (Path(c['data'])/'gsm8k-train.jsonl').read_text().splitlines()]
    test=[json.loads(line) for line in (Path(c['data'])/'gsm8k-test.jsonl').read_text().splitlines()]
    ids=random.Random(355052).sample(range(len(test)),64)
    prefix=''.join(f"Question: {x['question']}\nAnswer: {x['answer']}\n\n" for x in train[:24])
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    command=[sys.executable,'-B','-m','benchmarks.moe_replay.upgrade_probe']+arguments(Path(c['model']),max(c['batches']),port,'mi355x')
    command[command.index('--max-running-requests')+1]='128'
    at=command.index('--cuda-graph-bs-decode');command[at+1:at+2]=list(map(str,c['batches']))
    env=environment(lock);env.update(c['environment'],MARLOWE_UPGRADE_LOCK=str(root/'lock.json'),
        HF_HUB_OFFLINE='1',TOKENIZERS_PARALLELISM='false',SGLANG_USE_MARLOWE_KERNELS='0')
    save(dest/'launch.json',dict(command=command,environment={k:v for k,v in env.items() if k.startswith(('SGLANG_','AITER_','MARLOWE_'))},
                               job_id=os.environ['SLURM_JOB_ID'],refs=lock['refs']))
    proc=None;base=f'http://127.0.0.1:{port}'
    try:
        with (dest/'server.log').open('w') as log:
            proc=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            deadline=time.monotonic()+2400
            while time.monotonic()<deadline:
                if proc.poll() is not None:raise RuntimeError(f'SGLang exited {proc.returncode}; inspect {dest}/server.log')
                try:
                    info=request(base,'/get_server_info',timeout=10)
                    request(base,'/health_generate',timeout=30);break
                except Exception:time.sleep(3)
            else:raise TimeoutError('SGLang dispatch probe startup')
            save(dest/'server-info.json',info)
            for b in c['batches']:
                prompts=[prefix+f"Question: {test[i]['question']}\nAnswer:" for i in ids[:b]]
                responses=request(base,'/generate',dict(text=prompts,sampling_params=dict(temperature=0,max_new_tokens=4,ignore_eos=False)))
                if not isinstance(responses,list) or len(responses)!=b:raise RuntimeError(f'Incomplete probe batch {b}')
                save(dest/f'responses-b{b}.json',responses)
                request(base,'/flush_cache',timeout=120)
            coverage=json.loads((dest/'coverage.json').read_text())
            expected_layers=json.loads((Path(c['capture'])/f"b{c['batches'][0]}-s355052/capture.json").read_text())['layers']
            if coverage['layers']!=expected_layers or coverage['batches']!=sorted(c['batches']) or coverage['spans']!=coverage['expected']:
                raise RuntimeError(f'Incomplete native dispatch coverage: {coverage}')
            receipt=dict(passed=True,key=key,coverage=coverage,refs=lock['refs'],
                files={p.name:file_digest(p) for p in dest.iterdir() if p.suffix in ('.pt','.json')})
            save(dest/'validated.json',receipt)
    finally:stop(proc)
    cache.parent.mkdir(parents=True,exist_ok=True)
    if cache.exists():raise RuntimeError('Concurrent audit publication; refusing to overwrite evidence')
    shutil.copytree(dest,cache)
    return dict(reused=False,key=key,evidence=str(dest),receipt=receipt)
