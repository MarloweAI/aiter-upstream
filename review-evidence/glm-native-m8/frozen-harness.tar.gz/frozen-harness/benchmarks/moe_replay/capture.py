"""Capture exact rank-0 MoE inputs or time local MoE in a normal TP8 server.

Capture mode buffers all data on GPU and exports after requests finish. Timing
mode is a separate pass without capture copies; it drains the completed forward
to read event pairs for selected steps. It is not a serving-throughput benchmark.
"""
import functools
import json
import os
from pathlib import Path
import runpy
import torch
import triton as tr
import triton.language as tl
from .events import Event

from .protocol import LAYERS


@tr.jit
def copy_record(src, dst, control, layer: tl.constexpr, layers: tl.constexpr,
                capacity: tl.constexpr, width: tl.constexpr, rows: tl.constexpr,
                stride: tl.constexpr, BLOCK: tl.constexpr):
    slot=tl.load(control)
    if slot>=0:
        i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
        v=tl.load(src+(i//width)*stride+i%width,i<rows*width,other=0)
        tl.store(dst+((slot*layers+layer)*capacity*width)+i,v,i<rows*width)


@tr.jit
def set_slot(control, slot):
    tl.store(control,slot)


def install():
    from sglang.srt.models import deepseek_v2 as mod
    from sglang.srt.layers.moe.fused_moe_triton.layer import FusedMoE
    from sglang.srt.managers.scheduler import Scheduler
    from sglang.srt.model_executor.model_runner import ModelRunner
    dest=Path(os.environ['MARLOWE_REPLAY_OUTPUT'])
    mode=os.environ.get('MARLOWE_REPLAY_MODE','capture')
    limit=int(os.environ.get('MARLOWE_REPLAY_STEPS','16'))
    forward_mode=os.environ.get('MARLOWE_REPLAY_FORWARD_MODE','decode')
    capacity=int(os.environ.get('MARLOWE_REPLAY_MAX_ROWS','64'))
    assert forward_mode in ('decode','target_verify')
    state=dict(control=None,buffers={},blocks={},current=None,run=None,step=0,
               active=None,records=[],events={},timings=[],observed_modes=[])
    rank0=lambda: torch.distributed.is_initialized() and torch.distributed.get_rank()==0

    def init():
        if state['control'] is None:
            assert not torch.cuda.is_current_stream_capturing()
            state['control']=torch.full((1,),-1,device='cuda',dtype=torch.int32)
            if mode=='capture':
                for name,width,dtype in [('input',6144,torch.bfloat16),('output',6144,torch.bfloat16),
                    ('logits',256,torch.float32),('ids',9,torch.int32),('routing_weights',9,torch.float32)]:
                    state['buffers'][name]=torch.zeros((limit,len(LAYERS),capacity,width),device='cuda',dtype=dtype)
            else:
                # The model captures each graph tier before serving requests.
                # Construct HIP markers while still outside CUDA capture.
                tiers=[1<<i for i in range(capacity.bit_length()) if (1<<i)<=capacity]
                state['events']={(layer,rows):(Event(),Event()) for layer in LAYERS for rows in tiers}

    def store(name,tensor,layer):
        if mode=='capture':
            assert len(tensor)<=capacity,(name,tensor.shape,capacity)
            copy_record[(tr.cdiv(tensor.numel(),1024),)](tensor,state['buffers'][name],state['control'],
                LAYERS.index(layer),len(LAYERS),capacity,tensor.shape[1],tensor.shape[0],tensor.stride(0),1024)

    original_normal=mod.DeepseekV2MoE.forward_normal
    @functools.wraps(original_normal)
    def normal(self,x,*args,**kwargs):
        chosen=rank0() and self.layer_id in LAYERS and len(x)<=capacity
        old=state['current']
        if chosen:
            init();state['blocks'][self.layer_id]=self
            if state['active'] is not None:
                previous=state['active'].setdefault('moe_rows',len(x))
                assert previous==len(x),(self.layer_id,previous,len(x))
            state['current']=(self.layer_id,len(x))
            if mode=='timing' and state['current'] not in state['events']:
                assert not torch.cuda.is_current_stream_capturing()
                state['events'][state['current']]=(Event(),Event())
        else:state['current']=None
        try:return original_normal(self,x,*args,**kwargs)
        finally:state['current']=old
    mod.DeepseekV2MoE.forward_normal=normal

    original_gate=mod.MoEGate.forward
    @functools.wraps(original_gate)
    def gate(self,x,*args,**kwargs):
        key=state['current']
        if key:
            store('input',x,key[0])
            if mode=='timing' and torch.cuda.is_current_stream_capturing():state['events'][key][0].record()
        out=original_gate(self,x,*args,**kwargs)
        if key:store('logits',out,key[0])
        return out
    mod.MoEGate.forward=gate

    original_experts=FusedMoE.forward
    @functools.wraps(original_experts)
    def experts(self,x,routes,*args,**kwargs):
        key=state['current']
        if key:
            assert routes.topk_ids.shape[1]==9
            store('ids',routes.topk_ids,key[0]);store('routing_weights',routes.topk_weights,key[0])
        return original_experts(self,x,routes,*args,**kwargs)
    FusedMoE.forward=experts

    original_combine=mod.maybe_fuse_routed_scale_and_shared_add
    @functools.wraps(original_combine)
    def combine(*args,**kwargs):
        out=original_combine(*args,**kwargs)
        key=state['current']
        if key:
            if mode=='timing' and torch.cuda.is_current_stream_capturing():state['events'][key][1].record()
            store('output',out,key[0])
        return out
    mod.maybe_fuse_routed_scale_and_shared_add=combine

    original_batch=Scheduler.run_batch
    @functools.wraps(original_batch)
    def batch(self,batch,*args,**kwargs):
        if not rank0():return original_batch(self,batch,*args,**kwargs)
        rids=[str(r.rid) for r in batch.reqs]
        if rids and all(r.startswith('moereplay:') for r in rids):
            names={r.split(':')[1] for r in rids};assert len(names)==1
            name=names.pop();assert state['run'] in (None,name)
            state['run']=name
            state['observed_modes'].append(str(batch.forward_mode))
            selected=(batch.forward_mode.is_decode() if forward_mode=='decode' else
                      batch.forward_mode.is_target_verify())
            if selected:
                spec=getattr(batch,'spec_info',None)
                draft_tokens=getattr(spec,'draft_token_num',None)
                state['active']=dict(decode_step=state['step'],request_ids=rids,
                    live_rows=[not r.finished() for r in batch.reqs],scheduled_rows=len(rids),
                    output_lengths=[len(r.output_ids) for r in batch.reqs],
                    generated_token_ids=[list(r.output_ids) for r in batch.reqs],
                    forward_mode=forward_mode,draft_token_num=draft_tokens)
                state['step']+=1
        try:return original_batch(self,batch,*args,**kwargs)
        finally:state['active']=None
    Scheduler.run_batch=batch

    original_forward=ModelRunner.forward
    @functools.wraps(original_forward)
    def forward(self,fb,*args,**kwargs):
        if not rank0():return original_forward(self,fb,*args,**kwargs)
        init();created=False
        if forward_mode=='target_verify' and state['run'] and fb.forward_mode.is_target_verify():
            spec=getattr(fb,'spec_info',None);draft_tokens=getattr(spec,'draft_token_num',None)
            request_rows=len(fb.seq_lens)
            state['active']=dict(decode_step=state['step'],request_ids=[],live_rows=[True]*request_rows,
                scheduled_rows=request_rows,output_lengths=[],generated_token_ids=[],
                forward_mode=forward_mode,draft_token_num=draft_tokens,
                moe_rows=request_rows*draft_tokens)
            state['step']+=1;created=True
        meta=state['active'];enabled=meta is not None and meta['decode_step']<limit
        set_slot[(1,)](state['control'],meta['decode_step'] if enabled else -1)
        try:
            out=original_forward(self,fb,*args,**kwargs)
            if enabled:
                spec=getattr(fb,'spec_info',None)
                draft_tokens=getattr(spec,'draft_token_num',None) or meta.get('draft_token_num')
                moe_rows=meta.get('moe_rows')
                assert moe_rows is not None
                live_requests=sum(meta['live_rows'])
                actual_rows=(live_requests*draft_tokens if draft_tokens else live_requests)
                active_requests=(moe_rows//draft_tokens if draft_tokens else moe_rows)
                # Decode graph tiers are powers of two.  Target verification
                # flattens each request's draft-token rows inside that tier.
                graph_requests=1<<(active_requests-1).bit_length()
                graph_moe_rows=(graph_requests*draft_tokens if draft_tokens else graph_requests)
                meta=dict(meta,can_run_graph=bool(out.can_run_graph),actual_request_count=live_requests,
                          request_graph_rows=graph_requests,draft_token_num=draft_tokens,
                          actual_token_count=actual_rows,scheduled_rows=moe_rows,graph_rows=graph_moe_rows)
                assert meta['can_run_graph'],'Selected forward must use graph'
                state['records'].append(meta)
                if mode=='timing':
                    # Separate timing-only pass: no copy kernels in its graph.
                    torch.cuda.synchronize()
                    state['timings'].append(dict(meta,layer_us={str(l):state['events'][(l,graph_moe_rows)][0].elapsed_us(
                        state['events'][(l,graph_moe_rows)][1]) for l in LAYERS}))
            return out
        finally:
            if created:state['active']=None
    ModelRunner.forward=forward

    original_flush=Scheduler.flush_cache
    @functools.wraps(original_flush)
    def flush(self,*args,**kwargs):
        if rank0() and state['run'] and self.is_fully_idle():
            target=dest/state['run'];target.mkdir(parents=True,exist_ok=True)
            torch.cuda.synchronize()
            meta=dict(mode=mode,forward_mode=forward_mode,rank=0,layers=LAYERS,steps=state['records'],total_decode_steps=state['step'],
                      captured_steps=len(state['records']),limit=limit,job=os.environ.get('SLURM_JOB_ID'),
                      row_capacity=capacity,observed_scheduler_modes=state['observed_modes'],
                      float32_matmul_precision=torch.get_float32_matmul_precision(),
                      allow_tf32=torch.backends.cuda.matmul.allow_tf32,
                      gate_dtypes={str(l):str(b.gate.weight.dtype) for l,b in state['blocks'].items()})
            if mode=='capture':
                if not state['records']:
                    (target/'capture.json').write_text(json.dumps(meta,indent=2)+'\n')
                    state.update(run=None,step=0,records=[],timings=[],observed_modes=[])
                    return original_flush(self,*args,**kwargs)
                max_rows=max(s['graph_rows'] for s in state['records'])
                torch.save({k:v[:len(state['records']),:,:max_rows].contiguous().cpu() for k,v in state['buffers'].items()},target/'tensors.pt')
                weightdir=dest/'weights';weightdir.mkdir(exist_ok=True)
                for layer,block in sorted(state['blocks'].items()):
                    path=weightdir/f'layer-{layer}.pt'
                    if path.exists():continue
                    assert block.tp_size==8 and block.moe_ep_size==1 and block.num_fused_shared_experts==1
                    ex=block.experts
                    assert type(ex.scheme).__name__=='QuarkW4A4MXFp4MoE'
                    data={k:getattr(ex,a).detach().view(torch.uint8).cpu() for k,a in
                        [('w1','w13_weight'),('w2','w2_weight'),('w1_scale','w13_weight_scale'),('w2_scale','w2_weight_scale')]}
                    data.update(gate_weight=block.gate.weight.detach().cpu(),bias=block.gate.e_score_correction_bias.detach().cpu(),
                        tiny_router_gemm_max_tokens=block.gate.tiny_router_gemm_max_tokens)
                    torch.save(data,path)
            else:meta['timings']=state['timings']
            (target/'capture.json').write_text(json.dumps(meta,indent=2)+'\n')
            state.update(run=None,step=0,records=[],timings=[],observed_modes=[])
        return original_flush(self,*args,**kwargs)
    Scheduler.flush_cache=flush


if os.environ.get('MARLOWE_REPLAY_OUTPUT'):install()
if __name__=='__main__':runpy.run_module('sglang.launch_server',run_name='__main__')
