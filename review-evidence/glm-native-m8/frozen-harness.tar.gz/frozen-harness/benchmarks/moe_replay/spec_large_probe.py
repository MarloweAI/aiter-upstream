"""Short B128/B256 screen before full MTP target-verification qualification."""
import argparse
import json
import os
from pathlib import Path
import statistics

from .upgrade_state import save


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--model',type=Path,required=True)
    p.add_argument('--source-digest',required=True)
    p.add_argument('--layers',type=int,nargs='+',default=[3,40,77])
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    import torch
    from marlowe_kernels._runtime import source_digest
    from marlowe_kernels._kernels.amd.glm52_moe.bandwidth_program import BANDWIDTH_CONFIGS
    from marlowe_kernels._kernels.amd.glm52_moe.safe_fixed_program import SafeFixedConfig,SafeFixedProgram
    from .backend import Layer
    from .protocol import mxfp4_intermediate_is_fused
    from .reference import compare,expert_reference
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    from sglang.srt.layers.moe.utils import initialize_moe_config
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    assert source_digest()==a.source_digest
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    set_global_server_args_for_scheduler(ServerArgs(model_path=str(a.model),tp_size=8,ep_size=1,
        dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    initialize_moe_config()
    init_distributed_environment(world_size=1,rank=0,local_rank=0,
        distributed_init_method='file://'+str(a.output/f'rendezvous-{os.getpid()}'),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    parallel=get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,
                                     tp_size=8,moe_tp_size=8,moe_ep_size=1)
    parallel.__enter__()
    meta=json.loads((a.capture/'b64-s355052/capture.json').read_text())
    data=torch.load(a.capture/'b64-s355052/tensors.pt',map_location='cuda',weights_only=True)
    rows=[]
    for b in (128,256):
        for lid in a.layers:
            j=meta['layers'].index(lid)
            x=torch.cat([data['input'][slot,j,:64] for slot in range(b//64)]).contiguous()
            layer=Layer(torch.load(a.capture/'weights'/f'layer-{lid}.pt',weights_only=True),lid)
            owner=layer.port;program=SafeFixedProgram(owner,b,SafeFixedConfig(**BANDWIDTH_CONFIGS[64]['config']))
            program.router_fp32=True;owner._fp32_programs[b]=program;owner._prepared_modes.add((b,'internal_fp32'))
            native_logits=layer.gate(x)
            logits=(x.float()@layer.gate.weight.detach().float().T).contiguous()
            bias=layer.bias_by_dtype[torch.float32]
            port=owner.forward_fp32(x,logits,bias).clone();pi,pw=(v.clone() for v in owner.routing(b,routing='internal_fp32'))
            modes=[];original=layer.fm.get_2stage_cfgs
            def observe(*args,**kwargs):
                cfg=original(*args,**kwargs);modes.append(cfg);return cfg
            layer.fm.get_2stage_cfgs=observe
            try:native=layer.from_logits(x,native_logits,'aiter').clone()
            finally:layer.fm.get_2stage_cfgs=original
            ni,nw=layer.last_ids.clone(),layer.last_weights.clone();assert modes
            native_fused=mxfp4_intermediate_is_fused(modes[-1])
            native_ref=expert_reference(layer.weights,x,ni,nw,native_fused)
            port_ref=expert_reference(layer.weights,x,pi,pw,program.fp32_middle)
            checks=dict(aiter=compare(native,native_ref),port=compare(port,port_ref))
            if not all(v['passed'] for v in checks.values()):raise RuntimeError((b,lid,checks))
            latency={}
            for name,call in [('aiter',lambda:layer(x,'aiter')),
                              ('port_internal',lambda:owner.forward_fp32(x,
                                  (x.float()@layer.gate.weight.detach().float().T).contiguous(),bias))]:
                for _ in range(5):call()
                samples=[]
                for _ in range(20):
                    start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
                    start.record();call();end.record();end.synchronize();samples.append(start.elapsed_time(end)*1000)
                latency[name]=statistics.median(samples)
            row=dict(batch=b,layer=lid,checks=checks,latency_us=latency,
                     port_program=program.info,native_config=str(modes[-1]))
            rows.append(row);print(json.dumps(dict(batch=b,layer=lid,latency_us=latency)),flush=True)
    save(a.output/'summary.json',dict(job=os.environ['SLURM_JOB_ID'],source=source_digest(),rows=rows))
    parallel.__exit__(None,None,None)
    torch.distributed.destroy_process_group()


if __name__=='__main__':main()
