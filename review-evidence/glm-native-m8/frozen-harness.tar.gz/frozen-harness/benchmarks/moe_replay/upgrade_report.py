"""CPU-only upgrade report, including completed comparisons when a gate fails."""
import argparse
import json
from pathlib import Path
import statistics
from .upgrade_state import file_digest,save


def read(path):
    return json.loads(path.read_text()) if path.exists() else None


def write_report(lock, failure=None):
    root=Path(lock['run_root']);c=lock['config'];runtime=read(Path(lock['runtime_root'])/'runtime.json')
    preflight=read(root/'preflight.json')
    if preflight and preflight.get('status')!='passed':runtime=None
    rows=[];failures=[];details=[]
    for b in c['batches']:
        path=root/'replay'/f'b{b}.json';r=read(path)
        valid=bool(r and r.get('qualified') and all(r.get('graph_checks',{}).get(k) for k in ('aiter','port_ew')))
        problem=read(root/'replay'/f'b{b}-graph-validation-failure.json')
        eager_problem=read(root/'replay'/f'b{b}-eager-validation-failure.json')
        if problem or eager_problem:valid=False  # Never erase an observed failure by retrying until a pass.
        row=dict(batch=b,qualified=valid)
        if valid:
            a=statistics.mean(r['timing']['aiter_preload_events']['interval_medians_us'])
            p=statistics.mean(r['timing']['port_ew_preload_events']['interval_medians_us'])
            row.update(aiter_us=a,port_ew_us=p,port_latency_reduction_pct=100*(1-p/a),cases=len(r['sequence']),
                       result=str(path),sha256=file_digest(path))
            diagnostics=[v for values in r.get('graph_validation',{}).values() for v in values]
            row['pairwise_diagnostic_failures']=sum(not v['graph_vs_eager']['passed'] for v in diagnostics)
            if diagnostics:
                row['max_graph_reference_nrmse']=max(v['graph_reference']['nrmse'] for v in diagnostics)
                row['max_eager_reference_nrmse']=max(v['eager_reference']['nrmse'] for v in diagnostics)
            old_path=Path(c['previous_replay'])/f'b{b}.json' if c.get('previous_replay') else None
            old=read(old_path) if old_path else None
            if old and old.get('qualified') and all(old.get(k)==r.get(k) for k in
                    ('sequence','capture_sha256','metadata_sha256','weight_hashes')):
                row['previous']=dict(path=str(old_path),sha256=file_digest(old_path),
                    aiter_change_pct=100*(a/statistics.mean(old['timing']['aiter_preload_events']['interval_medians_us'])-1),
                    port_ew_change_pct=100*(p/statistics.mean(old['timing']['port_ew_preload_events']['interval_medians_us'])-1))
        problem=read(root/'replay'/f'b{b}-graph-validation-failure.json')
        if problem:
            failures.append(dict(batch=b,**problem));case=problem['case'];detail=problem['detail']
            details.append(f"B{b}, {problem['variant']}, layer {case['layer']}, decode step {case['decode_step']}: "
                           f"graph/reference passed={detail['graph_reference']['passed']}, "
                           f"eager/reference passed={detail['eager_reference']['passed']}; "
                           f"eager mismatch fraction={detail['eager_reference']['mismatch_fraction']:.9g}, "
                           f"eager NRMSE={detail['eager_reference']['nrmse']:.6%}. "
                           'This batch has no qualified timing.')
        if eager_problem:
            failures.append(dict(batch=b,**eager_problem));case=eager_problem['case']
            failed=[name for name in ('aiter_reference','port_reference') if not eager_problem['checks'][name]['passed']]
            details.append(f"B{b}, layer {case['layer']}, decode step {case['decode_step']}: "
                           f"failed {', '.join(failed)}. Raw inputs/outputs and metrics are preserved; no qualified timing.")
        rows.append(row)
    complete=all(r['qualified'] for r in rows) and not failure
    lines=['# AITER versus Port-EW upgrade qualification','',
           '**Status: '+('passed.' if complete else 'incomplete; failed/unrun batches are not qualified.')+'**','',
           f"SGLang `{lock['refs']['sglang']['sha']}`; AITER `{lock['refs']['aiter']['sha']}`.",
           f"Source/configuration fingerprint: `{lock['fingerprint']}`.",'',
           'GLM-5.2 MXFP4, MI355X, TP8/EP1 rank 0. Existing captures: 30 layers × 16 ordered decode steps per batch.',
           'Router GEMM through local combine, shared expert included. Input preloading is outside native HIP event intervals. TP collectives, residual and normalization are excluded.','',
           '| Batch | AITER µs | Port-EW µs | Port-EW latency reduction | Status |',
           '|---:|---:|---:|---:|---|']
    for r in rows:
        lines.append(f"| {r['batch']} | {r['aiter_us']:.2f} | {r['port_ew_us']:.2f} | {r['port_latency_reduction_pct']:+.2f}% | qualified |" if r['qualified']
                     else f"| {r['batch']} | — | — | — | not qualified |")
    lines+=['','Values are means of per-case medians; both backends use the same inputs, weights, case order and timing protocol.',
            'Eager and graph outputs must each pass the independent reference at unchanged limits: rtol=0.02, atol=0.02, NRMSE≤0.01, all finite and zero elementwise mismatches. The reference rounds each weighted contribution to BF16, then sums in FP32 before the final BF16 conversion; this avoids introducing its own order-dependent BF16 summation error. Pairwise graph/eager differences are retained as variability diagnostics.','']
    if c['environment'].get('MARLOWE_KERNELS_NATIVE_TOPK')=='1':
        lines+=['Both arms use the target SGLang/AITER native top-k, preserving its route ordering and tie choices. '
                'Port-EW consumes supplied routes; native top-k cost is included. Historical fused-router timings '
                'are a different implementation boundary and are not substituted here.','']
    if details:lines+=['## Failure details','',*details,'']
    if failure and not details:lines+=['## Failure','',str(failure),'']
    if runtime:
        image=runtime['image']
        lines += ['## Runtime and reuse','',f"Provider: `{image['provider']}`. Image SHA256: `{image['image_sha256']}`.",
                  'Versions: '+', '.join(f"{k} `{v}`" for k,v in runtime['versions'].items())+'.',
                  'Resolved source patches and dependency repairs are recorded in the runtime receipt.','']
        if image['provider']=='legacy-completed-overlay':
            lines+=['The completed environment overlay and original image were reused. No duplicate image build was launched. This output predates the Sailfish integration; it is not a Sailfish-built image.',
                    'The original build/logs were preserved. Its replaced TVM-FFI package was archived; the repaired overlay uses 0.1.9 with the existing TileLang.','']
    audit=read(root/'audit.json')
    if audit and audit.get('status')=='passed':
        cov=audit['detail']['receipt']['coverage']
        lines += [f"Native TP8 audit passed {cov['spans']} layer/batch traces and decode sizes {cov['batches']}. "
                  +('Verified audit evidence was reused; no new eight-GPU allocation.' if audit['detail'].get('reused') else 'The native eight-GPU probe was run.'),'']
    comparisons=[r for r in rows if 'previous' in r]
    if comparisons:
        lines+=['## Change from the prior replay','',
                '| Batch | AITER latency change | Port-EW latency change |','|---:|---:|---:|']
        for r in comparisons:lines.append(f"| {r['batch']} | {r['previous']['aiter_change_pct']:+.2f}% | {r['previous']['port_ew_change_pct']:+.2f}% |")
        lines+=['',f"Prior replay: `{c['previous_replay']}`. Same captured cases/weights; negative means lower latency. Runtime changes and measurement variation can both contribute.",'']
    lines+=['## Coverage limits','',
            'Only the saved unpadded windows are qualified. These are local MoE timings, not fresh full-serving throughput or accuracy results.',
            'An upstream change that selects unsupported numerical behavior or breaks dispatch parity stops qualification; image-build success alone is insufficient.','']
    report=root/'REPORT.md';report.write_text('\n'.join(lines))
    save(root/'summary.json',dict(passed=complete,rows=rows,failures=failures,failure=str(failure) if failure else None))
    return dict(passed=complete,backends=['aiter','port_ew'],results=rows,report=str(report))


def main():
    p=argparse.ArgumentParser();p.add_argument('--lock',required=True,type=Path);p.add_argument('--failure')
    a=p.parse_args();write_report(json.loads(a.lock.read_text()),a.failure)


if __name__=='__main__':main()
