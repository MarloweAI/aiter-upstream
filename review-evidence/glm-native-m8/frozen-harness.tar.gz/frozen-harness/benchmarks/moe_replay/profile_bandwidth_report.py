"""Join ROI-filtered hardware counters to ordered replay cases, fail closed."""
import argparse
import collections
import csv
import json
import itertools
from pathlib import Path
import re
import statistics as st


def stage(name):
    if 'gemm1_a4w4_' in name: return 'g1'
    if 'gemm2_a4w4_' in name: return 'g2'
    return None


def read_csv(path):
    with path.open() as f: return list(csv.DictReader(f))


def collect(folder):
    markers = read_csv(folder / 'counters_marker_api_trace.csv')
    markers = [r for r in markers if re.fullmatch(r'marlowe_bw_b(\d+)_r(\d+)', r['Function'])]
    bounds = [(int(r['Start_Timestamp']), int(r['End_Timestamp'])) for r in markers]
    # Initialization/reference traces may be huge. Retain only expert
    # dispatches within the explicitly marked microbenchmark regions.
    with (folder / 'counters_kernel_trace.csv').open() as f:
        header = next(f)
        expert_lines = (line for line in f if 'gemm1_a4w4_' in line or 'gemm2_a4w4_' in line)
        trace = [r for r in csv.DictReader(itertools.chain([header], expert_lines)) if stage(r['Kernel_Name']) and any(
            lo <= int(r['Start_Timestamp']) <= int(r['End_Timestamp']) <= hi for lo,hi in bounds)]
    counters = collections.defaultdict(lambda: collections.defaultdict(float))
    for row in read_csv(folder / 'counters_counter_collection.csv'):
        counters[row['Dispatch_Id']][row['Counter_Name']] += float(row['Counter_Value'])
    result = []
    for marker in markers:
        match = re.fullmatch(r'marlowe_bw_b(\d+)_r(\d+)', marker['Function'])
        if not match: continue
        b, repetition = map(int, match.groups())
        evidence = json.loads((folder / 'replay' / f'b{b}.json').read_text())
        timing = json.loads((folder.parent / 'timing' / f'b{b}.json').read_text())
        assert evidence['sequence'] == timing['sequence'], ('Routing/order changed',folder,b)
        for key in ('capture_sha256','metadata_sha256'):
            assert evidence[key] == timing[key], (folder,b,key)
        for key in ('commits','image_sha256','script_sha256','steps'):
            assert evidence['identity'][key] == timing['identity'][key], (folder,b,key)
        start, end = int(marker['Start_Timestamp']), int(marker['End_Timestamp'])
        rows = sorted((r for r in trace if stage(r['Kernel_Name']) and
            start <= int(r['Start_Timestamp']) <= int(r['End_Timestamp']) <= end),
            key=lambda r: int(r['Start_Timestamp']))
        assert len(rows) == 2*len(evidence['sequence']), (folder, b, repetition, len(rows))
        for i, row in enumerate(rows):
            case = evidence['sequence'][i//2]
            which = stage(row['Kernel_Name'])
            assert which == ('g1' if i%2 == 0 else 'g2')
            assert row['Dispatch_Id'] in counters, (folder, row)
            result.append(dict(batch=b, repetition=repetition, case_index=i//2,
                layer=case['layer'], decode_step=case['decode_step'], stage=which,
                kernel=row['Kernel_Name'], counters=dict(counters[row['Dispatch_Id']]),
                resources={k:int(row[k]) for k in ['LDS_Block_Size','Scratch_Size','VGPR_Count',
                    'Accum_VGPR_Count','SGPR_Count','Workgroup_Size_X','Grid_Size_X']},
                diagnostic_profiled_us=(int(row['End_Timestamp'])-int(row['Start_Timestamp']))/1000))
    assert result, ('No validated ROI records', folder)
    for b in {r['batch'] for r in result}:
        evidence = json.loads((folder / 'replay' / f'b{b}.json').read_text())
        actual = sorted({r['repetition'] for r in result if r['batch']==b})
        assert actual == list(range(evidence['identity']['repeats'])), (folder,b,actual)
    return result


def ratio(a, b):
    return a/b if b else None


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a=p.parse_args();a.output.mkdir(parents=True, exist_ok=True)
    groups={}
    for name in ('memory','compute','scheduling','latency'):
        folder=a.root/name
        if (folder/'counters_counter_collection.csv').exists():groups[name]=collect(folder)
    validation = dict(passed=set(groups)=={'memory','compute','scheduling','latency'},
        groups={name:len(rows) for name,rows in groups.items()},
        checks=['Exact routes and case order match unprofiled timing',
                'Capture, metadata, source, image and commit fingerprints match',
                'Every ROI contains exactly alternating G1/G2 dispatches',
                'Every expected repetition and dispatch counter is present'],
        scope='Counter-instrumented durations excluded from performance results')
    (a.output/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
    merged=collections.defaultdict(lambda: dict(samples=collections.defaultdict(list),groups=set()))
    for group, rows in groups.items():
        for row in rows:
            key=(row['batch'],row['case_index'],row['stage'])
            item=merged[key]
            item['groups'].add(group)
            item.update({k:row[k] for k in ['batch','case_index','layer','decode_step','stage','kernel','resources']})
            for name,value in row['counters'].items():item['samples'][name].append(value)
    output=[]
    for (b,index,which),item in sorted(merged.items()):
        timing=json.loads((a.root/'timing'/f'b{b}.json').read_text())
        case=timing['sequence'][index]
        assert case['layer']==item['layer'] and case['decode_step']==item['decode_step']
        counters={k:st.median(v) for k,v in item.pop('samples').items()}
        item['counters']=counters;item['groups']=sorted(item['groups'])
        item['active_experts']=case['active_experts'];item['tiles']=case['tiles']
        item['useful_row_fraction']=case['useful_rows']/case['padded_rows']
        us=timing['timing']['interval_medians_us'][index*2+(0 if which=='g1' else 1)]
        item['unprofiled_stage_us']=us
        weight_bytes=case[which+'_weight_bytes']
        item['useful_weight_bytes']=weight_bytes
        item['effective_weight_TBs']=weight_bytes/us/1e6
        hit=counters.get('TCC_HIT_sum',0);miss=counters.get('TCC_MISS_sum',0)
        item['l2_hit_fraction']=ratio(hit,hit+miss)
        item['l2_to_fabric_dram_destination_bytes']=counters.get('TCC_EA0_RDREQ_DRAM_32B_sum',0)*32
        item['destination_read_over_unique_weights']=ratio(item['l2_to_fabric_dram_destination_bytes'],weight_bytes)
        item['mean_occupancy_per_cu']=counters.get('MeanOccupancyPerCU')
        item['wait_over_active_wave_cycles']=ratio(counters.get('SQ_WAIT_INST_ANY',0),counters.get('SQ_ACTIVE_INST_ANY',0))
        item['tcp_to_tcc_read_latency_cycles']=ratio(counters.get('TCP_TCC_READ_REQ_LATENCY_sum',0),
            counters.get('TCP_TCC_READ_REQ_sum',0))
        flop=9*b*6144*256*(4 if which=='g1' else 2)
        executed=counters.get('SQ_INSTS_VALU_MFMA_MOPS_F6F4',0)*512
        item['useful_gemm_flops']=flop;item['counter_mfma_flops']=executed
        item['useful_over_counter_mfma_flops']=ratio(flop,executed)
        output.append(item)
    (a.output/'per-case.json').write_text(json.dumps(output,indent=2)+'\n')
    summary=[]
    fields=['unprofiled_stage_us','effective_weight_TBs','l2_hit_fraction',
        'destination_read_over_unique_weights','mean_occupancy_per_cu','wait_over_active_wave_cycles',
        'tcp_to_tcc_read_latency_cycles','useful_row_fraction','useful_over_counter_mfma_flops']
    for b in sorted({r['batch'] for r in output}):
        for which in ('g1','g2'):
            rows=[r for r in output if r['batch']==b and r['stage']==which]
            summary.append(dict(batch=b,stage=which,cases=len(rows),
                aggregate_effective_weight_TBs=sum(r['useful_weight_bytes'] for r in rows)/sum(r['unprofiled_stage_us'] for r in rows)/1e6,
                **{f:st.mean(r[f] for r in rows if r[f] is not None) if any(r[f] is not None for r in rows) else None for f in fields}))
    (a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (a.output/'summary.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=['batch','stage','cases','aggregate_effective_weight_TBs']+fields)
        writer.writeheader();writer.writerows(summary)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
