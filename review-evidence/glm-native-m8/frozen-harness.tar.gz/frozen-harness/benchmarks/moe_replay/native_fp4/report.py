"""Render the three-arm table; unqualified batches are never shown as wins."""
import argparse,json,statistics
from pathlib import Path
from benchmarks.moe_replay.upgrade_state import file_digest

def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args()
    rows=[]
    lines=['# Native-FP4 Port-EW comparison','',
           'GLM-5.2 MXFP4, MI355X, TP8/EP1 rank-0 replay. Router GEMM through local combine, shared expert included. Lower latency is better.',
           '30 layers × 16 consecutive captured decode steps; 40 samples and 10 warmups. Means of per-case medians. Input preloads are outside native HIP event intervals. TP collective, normalization and residual are excluded.','',
           '| Batch | AITER µs | Port-EW BF16 µs | Port-EW native FP4 µs | FP4 vs AITER reduction | FP4 vs BF16 reduction |',
           '|---:|---:|---:|---:|---:|---:|']
    for b in (1,2,4,8,16,32,64):
        path=a.root/'replay'/f'b{b}.json'
        r=json.loads(path.read_text()) if path.exists() else {}
        passed=r.get('qualified') and all(r.get('graph_checks',{}).get(v) for v in ('aiter','port_ew','port_fp4'))
        passed=passed and not any((a.root/'replay'/f'b{b}-{kind}-validation-failure.json').exists() for kind in ('eager','graph'))
        if not passed:
            rows.append(dict(batch=b,qualified=False));lines.append(f'| {b} | — | — | — | not qualified | — |');continue
        t={v:statistics.mean(r['timing'][v+'_preload_events']['interval_medians_us']) for v in ('aiter','port_ew','port_fp4')}
        ap=100*(1-t['port_fp4']/t['aiter']);bp=100*(1-t['port_fp4']/t['port_ew'])
        rows.append(dict(batch=b,qualified=True,**t,fp4_vs_aiter_pct=ap,fp4_vs_bf16_pct=bp,sha256=file_digest(path),cases=len(r['sequence'])))
        lines.append(f"| {b} | {t['aiter']:.2f} | {t['port_ew']:.2f} | {t['port_fp4']:.2f} | {ap:+.2f}% | {bp:+.2f}% |")
    lines+=['','Runtime reused from the pasted comparison: SGLang `c46bf5e990bdd99e2c200214b04683022100e4df`; AITER `34947d4012bec80888581adc035e9ab6156d129b`. Existing image, dependency overlay, captured inputs/weights and eight-GPU dispatch audit are reused. This does not claim these commits remain the newest upstream.','',
            'All three arms are measured together with randomized graph replay order. Correctness requires unchanged independent-reference thresholds (rtol=0.02, atol=0.02, NRMSE≤0.01), finite outputs and zero elementwise mismatches. Routing parity and actual SGLang kernel selections are checked.','',
            'Full serving throughput, GSM8K answer accuracy and other topologies are not measured by this experiment. See the per-batch JSON files for graph/eager diagnostics and timing distributions.']
    (a.root/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (a.root/'summary.json').write_text(json.dumps(dict(passed=all(r['qualified'] for r in rows),rows=rows),indent=2)+'\n')
    print('\n'.join(lines))
if __name__=='__main__':main()
