"""Compile and independently qualify experimental native FP4 on real captures."""
import json,os
from pathlib import Path
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeConfig,NativeProgram
from benchmarks.moe_replay.reference import expert_reference,compare

def main():
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    root=Path(os.environ['NATIVE_ROOT'])
    capture=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    payload=torch.load(capture/'weights/layer-3.pt',map_location='cuda',weights_only=False)
    w={k:payload[k] for k in ('w1','w2','w1_scale','w2_scale')}
    owner=create_moe(MoEConfig(),MoEWeights(*w.values()),implementation='native_fp4')
    records=[]
    for b in (1,8,16,64):
        tensors=torch.load(capture/f'b{b}-s355052/tensors.pt',map_location='cuda',weights_only=False)
        print('tensor_keys',list(tensors),flush=True)
        x=tensors['input'][0,0].contiguous()
        logits=tensors['logits'][0,0].to(torch.bfloat16).contiguous()
        for direct,sk,bn,nw in ((True,1,128,2),(False,1,128,2),(False,3,128,2),(False,1,256,2)):
            c=NativeConfig(direct=direct,split_k=sk,gate_n=bn,gate_waves=nw)
            program=NativeProgram(owner,b,c)
            out=program.run(x,logits,payload['bias'].to(torch.bfloat16)).clone()
            torch.cuda.synchronize()
            ref=expert_reference(w,x,program.p['ids'],program.p['weights'],program.fp32_middle)
            result=compare(out,ref)
            row=dict(batch=b,config=c.__dict__,check=result)
            row['diagnostics']=dict(out_abs=float(out.abs().max()),ref_abs=float(ref.abs().max()),mid_scale=program.mid_scale.flatten()[:16].tolist(),mid=program.mid.flatten()[:32].tolist(),input_scale=program.p['workspace'][256:272].tolist())
            records.append(row);print(json.dumps(row),flush=True)
            (root/'probe.json').write_text(json.dumps(records,indent=2))
            if not result['passed']:
                torch.save(dict(input=x,logits=logits,output=out,reference=ref,mid=program.mid,scale=program.mid_scale,partial=program.partial,prep=program.p),root/f'probe-failure-b{b}-direct{direct}-sk{sk}-bn{bn}.pt')
if __name__=='__main__':main()
