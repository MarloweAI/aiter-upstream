"""Three-arm replay against the unchanged, audited SGLang/AITER runtime."""
import hashlib,json,os
from pathlib import Path
import torch
from benchmarks.moe_replay import run
from benchmarks.moe_replay.sglang_adapter import SGLangLayer
from benchmarks.moe_replay.dispatch_audit import capture_dispatch,compare_dispatch
from benchmarks.moe_replay.upgrade_state import file_digest
from marlowe_kernels import create_moe
from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeConfig,NativeProgram

ROOT=Path(os.environ['NATIVE_ROOT'])
BASE=Path('/workspace/home/mishas/results/marlowe-kernels/upgrades/runs/127484f037bab851f068f867')
AUDIT=BASE/'native-audit'

class NativeLayer(SGLangLayer):
    def __init__(self,payload,layer_id,spec):
        # Historical three-arm experiments retain their BF16 control even
        # after the public factory promotes a newer Port-EW implementation.
        super().__init__(payload,layer_id,spec,implementation='bf16')
        self.native=create_moe(self.port.config,self.port.weights,implementation='native_fp4')
    def warmup(self,b):
        super().warmup(b)
        configs=json.loads((ROOT/'selected-configs.json').read_text())
        if b not in self.native._programs:
            self.native._programs[b]=NativeProgram(self.native,b,NativeConfig(**configs[str(b)]))
        self.native.warmup((b,),routing='internal')
        self.native.warmup((b,),routing='supplied')
    def from_logits(self,x,logits,variant):
        if variant!='port_fp4':return super().from_logits(x,logits,variant)
        if logits.dtype==torch.bfloat16:
            out=self.native(x,logits,self.bias_by_dtype[logits.dtype])
        else:
            weights,ids=self.routes(x,logits)
            out=self.native.forward_routed(x,ids,weights)
        self.last_logits=logits
        self.last_ids,self.last_weights=self.native.routing(len(x))
        return out
    def expert_routed(self,x,ids,weights,variant):
        if variant!='port_fp4':return super().expert_routed(x,ids,weights,variant)
        return self.native.forward_routed(x,ids[:,:8].contiguous(),weights[:,:8].contiguous())

def factory(payload,layer_id):
    payload.update(torch.load(AUDIT/f'gate-{layer_id}.pt',weights_only=True))
    spec=json.loads((AUDIT/f'layer-{layer_id}.json').read_text())
    for key,expected in spec['weight_content_sha256'].items():
        raw=payload[key].detach().contiguous().view(torch.uint8).numpy()
        assert hashlib.sha256(memoryview(raw)).hexdigest()==expected
    layer=NativeLayer(payload,layer_id,spec)
    for field,key in {'w13_weight':'w1','w2_weight':'w2','w13_scale':'w1_scale','w2_scale':'w2_scale'}.items():
        expected=spec['weights'][key]
        value=layer.weights[key]
        dtype=getattr(torch,expected['dtype'].removeprefix('torch.'))
        # Preserve AITER's is_shuffled metadata when no dtype change is needed.
        # Losing it disables the tuned FlyDSL path at B32/B64.
        if value.dtype!=dtype:value=value.view(dtype)
        assert list(value.shape)==expected['shape'] and list(value.stride())==expected['stride']
        setattr(layer.quant_info,field,value)
    return layer

def verify(layer,x,b):
    context=torch.cuda.graph(torch.cuda.CUDAGraph())
    stream=context.capture_stream;stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for variant in ('aiter','port_ew','port_fp4'):
            for _ in range(2):layer(x,variant)
    torch.cuda.synchronize()
    observed,out,graph=capture_dispatch(lambda:layer(x,'aiter'))
    native=json.loads((AUDIT/f'dispatch-l{layer.layer_id}-b{b}.json').read_text())
    result=compare_dispatch(native,observed)
    if not result['passed']:
        (ROOT/f'dispatch-failure-l{layer.layer_id}-b{b}.json').write_text(json.dumps(result,indent=2))
        raise RuntimeError(f'Dispatch mismatch: B{b}, layer{layer.layer_id}; evidence saved')
    return dict(layer=layer.layer_id,batch=b,**result)

def main():
    import sys
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    lock=json.loads((BASE/'lock.json').read_text());c=lock['config']
    # The parent runtime is read-only to this experiment; verify its refs have
    # not moved before reusing the already-qualified native dispatch evidence.
    import subprocess
    runtime=Path('/workspace/home/mishas/results/marlowe-kernels/upgrades/runtimes/833390bddc1ba25ff74d38fc')
    for component,expected in {'sglang':'c46bf5e990bdd99e2c200214b04683022100e4df','aiter':'34947d4012bec80888581adc035e9ab6156d129b'}.items():
        actual=subprocess.check_output(['git','-C',str(runtime/component),'rev-parse','HEAD'],text=True).strip()
        if actual!=expected:raise RuntimeError(f'Pinned runtime changed: {component}: {actual}')
    receipt=json.loads((AUDIT/'validated.json').read_text())
    assert receipt['passed']
    for name,expected in receipt['files'].items():assert file_digest(AUDIT/name)==expected
    set_global_server_args_for_scheduler(ServerArgs(model_path=c['model'],tp_size=8,ep_size=1,dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    init_distributed_environment(world_size=1,rank=0,local_rank=0,distributed_init_method='file://'+str(ROOT/f'rendezvous-{os.getpid()}'),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    from marlowe_kernels._runtime import cache_identity
    try:
        with get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,world_rank=0,tp_size=8,moe_tp_size=8,moe_ep_size=1):
            run.main(['--capture',c['capture'],'--output',str(ROOT/'replay'),'--model',c['model'],*sys.argv[1:]],
                     layer_factory=factory,dispatch_validator=verify,port_variants=('port_ew','port_fp4'),
                     runtime_identity=dict(adapter_sha256=file_digest(Path(__file__)),jit_namespace=cache_identity(),baseline_run=str(BASE),lock_sha256=file_digest(BASE/'lock.json'),
                                           native_configs=json.loads((ROOT/'selected-configs.json').read_text())))
    finally:torch.distributed.destroy_process_group()
if __name__=='__main__':main()
