"""Verify emitted expert assembly uses native scaled FP4, without BF16 MFMA."""
import argparse,json,re
from pathlib import Path
from benchmarks.moe_replay.upgrade_state import file_digest

def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args()
    expected=set();namespaces=set()
    for result in (a.root/'replay').glob('b*.json'):
        if '-validation' in result.name:continue
        record=json.loads(result.read_text())
        if not record.get('qualified'):continue
        runtime=record['identity']['runtime'];b=record['batch']
        prefix=runtime['jit_namespace'];namespaces.add(prefix)
        c=runtime['native_configs'][str(b)]
        for first in (True,False):
            values=dict(K=6144 if first else 256,N=512 if first else 6144,
                        BN=c['gate_n' if first else 'down_n'],FIRST=first,
                        SK=c['split_k'] if first else 1,FP32_OUT=b in (1,4,8,32),
                        NW=c['gate_waves' if first else 'down_waves'],DIRECT=c['direct'],
                        PIPE=c['gate_pipeline' if first else 'down_pipeline'],NT=c['non_temporal'])
            name=f'mk_{prefix}_native_projection-'+ '-'.join(f'{k}={v}' for k,v in values.items())+'.s'
            expected.add(a.root/'pyhip-cache'/name)
    records=[]
    for path in sorted(expected):
        s=path.read_text()
        matrix=re.findall(r'^\s*(v_mfma_\S+)',s,re.M)
        lines=re.findall(r'^\s*v_mfma_.*$',s,re.M)
        fp4_formats=all('cbsz:4' in line and 'blgp:4' in line for line in lines)
        passed=bool(matrix) and fp4_formats and all(op=='v_mfma_scale_f32_16x16x128_f8f6f4' for op in matrix)
        resources={key:int(value) for key,value in re.findall(r'^\s*\.amdhsa_(next_free_vgpr|next_free_sgpr|private_segment_fixed_size)\s+(\d+)',s,re.M)}
        records.append(dict(file=path.name,sha256=file_digest(path),passed=passed,
                            static_matrix_instructions=len(matrix),fp4_operand_formats=fp4_formats,
                            matrix_instructions=sorted(set(matrix)),resources=resources))
    result=dict(jit_namespaces=sorted(namespaces),passed=bool(records) and all(r['passed'] for r in records),kernels=records)
    (a.root/'isa-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not result['passed']:raise RuntimeError('Native FP4 ISA audit failed')
if __name__=='__main__':main()
