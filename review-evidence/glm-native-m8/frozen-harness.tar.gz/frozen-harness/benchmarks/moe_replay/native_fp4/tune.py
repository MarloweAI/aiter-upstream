"""Tile/split-K screening on ordered real-layer weights, followed by full replay.

Screening fixes captured router logits and times preparation through combine.
It is not the final router-GEMM-inclusive comparison. Inputs are touched before
native graph event intervals; 30 distinct weight sets exceed the cache budget.
"""
import itertools,json,os,statistics,dataclasses,gc,sys
from pathlib import Path
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.native_program import NativeConfig,NativeProgram
from benchmarks.moe_replay.reference import expert_reference,compare
from benchmarks.moe_replay.run import prepare_graph,timings
from benchmarks.moe_replay.protocol import cases,load_metadata

class ScreenLayer:
    def __init__(self,owner,program,logits,bias):
        self.owner,self.program,self.logits,self.bias=owner,program,logits,bias
    def __call__(self,x,variant):
        logits=self.logits[x.data_ptr()] if isinstance(self.logits,dict) else self.logits
        return self.program.run(x,logits,self.bias)

def main():
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    root=Path(os.environ['NATIVE_ROOT']);capture=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')
    records=[];selected={};owners={};payloads={}
    finalists='--finalists' in sys.argv
    refine='--refine' in sys.argv
    initial=json.loads((root/'tuning.json').read_text()) if refine or finalists else []
    refined=json.loads((root/'refinement.json').read_text()) if finalists else []
    qualified_configs=json.loads((root/'selected-configs.json').read_text()) if finalists else {}
    records_path=root/('finalists.json' if finalists else 'refinement.json' if refine else 'tuning.json')
    for b in (1,2,4,8,16,32,64):
        source=capture/f'b{b}-s355052';meta=load_metadata(source);meta['steps']=meta['steps'][:16 if finalists else 1]
        sequence=list(cases(meta));data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
        for lid in meta['layers']:
            if lid not in owners:
                payload=torch.load(capture/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
                w={k:payload[k] for k in ('w1','w2','w1_scale','w2_scale')}
                owners[lid]=create_moe(MoEConfig(),MoEWeights(*w.values()),implementation='native_fp4')
                payloads[lid]=payload
        lid=meta['layers'][0];x=data['input'][0,0].contiguous();logits=data['logits'][0,0].bfloat16().contiguous()
        pilot=NativeProgram(owners[lid],b)
        pilot.run(x,logits,payloads[lid]['bias'].bfloat16());torch.cuda.synchronize()
        w={k:payloads[lid][k] for k in ('w1','w2','w1_scale','w2_scale')}
        ref=expert_reference(w,x,pilot.p['ids'],pilot.p['weights'],pilot.fp32_middle)
        del pilot
        def measure(c):
            layers={}
            for j,lid in enumerate(meta['layers']):
                program=NativeProgram(owners[lid],b,c)
                logits={data['input'][slot,j].data_ptr():data['logits'][slot,j].bfloat16().contiguous() for slot in range(len(meta['steps']))}
                layers[lid]=ScreenLayer(owners[lid],program,logits,payloads[lid]['bias'].bfloat16())
            first=layers[meta['layers'][0]]
            out=first(x,'native').clone();torch.cuda.synchronize();check=compare(out,ref)
            record=dict(batch=b,config=dataclasses.asdict(c),check=check)
            if check['passed']:
                for j,lid in enumerate(meta['layers']):layers[lid](data['input'][0,j],'native')
                torch.cuda.synchronize()
                graph=prepare_graph(sequence,layers,data,'native',True,True)
                t=timings({'native':graph},16 if finalists else 12,4)['native']
                record.update(us=statistics.mean(t['interval_medians_us']),timing=t)
                del graph
            records.append(record);records_path.write_text(json.dumps(records,indent=2))
            print(json.dumps({k:v for k,v in record.items() if k!='timing'}),flush=True)
            del layers;gc.collect()
            return record
        if finalists:
            baseline=NativeConfig(**qualified_configs[str(b)])
            candidates={baseline}
            for rows in (initial,refined):
                leaders=sorted([r for r in rows if r['batch']==b and r['check']['passed']],key=lambda r:r['us'])[:3]
                candidates.update(NativeConfig(**r['config']) for r in leaders)
            if b>=8:
                # Later decode steps activate more experts than step zero.
                # Preserve distinct work decompositions, not just near-tied
                # finalists from the step-zero screen.
                families={}
                for row in initial:
                    if row['batch']!=b or not row['check']['passed']:continue
                    cfg=NativeConfig(**row['config'])
                    key=(cfg.direct,cfg.gate_n,cfg.gate_waves,cfg.split_k)
                    if key not in families or row['us']<families[key]['us']:families[key]=row
                for row in families.values():
                    cfg=NativeConfig(**row['config'])
                    candidates.add(cfg)
                    candidates.add(dataclasses.replace(cfg,non_temporal=True))
            results=[measure(c) for c in sorted(candidates,key=lambda c:json.dumps(dataclasses.asdict(c),sort_keys=True))]
            good=[r for r in results if r['check']['passed']]
            leader=NativeConfig(**min(good,key=lambda r:r['us'])['config'])
            for bn,nw in ((64,1),(128,1),(128,2),(256,2),(256,4)):
                cfg=dataclasses.replace(leader,down_n=bn,down_waves=nw)
                if cfg not in candidates:
                    result=measure(cfg)
                    if result['check']['passed']:good.append(result)
            original=next(r for r in good if r['config']==dataclasses.asdict(baseline))
            best=min(good,key=lambda r:r['us'])
            # Do not replace a qualified setting for a sub-percent screen delta.
            if best['us']>=original['us']*.99:best=original
        elif refine:
            # Remeasure baseline finalists in this same sweep; never compare
            # noisy minima from two separate runs to decide the winner.
            previous=[r for r in initial if r['batch']==b and r['check']['passed']]
            leaders=sorted(previous,key=lambda r:r['us'])[:3]
            candidates=set()
            for row in leaders:
                c=NativeConfig(**row['config'])
                for nt in (False,True):
                    candidates.add(dataclasses.replace(c,non_temporal=nt))
                    for sk in (8,12,24):
                        candidates.add(dataclasses.replace(c,split_k=sk,non_temporal=nt,gate_pipeline=True))
            results=[measure(c) for c in sorted(candidates,key=lambda c:json.dumps(dataclasses.asdict(c),sort_keys=True))]
            good=[r for r in results if r['check']['passed']]
            if not good:raise RuntimeError(f'No correct refinement B{b}')
            best=min(good,key=lambda r:r['us'])
        else:
            gate=[]
            for direct,(bn,nw),sk in itertools.product((True,False),((64,1),(128,1),(128,2),(256,2),(256,4)),(1,2,3,6)):
                row=measure(NativeConfig(direct=direct,gate_n=bn,gate_waves=nw,split_k=sk))
                if row['check']['passed']:gate.append(row)
            if not gate:raise RuntimeError(f'No correct candidate B{b}')
            best=min(gate,key=lambda r:r['us'])
            serial=[]
            for row in sorted(gate,key=lambda r:r['us'])[:4]:
                c=dataclasses.replace(NativeConfig(**row['config']),gate_pipeline=False)
                result=measure(c)
                if result['check']['passed']:serial.append(result)
            best=min([best,*serial],key=lambda r:r['us'])
            down=[]
            for bn,nw in ((64,1),(128,1),(256,1),(256,2),(256,4)):
                c=dataclasses.replace(NativeConfig(**best['config']),down_n=bn,down_waves=nw)
                row=measure(c)
                if row['check']['passed']:down.append(row)
            best=min([best,*down],key=lambda r:r['us'])
            serial_down=measure(dataclasses.replace(NativeConfig(**best['config']),down_pipeline=False))
            if serial_down['check']['passed'] and serial_down['us']<best['us']:best=serial_down
        selected[str(b)]=best['config'];(root/('finalists-configs.json' if finalists else 'selected-configs.json')).write_text(json.dumps(selected,indent=2))
        print('SELECTED',b,best['config'],best['us'],flush=True)
        del data,ref
        torch.cuda.empty_cache()
if __name__=='__main__':main()
