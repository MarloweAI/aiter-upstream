"""Reduced operand/order diagnosis, never an admission gate or timing source."""

import argparse
import itertools
import json
import os
from pathlib import Path


def reachable_bf16_sums(operands):
    """Enumerate every serial order for exactly nine BF16 atomic operands."""
    import torch

    if len(operands) != 9:
        raise ValueError("Diagnostic is bounded to nine route operands")
    permutation = torch.tensor(list(itertools.permutations(range(9))), dtype=torch.long)
    values = torch.tensor(operands, dtype=torch.float32)
    sums = torch.zeros(len(permutation), dtype=torch.float32)
    for slot in range(9):
        sums = (sums + values[permutation[:, slot]]).bfloat16().float()
    reachable, counts = torch.unique(sums, sorted=True, return_counts=True)
    return {
        "permutation_count": len(permutation),
        "reachable": reachable.tolist(),
        "counts": counts.tolist(),
        "min": reachable.min().item(),
        "max": reachable.max().item(),
    }


def main():
    import torch

    from .upstream_contract import file_digest
    from .upstream_reference import quantize, unpack_weights

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--failure", type=Path, nargs="+", required=True)
    parser.add_argument("--packed-weights", type=Path, required=True)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(4)
    torch.set_grad_enabled(False)
    torch.backends.cuda.matmul.allow_tf32 = False
    if not os.environ.get("SLURM_JOB_ID") or torch.cuda.device_count() != 1:
        raise SystemExit("Run inside an owned one-GPU allocation")
    packed = torch.load(args.packed_weights, map_location="cuda", weights_only=True)
    weights = {k: packed[k] for k in ("w1", "w2", "w1_scale", "w2_scale")}
    decoded = unpack_weights(weights)
    contract = json.loads(args.contract.read_text())
    records = []
    for path in args.failure:
        data = torch.load(path, map_location="cuda", weights_only=True)
        actual, expected = data["actual"].double(), data["expected"].double()
        coords = torch.nonzero((actual - expected).abs() > 0.02 + 0.02 * expected.abs())
        qx = quantize(data["input"], contract["input_rounding"])
        operands = {}
        targets = coords.tolist()
        for token, column in targets:
            operands[(token, column)] = [None] * 9
        experts = sorted(
            {e for token, _ in targets for e in data["ids"][token].tolist()}
        )
        for expert in experts:
            rows, slots = torch.where(data["ids"] == expert)
            gate, up = (qx[rows] @ decoded["w1"][expert].T).chunk(2, -1)
            middle = gate * torch.sigmoid(gate) * up
            if not contract["fp32_middle"]:
                middle = middle.bfloat16()
            middle = quantize(middle, contract["middle_rounding"])
            # Same full expert-row GEMM as the independent reference, then
            # retain only the few failed coordinates for CPU enumeration.
            contribution = (middle @ decoded["w2"][expert].T) * data["weights"][
                rows, slots, None
            ]
            rounded = contribution.bfloat16().float()
            for token, column in targets:
                match = torch.nonzero(rows == token).flatten()
                if len(match):
                    index = int(match[0])
                    slot = int(slots[index])
                    operands[(token, column)][slot] = {
                        "expert": expert,
                        "fp32_weighted": contribution[index, column].item(),
                        "bf16_operand": rounded[index, column].item(),
                    }
        torch.cuda.synchronize()
        for token, column in targets:
            parts = operands[(token, column)]
            if any(part is None for part in parts):
                raise RuntimeError("Incomplete nine-operand decomposition")
            values = [part["bf16_operand"] for part in parts]
            reachable = reachable_bf16_sums(values)
            got, ref = actual[token, column].item(), expected[token, column].item()
            ideal = torch.tensor(values).sum().bfloat16().item()
            records.append(
                {
                    "source": str(path),
                    "coordinate": [token, column],
                    "actual": got,
                    "expected": ref,
                    "absolute_error": abs(got - ref),
                    "tolerance": 0.02 + 0.02 * abs(ref),
                    "operands_route_slot_order": parts,
                    "independent_operand_fp32_sum_then_bf16": ideal,
                    "matches_saved_reference": ideal == ref,
                    "reachable_serial_bf16_orders": reachable,
                    "actual_reachable": got in reachable["reachable"],
                    "scope": "arithmetic diagnosis only; no tolerance or admission policy change",
                }
            )
    args.output.write_text(
        json.dumps(
            {
                "contract": contract,
                "records": records,
                "job": os.environ["SLURM_JOB_ID"],
                "source_sha256": file_digest(__file__),
                "reference_sha256": file_digest(
                    Path(__file__).with_name("upstream_reference.py")
                ),
                "packed_weights_sha256": file_digest(args.packed_weights),
                "limitation": "Independent Torch-derived operands may differ slightly from hardware MFMA operands; reachability proves rounding plausibility, not a complete kernel mechanism proof.",
                "admission_policy_changed": False,
            },
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "output": str(args.output),
                "cases": len(records),
                "all_actual_reachable": all(r["actual_reachable"] for r in records),
                "all_saved_reference_matched": all(
                    r["matches_saved_reference"] for r in records
                ),
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
