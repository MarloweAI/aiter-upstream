"""Runtime-only ABI/import probe. Synthetic calls are not benchmark evidence."""

import argparse
import importlib
import importlib.metadata
import os
import socket
from pathlib import Path

from .upstream_campaign import metadata_info, revision, save


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--aiter-source", type=Path, required=True)
    parser.add_argument("--aiter-sha", required=True)
    parser.add_argument("--sglang-source", type=Path, required=True)
    parser.add_argument("--sglang-sha", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    import aiter
    import torch
    import triton

    module = importlib.import_module("aiter.fused_moe")
    if torch.cuda.device_count() != 1 or torch.version.hip is None:
        raise RuntimeError("Pilot needs one visible AMD GPU")
    if (
        revision(args.aiter_source) != args.aiter_sha
        or revision(args.sglang_source) != args.sglang_sha
    ):
        raise RuntimeError("Wrong pinned source revision")
    if not Path(module.__file__).resolve().is_relative_to(args.aiter_source.resolve()):
        raise RuntimeError("Wrong imported AITER source")
    result = {
        "job": os.environ.get("SLURM_JOB_ID"),
        "host": socket.gethostname(),
        "torch": torch.__version__,
        "hip": torch.version.hip,
        "triton": triton.__version__,
        "device": torch.cuda.get_device_name(),
        "aiter_sha": args.aiter_sha,
        "aiter_module": module.__file__,
        "sglang_sha": args.sglang_sha,
        "flydsl": importlib.metadata.version("flydsl"),
        "purpose": "synthetic ABI initialization only; no performance cells",
    }
    save(args.output, result)
    if result["flydsl"] != "0.3.4.1":
        raise RuntimeError("Current pinned AITER requires FlyDSL0.3.4.1")
    torch.set_grad_enabled(False)
    torch.set_num_threads(4)
    # Full GLM TP8 packed dimensions, deliberately zero operands. This proves
    # dispatch/build ABI only, never numerical qualification on real captures.
    w1 = torch.zeros((257, 512, 3072), device="cuda", dtype=torch.uint8).view(
        torch.float4_e2m1fn_x2
    )
    w2 = torch.zeros((257, 6144, 128), device="cuda", dtype=torch.uint8).view(
        torch.float4_e2m1fn_x2
    )
    w1.is_shuffled = w2.is_shuffled = True
    s1 = torch.full((257, 512, 192), 127, device="cuda", dtype=torch.uint8).view(
        torch.float8_e8m0fnu
    )
    s2 = torch.full((257, 6144, 8), 127, device="cuda", dtype=torch.uint8).view(
        torch.float8_e8m0fnu
    )
    observed, old = [], module.get_2stage_cfgs

    def observe(*a, **kw):
        value = old(*a, **kw)
        observed.append(metadata_info(value))
        return value

    module.get_2stage_cfgs = observe
    try:
        for rows in (4, 32, 128, 256):
            x = torch.zeros((rows, 6144), device="cuda", dtype=torch.bfloat16)
            ids = torch.arange(9, device="cuda", dtype=torch.int32).repeat(rows, 1)
            ids[:, 8] = 256
            weights = torch.ones((rows, 9), device="cuda", dtype=torch.float32)
            output = module.fused_moe(
                x,
                w1,
                w2,
                weights,
                ids,
                activation=aiter.ActivationType.Silu,
                quant_type=aiter.QuantType.per_1x32,
                w1_scale=s1,
                w2_scale=s2,
                gate_mode=module.GateMode.SEPARATED.value,
            )
            torch.cuda.synchronize()
            if output.shape != x.shape or not torch.isfinite(output).all():
                raise RuntimeError(f"ABI probe bad output M{rows}")
            result.setdefault("native_dispatch", {})[str(rows)] = observed[-1]
            save(args.output, result)
    finally:
        module.get_2stage_cfgs = old
    try:
        import sglang
        from sglang.srt.layers.moe.fused_moe_triton.layer import FusedMoE
        from sglang.srt.managers.scheduler import Scheduler
        from sglang.srt.model_executor.model_runner import ModelRunner
        from sglang.srt.models.deepseek_v2 import DeepseekV2MoE, MoEGate

        if (
            not Path(sglang.__file__)
            .resolve()
            .is_relative_to(args.sglang_source.resolve())
        ):
            raise RuntimeError("Wrong imported SGLang source")
        result["capture_imports"] = {
            "passed": all(
                hasattr(cls, method)
                for cls, method in (
                    (DeepseekV2MoE, "forward_normal"),
                    (MoEGate, "forward"),
                    (FusedMoE, "forward"),
                    (Scheduler, "run_batch"),
                    (Scheduler, "flush_cache"),
                    (ModelRunner, "forward"),
                )
            ),
            "sglang_module": sglang.__file__,
        }
    except Exception as error:  # noqa: BLE001 - preserve any capture ABI/import failure
        result["capture_imports"] = {"passed": False, "error": repr(error)}
    result["state"] = "completed"
    save(args.output, result)
    print(result, flush=True)


if __name__ == "__main__":
    main()
