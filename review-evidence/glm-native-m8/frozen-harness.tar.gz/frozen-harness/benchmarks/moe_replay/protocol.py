"""CPU-only replay ordering and coverage validation."""
LAYERS = [3,5,8,11,13,16,18,21,23,26,29,31,34,36,39,40,44,46,48,51,54,56,59,61,64,66,69,72,74,77]
BATCHES = [1,2,4,8,16,32,64]


def cases(metadata):
    previous=-1
    for slot,step in enumerate(metadata['steps']):
        assert step['decode_step']==previous+1
        previous=step['decode_step']
        assert step['scheduled_rows']==len(step['live_rows'])
        assert sum(step['live_rows'])==step['actual_token_count']
        assert 0<=step['actual_token_count']<=step['scheduled_rows']<=step['graph_rows']<=64
        assert step['graph_rows'] in BATCHES
        if step['actual_token_count']==0:continue
        for layer_index,layer in enumerate(metadata['layers']):
            yield dict(slot=slot,layer_index=layer_index,layer=layer,**step)


def load_metadata(root):
    import json
    from benchmarks.routing_records import live_steps
    metadata=json.loads((root/'capture.json').read_text())
    if (root/'responses.json').exists():
        responses=json.loads((root/'responses.json').read_text())
        metadata['steps']=live_steps(metadata,responses)
        corrected={s['decode_step']:s for s in metadata['steps']}
        if 'timings' in metadata:
            metadata['timings']=[dict(t,**{k:v for k,v in corrected[t['decode_step']].items() if k!='layer_us'})
                                 for t in metadata['timings']]
    return metadata


def mxfp4_intermediate_is_fused(metadata):
    """Qualify the rounding contract before using the independent reference.

    AITER's layout-aware G2 consumes the packed FP4+scale tuple returned by
    G1. skip_inter_quant means no *second* quantization of that tuple. It is
    valid only alongside an explicitly FP4-producing G1 for this reference.
    """
    if getattr(metadata,'run_1stage',False):
        raise ValueError('One-stage numerical contract requires qualification')
    if metadata.fuse_quant not in ('','fp4'):
        raise ValueError('Unverified intermediate quantization type')
    if getattr(metadata,'skip_inter_quant',False) and metadata.fuse_quant!='fp4':
        raise ValueError('Unverified unquantized intermediate contract')
    return metadata.fuse_quant=='fp4'
