"""Prove FP32 internal top-k sees sub-BF16-ULP routing differences."""
import argparse
import json
import os
from pathlib import Path

from .upgrade_state import save


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--source-digest',required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    import torch
    from marlowe_kernels import create_moe,MoEConfig,MoEWeights
    from marlowe_kernels._runtime import source_digest
    from .reference import expert_reference,compare
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    assert source_digest()==a.source_digest
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    payload=torch.load(a.capture/'weights/layer-3.pt',map_location='cuda',weights_only=True)
    w={key:payload[key] for key in ('w1','w2','w1_scale','w2_scale')}
    owner=create_moe(MoEConfig(),MoEWeights(w['w1'],w['w2'],w['w1_scale'],w['w2_scale']))
    owner.warmup((1,),routing='internal')
    owner.warmup((1,),routing='internal_fp32')
    x=torch.load(a.capture/'b1-s355052/tensors.pt',map_location='cuda',weights_only=True)['input'][0,0,:1].contiguous()
    bias32=torch.zeros(256,device='cuda',dtype=torch.float32)
    bias16=bias32.bfloat16()
    rows=[]
    for higher in (7,8):
        logits32=torch.full((1,256),-20.,device='cuda',dtype=torch.float32)
        logits32[:,0:7]=10.
        logits32[:,7]=1.0001 if higher==8 else 1.0002
        logits32[:,8]=1.0002 if higher==8 else 1.0001
        logits16=logits32.bfloat16()
        y32=owner.forward_fp32(x,logits32,bias32).clone()
        ids32,weights32=(t.clone() for t in owner.routing(1,routing='internal_fp32'))
        y16=owner(x,logits16,bias16).clone()
        ids16,weights16=(t.clone() for t in owner.routing(1,routing='internal'))
        ref32=expert_reference(w,x,ids32,weights32,True)
        ref16=expert_reference(w,x,ids16,weights16,True)
        row=dict(higher=higher,logits32=[float(logits32[0,i]) for i in (7,8)],
                 logits16=[float(logits16[0,i]) for i in (7,8)],
                 ids32=ids32.cpu().tolist(),ids16=ids16.cpu().tolist(),
                 weights32=weights32.cpu().tolist(),weights16=weights16.cpu().tolist(),
                 reference_fp32=compare(y32,ref32),reference_bf16=compare(y16,ref16))
        rows.append(row)
    selected=lambda row:set(row['ids32'][0][:8])
    bf16_selected=lambda row:row['ids16'][0][:8]
    # Both FP32 candidates become exactly 1.0 after BF16 rounding. Their
    # opposite order can therefore affect only the FP32 specialization.
    passed=(rows[0]['logits16']==rows[1]['logits16']==[1.,1.]
            and selected(rows[0])!=selected(rows[1])
            and 7 in selected(rows[0]) and 8 in selected(rows[1])
            and bf16_selected(rows[0])==bf16_selected(rows[1])
            and all(r['reference_fp32']['passed'] and r['reference_bf16']['passed'] for r in rows))
    save(a.output/'summary.json',dict(passed=passed,rows=rows,job=os.environ['SLURM_JOB_ID'],
                                      library_source=source_digest()))
    if not passed:raise RuntimeError('FP32 internal top-k did not distinguish the sub-BF16-ULP scores')
    print(json.dumps(dict(passed=passed,fp32_winners=[sorted(selected(r)) for r in rows],
                          bf16_winner=bf16_selected(rows[0]))),flush=True)


if __name__=='__main__':main()
