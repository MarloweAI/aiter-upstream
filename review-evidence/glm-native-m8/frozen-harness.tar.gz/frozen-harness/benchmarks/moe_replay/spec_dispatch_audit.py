"""Audit AITER dispatch for real GLM-5.2 MTP target-verification shapes."""
import argparse
import functools
import json
import os
from pathlib import Path
import subprocess

from .upgrade_state import digest,save


def revision(module):
    path=Path(module.__file__).resolve()
    for parent in path.parents:
        if (parent/'.git').exists():
            return dict(path=str(path),root=str(parent),commit=subprocess.check_output(
                ['git','-C',str(parent),'rev-parse','HEAD'],text=True).strip())
    raise RuntimeError(f'No Git checkout contains {path}')


def function(fn):
    if isinstance(fn,functools.partial):
        return dict(name=f'{fn.func.__module__}.{fn.func.__name__}',
                    keywords={k:repr(v) for k,v in (fn.keywords or {}).items()})
    return dict(name=f'{fn.__module__}.{fn.__name__}',keywords={})


def metadata(cfg):
    fields=('block_m','ksplit','run_1stage','has_bias','use_non_temporal_load','fuse_quant',
            'stage2_has_bias','flat','output_aux','prequant','skip_inter_quant','route_bucket',
            'expected_sorted_blocks','min_sorted_blocks','max_sorted_blocks')
    result={name:repr(getattr(cfg,name,None)) for name in fields}
    result.update(stage1=function(cfg.stage1),stage2=function(cfg.stage2))
    return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--model',type=Path,required=True)
    p.add_argument('--aiter-commit',required=True)
    p.add_argument('--sglang-commit',required=True)
    p.add_argument('--request-batches',type=int,nargs='+',default=[1,2,4,8,16,32,64])
    p.add_argument('--layers',type=int,nargs='+',default=[3,40,77])
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    assert os.environ.get('SLURM_JOB_ID')
    import torch,aiter
    import sglang.srt.server_args as sglang_module
    from .backend import Layer
    from .dispatch_audit import capture_dispatch
    from sglang.srt.server_args import ServerArgs,set_global_server_args_for_scheduler
    from sglang.srt.distributed.parallel_state import init_distributed_environment,initialize_model_parallel
    from sglang.srt.runtime_context import get_parallel
    from sglang.srt.layers.moe.utils import initialize_moe_config
    assert torch.cuda.device_count()==1
    versions=dict(aiter=revision(aiter),sglang=revision(sglang_module))
    assert versions['aiter']['commit']==a.aiter_commit,versions
    assert versions['sglang']['commit']==a.sglang_commit,versions
    set_global_server_args_for_scheduler(ServerArgs(model_path=str(a.model),tp_size=8,ep_size=1,
        dtype='bfloat16',quantization='quark',moe_a2a_backend='none'))
    initialize_moe_config()
    init_distributed_environment(world_size=1,rank=0,local_rank=0,
        distributed_init_method='file://'+str(a.output/f'rendezvous-{os.getpid()}'),backend='nccl')
    initialize_model_parallel(tensor_model_parallel_size=1,expert_model_parallel_size=1,enable_symm_mem=False)
    parallel=get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0,
                                     tp_size=8,moe_tp_size=8,moe_ep_size=1)
    parallel.__enter__();rows=[]
    try:
        for request_batch in a.request_batches:
            b=request_batch*4;source=a.capture/f'c{request_batch}-d4-s355052'
            data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
            meta=json.loads((source/'capture.json').read_text())
            layer_rows=[]
            for lid in a.layers:
                payload=torch.load(a.capture/'weights'/f'layer-{lid}.pt',weights_only=True)
                layer=Layer(payload,lid)
                # Layer indices in the capture follow the full 30-layer metadata.
                x=data['input'][0,meta['layers'].index(lid),:b]
                logits=layer.gate(x);observed=[];original=layer.fm.get_2stage_cfgs
                def observe(*args,**kwargs):
                    cfg=original(*args,**kwargs);observed.append(cfg);return cfg
                layer.fm.get_2stage_cfgs=observe
                try:
                    layer.from_logits(x,logits,'aiter');torch.cuda.synchronize()
                    signature,_,graph=capture_dispatch(lambda:layer.from_logits(x,layer.gate(x),'aiter'))
                finally:layer.fm.get_2stage_cfgs=original
                assert observed
                layer_rows.append(dict(layer=lid,config=metadata(observed[-1]),
                    dispatch_digest=digest(signature),dispatch=signature))
                del graph,layer
            rows.append(dict(request_batch=request_batch,moe_rows=b,layers=layer_rows))
            print(json.dumps(dict(request_batch=request_batch,moe_rows=b,
                kernels=[(r['config']['stage1']['keywords'].get('kernelName'),
                          r['config']['stage2']['keywords'].get('kernelName')) for r in layer_rows])),flush=True)
            del data;torch.cuda.empty_cache()
        save(a.output/'dispatch.json',dict(job=os.environ['SLURM_JOB_ID'],versions=versions,rows=rows))
    finally:
        parallel.__exit__(None,None,None);torch.distributed.destroy_process_group()


if __name__=='__main__':main()
