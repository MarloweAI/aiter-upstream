"""CPU-only failed-output coordinates; run on an owned compute allocation."""

import argparse
import json
from pathlib import Path


def main():
    import torch

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--failure", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = torch.load(args.failure, map_location="cpu", weights_only=True)
    expected, actual = data["expected"].double(), data["actual"].double()
    error = (actual - expected).abs()
    tolerance = 0.02 + expected.abs() * 0.02
    coordinates = torch.nonzero(error > tolerance).tolist()
    receipt = {
        "source": str(args.failure),
        "policy": {"rtol": 0.02, "atol": 0.02},
        "total_elements": actual.numel(),
        "failed_elements": [
            {
                "coordinate": coord,
                "actual": actual[tuple(coord)].item(),
                "expected": expected[tuple(coord)].item(),
                "absolute_error": error[tuple(coord)].item(),
                "tolerance": tolerance[tuple(coord)].item(),
                "expert_ids": data["ids"][coord[0]].tolist(),
                "route_weights": data["weights"][coord[0]].tolist(),
            }
            for coord in coordinates
        ],
    }
    args.output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)


if __name__ == "__main__":
    main()
