"""Replay the interfaces and configuration observed in the target SGLang worker.

No kernel-name map or duplicated AITER picker lives here. The eight-GPU audit
exports the effective objects' configuration; graph-operation parity gates use.
"""
import dataclasses
from enum import Enum
import importlib
import inspect
import types
import torch
from .backend import Layer as LegacyLayer


def encode(value):
    if isinstance(value,Enum):return {'enum':type(value).__module__+':'+type(value).__qualname__,'name':value.name}
    if isinstance(value,torch.dtype):return {'dtype':str(value).removeprefix('torch.')}
    if value is None or isinstance(value,(str,int,float,bool)):return value
    if isinstance(value,(list,tuple)):return [encode(v) for v in value]
    if isinstance(value,dict):return {k:encode(v) for k,v in value.items()}
    raise TypeError(f'Unsupported SGLang configuration value: {type(value)}')


def decode(value):
    if isinstance(value,list):return [decode(v) for v in value]
    if isinstance(value,dict):
        if 'dtype' in value:return getattr(torch,value['dtype'])
        if 'enum' in value:
            module,name=value['enum'].split(':')
            if not module.startswith(('sglang.','aiter.')):raise ValueError('Unexpected enum namespace')
            cls=importlib.import_module(module)
            for part in name.split('.'):cls=getattr(cls,part)
            return cls[value['name']]
        return {k:decode(v) for k,v in value.items()}
    return value


def config_fields(obj, exclude=()):
    return {f.name:encode(getattr(obj,f.name)) for f in dataclasses.fields(obj)
            if f.init and f.name not in exclude}


class SGLangLayer(LegacyLayer):
    def __init__(self,payload,layer_id,spec,*,implementation="port_ew"):
        super().__init__(payload,layer_id,implementation=implementation)
        from sglang.srt.layers.moe.topk import TopK
        from sglang.srt.layers.moe.moe_runner.base import MoeRunnerConfig
        from sglang.srt.layers.moe.moe_runner.runner import MoeRunner
        from sglang.srt.layers.moe.moe_runner.aiter import AiterMoeQuantInfo
        from sglang.srt.layers.moe.token_dispatcher.standard import StandardDispatcher
        from sglang.srt.runtime_context import get_parallel
        if spec['scheme']!='QuarkW4A4MXFp4MoE' or spec['runner_backend']['name']!='AITER':
            raise ValueError('Target SGLang did not select the supported MXFP4/AITER runner')
        self.spec=spec
        params=decode(spec['topk']);params.pop('torch_native',None)
        params['correction_bias']=self.bias;params['layer_id']=layer_id
        params['is_fp4_experts']=spec['is_fp4_experts']
        unknown=set(params)-set(inspect.signature(TopK).parameters)
        if unknown:raise ValueError(f'TopK API changed: unsupported fields {unknown}')
        with get_parallel().override(moe_ep_rank=0,moe_tp_rank=0,tp_rank=0):
            self.topk=TopK(**params)
            routed=dict(params,top_k=8,num_fused_shared_experts=0,fused_shared_experts_scaling_factor=None)
            self.routed_topk=TopK(**routed)
            self.runner_config=MoeRunnerConfig(**decode(spec['runner_config']))
            self.dispatcher=StandardDispatcher(self.runner_config)
            self.runner=MoeRunner(decode(spec['runner_backend']),self.runner_config)
        q=decode(spec['quant_info'])
        mapping={'w13_weight':'w1','w2_weight':'w2','w13_scale':'w1_scale','w2_scale':'w2_scale'}
        q.update({field:self.weights[key] for field,key in mapping.items()})
        self.quant_info=AiterMoeQuantInfo(**q)
        if self.gate.tiny_router_gemm_max_tokens!=spec['tiny_router_gemm_max_tokens']:
            self.gate.tiny_router_gemm_max_tokens=spec['tiny_router_gemm_max_tokens']

    def routes(self,x,logits):
        selected=self.routed_topk(x,logits)
        return selected.topk_weights,selected.topk_ids

    def from_logits(self,x,logits,variant):
        if variant=='port_ew':return super().from_logits(x,logits,variant)
        if variant!='aiter':raise ValueError(variant)
        topk=self.topk(x,logits)
        dispatched=self.dispatcher.dispatch(x,topk)
        combined=self.runner.run(dispatched,self.quant_info)
        out=self.dispatcher.combine(combined)
        self.last_logits,self.last_ids,self.last_weights=logits,topk.topk_ids,topk.topk_weights
        return out

    def expert_routed(self,x,ids,weights,variant):
        if variant=='port_ew':return super().expert_routed(x,ids,weights,variant)
        from sglang.srt.layers.moe.topk import StandardTopKOutput
        selected=StandardTopKOutput(topk_weights=weights,topk_ids=ids,router_logits=None)
        return self.dispatcher.combine(self.runner.run(self.dispatcher.dispatch(x,selected),self.quant_info))
