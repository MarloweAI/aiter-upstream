"""Run numbered experiment commands in one existing Slurm allocation."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path(os.environ['CHUNK_ROOT'])
deadline = time.monotonic() + 2.8 * 3600
print('READY', os.environ.get('SLURM_JOB_ID'), flush=True)
while time.monotonic() < deadline and not (root / 'STOP').exists():
    for command in sorted((root / 'commands').glob('*.sh')):
        if command.with_suffix('.done').exists():
            continue
        with command.with_suffix('.log').open('w') as log:
            process = subprocess.Popen(['bash', str(command)], stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait(timeout=1800)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                code = 124
        command.with_suffix('.done').write_text(json.dumps({'returncode': code}))
    time.sleep(1)
