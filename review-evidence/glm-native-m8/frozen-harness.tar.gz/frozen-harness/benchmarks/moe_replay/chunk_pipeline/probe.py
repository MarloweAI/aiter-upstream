"""Independent reference and changing-route CUDA-graph checks before timing."""
from dataclasses import asdict
import json,os
from pathlib import Path
import torch
from marlowe_kernels import MoEConfig,MoEWeights,create_moe
from benchmarks.moe_replay.reference import expert_reference,compare
from .program import Program,Config

ROOT=Path(os.environ['CHUNK_ROOT'])
CAPTURE=Path('/workspace/home/mishas/results/marlowe-kernels/moe-replay-20260918/capture-v2')

def main():
    torch.set_num_threads(4);torch.set_grad_enabled(False);torch.backends.cuda.matmul.allow_tf32=False
    print('DEVICE',torch.cuda.get_device_properties(0),'TORCH',torch.__version__,'HIP',torch.version.hip,flush=True)
    q=torch.load(CAPTURE/'weights/layer-77.pt',map_location='cuda',weights_only=True)
    weights={k:q[k] for k in ('w1','w2','w1_scale','w2_scale')}
    owner=create_moe(MoEConfig(),MoEWeights(*weights.values()),implementation='native_fp4')
    data=torch.load(CAPTURE/'b32-s355052/tensors.pt',map_location='cuda',weights_only=True)
    cases=[]
    gen=torch.Generator(device='cuda');gen.manual_seed(355052)
    for n,step in enumerate((0,7,8,15)):
        x=data['input'][step,-1];logits=data['logits'][step,-1].bfloat16();ids=data['ids'][step,-1,:,:8].contiguous();rw=data['routing_weights'][step,-1,:,:8].contiguous()
        cases.append((f'captured-{step}',x,logits,ids,rw))
    for kind in ('dense','balanced','random'):
        x=data['input'][1,-1];logits=data['logits'][1,-1].bfloat16()
        if kind=='dense':ids=torch.arange(8,device='cuda').expand(32,-1).contiguous().int()
        elif kind=='balanced':ids=torch.arange(256,device='cuda').view(32,8).int()
        else:ids=torch.rand((32,256),device='cuda',generator=gen).topk(8).indices.int()
        rw=torch.rand((32,8),device='cuda',generator=gen);rw=rw/rw.sum(1,keepdim=True)*2.5
        cases.append((kind,x,logits,ids,rw))
    references=[]
    for _,x,_,ids,rw in cases:
        i9=torch.cat((ids,torch.full((32,1),256,device='cuda',dtype=torch.int32)),1)
        w9=torch.cat((rw,torch.ones((32,1),device='cuda')),1)
        references.append(expert_reference(weights,x,i9,w9,True))
    configs=json.loads(os.environ.get('CHUNK_CONFIGS','[{"local":false,"runtime_policy":true},{"local":true},{"local":true,"early_limit":4}]'))
    records=[];output=ROOT/os.environ.get('CHUNK_PROBE','probe.json')
    for cfg in configs:
        print('BUILD',cfg,flush=True);p=Program(owner,32,Config(**cfg));rows=[]
        for (name,x,l,ids,rw),ref in zip(cases,references):
            out=p.run(x,l,q['bias'].bfloat16(),supplied_ids=ids,supplied_weights=rw).clone();torch.cuda.synchronize()
            check=compare(out,ref);state=p.validation();rows.append(dict(case=name,check=check,state=state))
            print('EAGER',name,check,state,flush=True)
            if not check['passed'] or not state['passed']:
                torch.save(dict(input=x,ids=ids,rw=rw,output=out,reference=ref,state=p.schedule),ROOT/f'failure-{p.info["key"]}-{name}.pt')
                break
        record=dict(config=asdict(p.pc),info=p.info,eager=rows)
        if len(rows)==len(cases) and all(r['check']['passed'] and r['state']['passed'] for r in rows):
            graph=torch.cuda.CUDAGraph();outputs=[]
            with torch.cuda.graph(graph):
                for _,x,l,ids,rw in cases:outputs.append(p.run(x,l,q['bias'].bfloat16(),supplied_ids=ids,supplied_weights=rw).clone())
            for _ in range(20):graph.replay()
            torch.cuda.synchronize();record['graph']=[compare(y,r) for y,r in zip(outputs,references)];record['state']=p.validation()
            print('GRAPH',record['graph'],record['state'],flush=True)
        records.append(record);output.write_text(json.dumps(records,indent=2))
    assert all(len(r['eager'])==len(cases) and all(c['check']['passed'] and c['state']['passed'] for c in r['eager']) and
               all(c['passed'] for c in r.get('graph',[])) and r.get('state',{}).get('passed') for r in records)

if __name__=='__main__':main()
