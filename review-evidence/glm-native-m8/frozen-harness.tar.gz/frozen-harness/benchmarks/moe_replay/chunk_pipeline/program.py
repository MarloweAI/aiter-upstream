"""Prepared B32 persistent worker pipeline, using the current fused preparation."""
import ctypes
import torch
from marlowe_kernels._runtime import jit
from marlowe_kernels._kernels.amd.glm52_moe.coalesced_program import CoalescedProgram,CoalescedConfig
from marlowe_kernels._kernels.amd.glm52_moe.selected_program import SELECTED_CONFIGS
from .build import Config,build

ROOT_WORDS=256
DOMAIN_COUNT=16
META_WORDS=16

class Stage(ctypes.Structure):
    _fields_=[(n,ctypes.c_void_p) for n in ('x','xs','w','ws','y','ys','ids','rw','expert','valid')]+[('batch',ctypes.c_int),('padding',ctypes.c_uint)]
class Down(ctypes.Structure):
    _fields_=[('stage',Stage)]+[(n,ctypes.c_void_p) for n in ('ready','error','trace','dispatch')]
class Bank(ctypes.Structure):
    _fields_=[('gate',Stage),('down',Down)]
class Args(ctypes.Structure):
    _fields_=[('bank',Bank*2)]+[(n,ctypes.c_void_p) for n in ('dispatch','schedule','trace')]+[('max_tiles',ctypes.c_uint),('local',ctypes.c_uint)]
assert ctypes.sizeof(Stage)==88 and ctypes.sizeof(Bank)==208 and Args.schedule.offset==424


@jit()
def chunk_prepare(J,L:'void*',C:'void*',X:'void*',IDS:'void*',W:'void*',Q:'void*',S:'void*',QDQ:'void*',O:'void*',SI:'void*',SW:'void*',
            STATE:'void*',SORT:'void*',RW:'void*',EXP:'void*',SCHED:'void*',B,MAXIMUM,WORDS,SUPPLIED):
    from marlowe_kernels._kernels.amd.glm52_moe.fused_dispatch import dispatch_prepare
    dispatch_prepare.gen_func(J,L,C,X,IDS,W,Q,S,QDQ,O,SI,SW,STATE,SORT,RW,EXP,0,B,False,MAXIMUM,False,True,SUPPLIED)
    base=J.gpr('su32',J.blockIdx.x[0]*384)
    index=J.gpr(base[0]+J.threadIdx.x[0]);zero=J.gpr('vu32',0)
    for offset in range(0,WORDS,B*384):
        with J.ExecMask(index[0]+offset<WORDS,early_skip=False):
            J.global_store_dword((index[0]+offset)*4,zero,SCHED,mod='sc1')


class Program(CoalescedProgram):
    def __init__(self,owner,batch,config=Config()):
        assert batch==32
        self.pc=config
        super().__init__(owner,batch,CoalescedConfig(**SELECTED_CONFIGS[32]['config']))
        self.max_tiles=self.p['experts'].numel()
        words=ROOT_WORDS+DOMAIN_COUNT*self.max_tiles+META_WORDS*self.max_tiles
        self.schedule=torch.empty(words,device=owner.device,dtype=torch.int32)
        self.trace=torch.empty((self.max_tiles,104,12),device=owner.device,dtype=torch.int64) if config.profile else None
        self.lib,info=build(batch,self.maximum,config);self.info=dict(info)
        self.workers=owner._cu_count*min(config.workers_per_cu,self.info['blocks_per_cu'])
        self.lib.run.argtypes=[Args,ctypes.c_uint,ctypes.c_void_p];self.lib.run.restype=ctypes.c_int
        self.info.update(workers=self.workers,max_tiles=self.max_tiles,state_words=words)

    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        p,b=self.p,self.b;output=p['output'] if out is None else out
        if self.trace is not None:self.trace.zero_()
        chunk_prepare([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
                p['packed'].data_ptr(),p['workspace'].data_ptr(),p['qdq'].data_ptr(),output.data_ptr(),
                0 if supplied_ids is None else supplied_ids.data_ptr(),0 if supplied_weights is None else supplied_weights.data_ptr(),
                self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.schedule.data_ptr(),
                b,self.maximum,self.schedule.numel(),supplied_ids is not None)
        banks=[];trace=self.trace.data_ptr() if self.trace is not None else 0
        for bank in range(2):
            ids=p['sorted_ids'].data_ptr()+bank*self.maximum*4;rw=p['sorted_weights'].data_ptr()+bank*self.maximum*4
            valid=self.state.data_ptr()+8+bank*4
            g=Stage(p['packed'].data_ptr(),p['workspace'].data_ptr()+256,self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),
                    self.mid.data_ptr(),self.mid_scale.data_ptr(),ids,rw,p['experts'].data_ptr(),valid,b,0)
            d=Stage(self.mid.data_ptr(),self.mid_scale.data_ptr(),self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),
                    output.data_ptr(),self.mid_scale.data_ptr(),ids,rw,p['experts'].data_ptr(),valid,b,0)
            ready=self.schedule.data_ptr()+(ROOT_WORDS+DOMAIN_COUNT*self.max_tiles+2)*4
            banks.append(Bank(g,Down(d,ready,self.schedule.data_ptr()+8,trace,self.state.data_ptr())))
        args=Args((Bank*2)(*banks),self.state.data_ptr(),self.schedule.data_ptr(),trace,self.max_tiles,self.pc.local)
        rc=self.lib.run(args,self.workers,torch.cuda.current_stream().cuda_stream)
        if rc:raise RuntimeError(('persistent launch',rc))
        return output

    def validation(self):
        state=self.schedule.cpu();dispatch=self.state.cpu();tiles=int(state[0])
        meta=state[ROOT_WORDS+DOMAIN_COUNT*self.max_tiles:].view(-1,META_WORDS)[:tiles]
        passed=int(state[2])==0 and int(state[1])==tiles
        passed &= bool((meta[:,1]>=8).all() and (meta[:,2]==255).all() and (meta[:,3]>=96).all() and (meta[:,4]==96).all())
        passed &= not bool(state[32:48].any()) and int(dispatch[-1])==0 and not bool(dispatch[4:-1].any())
        return dict(passed=passed,error=int(state[2]),claimed_tiles=tiles,completed_tiles=int(state[1]),
                    workers_by_domain=state[16:32].tolist(),tiles_by_domain=state[48:64].tolist(),
                    early_active=state[32:48].tolist(),dispatch_error=int(dispatch[-1]))
