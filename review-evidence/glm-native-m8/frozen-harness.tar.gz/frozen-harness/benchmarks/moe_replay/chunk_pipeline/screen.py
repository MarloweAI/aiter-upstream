"""Paired B32 screen with all 30 weight sets and untimed graph input preloads."""
from dataclasses import asdict
import gc,json,os,statistics
from pathlib import Path
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.selected_program import create_selected_program
from benchmarks.moe_replay.native_fp4.tune import ScreenLayer
from benchmarks.moe_replay.protocol import cases,load_metadata
from benchmarks.moe_replay.run import prepare_graph,timings
from benchmarks.moe_replay.reference import expert_reference,compare
from .program import Program,Config
from .probe import ROOT,CAPTURE

def main():
    torch.set_num_threads(4);torch.set_grad_enabled(False);torch.backends.cuda.matmul.allow_tf32=False
    cfgs=json.loads(os.environ.get('CHUNK_CONFIGS','[{"local":false,"runtime_policy":true},{"local":true},{"local":true,"early_limit":4}]'))
    output=ROOT/os.environ.get('CHUNK_SCREEN','screen.json')
    meta=load_metadata(CAPTURE/'b32-s355052');validation_sequence=list(cases(meta))
    meta['steps']=meta['steps'][:int(os.environ.get('CHUNK_STEPS','2'))];sequence=list(cases(meta))
    data=torch.load(CAPTURE/'b32-s355052/tensors.pt',map_location='cuda',weights_only=True)
    owners={};payloads={};logits={};controls={}
    for j,lid in enumerate(meta['layers']):
        p=torch.load(CAPTURE/f'weights/layer-{lid}.pt',map_location='cuda',weights_only=True);payloads[lid]=p
        owners[lid]=create_moe(MoEConfig(),MoEWeights(*(p[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
        logits[lid]={data['input'][s,j].data_ptr():data['logits'][s,j].bfloat16().contiguous() for s in range(data['input'].shape[0])}
        controls[lid]=ScreenLayer(owners[lid],create_selected_program(owners[lid],32),logits[lid],p['bias'].bfloat16())
        controls[lid](data['input'][0,j],'current')
    counter_mode=bool(os.environ.get('CHUNK_COUNTERS'))
    torch.cuda.synchronize();base=prepare_graph(sequence,controls,data,'current',True,not counter_mode)
    selected=[sequence[0],sequence[len(meta['layers'])//2]]+[c for c in validation_sequence if c['layer']==meta['layers'][-1]]
    refs={}
    for c in selected:
        lid,slot,j=c['layer'],c['slot'],c['layer_index'];x=data['input'][slot,j];ids=data['ids'][slot,j];rw=data['routing_weights'][slot,j]
        refs[(slot,lid)]=expert_reference({k:payloads[lid][k] for k in ('w1','w2','w1_scale','w2_scale')},x,ids,rw,True)
    records=[]
    for raw in cfgs:
        cfg=Config(**raw);print('CANDIDATE',asdict(cfg),flush=True)
        layers={lid:ScreenLayer(owners[lid],Program(owners[lid],32,cfg),logits[lid],payloads[lid]['bias'].bfloat16()) for lid in meta['layers']}
        checks=[]
        for c in selected:
            lid,slot,j=c['layer'],c['slot'],c['layer_index'];x=data['input'][slot,j];p=layers[lid].program
            out=p.run(x,logits[lid][x.data_ptr()],payloads[lid]['bias'].bfloat16(),supplied_ids=data['ids'][slot,j,:,:8].contiguous(),supplied_weights=data['routing_weights'][slot,j,:,:8].contiguous()).clone()
            check=compare(out,refs[(slot,lid)]);state=p.validation();checks.append(dict(case=c,check=check,state=state))
            if not check['passed'] or not state['passed']:break
        row=dict(config=asdict(cfg),checks=checks,info=layers[meta['layers'][0]].program.info)
        row['passed']=len(checks)==len(selected) and all(c['check']['passed'] and c['state']['passed'] for c in checks)
        if row['passed']:
            for j,lid in enumerate(meta['layers']):layers[lid](data['input'][0,j],'candidate')
            torch.cuda.synchronize();graph=prepare_graph(sequence,layers,data,'candidate',True,not counter_mode)
            if counter_mode:
                import ctypes
                roctx=ctypes.CDLL('/opt/rocm/lib/librocprofiler-sdk-roctx.so')
                roctx.roctxRangePushA.argtypes=[ctypes.c_char_p]
                for name,g in [('current',base),('candidate',graph)]:
                    for _ in range(3):g['graph'].replay()
                    torch.cuda.synchronize()
                    for rep in range(3):
                        roctx.roctxRangePushA(f'chunk_{len(records)}_{name}_{rep}'.encode())
                        g['graph'].replay();torch.cuda.synchronize();roctx.roctxRangePop()
                row['counter_ranges']=f'chunk_{len(records)}_*'
                result={}
            else:result=timings({'current':base,'candidate':graph},int(os.environ.get('CHUNK_SAMPLES','16')),5)
            states={str(lid):layer.program.validation() for lid,layer in layers.items()}
            row.update(timing=result,us={k:statistics.mean(v['interval_medians_us']) for k,v in result.items()},post_states=states)
            row['passed'] &= all(s['passed'] for s in states.values());del graph
        records.append(row);output.write_text(json.dumps(records,indent=2))
        print(json.dumps({k:v for k,v in row.items() if k not in ('timing','checks','post_states')}),flush=True)
        del layers;gc.collect();torch.cuda.empty_cache()

if __name__=='__main__':main()
