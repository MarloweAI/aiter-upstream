"""Separate G1 correctness from G2 and routing-bank cleanup."""
import json
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.selected_program import create_selected_program
from .program import Program,Config
from .probe import ROOT,CAPTURE

def main():
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    q=torch.load(CAPTURE/'weights/layer-77.pt',map_location='cuda',weights_only=True)
    owner=create_moe(MoEConfig(),MoEWeights(*(q[k] for k in ('w1','w2','w1_scale','w2_scale'))),implementation='native_fp4')
    d=torch.load(CAPTURE/'b32-s355052/tensors.pt',map_location='cuda',weights_only=True)
    x=d['input'][0,-1];l=d['logits'][0,-1].bfloat16();ids=d['ids'][0,-1,:,:8].contiguous();rw=d['routing_weights'][0,-1,:,:8].contiguous();bias=q['bias'].bfloat16()
    control=create_selected_program(owner,32);control.run(x,l,bias,supplied_ids=ids,supplied_weights=rw);torch.cuda.synchronize()
    rows=[]
    for local in (False,True):
        for initialized in (False,True):
            p=Program(owner,32,Config(local=local,stop_after_g1=True,profile=True))
            if initialized:p.mid.zero_();p.mid_scale.zero_()
            torch.cuda.synchronize();p.run(x,l,bias,supplied_ids=ids,supplied_weights=rw);torch.cuda.synchronize()
            diff=(p.mid!=control.mid);ds=(p.mid_scale!=control.mid_scale)
            rows.append(dict(local=local,initialized=initialized,mid_different=int(diff.sum()),scale_different=int(ds.sum()),
                             diffs_by_chunk=diff.reshape(32,9,8,16).sum((0,1,3)).cpu().tolist(),
                             scale_diff_by_chunk=ds.sum((0,1)).cpu().tolist(),state=p.schedule[:64].cpu().tolist(),info=p.info))
            print(json.dumps(rows[-1]),flush=True)
            torch.save(dict(mid=p.mid,control=control.mid,scales=p.mid_scale,control_scales=control.mid_scale,trace=p.trace,state=p.schedule,ids=p.p['ids']),ROOT/f'gate-diagnostic-{local}-{initialized}.pt')
    (ROOT/'gate-diagnostic.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':main()
