"""Prove that an inactive emitter option did not change qualified GPU bodies."""
import hashlib,json,os,re
from pathlib import Path
from .build import build,Config

def canonical_cpp(source):
    # PyHIP's process-global BB numbers and source locations are comments.
    # Its generated labels can change numbering with the emitter filename.
    # Keep every instruction, register, operand, constraint and C++ statement;
    # rename labels solely by their definition order, including all references.
    lines=[]
    for line in source.decode().splitlines():
        if line.startswith('"') and line.endswith('"'):
            value=json.loads(line).split(';',1)[0].strip()
            lines.append(json.dumps(value))
        else:lines.append(line)
    result='\n'.join(lines)
    names=re.findall(r'([gd]_label_\d+_%=):',result)
    assert len(names)==len(set(names))
    mapping={name:f'canonical_label_{i}' for i,name in enumerate(names)}
    return re.sub(r'[gd]_label_\d+_%=',lambda m:mapping[m[0]],result)

def main():
    root=Path(os.environ['CHUNK_ROOT'])
    replay=json.loads((root/'qualified/b32.json').read_text())
    original=replay['state_checks'][0]['builds']
    selected=json.loads((root/'selected.json').read_text());rows=[]
    for name,config in selected.items():
        _,current=build(32,4391,Config(**config))
        old=Path(original[name]['library']).with_name('worker.cpp').read_bytes()
        new=Path(current['library']).with_name('worker.cpp').read_bytes()
        row=dict(variant=name,old_key=original[name]['key'],new_key=current['key'],
                 identical_cpp=old==new,cpp_sha256=hashlib.sha256(new).hexdigest(),
                 canonical_cpp_equal=canonical_cpp(old)==canonical_cpp(new),
                 canonical_cpp_sha256=hashlib.sha256(canonical_cpp(new).encode()).hexdigest(),
                 same_gate=original[name]['gate_asm_sha256']==current['gate_asm_sha256'],
                 same_down=original[name]['down_asm_sha256']==current['down_asm_sha256'],
                 same_compiler=original[name]['compiler']==current['compiler'])
        rows.append(row);print(json.dumps(row),flush=True)
    (root/'selected-code-proof-canonical.json').write_text(json.dumps(rows,indent=2))
    assert all(r['canonical_cpp_equal'] and r['same_compiler'] for r in rows)

if __name__=='__main__':main()
