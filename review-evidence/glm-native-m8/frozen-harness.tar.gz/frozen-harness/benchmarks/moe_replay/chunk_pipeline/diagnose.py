"""Preserve and localize the global-control failure; this is not qualification."""
import json
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from marlowe_kernels._kernels.amd.glm52_moe.selected_program import create_selected_program
from benchmarks.moe_replay.reference import compare,expert_reference
from .program import Program,Config,ROOT_WORDS,DOMAIN_COUNT,META_WORDS
from .probe import ROOT,CAPTURE

def main():
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    q=torch.load(CAPTURE/'weights/layer-77.pt',map_location='cuda',weights_only=True)
    w={k:q[k] for k in ('w1','w2','w1_scale','w2_scale')}
    owner=create_moe(MoEConfig(),MoEWeights(*w.values()),implementation='native_fp4')
    d=torch.load(CAPTURE/'b32-s355052/tensors.pt',map_location='cuda',weights_only=True)
    x=d['input'][0,-1];l=d['logits'][0,-1].bfloat16();ids=d['ids'][0,-1,:,:8].contiguous();rw=d['routing_weights'][0,-1,:,:8].contiguous();bias=q['bias'].bfloat16()
    control=create_selected_program(owner,32);y=control.run(x,l,bias,supplied_ids=ids,supplied_weights=rw).clone()
    ref=expert_reference(w,x,control.p['ids'],control.p['weights'],True)
    rows=[]
    for workers in (1,2):
        p=Program(owner,32,Config(local=False,workers_per_cu=workers));torch.cuda.synchronize()
        for rep in range(3):
            out=p.run(x,l,bias,supplied_ids=ids,supplied_weights=rw).clone();torch.cuda.synchronize()
            state=p.schedule.cpu();dispatch=p.state.cpu();tiles=int(state[0]);meta=state[ROOT_WORDS+DOMAIN_COUNT*p.max_tiles:].view(-1,META_WORDS)[:tiles]
            result=dict(workers=workers,rep=rep,check=compare(out,ref),state=p.validation(),
                        mid_different=int((p.mid!=control.mid).sum()),scale_different=int((p.mid_scale!=control.mid_scale).sum()),
                        bad_next_g1=meta[:,1].unique().tolist(),bad_masks=meta[:,2].unique().tolist(),
                        bad_next_g2=meta[:,3].unique().tolist(),bad_done=meta[:,4].unique().tolist(),
                        dispatch_nonzero=int((dispatch[4:-1]!=0).sum()))
            rows.append(result);print(json.dumps(result),flush=True)
            torch.save(dict(output=out,reference=ref,mid=p.mid,mid_control=control.mid,scale=p.mid_scale,scale_control=control.mid_scale,state=state,dispatch=dispatch),ROOT/f'diagnostic-global-w{workers}-r{rep}.pt')
    (ROOT/'diagnostic-global.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':main()
