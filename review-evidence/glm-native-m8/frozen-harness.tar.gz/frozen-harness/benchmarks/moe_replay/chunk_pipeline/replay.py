"""Full router-inclusive paired qualification using the existing native audit."""
import hashlib,json,os
from pathlib import Path
from marlowe_kernels import create_moe
from benchmarks.moe_replay.native_fp4 import replay as base
from benchmarks.moe_replay import run
from benchmarks.moe_replay.persistent_fp4.provenance import validate_source
from .program import Program,Config

ROOT=Path(os.environ['CHUNK_ROOT'])
CHOICE=json.loads((ROOT/os.environ.get('CHUNK_CHOICE','selected.json')).read_text())
CHOICES=CHOICE if all(isinstance(v,dict) for v in CHOICE.values()) else {'pipeline':CHOICE}

class Layer(base.NativeLayer):
    def __init__(self,*args,**kw):
        super().__init__(*args,**kw)
        self.current=create_moe(self.port.config,self.port.weights)
        self.pipelines={name:create_moe(self.port.config,self.port.weights,implementation='native_fp4') for name in CHOICES}
    def warmup(self,b):
        super().warmup(b)
        for name,owner in self.pipelines.items():
            if b not in owner._programs:owner._programs[b]=Program(owner,b,Config(**CHOICES[name]))
        for owner in (self.current,*self.pipelines.values()):
            owner.warmup((b,),routing='internal');owner.warmup((b,),routing='supplied')
    def from_logits(self,x,logits,variant):
        if variant!='current' and variant not in self.pipelines:return super().from_logits(x,logits,variant)
        import torch
        owner=self.current if variant=='current' else self.pipelines[variant]
        if logits.dtype==torch.bfloat16:out=owner(x,logits,self.bias_by_dtype[logits.dtype])
        else:
            rw,ids=self.routes(x,logits);out=owner.forward_routed(x,ids,rw)
        self.last_logits=logits;self.last_ids,self.last_weights=owner.routing(len(x));return out
    def expert_routed(self,x,ids,rw,variant):
        if variant!='current' and variant not in self.pipelines:return super().expert_routed(x,ids,rw,variant)
        owner=self.current if variant=='current' else self.pipelines[variant]
        return owner.forward_routed(x,ids[:,:8].contiguous(),rw[:,:8].contiguous())

def main():
    paths=validate_source();original=run.main
    def paired(argv,**kw):
        argv=list(argv);argv[argv.index('--output')+1]=str(ROOT/os.environ.get('CHUNK_REPLAY','qualified'))
        kw['port_variants']=('current',*CHOICES)
        def validate(layer,b):
            states={name:owner._programs[b].validation() for name,owner in layer.pipelines.items()}
            return dict(layer=layer.layer_id,batch=b,passed=all(v['passed'] for v in states.values()),variants=states,
                        builds={name:owner._programs[b].info for name,owner in layer.pipelines.items()})
        kw['state_validator']=validate
        kw['runtime_identity'].update(choice=CHOICE,source_paths=paths,chunk_sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.iterdir() if p.suffix in ('.py','.hpp')})
        return original(argv,**kw)
    base.NativeLayer=Layer;run.main=paired;base.main()

if __name__=='__main__':main()
