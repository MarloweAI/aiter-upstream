"""GPU-buffered task timelines; profiling never supplies headline latency."""
import json,os,statistics
import torch
from marlowe_kernels import create_moe,MoEConfig,MoEWeights
from benchmarks.moe_replay.reference import compare,expert_reference
from .program import Program,Config
from .probe import ROOT,CAPTURE

def main():
    torch.set_grad_enabled(False);torch.set_num_threads(4)
    cases=torch.load(CAPTURE/'b32-s355052/tensors.pt',map_location='cuda',weights_only=True)
    cfgs=json.loads(os.environ.get('CHUNK_CONFIGS','[{"local":true,"cache_local":true},{"local":true,"cache_local":true,"early_limit":4}]'))
    records=[];out=ROOT/os.environ.get('CHUNK_PROFILE','task-profile.json')
    for raw in cfgs:
        for j,lid in [(0,3),(15,40),(29,77)]:
            q=torch.load(CAPTURE/f'weights/layer-{lid}.pt',map_location='cuda',weights_only=True)
            w={k:q[k] for k in ('w1','w2','w1_scale','w2_scale')};owner=create_moe(MoEConfig(),MoEWeights(*w.values()),implementation='native_fp4')
            p=Program(owner,32,Config(**dict(raw,profile=True)));x=cases['input'][0,j];l=cases['logits'][0,j].bfloat16()
            ids=cases['ids'][0,j,:,:8].contiguous();rw=cases['routing_weights'][0,j,:,:8].contiguous()
            for _ in range(2):p.run(x,l,q['bias'].bfloat16(),supplied_ids=ids,supplied_weights=rw)
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):y=p.run(x,l,q['bias'].bfloat16(),supplied_ids=ids,supplied_weights=rw)
            graph.replay();torch.cuda.synchronize()
            ref=expert_reference(w,x,p.p['ids'],p.p['weights'],True);check=compare(y,ref);state=p.validation()
            assert check['passed'] and state['passed'],(raw,lid,check,state)
            n=state['claimed_tiles'];t=p.trace[:n].cpu();p.lib.clock_rate.restype=__import__('ctypes').c_int;rate=p.lib.clock_rate();ticks_per_us=rate/1000
            assert rate>0
            g=t[:,:8];d=t[:,8:];assert bool((t[:,:,1]>=t[:,:,0]).all())
            owner_ids=g[:,0,10];prod_mismatch=int((g[:,:,2]!=owner_ids[:,None]).sum());remote=int((d[:,:,2]!=owner_ids[:,None]).sum())
            if p.pc.local:assert prod_mismatch==0
            if p.pc.local and not p.pc.steal:assert remote==0
            gap=(g[:,4:,1].max(1).values-g[:,:4,1].max(1).values).double()/ticks_per_us
            wait0=(d[:,:,7]-d[:,:,6]).double()/ticks_per_us;wait1=(d[:,:,9]-d[:,:,8]).double()/ticks_per_us
            # Completed first-step instruction issue precedes wait1_begin. A
            # positive overlap count verifies G2 issued work before all G1
            # producers for the same tile completed their matrix bodies.
            overlap=(d[:,:,8]<g[:,:,1].max(1).values[:,None]) & (d[:,:,5]==3)
            row=dict(config=raw,layer=lid,info=p.info,check=check,state=state,clock_khz=rate,
                     median_g1_us=float(((g[:,:,1]-g[:,:,0]).double()/ticks_per_us).median()),
                     median_g2_us=float(((d[:,:,1]-d[:,:,0]).double()/ticks_per_us).median()),
                     ready_gap_median_us=float(gap.median()),wait0_mean_us=float(wait0.mean()),wait1_mean_us=float(wait1.mean()),
                     early_tasks=int((d[:,:,5]==3).sum()),overlapping_tasks=int(overlap.sum()),
                     producer_xcd_mismatches=prod_mismatch,remote_consumers=remote)
            path=ROOT/f'trace-{p.info["key"]}-l{lid}.pt';torch.save(dict(trace=t,info=row,ids=p.p['ids'].cpu()),path)
            row['trace']=str(path);records.append(row);out.write_text(json.dumps(records,indent=2));print(json.dumps(row),flush=True)
            del graph,p,owner,q,w;torch.cuda.empty_cache()

if __name__=='__main__':main()
