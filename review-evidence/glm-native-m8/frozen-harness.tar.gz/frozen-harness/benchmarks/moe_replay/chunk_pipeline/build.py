"""Embed the current B32 Port-EW matrix bodies in a device task scheduler."""
import ctypes
from dataclasses import asdict, dataclass
from functools import lru_cache
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess

from marlowe_kernels._kernels.amd.glm52_moe.persistent import _artifact, _inline
from marlowe_kernels._kernels.amd.glm52_moe.native_prefetch import prefetch_projection
from marlowe_kernels._kernels.amd.glm52_moe import native_coalesced


@dataclass(frozen=True)
class Config:
    local: bool = True
    early_limit: int = 0
    producer_workers: int = 2
    workers_per_cu: int = 2
    steal: bool = False
    cache_local: bool = False
    profile: bool = False
    global_barrier: bool = False
    gate_depth: int = 6
    local_publish: bool = False
    stop_after_g1: bool = False
    fast_queue: bool = False
    cache_metadata: bool = False
    single_xcd: int = -1
    task_batch: int = 1
    runtime_policy: bool = False
    force_wave: bool = False
    skip_ready: bool = False
    pipeline_payloads: bool = False

    def __post_init__(self):
        assert self.early_limit >= 0 and self.producer_workers > 0
        assert self.workers_per_cu > 0
        assert not self.cache_local or self.local
        assert self.gate_depth in (1,2,3,4,6)
        assert not self.local_publish or (self.local and self.cache_local and not self.steal)
        assert not self.cache_metadata or self.local_publish
        assert self.task_batch in (1,2,4,8)
        assert not self.pipeline_payloads or self.skip_ready


def down_source():
    """Keep GEMM/epilogue expressions; gate only the intermediate loads."""
    source = Path(native_coalesced.__file__).read_text()
    source = source.replace('from .', 'from marlowe_kernels._kernels.amd.glm52_moe.')
    source = source.replace('def coalesced_projection(', 'def chunk_projection(', 1)
    old = "IDS:'void*', RW:'void*', EXP:'void*', VALID:'void*', B:'int'):"
    assert source.count(old) == 1
    source = source.replace(old, "IDS:'void*', RW:'void*', EXP:'void*', VALID:'void*', B:'int', READY:'void*', ERROR:'void*', TRACE:'void*', DSTATE:'void*', BATCH, MAXIMUM, CACHE_LOCAL, PROFILE, SKIP_READY, PIPELINE_PAYLOADS):")
    begin = source.index('    if PIPE:\n        pending=')
    end = source.index('    if FIRST and SK>1:', begin)
    source = source[:begin] + '''    assert not FIRST and K==256 and BN==64 and NW==1 and SK==1
    def timestamp(field):
        if PROFILE:
            ticks=J.gpr(2,'su32');J.s_memrealtime(ticks)
            J.s_waitcnt(mod='lgkmcnt(0)')
            words=J.gpr(2,'vu32')
            J.v_mov_b32(words[0],ticks[0]);J.v_mov_b32(words[1],ticks[1])
            with J.ExecMask(lane[0]==0,early_skip=False):
                offset=((J.blockIdx.y[0]*104+8+J.blockIdx.x[0])*12+field)*8
                scalar_offset=J.gpr('su32',offset)
                J.global_store_dwordx2(J.gpr('vu32',scalar_offset[0]),words,TRACE)

    def wait_chunk(mask,field):
        timestamp(field)
        if SKIP_READY and mask==15:
            timestamp(field+1)
            return
        tries=J.gpr('su32',0);value=J.gpr('vu32');ready=J.gpr('su32')
        with J.While() as loop:
            if SKIP_READY:J.Jump(loop['end'],(J.blockIdx.z[0]&2)==0)
            J.global_load_dword(value,J.gpr('vu32',J.blockIdx.y[0]*64),READY,mod='sc1')
            J.s_waitcnt(mod='vmcnt(0)');J.v_readfirstlane_b32(ready,value)
            J.Jump(loop['end'],(ready[0]&mask)==mask)
            tries[:]+=1
            J.Jump('chunk_timeout',tries[0]>=262144)
            J.s_sleep(1)
        timestamp(field+1)

    # Keep the original weight prefetch, but defer every activation/scale load
    # until that K128 chunk has been published. Accumulators stay live.
    def load_weights(slot,step):
        k=J.gpr('su32',step*128)
        for n in range(blocks):
            J.global_load_dwordx4(bvec[slot,n],qb_base[n][0]+(k[0]//128)*1024,W,mod="sc0 nt" if NT else "")
            J.global_load_ubyte(bscale[slot,n],sb_base[n][0]+(k[0]//256)*256+((k[0]//128)%2)*2,WS)

    def load_payload(slot,step):
        avec[slot]=0;ascale[slot]=127
        with J.ExecMask(token<B[0],early_skip=False):
            if CACHE_LOCAL:
                with J.If((J.blockIdx.z[0]&1)==0):
                    # NT at wave scope bypasses stale CU L1, while retaining
                    # eligibility for the owner's XCD L2 (CDNA4 ISA table49).
                    J.global_load_dwordx4(avec[slot],qa_base[0]+step*64,X,mod='nt')
                    J.global_load_ubyte(ascale[slot],sa_base[0]+step*4,XS,mod='nt')
                with J.If((J.blockIdx.z[0]&1)!=0):
                    J.global_load_dwordx4(avec[slot],qa_base[0]+step*64,X,mod='sc1')
                    J.global_load_ubyte(ascale[slot],sa_base[0]+step*4,XS,mod='sc1')
            else:
                J.global_load_dwordx4(avec[slot],qa_base[0]+step*64,X,mod='sc1')
                J.global_load_ubyte(ascale[slot],sa_base[0]+step*4,XS,mod='sc1')

    if PIPELINE_PAYLOADS:
        # Whole-ready consumers preserve the original 10-request prefetch
        # pipeline. Only early consumers defer the second payload's loads.
        with J.If((J.blockIdx.z[0]&2)==0):
            timestamp(6);timestamp(7)
            load_payload(0,0);load_weights(0,0)
            load_payload(1,1);load_weights(1,1)
            J.s_waitcnt(mod='vmcnt(10)');compute(0)
            timestamp(8);timestamp(9)
            J.s_waitcnt(mod='vmcnt(0)');compute(1)
        with J.If((J.blockIdx.z[0]&2)!=0):
            wait_chunk(15,6);load_payload(0,0);load_weights(0,0);load_weights(1,1)
            J.s_waitcnt(mod='vmcnt(8)');compute(0)
            wait_chunk(255,8);load_payload(1,1);J.s_waitcnt(mod='vmcnt(0)');compute(1)
    else:
        load_weights(0,0);load_weights(1,1)
        wait_chunk(15,6);load_payload(0,0);J.s_waitcnt(mod='vmcnt(0)');compute(0)
        wait_chunk(255,8);load_payload(1,1);J.s_waitcnt(mod='vmcnt(0)');compute(1)
''' + source[end:]
    source += '''
    from marlowe_kernels._kernels.amd.glm52_moe.fused_dispatch import clear_next
    clear_next(J,DSTATE,IDS,RW,BATCH,64,96,MAXIMUM)
    J.Jump('chunk_end')
    J.Label('chunk_timeout')
    with J.ExecMask(lane[0]==0,early_skip=False):
        J.global_atomic_or(J.gpr('vu32'),J.gpr('vu32',0),J.gpr('vu32',1),ERROR,mod='sc0')
    J.Label('chunk_end')
'''
    # native_projection advances IDS/RW internally. clear_next needs bank-zero
    # pointers, so put them aside before the native body starts.
    source = source.replace("    assert K%128==0", "    sort_base=J.gpr(2,'su32',align=2);J.s_mov_b64(sort_base,IDS)\n    rw_base=J.gpr(2,'su32',align=2);J.s_mov_b64(rw_base,RW)\n    assert K%128==0", 1)
    # Clear routing from the original double-buffer base, passed separately as
    # pointers in the original input bank; recover bank zero using snapshot.
    source = source.replace('    clear_next(J,DSTATE,IDS,RW,BATCH,64,96,MAXIMUM)', '''    bank=J.gpr('su32');J.s_load_dword(bank,DSTATE,4);J.s_waitcnt(mod='lgkmcnt(0)')
    offset=J.gpr('su32',bank[0]*(MAXIMUM*4))
    J.s_sub_u32(sort_base[0],sort_base[0],offset);J.s_subb_u32(sort_base[1],sort_base[1],0)
    J.s_sub_u32(rw_base[0],rw_base[0],offset);J.s_subb_u32(rw_base[1],rw_base[1],0)
    class CoherentMetadata:
        def __init__(self,parent):self.parent=parent
        def __getattr__(self,name):return getattr(self.parent,name)
        def global_store_dword(self,*args,**kw):
            kw['mod']='sc1';return self.parent.global_store_dword(*args,**kw)
    clear_next(CoherentMetadata(J),DSTATE,sort_base,rw_base,BATCH,64,96,MAXIMUM)''')
    return source


@lru_cache(maxsize=8)
def gate_body(batch,depth):
    args=([1,1,1],[64],6144,512,64,True,1,True,1,False,True,True,depth,*([0]*10),batch)
    return _artifact(prefetch_projection,args)


def inline_body(*args):
    # Low SGPRs include compiler-reserved kernel argument registers. Keep
    # hand-written bodies out of that ABI region; the compiler has s0..s47
    # for its scheduler and every matrix-body SGPR is declared clobbered.
    # The wrapper writes virtual launch registers even if the PyHIP body does
    # not reference that coordinate (e.g. z with SK1). Declare those writes as
    # clobbers too, otherwise C++ may keep a live scheduler value there.
    lines,registers,*rest=args
    registers=list(dict.fromkeys(list(registers)+['s0','s1','s2','s3','s4','v0']))
    body=_inline(lines,registers,*rest)
    body=re.sub(r'\bs\[(\d+):(\d+)\]',lambda m:f's[{int(m[1])+48}:{int(m[2])+48}]',body)
    body=re.sub(r'\bs(\d+)\b',lambda m:f's{int(m[1])+48}',body)
    return body


@lru_cache(maxsize=64)
def build(batch, maximum, config):
    assert batch == 32, 'Only B32 is qualified by this experiment'
    root = Path(os.environ['CHUNK_ROOT']) / 'build'
    root.mkdir(parents=True, exist_ok=True)
    emitter = down_source()
    emitter_id = hashlib.sha256(emitter.encode()).hexdigest()[:16]
    path = root / f'chunk_projection_{emitter_id}.py'
    if not path.exists():path.write_text(emitter)
    spec = importlib.util.spec_from_file_location(f'chunk_projection_{emitter_id}', path)
    module = importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    gate_args = ([1,1,1],[64],6144,512,64,True,1,True,1,False,True,True,6,*([0]*10),batch)
    down_args = ([1,1,1],[64],256,6144,64,False,1,True,1,False,True,True,2,'lds',*([0]*10),batch,
                 0,0,0,0,batch,maximum,config.cache_local,config.profile,config.skip_ready,config.pipeline_payloads)
    g_asm,g_regs = gate_body(batch,config.gate_depth)
    d_asm,d_regs = _artifact(module.chunk_projection, down_args)
    gate = inline_body(g_asm,g_regs,'g','ka','column','tile','0',not config.cache_local)
    # G2 emitter already applies the correct cache policy to payload and flags.
    down = inline_body(d_asm,d_regs,'d','ka + 88','column','tile','remote | (early << 1)',False)
    if config.force_wave:
        # Diagnostic for compiler divergence around the lane-zero scheduler.
        # Both embedded bodies are collective one-wave operations.
        gate=gate.replace('\\n"\n"s_mov_b64 s[48:49]', '\\n"\n"s_mov_b64 exec, -1\\n"\n"s_mov_b64 s[48:49]',1)
        down=down.replace('\\n"\n"s_mov_b64 s[48:49]', '\\n"\n"s_mov_b64 exec, -1\\n"\n"s_mov_b64 s[48:49]',1)
    template = Path(__file__).with_name('scheduler.hpp').read_text()
    source = template.replace('// GATE_BODY',gate).replace('// DOWN_BODY',down)
    values = dict(LOCAL=int(config.local),EARLY=config.early_limit,PRODUCERS=config.producer_workers,
                  STEAL=int(config.steal),PROFILE=int(config.profile),GLOBAL_BARRIER=int(config.global_barrier),
                  LOCAL_PUBLISH=int(config.local_publish))
    values['STOP_G1']=int(config.stop_after_g1)
    values['FAST_QUEUE']=int(config.fast_queue)
    values['CACHE_METADATA']=int(config.cache_metadata)
    values['SINGLE_XCD']=config.single_xcd
    values['TASK_BATCH']=config.task_batch
    values['RUNTIME_POLICY']=int(config.runtime_policy)
    for key,value in values.items():source=source.replace('@'+key+'@',str(value))
    compiler = subprocess.check_output(['/opt/rocm/bin/hipcc','--version'], text=True)
    key = hashlib.sha256((source+emitter+compiler+Path(__file__).read_text()).encode()).hexdigest()[:20]
    folder=root/key;folder.mkdir(exist_ok=True);cpp=folder/'worker.cpp';library=folder/'worker.so'
    cpp.write_text(source);(folder/'emitter.py').write_text(emitter)
    command=['/opt/rocm/bin/hipcc','-std=c++20','-O2','-ffp-contract=off','--offload-arch=gfx950',
             '-shared','-fPIC','-Rpass-analysis=kernel-resource-usage',str(cpp),'-o',str(library)]
    (folder/'command.json').write_text(json.dumps(command,indent=2))
    if not library.exists():
        with (folder/'build.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    lib=ctypes.CDLL(str(library));lib.occupancy.restype=ctypes.c_int
    occupancy=lib.occupancy();assert occupancy>0,occupancy
    lib.registers.restype=ctypes.c_int;lib.scratch.restype=ctypes.c_int
    info=dict(key=key,config=asdict(config),compiler=compiler,blocks_per_cu=occupancy,
              registers=lib.registers(),scratch_bytes=lib.scratch(),dynamic_lds=2048,
              gate_asm_sha256=hashlib.sha256(str(g_asm).encode()).hexdigest(),
              down_asm_sha256=hashlib.sha256(str(d_asm).encode()).hexdigest(),library=str(library))
    (folder/'identity.json').write_text(json.dumps(info,indent=2))
    return lib,info
