"""Compact evidence from the full replay; raw samples remain in the archive."""
import argparse,csv,hashlib,json,statistics
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8<<20),b''):h.update(block)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--archive-root',type=Path);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    source=a.root/'qualified/b32.json';r=json.loads(source.read_text())
    assert r['qualified'] and all(r['graph_checks'].values())
    sequence=r['sequence'];variants=r['identity']['variants'];timing=r['timing']
    current=statistics.mean(timing['current_preload_events']['interval_medians_us'])
    comparison=[];per_case=[]
    for variant in variants:
        row=timing[variant+'_preload_events'];latency=statistics.mean(row['interval_medians_us'])
        comparison.append(dict(variant=variant,mean_case_median_us=latency,
                               change_vs_current_pct=100*(current-latency)/current,
                               graph_us_per_case=row['graph_median_us']/len(sequence)))
        for case,value in zip(sequence,row['interval_medians_us']):
            per_case.append(dict(variant=variant,layer=case['layer'],step=case['decode_step'],us=value))
    summary=dict(batch=32,scope=r['scope'],qualified=r['qualified'],cases=len(sequence),
                 layers=len({c['layer'] for c in sequence}),steps=len({c['decode_step'] for c in sequence}),
                 dispatch_checks=len(r['dispatch_checks']),dispatch_passed=all(c['passed'] for c in r['dispatch_checks']),
                 graph_checks=r['graph_checks'],state_passed=all(c['passed'] for c in r['state_checks']),
                 samples=r['samples'],warmups=r['warmups'],comparison=comparison,
                 selected=r['identity']['runtime']['choice'],torch=r['torch'],hip=r['hip'],job=r['job'],
                 identity=r['identity'],archive_source=str((a.archive_root or a.root)/'qualified/b32.json'),archive_sha256=digest(source))
    (a.output/'summary.json').write_text(json.dumps(summary,indent=2))
    for name,rows in [('comparison.csv',comparison),('per-case.csv',per_case)]:
        with (a.output/name).open('w') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
    print(json.dumps({k:v for k,v in summary.items() if k not in ('identity','selected')},indent=2))

if __name__=='__main__':main()
