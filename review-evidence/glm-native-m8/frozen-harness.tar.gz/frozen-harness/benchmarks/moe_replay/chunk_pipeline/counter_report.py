"""Summarize ROI-scoped counters; profiler durations are never benchmark times."""
import csv,json,os
from collections import defaultdict
from pathlib import Path

def main():
    root=Path(os.environ['CHUNK_ROOT'])/os.environ.get('CHUNK_HARDWARE','hardware')
    report={}
    for folder in sorted(root.iterdir()):
        if not folder.is_dir():continue
        traces=list(folder.glob('*marker_api_trace.csv'))
        counters=list(folder.glob('*counter_collection.csv'))
        if len(traces)!=1 or len(counters)!=1:continue
        ranges=[]
        for r in csv.DictReader(traces[0].open()):
            if r['Function'].startswith('chunk_'):
                ranges.append((int(r['Start_Timestamp']),int(r['End_Timestamp']),r['Function'].rsplit('_',1)[0]))
        stats=defaultdict(lambda:defaultdict(float));dispatches=defaultdict(set)
        resources={}
        for r in csv.DictReader(counters[0].open()):
            begin,end=int(r['Start_Timestamp']),int(r['End_Timestamp'])
            name=next((name for lo,hi,name in ranges if lo<=begin and end<=hi),None)
            if name is None:continue
            kernel=r['Kernel_Name']
            stage=('worker' if 'chunk_worker' in kernel else 'prepare' if 'prepare' in kernel
                   else 'g1' if 'dispatched_native' in kernel else 'g2')
            key=name+'/'+stage
            stats[key][r['Counter_Name']]+=float(r['Counter_Value'])
            dispatches[key].add(r['Dispatch_Id'])
            resources[key]={k:int(r[k]) for k in ('VGPR_Count','SGPR_Count','Scratch_Size','LDS_Block_Size')}
        replay=json.loads((folder/'replay.json').read_text())
        result={}
        for key,values in stats.items():
            # Every range contains 30 layers x CHUNK_STEPS, repeated three times.
            count=30*int(os.environ.get('CHUNK_STEPS','2'))*3
            result[key]=dict(counters_per_moe={k:v/count for k,v in values.items()},
                             dispatches=len(dispatches[key]),expected_moe_calls=count,
                             profiler_resources=resources[key])
        report[folder.name]=dict(configs=[r['config'] for r in replay],stages=result)
    (root/'summary.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
