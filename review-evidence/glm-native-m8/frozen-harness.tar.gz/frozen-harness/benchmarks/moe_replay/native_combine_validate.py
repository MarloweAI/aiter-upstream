"""Exercise native-route API state, graph replay, output clearing and fallback."""
import argparse
import json
import os
from pathlib import Path
from .upgrade_state import save


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capture',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--expected-library-source',required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    import torch
    from marlowe_kernels import create_moe,MoEConfig,MoEWeights,UnsupportedConfiguration
    from marlowe_kernels._runtime import source_digest
    from .reference import expert_reference,compare
    from .protocol import load_metadata
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    assert source_digest()==a.expected_library_source
    torch.set_num_threads(4);torch.set_grad_enabled(False)
    owners={};weights={};checks=[];shared_across_tokens=[];aliases=[]
    for lid in (3,16,40,77):
        payload=torch.load(a.capture/'weights'/f'layer-{lid}.pt',map_location='cuda',weights_only=True)
        w={k:payload[k] for k in ('w1','w2','w1_scale','w2_scale')};weights[lid]=w
        owners[lid]=create_moe(MoEConfig(),MoEWeights(*(w[k] for k in w)))
    for b in (1,2,4,8,16,32,64):
        source=a.capture/f'b{b}-s355052';meta=load_metadata(source)
        data=torch.load(source/'tensors.pt',map_location='cuda',weights_only=True)
        for lid in ((3,16,40,77) if b==1 else (3,40,77)):
            owner=owners[lid];j=meta['layers'].index(lid)
            owner.warmup((b,),routing='native');owner.warmup((b,),routing='supplied')
            assert b in owner.prepared_batches
            x=torch.empty((b,6144),device='cuda',dtype=torch.bfloat16)
            ids=torch.empty((b,8),device='cuda',dtype=torch.int32)
            rw=torch.empty((b,8),device='cuda',dtype=torch.float32)
            output=torch.empty_like(x)
            def update(step,reverse=False):
                x.copy_(data['input'][step,j,:b]);ids.copy_(data['ids'][step,j,:b,:8]);rw.copy_(data['routing_weights'][step,j,:b,:8])
                if reverse:ids.copy_(ids.flip(1));rw.copy_(rw.flip(1))
                assert bool((ids.sort(1).values[:,1:]!=ids.sort(1).values[:,:-1]).all())
            def call(out=None):return owner.forward_native_routed(x,ids,rw,out=out)
            update(0);default=call();call(output);torch.cuda.synchronize()
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):call(output)
            default_graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(default_graph):call()
            for step in (0,1,7,15):
                update(step)
                i9=torch.cat((ids,torch.full((b,1),256,device='cuda',dtype=torch.int32)),1)
                w9=torch.cat((rw,torch.ones((b,1),device='cuda')),1)
                reference=expert_reference(weights[lid],x,i9,w9,b in (1,4,8,32))
                for reverse in (False,True):
                    update(step,reverse)
                    output.fill_(float('nan'));eager=call(output).clone()
                    default.fill_(float('nan'));default_eager=call().clone()
                    for _ in range(7):
                        output.fill_(float('nan'));graph.replay()
                        default.fill_(float('nan'));default_graph.replay()
                    torch.cuda.synchronize()
                    actual_ids,actual_weights=owner.routing(b,routing='native')
                    row=dict(batch=b,layer=lid,step=step,reverse=reverse,
                             eager=compare(eager,reference),default_eager=compare(default_eager,reference),
                             graph=compare(output,reference),default_graph=compare(default,reference),
                             exact_ids=bool(torch.equal(actual_ids[:,:8],ids)),
                             exact_weights=bool(torch.equal(actual_weights[:,:8],rw)),
                             shared=bool((actual_ids[:,8]==256).all() and (actual_weights[:,8]==1).all()))
                    supplied=owner.forward_routed(x,ids,rw)
                    row['supplied_and_native_share_output']=supplied.data_ptr()==default.data_ptr()
                    program=owner._native_programs[b]
                    row['state_clean']=program.state_check()['passed'] if hasattr(program,'state_check') else True
                    x.zero_();output.fill_(float('nan'));default.fill_(float('nan'))
                    graph.replay();default_graph.replay();torch.cuda.synchronize()
                    row['zero_clears_output']=bool((output==0).all() and (default==0).all())
                    row['passed']=all(row[k]['passed'] for k in ('eager','default_eager','graph','default_graph')) and all(row[k] for k in ('exact_ids','exact_weights','shared','supplied_and_native_share_output','state_clean','zero_clears_output'))
                    checks.append(row);save(a.output/'checks.json',checks)
                    if not row['passed']:
                        torch.save(dict(input=data['input'][step,j,:b].cpu(),ids=ids.cpu(),weights=rw.cpu(),eager=eager.cpu(),reference=reference.cpu()),a.output/f'failure-b{b}-l{lid}-s{step}-r{int(reverse)}.pt')
                        raise RuntimeError(row)
            if lid==3:
                update(0);borrowed=call();value=borrowed.clone()
                try:owner.forward_native_routed(borrowed,ids,rw)
                except UnsupportedConfiguration as error:
                    assert 'overlap' in str(error).lower()
                else:raise AssertionError('Native borrowed-output alias accepted')
                assert torch.equal(borrowed,value)
                aliases.append(dict(batch=b,borrowed_alias_rejected=True))
            if lid==77:
                update(0)
                ids.copy_(torch.arange(8,device='cuda',dtype=torch.int32).expand(b,8))
                rw.fill_(2.5/8)
                i9=torch.cat((ids,torch.full((b,1),256,device='cuda',dtype=torch.int32)),1)
                w9=torch.cat((rw,torch.ones((b,1),device='cuda')),1)
                ref=expert_reference(weights[lid],x,i9,w9,b in (1,4,8,32))
                general_view=owner.forward_routed(x,ids,rw)
                general=general_view.clone()
                native_view=owner.forward_native_routed(x,ids,rw)
                native=native_view.clone()
                check=compare(general,ref)
                alias_check=compare(native,ref)
                shared_across_tokens.append(dict(batch=b,shared_expert_across_tokens=b>1,
                                                  supplied_reference=check,
                                                  native_alias_reference=alias_check,
                                                  same_output_scratch=general_view.data_ptr()==native_view.data_ptr()))
                assert check['passed'] and alias_check['passed'] and general_view.data_ptr()==native_view.data_ptr()
            del graph,default_graph
        print(json.dumps(dict(batch=b,native_api_passed=True)),flush=True)
    save(a.output/'summary.json',dict(passed=True,library_source=source_digest(),cases=len(checks),
         checks=checks,shared_across_tokens=shared_across_tokens,
         alias_checks=aliases,job=os.environ['SLURM_JOB_ID']))


if __name__=='__main__':main()
