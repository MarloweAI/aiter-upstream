"""Collect short native FP8-KV target-verification trajectories once (TP8).

This is input collection, not a serving benchmark. No candidate kernel runs.
"""

import argparse
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
from pathlib import Path

from .upstream_campaign import revision, save
from .upstream_contract import CONCURRENCIES, file_digest, select_cases


def build_command(model, port, *, steps=16):
    return [
        sys.executable,
        "-B",
        "-m",
        "benchmarks.moe_replay.upstream_capture",
        "--model-path",
        str(model),
        "--tokenizer-path",
        str(model),
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--tp",
        "8",
        "--ep-size",
        "1",
        "--dp",
        "1",
        "--dtype",
        "bfloat16",
        "--kv-cache-dtype",
        "fp8_e4m3",
        "--quantization",
        "quark",
        "--chunked-prefill-size",
        "8192",
        "--context-length",
        "10240",
        "--max-total-tokens",
        "655360",
        "--max-running-requests",
        "64",
        "--mem-fraction-static",
        "0.65",
        "--disable-radix-cache",
        "--watchdog-timeout",
        "1200",
        "--random-seed",
        "355052",
        "--weight-loader-disable-mmap",
        "--model-loader-extra-config",
        '{"enable_multithread_load":true,"num_threads":2}',
        "--cuda-graph-bs-decode",
        "1",
        "2",
        "4",
        "8",
        "16",
        "32",
        "64",
        "--cuda-graph-max-bs-decode",
        "64",
        "--moe-a2a-backend",
        "none",
        "--dsa-prefill-backend",
        "tilelang",
        "--dsa-decode-backend",
        "tilelang",
        "--speculative-algorithm",
        "EAGLE",
        "--speculative-num-steps",
        "3",
        "--speculative-eagle-topk",
        "1",
        "--speculative-num-draft-tokens",
        "4",
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-manifest", type=Path, required=True)
    parser.add_argument("--sglang-source", type=Path, required=True)
    parser.add_argument("--sglang-sha", required=True)
    parser.add_argument("--aiter-source", type=Path, required=True)
    parser.add_argument("--aiter-sha", required=True)
    parser.add_argument(
        "--concurrencies", type=int, nargs="+", default=[64, 1, 2, 4, 8, 16, 32]
    )
    parser.add_argument("--steps", type=int, default=16)
    parser.add_argument("--output-tokens", type=int, default=128)
    args = parser.parse_args()
    if any(c not in CONCURRENCIES for c in args.concurrencies):
        raise SystemExit("Invalid concurrency")
    if not os.environ.get("SLURM_JOB_ID"):
        raise SystemExit("Use an owned TP8 Slurm allocation")
    import torch
    from transformers import AutoTokenizer

    from benchmarks.client import prompts
    from benchmarks.routing_experiment import request
    from benchmarks.serve import stop

    from .protocol import LAYERS

    if torch.cuda.device_count() != 8 or torch.version.hip is None:
        raise SystemExit("Confirm exactly eight visible AMD GPUs before model load")
    if (
        revision(args.sglang_source) != args.sglang_sha
        or revision(args.aiter_source) != args.aiter_sha
    ):
        raise SystemExit("Pinned native capture sources mismatch")
    args.output.mkdir(parents=True, exist_ok=False)
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    # Reuse the coworker's FP8 serving helper: seeded, distinct 8192-token
    # sequences drawn from valid non-special tokenizer IDs. These are synthetic
    # requests that produce genuine model states, not random hidden tensors.
    inputs = prompts(tokenizer, 64, seed=355052)
    assert all(len(tokens) == 8192 for tokens in inputs)
    assert len({tuple(tokens) for tokens in inputs}) == 64
    sampling = {
        "temperature": 0,
        "max_new_tokens": args.output_tokens,
        "ignore_eos": True,
    }
    save(args.output / "input-token-ids.json", inputs)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    base, command = (
        f"http://127.0.0.1:{port}",
        build_command(args.model, port, steps=args.steps),
    )
    env = os.environ.copy()
    for key in list(env):
        if key.startswith(
            ("GAP_", "M1_", "GLM_CAPTURE_", "SGLANG_OPT_", "MOE_COMBINED_")
        ):
            env.pop(key)
    env.update(
        MARLOWE_REPLAY_OUTPUT=str(args.output),
        MARLOWE_REPLAY_MODE="capture",
        MARLOWE_REPLAY_STEPS=str(args.steps),
        MARLOWE_REPLAY_FORWARD_MODE="target_verify",
        MARLOWE_REPLAY_MAX_ROWS="256",
        MARLOWE_CAPTURE_SGLANG_SHA=args.sglang_sha,
        MARLOWE_CAPTURE_AITER_SHA=args.aiter_sha,
        SGLANG_USE_MARLOWE_KERNELS="0",
        SGLANG_USE_MARLOWE_ATTENTION="0",
        MARLOWE_KERNELS_BENCHMARK_ALL="0",
        MARLOWE_KERNELS_VALIDATE="0",
        SGLANG_RAGGED_VERIFY_MODE="static",
        SGLANG_SET_CPU_AFFINITY="0",
        SGLANG_USE_AITER="1",
        ROCM_QUICK_REDUCE_QUANTIZATION="INT4",
        PYTHONUNBUFFERED="1",
        PYTHONDONTWRITEBYTECODE="1",
        TOKENIZERS_PARALLELISM="false",
        HF_HUB_OFFLINE="1",
    )
    identity = {
        "job": os.environ["SLURM_JOB_ID"],
        "command": command,
        "runtime": json.loads(args.runtime_manifest.read_text()),
        "layers": list(LAYERS),
        "sglang_sha": args.sglang_sha,
        "aiter_sha": args.aiter_sha,
        "model_metadata": {
            name: file_digest(args.model / name)
            for name in ("config.json", "model.safetensors.index.json")
        },
        "concurrencies": args.concurrencies,
        "input_length": 8192,
        "output_tokens": args.output_tokens,
        "steps": args.steps,
        "prompt": "coworker FP8 serving helper: 64 distinct seeded8192-token sequences of valid non-special IDs, genuine model forward",
        "prompt_generator_sha256": file_digest(Path(__file__).parents[1] / "client.py"),
        "environment": {
            k: v
            for k, v in env.items()
            if k.startswith(("MARLOWE_", "SGLANG_", "ROCM_", "PYTHONPATH"))
        },
    }
    save(args.output / "launch.json", identity)
    proc = None
    try:
        with (args.output / "server.log").open("w") as log:
            proc = subprocess.Popen(
                command,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            deadline = time.monotonic() + 2400
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError(
                        f"Server exited{proc.returncode}; inspect server.log"
                    )
                try:
                    info = request(base, "/get_server_info", timeout=10)
                    request(base, "/health_generate", timeout=30)
                    break
                except (urllib.error.URLError, OSError, TimeoutError, ValueError):
                    time.sleep(3)
            else:
                raise TimeoutError("Native capture model initialization exceeded40min")
            config = info.get("server_args", info)
            for key, expected in {
                "tp_size": 8,
                "ep_size": 1,
                "kv_cache_dtype": "fp8_e4m3",
            }.items():
                if config.get(key) != expected:
                    raise RuntimeError(
                        f"Unverified actual server setting{key}: {config.get(key)}"
                    )
            save(args.output / "server-info.json", info)
            for c in args.concurrencies:
                name = f"c{c}-d4-s355052"
                result = request(
                    base,
                    "/generate",
                    {
                        "input_ids": inputs[:c],
                        "sampling_params": sampling,
                        "rid": [f"moereplay:{name}:{i}" for i in range(c)],
                    },
                    timeout=900,
                )
                save(args.output / name / "responses.json", result)
                request(base, "/flush_cache", timeout=900)
                metadata = json.loads((args.output / name / "capture.json").read_text())
                cases, excluded = select_cases(metadata, c)
                if len(cases) != args.steps * len(LAYERS) or excluded:
                    raise RuntimeError(
                        f"Incomplete C{c} full-M capture: cases={len(cases)}, excluded={excluded}"
                    )
                if not (args.output / name / "tensors.pt").is_file():
                    raise RuntimeError("Missing captured tensor file")
                print(
                    json.dumps(
                        {"state": "captured", "concurrency": c, "cases": len(cases)}
                    ),
                    flush=True,
                )
            save(
                args.output / "completed.json",
                {
                    "state": "completed",
                    "concurrencies": args.concurrencies,
                    "steps": args.steps,
                    "layers": list(LAYERS),
                },
            )
    finally:
        stop(proc)


if __name__ == "__main__":
    main()
