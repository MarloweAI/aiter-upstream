"""Fetch two exact upstream revisions and run the paired upgrade qualification.

CPU-only controller. GPU work is submitted through Slurm; no existing runtime
is modified. Reinvoking the same configuration/SHAs resumes successful stages.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile
import tempfile
import time
from .upgrade_state import digest, save, validate_config

REPO = Path(__file__).resolve().parents[2]


def resolve(url, ref):
    if re.fullmatch(r'[0-9a-fA-F]{40}', ref):
        return ref.lower()
    lines = subprocess.check_output(['git','ls-remote',url,ref,'refs/heads/'+ref,
                                     'refs/tags/'+ref,'refs/tags/'+ref+'^{}'],text=True).splitlines()
    found = {line.split()[1]:line.split()[0] for line in lines}
    for name in ('refs/tags/'+ref+'^{}','refs/heads/'+ref,'refs/tags/'+ref,ref):
        if name in found:return found[name]
    raise ValueError(f'Cannot resolve {url} ref {ref!r}; use a branch, tag or full SHA')


def source_files():
    return sorted([p for directory in ('marlowe_kernels','benchmarks')
                   for p in (REPO/directory).rglob('*.py')] + [REPO/'pyproject.toml'])


class Remote:
    def __init__(self, config):
        self.config=config
        self.ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','-i',
                  str(Path(config['identity_file']).expanduser()),config['host']]

    def run(self, args, **kwargs):
        return subprocess.run(self.ssh+[shlex.join([str(x) for x in args])],check=True,
                              text=True,capture_output=True,**kwargs).stdout

    def put(self, paths, dest):
        self.run(['mkdir','-p',dest])
        subprocess.run(['scp','-q','-o','BatchMode=yes','-i',str(Path(self.config['identity_file']).expanduser()),
                        *map(str,paths),self.config['host']+':'+shlex.quote(dest+'/')],check=True)

    def read_json(self, path):
        raw=self.run(['python3','-c','import pathlib,sys; p=pathlib.Path(sys.argv[1]); print(p.read_text() if p.exists() else "null")',path])
        return json.loads(raw)


    def verify(self, artifacts):
        code="""import hashlib,json,sys
for path,expected in json.loads(sys.argv[1]).items():
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(8388608),b''):h.update(chunk)
    assert h.hexdigest()==expected,path
"""
        self.run(['python3','-c',code,json.dumps(artifacts)])


def reuse_audit(remote,lock,temp):
    """Check native audit evidence before allocating eight GPUs."""
    runtime=remote.read_json(lock['runtime_root']+'/runtime.json')
    if not runtime or not runtime.get('passed'):return None
    c=lock['config']
    # Keep this identity equal to upgrade_audit.audit_key. The worker checks it
    # again for a new audit; here all inputs are CPU-readable saved receipts.
    key=digest(dict(refs={k:v['sha'] for k,v in lock['refs'].items()},
        runtime=dict(requested=runtime['requested'],execution_source=runtime['execution_source'],
                     image_sha256=runtime['image']['image_sha256'],hardware=runtime['hardware']),
        deps=runtime['dependencies_sha256'],settings={k:c[k] for k in ('model','model_revision','topology','batches','environment')},
        adapter={name:lock['source_files']['benchmarks/moe_replay/'+name] for name in
                 ('upgrade_probe.py','sglang_adapter.py','dispatch_audit.py','upgrade_audit.py')}))
    cache=c['remote']['root']+'/audit-cache/'+key;receipt=remote.read_json(cache+'/validated.json')
    if not receipt or not receipt.get('passed') or receipt.get('key')!=key:return None
    remote.verify({cache+'/'+name:sha for name,sha in receipt['files'].items()})
    remote.run(['python3','-c','import pathlib,sys; p=pathlib.Path(sys.argv[1]); t=pathlib.Path(sys.argv[2]); '
        'p.symlink_to(t,target_is_directory=True) if not p.exists() else None; assert p.resolve()==t.resolve()',
        lock['run_root']+'/native-audit',cache])
    result=dict(stage='audit',status='passed',run_fingerprint=lock['fingerprint'],job_id=None,
                detail=dict(reused=True,key=key,evidence=cache,receipt=receipt))
    save(temp/'audit.json',result);remote.put([temp/'audit.json'],lock['run_root'])
    print('audit: reuse verified native evidence; no eight-GPU allocation',flush=True)
    return result


def script(lock, stage):
    c=lock['config'];sl=c['slurm'];root=lock['run_root'];runtime=lock['runtime_root']
    build=stage=='build';gpu=8 if stage=='audit' else 1
    cpus=128 if stage=='audit' else sl['build_cpus']
    directives=[f'#SBATCH --job-name=mk-upgrade-{stage}',f"#SBATCH --partition={sl['partition']}",
        f"#SBATCH --account={sl['account']}",f"#SBATCH --qos={sl['qos']}",
        f'#SBATCH --cpus-per-task={cpus}',f"#SBATCH --time={sl['time_limit']}",
        '#SBATCH --mem=0' if stage=='audit' else f"#SBATCH --mem={sl['memory_gb']}G"]
    if not build:directives.append(f'#SBATCH --gpus={gpu}')
    if stage=='audit':directives+=['#SBATCH --nodes=1','#SBATCH --exclusive']
    if sl.get('exclude'):directives.append('#SBATCH --exclude='+sl['exclude'])
    env=dict(c['environment'],PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',
        PYTHONNOUSERSITE='1',PYTHONPATH=root+'/source:'+runtime+'/benchmark-deps',
        MARLOWE_UPGRADE_LOCK=root+'/lock.json',PYHIP_CACHE_DIR=runtime+'/pyhip-cache',
        PYHIP_JIT_LOG='0',PYHIP_SIMPLE_GEN_FILENAME='1',MAX_JOBS=str(sl['build_cpus']))
    unsets=['USE_GLUON','USE_GLUON2','AITER_CONFIG_FMOE','AITER_MOE_SORT_BACKEND',
            'SGLANG_USE_MARLOWE_KERNELS','MARLOWE_KERNELS_BENCHMARK_ALL','PYTHONHOME',
            'SETUPTOOLS_SCM_PRETEND_VERSION','PIP_CONSTRAINT','PIP_REQUIRE_VIRTUALENV']
    worker=['-B','-m','benchmarks.moe_replay.upgrade_worker','--lock',root+'/lock.json','--stage',stage]
    if build:
        tool=c['runtime']['sailfish'];env['PYTHONPATH']+=':'+tool['directory']
        cmd=['srun','--mpi=none',tool['uv'],'run','--project',tool['directory'],'python',*worker]
    else:
        image=lock['image']
        if image['provider']=='legacy-completed-overlay':
            env['PYTHONPATH']+=':'+image['source_dirs']['sglang']+'/python:'+image['source_dirs']['aiter']
        cmd=['srun','--mpi=none','--container-image='+image['image'],
             '--container-mounts=/workspace:/workspace,/local:/local','--container-workdir='+root,
             '--no-container-entrypoint','--container-remap-root','--container-writable',image['python'],*worker]
    return '\n'.join(['#!/usr/bin/env bash',*directives,'set -euo pipefail',
        'unset '+' '.join(unsets),*[f'export {k}={shlex.quote(v)}' for k,v in env.items()],shlex.join(cmd),''])


def prepare_tool(remote, lock, temp):
    """Ship a pinned Sailfish tool checkout; all image construction stays in sai."""
    import shutil
    tool=lock['config']['runtime']['sailfish']; checkout=temp/'sailfish';checkout.mkdir()
    archive=temp/'sailfish-upstream.tar.gz'
    with archive.open('wb') as out:
        subprocess.run(['gh','api',f"repos/{tool['repository']}/tarball/{tool['commit']}"],stdout=out,check=True)
    with tarfile.open(archive) as t:
        for member in t.getmembers():
            parts=member.name.split('/',1)
            if len(parts)<2 or not parts[1]:continue
            member.name=parts[1];t.extract(member,checkout,filter='data')
    project=checkout/'pyproject.toml';original=project.read_text();patch=None
    if tool['commit']=='20056a58c1f54ddc05f83233c12e0ab9ef5413d5' and not (checkout/'run/replay').exists():
        revised=original.replace('"run", "run.replay", "in_container"','"run", "in_container"')
        if revised==original:raise RuntimeError('Sailfish packaging workaround no longer applies')
        import difflib
        patch=''.join(difflib.unified_diff(original.splitlines(True),revised.splitlines(True),
                                         fromfile='a/pyproject.toml',tofile='b/pyproject.toml'))
        project.write_text(revised)
    uv=Path(shutil.which('uv') or '')
    if not uv.is_file():raise RuntimeError('uv is required to provision the Sailfish CLI')
    identity=dict(repository=tool['repository'],commit=tool['commit'],packaging_patch=patch,
                  archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                  uv_sha256=hashlib.sha256(uv.read_bytes()).hexdigest(),
                  uv_version=subprocess.check_output([str(uv),'--version'],text=True).strip())
    identity['source_files']={str(p.relative_to(checkout)):hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted(checkout.rglob('*')) if p.is_file()}
    marker=tool['directory']+'/tool-identity.json'
    cached=remote.read_json(marker)
    # Do not rewrite the tool source underneath a running/resumed image build.
    if cached:
        comparable=lambda x:{k:v for k,v in x.items() if k!='archive_sha256'}
        if comparable(cached)!=comparable(identity):
            raise RuntimeError('Sailfish tool cache identity differs; use a separate directory for the new pinned tool')
        remote.verify({tool['directory']+'/'+name:sha for name,sha in identity['source_files'].items()} |
                      {tool['uv']:identity['uv_sha256']})
        identity=cached
    lock['sailfish_identity']=identity
    bundle=temp/'sailfish-tool.tar.gz'
    with tarfile.open(bundle,'w:gz') as t:
        for f in sorted(checkout.rglob('*')):
            if f.is_file():t.add(f,arcname=str(f.relative_to(checkout)))
    if not cached:
        remote.put([bundle,uv],str(Path(tool['uv']).parent))
        remote.run(['mkdir','-p',tool['directory']])
        remote.run(['tar','-xzf',str(Path(tool['uv']).parent/bundle.name),'-C',tool['directory']])
        remote.run(['chmod','+x',tool['uv']])
        save(temp/'tool-identity.json',identity)
        remote.put([temp/'tool-identity.json'],tool['directory'])
    # Pin just the benchmark's PyHIP package, without exposing the old deps directory.
    dep=lock['runtime_root']+'/benchmark-deps'
    remote.run(['mkdir','-p',dep])
    remote.run(['python3','-c',
        'import pathlib,sys; p=pathlib.Path(sys.argv[1]); target=pathlib.Path(sys.argv[2]); '
        'assert target.is_dir(); '
        'p.symlink_to(target,target_is_directory=True) if not p.exists() else None; '
        'assert p.resolve()==target.resolve()',dep+'/pyhip',lock['config']['runtime']['benchmark_pyhip']])


def immutable_preflight_artifacts(remote, lock, receipt):
    """Reuse GPU ABI checks only for a verified image and unchanged PyHIP tree."""
    detail = receipt['detail']
    image = detail.get('image', {})
    if (image.get('provider') != 'sailfish' or not image.get('image_sha256') or
            image.get('image_sha256') != lock.get('image', {}).get('image_sha256')):
        return {}
    dep = detail.get('benchmark_dependency', {})
    if not dep.get('pyhip_path') or not dep.get('pyhip_tree_sha256'):
        return {}
    # PyHIP may be a mutable benchmark dependency outside the immutable image.
    # Hash it on the CPU before reusing the successful GPU compatibility check.
    current = remote.run(['env', 'PYTHONPATH=' + lock['run_root'] + '/source',
        'python3', '-c', 'from pathlib import Path; import sys; '
        'from benchmarks.moe_replay.runtime_support import tree_digest; '
        'print(tree_digest(Path(sys.argv[1]).parent))', dep['pyhip_path']]).strip()
    if current != dep['pyhip_tree_sha256']:
        return {}
    return {lock['runtime_root'] + '/runtime.json': hashlib.sha256(
        (json.dumps(detail, indent=2) + '\n').encode()).hexdigest()}


def stage_run(remote, lock, stage, temp):
    root=lock['run_root'];receipt=root+'/'+stage+'.json'
    existing=remote.read_json(receipt)
    if existing and existing.get('status')=='passed' and existing.get('run_fingerprint')==lock['fingerprint']:
        # Mutable legacy overlays require a fresh import/dependency check. For
        # other stages, verify the actual artifacts before trusting a receipt.
        artifacts={}
        if stage=='build':
            artifacts[existing['detail']['image']]=existing['detail']['image_sha256']
        elif stage=='preflight':
            artifacts=immutable_preflight_artifacts(remote,lock,existing)
        elif stage=='audit':
            detail=existing['detail']
            artifacts={str(Path(detail['evidence'])/name):sha for name,sha in detail['receipt']['files'].items()}
        elif stage=='replay':
            artifacts={r['result']:r['sha256'] for r in existing['detail']['results']}
        if artifacts:
            remote.verify(artifacts)
            print(f'{stage}: reuse verified stage receipt',flush=True);return existing
    if stage=='audit':
        reused=reuse_audit(remote,lock,temp)
        if reused:return reused
    # An interrupted controller attaches to its existing allocation instead of
    # scheduling duplicate GPU work.
    jobfile=root+'/'+stage+'-job.json';job=remote.read_json(jobfile)
    active=False
    if job and job.get('fingerprint')==lock['fingerprint']:
        active=bool(remote.run(['squeue','-h','-j',job['job_id'],'-o','%T']).strip())
    if not active:
        path=temp/(stage+'.sbatch');path.write_text(script(lock,stage));remote.put([path],root)
        job_id=remote.run(['sbatch','--parsable','--output='+root+'/'+stage+'-%j.log',root+'/'+path.name]).strip().split(';')[0]
        if not job_id.isdigit():raise RuntimeError('Unexpected Slurm job ID: '+job_id)
        job=dict(job_id=job_id,fingerprint=lock['fingerprint']);save(temp/(stage+'-job.json'),job)
        remote.put([temp/(stage+'-job.json')],root)
        print(f'{stage}: submitted Slurm job {job_id}',flush=True)
    else:print(f'{stage}: resume monitoring job {job["job_id"]}',flush=True)
    last=None
    while True:
        state=remote.run(['squeue','-h','-j',job['job_id'],'-o','%T']).strip()
        result=remote.read_json(receipt)
        if result and result.get('run_fingerprint')==lock['fingerprint'] and result.get('job_id')==job['job_id'] and result.get('status') in ('passed','failed'):
            save(temp/(stage+'.json'),result)
            if result['status']=='failed':raise RuntimeError(f"{stage} failed: {result.get('error')}; {root}/{stage}-{job['job_id']}.log")
            return result
        if not state:
            log=remote.run(['tail','-n','30',root+'/'+stage+'-'+job['job_id']+'.log'])
            raise RuntimeError(f'{stage} exited without a successful receipt:\n{log}')
        if state!=last:print(f'{stage}: {state}',flush=True);last=state
        time.sleep(10)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',default='glm52_tp8.json',type=Path)
    p.add_argument('--sglang-ref');p.add_argument('--aiter-ref')
    p.add_argument('--plan',action='store_true',help='Resolve and show the plan without building or launching GPUs')
    p.add_argument('--stop-after',choices=['build','preflight','audit','replay'],default='replay',help='Development/preflight stage limit; default runs the complete comparison')
    p.add_argument('--output',type=Path,help='Local receipt/report directory')
    a=p.parse_args();path=a.config if a.config.exists() else REPO/a.config
    config=validate_config(json.loads(path.read_text()))
    refs={name:dict(url=value['url'],requested_ref=getattr(a,name+'_ref') or value['ref']) for name,value in config['upstream'].items()}
    for value in refs.values():value['sha']=resolve(value['url'],value['requested_ref'])
    files=source_files();sources={str(f.relative_to(REPO)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
    runtime_key=digest(dict(refs={k:v['sha'] for k,v in refs.items()},recipe=config['runtime'],
        provider=sources.get('benchmarks/moe_replay/sailfish_images.py')))
    fingerprint=digest(dict(config=config,refs=refs,sources=sources))
    root=config['remote']['root']
    lock=dict(schema_version=1,fingerprint=fingerprint,refs=refs,config=config,source_files=sources,
              runtime_root=root+'/runtimes/'+runtime_key[:24],run_root=root+'/runs/'+fingerprint[:24],
              resolved_at=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    print(json.dumps(dict(sglang=refs['sglang']['sha'],aiter=refs['aiter']['sha'],backends=config['backends'],
          stages=['Sailfish image / completed output reuse','GPU compatibility','TP8 native dispatch audit','paired one-GPU AITER / Port-EW replay'],
          run_root=lock['run_root']),indent=2),flush=True)
    if a.plan:return
    output=a.output or REPO/'results/upgrades'/fingerprint[:24];output.mkdir(parents=True,exist_ok=True)
    save(output/'lock.json',lock)
    remote=Remote(config['remote'])
    with tempfile.TemporaryDirectory(prefix='marlowe-upgrade-') as td:
        temp=Path(td)
        try:prepare_tool(remote,lock,temp)
        except (RuntimeError,subprocess.CalledProcessError) as exc:
            (output/'REPORT.md').write_text(f'Tool preparation failed; no build or benchmark was submitted.\n\n{exc}\n')
            raise
        save(output/'lock.json',lock)
        bundle=temp/'source.tar.gz'
        with tarfile.open(bundle,'w:gz') as t:
            for f in files:t.add(f,arcname=str(f.relative_to(REPO)))
        save(temp/'lock.json',lock);remote.put([bundle,temp/'lock.json'],lock['run_root'])
        remote.run(['mkdir','-p',lock['run_root']+'/source'])
        remote.run(['tar','-xzf',lock['run_root']+'/source.tar.gz','-C',lock['run_root']+'/source'])
        try:
            for stage in ('build','preflight','audit','replay'):
                result=stage_run(remote,lock,stage,temp);save(output/(stage+'.json'),result)
                if stage=='build':lock['image']=result['detail']
                if stage==a.stop_after and stage!='replay':
                    print(f'{stage} complete; remaining stages were explicitly not requested.');return
            report=remote.run(['cat',lock['run_root']+'/REPORT.md']);(output/'REPORT.md').write_text(report)
            print(report)
        except (RuntimeError,subprocess.CalledProcessError) as exc:
            message=f'Upgrade stopped; no fallback to an older revision.\n\n{exc}\n\nEvidence: {lock["run_root"]}\n'
            try:
                # Reporting is CPU-only and reads completed evidence even when
                # the GPU worker stopped before its final report step.
                remote.run(['env','PYTHONPATH='+lock['run_root']+'/source','python3','-m',
                    'benchmarks.moe_replay.upgrade_report','--lock',lock['run_root']+'/lock.json','--failure',str(exc)])
                report=remote.run(['cat',lock['run_root']+'/REPORT.md'])
            except (RuntimeError,subprocess.CalledProcessError):report=message
            (output/'REPORT.md').write_text(report);print(message,file=sys.stderr);raise SystemExit(1)


if __name__=='__main__':main()
