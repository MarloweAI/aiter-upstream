"""Render relative GLM-5.2 TPOT as an editable SVG."""

from csv import DictReader
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ROWS = list(reversed(list(DictReader((ROOT / "slide-data.csv").open()))))
WIDTH, HEIGHT = 1200, 1220

NAVY = "#122131"
SLATE = "#526174"
MUTED = "#758296"
GRID = "#DCE5ED"
AXIS = "#93A1B1"
GREY = "#71767B"
GREEN = "#0B4A1B"
BLUE = "#1672DD"


def text(x, y, value, size=20, color=NAVY, weight=400, anchor="start", extra=""):
    return (f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" '
            f'font-weight="{weight}" text-anchor="{anchor}" {extra}>'
            f'{escape(str(value))}</text>')


def line(x1, y1, x2, y2, color, width=2, extra=""):
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
            f'stroke="{color}" stroke-width="{width}" {extra}/>')


def circle(x, y, radius, color):
    return f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{radius}" fill="{color}"/>'


parts = [
    f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" '
    f'viewBox="0 0 {WIDTH} {HEIGHT}" role="img" aria-labelledby="title desc">',
    '<title id="title">GLM-5.2 EAGLE 3-1-4 serving performance on MI355X and B200</title>',
    '<desc id="desc">Measured TPOT for concurrency 1 through 32: MI355X AITER, Marlowe MI355X, and B200 reference. Lower is better.</desc>',
    '<defs><linearGradient id="callout" x1="0" y1="0" x2="1" y2="0">'
    '<stop offset="0" stop-color="#F2FBF1"/>'
    '<stop offset="1" stop-color="#E8F6E8"/>'
    '</linearGradient></defs>',
    '<rect width="1200" height="1220" fill="#FFFFFF"/>',
    '<g font-family="DejaVu Sans, Arial, sans-serif">',
    text(62, 45, "AMD SERVING PERFORMANCE", 17, GREEN, 500,
         extra='letter-spacing="2.8"'),
    text(58, 116, "GLM-5.2", 62, NAVY, 700),
    text(62, 161, "EAGLE 3-1-4", 29, SLATE, 400),
]

legend = [
    (68, GREY, "MI355X AITER baseline"),
    (429, GREEN, "Marlowe MI355X"),
    (790, BLUE, "B200 reference"),
]
for x, color, label in legend:
    parts.append(line(x, 214, x + 38, 214, color, 3.1))
    parts.append(circle(x + 19, 214, 7.4, color))
    parts.append(text(x + 50, 221, label, 19.5, NAVY, 400))

parts.append(text(62, 278, "Relative TPOT (AITER = 100%) ↓", 28, NAVY, 700))

chart_left, chart_right = 112, 1135
plot_top, plot_bottom = 311, 768
ymin, ymax = 55.0, 105.0
xs = [151 + i * 190 for i in range(6)]


def y(value):
    fraction = (float(value) - ymin) / (ymax - ymin)
    return plot_bottom - fraction * (plot_bottom - plot_top)


ticks = (60, 70, 80, 90, 100)
for tick in ticks:
    yy = y(tick)
    if tick != ticks[0]:
        parts.append(line(chart_left, f"{yy:.2f}", chart_right, f"{yy:.2f}",
                          GRID, 1.5, 'stroke-dasharray="6 5"'))
    parts.append(text(94, f"{yy + 6:.2f}", f"{tick}%", 17, MUTED, 400, "end"))
parts.append(line(chart_left, plot_top, chart_left, plot_bottom, AXIS, 1.5))
parts.append(line(chart_left, plot_bottom, chart_right, plot_bottom, AXIS, 1.5))

for x, row in zip(xs, ROWS):
    parts.append(line(x, plot_bottom, x, plot_bottom + 9, AXIS, 1.5))
    parts.append(text(x, plot_bottom + 39, row["concurrency"], 20, NAVY,
                      400, "middle"))
parts.append(text(624, 837, "Concurrency", 21, NAVY, 400, "middle"))

for key, color in (
    ("mi355x_aiter_tpot_ms", GREY),
    ("marlowe_mi355x_tpot_ms", GREEN),
    ("b200_reference_tpot_ms", BLUE),
):
    points = []
    for x, row in zip(xs, ROWS):
        value = 100.0 * float(row[key]) / float(row["mi355x_aiter_tpot_ms"])
        points.append((x, y(value)))
    path = " ".join(("M" if i == 0 else "L") + f" {x:.2f} {yy:.2f}"
                    for i, (x, yy) in enumerate(points))
    parts.append(f'<path d="{path}" fill="none" stroke="{color}" '
                 'stroke-width="3.4" stroke-linecap="round" '
                 'stroke-linejoin="round"/>')
    for x, yy in points:
        parts.append(circle(x, yy, 7.2, color))

parts += [
    '<rect x="57" y="864" width="1080" height="119" rx="18" fill="url(#callout)"/>',
    '<path d="M 107 889 L 107 948 M 86 927 L 107 949 L 128 927" '
    f'fill="none" stroke="{GREEN}" stroke-width="4" stroke-linecap="round" '
    'stroke-linejoin="round"/>',
    text(155, 911, "11.2% lower TPOT vs MI355X AITER", 27, GREEN, 700),
    text(156, 950, "AITER set to 100% at each concurrency · geomean C=1–32",
         20, SLATE, 400),
    text(61, 1022, "TTFT:", 19, NAVY, 700),
    text(138, 1022, "0.83% lower vs AITER (geomean C=1–32)", 19, SLATE),
    text(61, 1061, "GSM8K:", 19, NAVY, 700),
    text(163, 1061, "93.63% → 93.18%  (−0.45 pp; paired p=0.590)", 19, SLATE),
    text(61, 1100, "SGLang:", 18, NAVY, 700),
    text(166, 1100, "0.0.0.dev117+g5f017ffab.d20260923  ·  5f017ffab", 18, SLATE),
    text(61, 1138, "AITER:", 18, NAVY, 700),
    text(151, 1138, "0.1.23.dev138+g52ffe895e.d20260923  ·  52ffe895e", 18, SLATE),
    line(61, 1163, 1137, 1163, GRID, 1.2),
    text(61, 1193,
         "8K input · 1K output · TP8/EP1 · BF16 KV · 2 warmup waves · 3 measured reps · exact prompt IDs",
         15.5, MUTED),
    '</g></svg>',
]

out = ROOT / "figures" / "glm52-left-panel-relative.svg"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text("\n".join(parts))
print(out)
