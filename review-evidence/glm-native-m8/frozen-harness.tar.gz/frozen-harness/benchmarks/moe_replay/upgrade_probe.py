"""Short full-TP8 audit of effective SGLang configuration and GPU graph nodes."""
import dataclasses
import functools
import hashlib
import json
import os
from pathlib import Path
import runpy
import torch
from .dispatch_audit import graph_dot,ordered_span
from .sglang_adapter import config_fields,encode
from .upgrade_state import save


def tensor_digest(t):
    raw=t.detach().contiguous().view(torch.uint8).cpu().numpy()
    return hashlib.sha256(memoryview(raw)).hexdigest()


def install():
    from sglang.srt.models import deepseek_v2 as mod
    from sglang.srt.layers.moe.moe_runner.runner import MoeRunner
    from sglang.srt.model_executor.model_runner import ModelRunner
    from sglang.srt.managers.scheduler import Scheduler
    lock=json.loads(Path(os.environ['MARLOWE_UPGRADE_LOCK']).read_text());root=Path(lock['run_root'])/'native-audit'
    c=lock['config'];capture=Path(c['capture']);layers=json.loads((capture/f"b{c['batches'][0]}-s355052/capture.json").read_text())['layers']
    root.mkdir(exist_ok=True)
    state=dict(active=None,specs={},spans={},before=None,completed_batches=set())
    rank0=lambda:torch.distributed.is_initialized() and torch.distributed.get_rank()==0
    normal=mod.DeepseekV2MoE.forward_normal
    @functools.wraps(normal)
    def forward(self,x,*args,**kwargs):
        selected=rank0() and self.layer_id in layers and len(x) in c['batches']
        old=state['active'];state['active']=(self,len(x)) if selected else None
        if selected:
            if kwargs.get('num_token_non_padded') is not None:raise RuntimeError('Graph-padded MoE audit is not implemented')
            if self.tp_size!=8 or self.moe_ep_size!=1 or self.num_fused_shared_experts!=1:raise RuntimeError('Unexpected live MoE topology')
            if getattr(self.topk,'enable_waterfill',False):raise RuntimeError('Waterfill needs a dedicated replay adapter')
        try:return normal(self,x,*args,**kwargs)
        finally:state['active']=old
    mod.DeepseekV2MoE.forward_normal=forward
    gate=mod.MoEGate.forward
    @functools.wraps(gate)
    def gated(self,x,*args,**kwargs):
        if state['active'] and torch.cuda.is_current_stream_capturing():state['before']=graph_dot()
        return gate(self,x,*args,**kwargs)
    mod.MoEGate.forward=gated
    runner=MoeRunner.run
    @functools.wraps(runner)
    def core(self,runner_input,quant_info,*args,**kwargs):
        current=state['active']
        if current:
            block,b=current;layer=block.layer_id
            if not torch.cuda.is_current_stream_capturing() and layer not in state['specs']:
                weight_fields={'w13_weight':'w1','w2_weight':'w2','w13_scale':'w1_scale','w2_scale':'w2_scale'}
                old_weights=torch.load(capture/'weights'/f'layer-{layer}.pt',weights_only=True,mmap=True)
                hashes={};descriptors={}
                for field,key in weight_fields.items():
                    value=getattr(quant_info,field)
                    hashes[key]=tensor_digest(value)
                    if hashes[key]!=tensor_digest(old_weights[key]):
                        raise RuntimeError(f'Packed weight layout/content changed at layer {layer}, {key}; captured weights cannot be reused safely')
                    descriptors[key]=dict(shape=list(value.shape),stride=list(value.stride()),dtype=str(value.dtype))
                # Gate precision is framework-owned. Refresh these small tensors
                # from the current model; expert bytes above must remain compatible.
                gates=dict(gate_weight=block.gate.weight.detach().cpu(),bias=block.gate.e_score_correction_bias.detach().cpu(),
                           tiny_router_gemm_max_tokens=block.gate.tiny_router_gemm_max_tokens)
                torch.save(gates,root/f'gate-{layer}.pt')
                spec=dict(layer=layer,scheme=type(block.experts.scheme).__name__,
                    runner_backend=encode(self.runner_backend),runner_config=config_fields(self.config,exclude=('layer',)),
                    topk=config_fields(block.topk.topk_config,exclude=('correction_bias',)),
                    is_fp4_experts=block.topk.is_fp4_experts,
                    tiny_router_gemm_max_tokens=block.gate.tiny_router_gemm_max_tokens,
                    quant_info=config_fields(quant_info,exclude=tuple(weight_fields)),
                    weights=descriptors,weight_content_sha256=hashes,
                    gate_sha256=tensor_digest(block.gate.weight),bias_sha256=tensor_digest(block.gate.e_score_correction_bias))
                state['specs'][layer]=spec;save(root/f'layer-{layer}.json',spec)
        return runner(self,runner_input,quant_info,*args,**kwargs)
    MoeRunner.run=core
    combine=mod.maybe_fuse_routed_scale_and_shared_add
    @functools.wraps(combine)
    def combined(*args,**kwargs):
        out=combine(*args,**kwargs)
        if state['active'] and torch.cuda.is_current_stream_capturing():
            block,b=state['active'];span=ordered_span(state['before'],graph_dot())
            state['spans'][(block.layer_id,b)]=span
            save(root/f'dispatch-l{block.layer_id}-b{b}.json',span)
        return out
    mod.maybe_fuse_routed_scale_and_shared_add=combined
    original=ModelRunner.forward
    @functools.wraps(original)
    def model(self,fb,*args,**kwargs):
        result=original(self,fb,*args,**kwargs)
        if rank0() and fb.forward_mode.is_decode() and result.can_run_graph:
            b=int(self.decode_cuda_graph_runner.bs)
            if b in c['batches']:
                state['completed_batches'].add(b)
                save(root/'executed-graphs.json',dict(batches=sorted(state['completed_batches']),rank=0))
        return result
    ModelRunner.forward=model
    flush=Scheduler.flush_cache
    @functools.wraps(flush)
    def flushed(self,*args,**kwargs):
        result=flush(self,*args,**kwargs)
        if rank0() and self.is_fully_idle():
            save(root/'coverage.json',dict(layers=sorted(state['specs']),batches=sorted(state['completed_batches']),
                spans=len(state['spans']),expected=len(layers)*len(c['batches'])))
        return result
    Scheduler.flush_cache=flushed


if os.environ.get('MARLOWE_UPGRADE_LOCK'):install()
if __name__=='__main__':runpy.run_module('sglang.launch_server',run_name='__main__')
