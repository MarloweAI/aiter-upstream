"""Offline route-conditioned FlyDSL microbenchmark search; no runtime selector.

Reuses profile_bandwidth's audited, frozen operands and independent reference.
BM16, inline G1 quantization and atomic G2 are held fixed so candidate costs
cover the same operations. Only microbenchmark graphs run during measurement.
"""
import argparse
import hashlib
import inspect
import itertools
import json
from pathlib import Path
import random
import statistics as st
import sys

PHASE = None
EXPERIMENT = None


def name(config):
    return json.dumps(config, sort_keys=True, separators=(',',':'))


def baseline(pair):
    g1 = pair['calls']['g1'][1]
    fn2,g2 = pair['calls']['g2']
    return dict(g1=dict(BN=g1['BN'],prefetch_hidden=g1.get('prefetch_hidden',False),
                        xcd_swizzle=g1.get('xcd_swizzle',0)),
                g2=dict(family='legacy' if fn2.__name__=='flydsl_mxfp4_gemm2' else 'layout',
                        BN=g2.get('BN',256),BK=g2.get('BK',256),use_nt=g2['use_nt'],
                        persist=g2.get('persist',False)))


def inventory(base):
    g1s = [dict(BN=n,prefetch_hidden=p,xcd_swizzle=x)
           for n,p,x in itertools.product((128,256),(False,True),(0,2,4))]
    g2s = [dict(family='layout',BN=n,BK=k,use_nt=nt,persist=p)
           for n,k,nt,p in itertools.product((128,256),(128,256),(False,True),(False,True))]
    g2s += [dict(family='legacy',BN=256,BK=256,use_nt=nt,persist=False) for nt in (False,True)]
    unique = {name(base):base}
    for c in g1s: unique[name(dict(g1=c,g2=base['g2']))] = dict(g1=c,g2=base['g2'])
    for c in g2s: unique[name(dict(g1=base['g1'],g2=c))] = dict(g1=base['g1'],g2=c)
    return list(unique.values())


def variants(pair, config):
    from aiter.ops.flydsl.mxfp4_gemm2_kernels import flydsl_mxfp4_gemm2
    from aiter.ops.flydsl.kernels.mxmoe_dispatcher import mxfp4_moe_gemm2
    fn1,kw1=pair['calls']['g1'];_,original=pair['calls']['g2']
    kw1=dict(kw1,**config['g1'])
    assert kw1['BM']==16 and kw1['inline_quant'] and kw1['use_nt']
    g2=dict(config['g2']);family=g2.pop('family')
    fn2=flydsl_mxfp4_gemm2 if family=='legacy' else mxfp4_moe_gemm2
    accepted=set(inspect.signature(fn2).parameters)
    kw2={k:v for k,v in original.items() if k in accepted}
    kw2.update({k:v for k,v in g2.items() if k in accepted})
    if family=='legacy':
        kw2.update(flat_out=pair['out'],atomic=True,mxfp4out=False,cshuffle=False,xcd_swizzle=0)
    else:
        kw2.update(out=pair['out'],a_dtype='fp4',b_dtype='fp4',epilog='atomic',SBM=16,
                   out_dtype='bf16',g2_bf16_lds=None,g2_spart=None)
    return fn1,kw1,fn2,kw2


def shortlist(result, axis, maximum=4):
    """Greedy coverage of training-case winners, not only aggregate winners."""
    base=result['baseline']
    indices=[i for i,r in enumerate(result['sequence']) if r['layer_index']%2==0]
    entries=[(k,r) for k,r in result['candidates'].items()
             if r['passed'] and r['config']['g2' if axis=='g1' else 'g1']==base['g2' if axis=='g1' else 'g1']]
    entries.sort(key=lambda item:st.mean(item[1]['medians_us'][i] for i in indices))
    selected=[entries[0]]
    best=[entries[0][1]['medians_us'][i] for i in indices]
    while len(selected)<min(maximum,len(entries)):
        choices=[item for item in entries if item not in selected]
        choice=min(choices,key=lambda item:sum(min(v,item[1]['medians_us'][i]) for v,i in zip(best,indices)))
        selected.append(choice)
        best=[min(v,choice[1]['medians_us'][i]) for v,i in zip(best,indices)]
    configs=[r['config'][axis] for _,r in selected]
    if base[axis] not in configs:configs.append(base[axis])
    return configs


def sweep(pairs, routes, references, setup, output, batch):
    import torch
    import triton
    from .events import Event
    from .kernels import touch_input
    from .reference import compare
    from .upgrade_state import save
    base=baseline(pairs[0])
    assert all(baseline(p)==base for p in pairs)
    if PHASE=='screen':
        candidates=inventory(base);samples=10
    else:
        prior=json.loads((EXPERIMENT/'screen'/f'search-b{batch}.json').read_text())
        assert prior['baseline']==base
        candidates=[dict(g1=g1,g2=g2) for g1,g2 in itertools.product(prior['shortlist']['g1'],prior['shortlist']['g2'])]
        candidates.sort(key=lambda c:c!=base);samples=20
    result=dict(batch=batch,phase=PHASE,baseline=base,sequence=routes,candidates={},samples=samples,
        worker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='G1/G2 only; BM16 and intermediate layout fixed; saved routes; 30 real layer weight sets')
    path=output/f'search-b{batch}.json'
    graphs={}
    for config in candidates:
        key=name(config)
        print(json.dumps(dict(batch=batch,phase=PHASE,candidate=config,event='prepare')),flush=True)
        try:
            calls=[variants(pair,config) for pair in pairs]
            # Warm/compile before graph capture. Scalar descriptors vary by
            # case, but all candidates retain the same tensor contracts.
            for fn1,k1,fn2,k2 in calls:fn1(**k1);fn2(**k2)
            torch.cuda.synchronize()
            events=[(Event(),Event()) for _ in pairs]
            sink=torch.empty((384,),device='cuda')
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                for pair,(fn1,k1,fn2,k2),(start,end) in zip(pairs,calls,events):
                    x=pair['x']
                    touch_input[(triton.cdiv(x.numel(),1024),)](x,sink,x.numel(),1024)
                    for field in ('sorted_expert_ids','cumsum_tensor','m_indices'):
                        v=k1.get(field)
                        if isinstance(v,torch.Tensor) and v.numel():
                            touch_input[(triton.cdiv(v.numel(),1024),)](v,sink,v.numel(),1024)
                    start.record();fn1(**k1);fn2(**k2);end.record()
            setup.replay();graph.replay();torch.cuda.synchronize()
            checks=[compare(pair['out'].reshape_as(ref),ref) for pair,ref in zip(pairs,references)]
            passed=all(r['passed'] for r in checks)
            result['candidates'][key]=dict(config=config,passed=passed,checks=checks)
            if passed:graphs[key]=(graph,events,sink,calls)
            else:print(json.dumps(dict(batch=batch,candidate=config,event='rejected_numerically',failures=sum(not r['passed'] for r in checks))),flush=True)
        except NotImplementedError as exc:
            result['candidates'][key]=dict(config=config,passed=False,unsupported=str(exc))
        save(path,result)
    assert name(base) in graphs,'Baseline failed correctness; no qualified comparison'
    for graph,*_ in graphs.values():
        for _ in range(3):setup.replay();graph.replay()
    torch.cuda.synchronize()
    rng=random.Random(355052)
    for sample in range(samples):
        order=list(graphs);rng.shuffle(order)
        for key in order:
            graph,events,*_=graphs[key]
            setup.replay();graph.replay();torch.cuda.synchronize()
            values=[s.elapsed_us(e) for s,e in events]
            result['candidates'][key].setdefault('samples_us',[]).append(values)
        print(json.dumps(dict(batch=batch,phase=PHASE,round=sample+1,candidates=len(graphs))),flush=True)
    for key in graphs:
        raw=result['candidates'][key]['samples_us']
        result['candidates'][key]['medians_us']=[st.median(r[i] for r in raw) for i in range(len(routes))]
    if PHASE=='screen':result['shortlist']={axis:shortlist(result,axis) for axis in ('g1','g2')}
    result['complete']=True
    save(path,result)
    return result


def main():
    global PHASE,EXPERIMENT
    p=argparse.ArgumentParser()
    p.add_argument('--phase',choices=['screen','sweep'],required=True)
    p.add_argument('--experiment',type=Path,required=True)
    a,rest=p.parse_known_args()
    PHASE,EXPERIMENT=a.phase,a.experiment
    from . import profile_bandwidth
    profile_bandwidth.probes=sweep
    sys.argv=[sys.argv[0],*rest,'--mode','probes']
    profile_bandwidth.main()


if __name__=='__main__':main()
