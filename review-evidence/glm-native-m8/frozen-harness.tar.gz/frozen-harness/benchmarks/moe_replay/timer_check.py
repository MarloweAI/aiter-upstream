"""GPU validation of native timing boundaries, replay updates and marker cost."""
import argparse
import json
import os
from pathlib import Path
import statistics as st
import torch
from .events import Event, call


def measure(graph, pairs, samples=40):
    for _ in range(10): graph.replay()
    torch.cuda.synchronize()
    outside = [torch.cuda.Event(enable_timing=True) for _ in range(2)]
    whole, intervals = [], []
    for _ in range(samples):
        outside[0].record(); graph.replay(); outside[1].record()
        outside[1].synchronize()
        whole.append(outside[0].elapsed_time(outside[1])*1000)
        intervals.append([s.elapsed_us(e) for s,e in pairs])
    return dict(graph_median_us=st.median(whole), graph_samples_us=whole,
                interval_medians_us=[st.median(v[i] for v in intervals) for i in range(len(pairs))],
                interval_samples_us=intervals)


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--event-flags',type=lambda s:int(s,0),default=0x20000000);a=p.parse_args()
    assert os.environ.get('SLURM_JOB_ID') and torch.cuda.device_count()==1
    torch.set_num_threads(4)
    x=torch.zeros(1024,device='cuda')
    rows={}
    for name,before,inside,repeats,markers in [('base',0,0,1,True),('before',1000000,0,1,True),
            ('inside',0,1000000,1,True),('double',0,2000000,1,True),
            ('chain_events',0,30000,30,True),('chain_plain',0,30000,30,False)]:
        pairs=[(Event(a.event_flags),Event(a.event_flags)) for _ in range(repeats)] if markers else []
        g=torch.cuda.CUDAGraph()
        with torch.cuda.graph(g):
            if before:torch.cuda._sleep(before)
            for i in range(repeats):
                if markers:pairs[i][0].record()
                if inside:torch.cuda._sleep(inside)
                x.add_(1)
                if markers:pairs[i][1].record()
            if pairs:call('hipGraphDebugDotPrint',pairs[0][0].graph,str(a.output.with_suffix('.dot')).encode(),0)
        rows[name]=measure(g,pairs)
        print(name,rows[name]['graph_median_us'],rows[name]['interval_medians_us'],flush=True)
        del g,pairs
    med=lambda name:rows[name]['interval_medians_us'][0]
    checks=dict(outside_work_excluded=abs(med('before')-med('base'))<10,
                inside_work_included=med('inside')>med('base')+100,
                duration_scales=1.7<(med('double')-med('base'))/(med('inside')-med('base'))<2.3)
    rows['checks']=checks;rows['passed']=all(checks.values())
    rows['marker_overhead_per_pair_us']=(rows['chain_events']['graph_median_us']-rows['chain_plain']['graph_median_us'])/30
    rows['event_flags']=a.event_flags
    rows['job']=os.environ['SLURM_JOB_ID'];rows['torch']=torch.__version__;rows['hip']=torch.version.hip
    a.output.write_text(json.dumps(rows,indent=2)+'\n')
    assert rows['passed'],checks


if __name__=='__main__':main()
