"""Native SGLang router and AITER/Port-EW local experts on captured TP8 weights."""
import importlib
import os
import torch
from marlowe_kernels import MoEConfig,MoEWeights,create_moe


class Layer:
    def __init__(self, payload, layer_id, *, implementation="port_ew"):
        import aiter
        from sglang.srt.models.deepseek_v2 import MoEGate
        self.layer_id=layer_id
        self.weights={k:payload[k].cuda() for k in ('w1','w2','w1_scale','w2_scale')}
        for key in ('w1','w2'):
            self.weights[key]=self.weights[key].view(torch.float4_e2m1fn_x2)
            self.weights[key].is_shuffled=True
        for key in ('w1_scale','w2_scale'):
            self.weights[key]=self.weights[key].view(torch.float8_e8m0fnu)
        # Reuse the pinned SGLang forward/selection logic with captured parameters.
        self.gate=MoEGate.__new__(MoEGate);torch.nn.Module.__init__(self.gate)
        self.gate.weight=torch.nn.Parameter(payload['gate_weight'].cuda(),requires_grad=False)
        self.gate.tiny_router_gemm_max_tokens=payload['tiny_router_gemm_max_tokens']
        self.gate.is_deepseek_v4=False
        self.bias=payload['bias'].cuda()
        # Match TopKConfig.correction_bias_for_dtype: convert once, outside graphs.
        self.bias_by_dtype={dtype:self.bias.to(dtype) for dtype in (torch.bfloat16,torch.float32)}
        self.fm=importlib.import_module('aiter.fused_moe')
        self.kw=dict(activation=aiter.ActivationType.Silu,quant_type=aiter.QuantType.per_1x32)
        self.port=create_moe(MoEConfig(),MoEWeights(self.weights['w1'],self.weights['w2'],
                            self.weights['w1_scale'],self.weights['w2_scale']),implementation=implementation)

    def warmup(self,b):
        logits=self.gate(torch.zeros((b,6144),device='cuda',dtype=torch.bfloat16))
        supplied=os.environ.get('MARLOWE_KERNELS_NATIVE_TOPK','0')=='1' or logits.dtype!=torch.bfloat16
        self.port.warmup((b,),routing='supplied' if supplied else 'internal')

    def routes(self,x,logits):
        from sglang.srt.layers.moe.topk import biased_grouped_topk_gpu
        return biased_grouped_topk_gpu(hidden_states=x,gating_output=logits,
            correction_bias=self.bias_by_dtype[logits.dtype],topk=8,renormalize=True,
            num_expert_group=1,topk_group=1,num_fused_shared_experts=0,
            routed_scaling_factor=2.5,apply_routed_scaling_factor_on_output=False)

    def __call__(self,x,variant):
        return self.from_logits(x,self.gate(x),variant)

    def expert_routed(self,x,ids,weights,variant):
        if variant=='port_ew':
            if (len(x),'supplied') not in self.port._prepared_modes:
                self.port.warmup((len(x),),routing='supplied')
            return self.port.forward_routed(x,ids[:,:8].contiguous(),weights[:,:8].contiguous())
        return self.fm.fused_moe(x,**self.weights,topk_ids=ids,topk_weight=weights,**self.kw)

    def from_logits(self,x,logits,variant):
        if variant=='port_ew' and logits.dtype==torch.bfloat16 and os.environ.get('MARLOWE_KERNELS_NATIVE_TOPK','0')!='1':
            out=self.port(x,logits,self.bias_by_dtype[logits.dtype])
            i9,w9=self.port.routing(len(x))
        elif variant=='port_ew':
            weights,ids=self.routes(x,logits)
            out=self.port.forward_routed(x,ids,weights)
            i9,w9=self.port.routing(len(x),routing='supplied')
        else:
            weights,ids=self.routes(x,logits)
            from sglang.kernels.ops.moe.fused_moe_triton_kernels import fused_append_shared_experts
            i9,w9=fused_append_shared_experts(ids,weights,1,1.0,256)
            out=self.fm.fused_moe(x,**self.weights,topk_ids=i9,topk_weight=w9,**self.kw)
        self.last_logits,self.last_ids,self.last_weights=logits,i9,w9
        return out
