"""Recompute the GLM-5.2 MTP serving time budget from saved measurements."""
import argparse
import json
from pathlib import Path
import statistics


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--serving',type=Path,required=True)
    p.add_argument('--replay',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--moe-layers',type=int,default=75)
    a=p.parse_args();assert a.moe_layers>0
    rows=[]
    for c in (1,2,4,8,16,32):
        timing=json.loads((a.replay/f'c{c}.json').read_text())['latency_us']
        arm={}
        for backend in ('aiter','port_ew'):
            reps=[json.loads((a.serving/backend/f'c{c}-r{index}.json').read_text()) for index in range(3)]
            requests=[record for rep in reps for record in rep['records']]
            assert requests and all(r['meta']['completion_tokens']==1024 for r in requests)
            elapsed_ms=[1000*(r['events'][-1][1]-r['events'][0][1]) for r in requests]
            verifications=[r['meta']['spec_verify_ct'] for r in requests]
            arm[backend]=dict(requests=len(requests),mean_verifications=statistics.mean(verifications),
                mean_acceptance_length=statistics.mean(r['meta']['spec_accept_length'] for r in requests),
                mean_decode_ms_per_output_token=sum(elapsed_ms)/(1023*len(requests)),
                pooled_ms_per_verification=sum(elapsed_ms)/sum(verifications),
                median_itl_ms=1000*statistics.median(rep['token_normalized_itl_median_s'] for rep in reps),
                p95_itl_ms=1000*statistics.median(rep['token_normalized_itl_p95_s'] for rep in reps),
                median_output_tok_s=statistics.median(rep['output_tokens_s'] for rep in reps),
                median_ttft_ms=1000*statistics.median(rep['ttft_median_s'] for rep in reps))
        old,new=arm['aiter'],arm['port_ew']
        model_aiter_ms=a.moe_layers*timing['aiter']/1000
        model_port_ms=a.moe_layers*timing['port_internal']/1000
        rows.append(dict(concurrency=c,moe_rows=c*4,moe_layers=a.moe_layers,
            per_layer_aiter_us=timing['aiter'],per_layer_port_bf16_us=timing['port_internal'],
            model_moe_aiter_ms=model_aiter_ms,model_moe_port_ms=model_port_ms,
            model_moe_saving_ms=model_aiter_ms-model_port_ms,
            measured_client_ms_per_verification_saving=old['pooled_ms_per_verification']-new['pooled_ms_per_verification'],
            inferred_model_moe_fraction_of_client_verification=model_aiter_ms/old['pooled_ms_per_verification'],
            verification_count_change_pct=100*(new['mean_verifications']/old['mean_verifications']-1),
            median_itl_reduction_pct=100*(1-new['median_itl_ms']/old['median_itl_ms']),
            mean_decode_per_token_reduction_pct=100*(1-new['mean_decode_ms_per_output_token']/old['mean_decode_ms_per_output_token']),
            median_output_throughput_gain_pct=100*(new['median_output_tok_s']/old['median_output_tok_s']-1),
            arms=arm))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(dict(serving=str(a.serving),replay=str(a.replay),rows=rows),indent=2)+'\n')


if __name__=='__main__':main()
