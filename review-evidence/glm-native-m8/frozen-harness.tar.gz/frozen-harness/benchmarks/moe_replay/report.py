"""Offline paired latency, instrumentation and in-model calibration summaries."""
import argparse,csv,json
from pathlib import Path
import statistics as st
from .protocol import load_metadata


def table(path,rows):
    if not rows:return
    with path.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)


def model_records(root,b):
    if root is None:return {}
    p=root/f'b{b}-s355052/capture.json'
    if not p.exists():return {}
    m=load_metadata(p.parent)
    return {(s['decode_step'],int(l)):dict(us=v,graph_rows=s['graph_rows'],actual=s['actual_token_count'])
            for s in m.get('timings',[]) for l,v in s['layer_us'].items()}


def prefixes(root,b):
    if root is None:return {}
    path=root/f'b{b}-s355052/capture.json'
    if not path.exists():return {}
    result={}
    for step in json.loads(path.read_text())['steps']:
        for rid,ids in zip(step['request_ids'],step.get('generated_token_ids',[])):
            if len(ids)>len(result.get(rid,[])):result[rid]=ids
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--model-aiter',type=Path);p.add_argument('--model-port',type=Path)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    rows=[];summaries=[]
    for path in sorted(a.results.glob('b*.json'),key=lambda p:int(p.stem[1:])):
        r=json.loads(path.read_text());assert r['qualified']
        assert all(r['graph_checks'].values()) and len(r['checks'])==len(r['sequence'])
        assert all(c['exact_routes'] and all(c[k]['passed'] for k in ('native_capture','aiter_reference','port_reference')) for c in r['checks'])
        n=len(r['sequence']);t=r['timing'];b=r['batch']
        ma=model_records(a.model_aiter,b);mp=model_records(a.model_port,b)
        for i,c in enumerate(r['sequence']):
            av=t['aiter_preload_events']['interval_medians_us'][i]
            pv=t['port_ew_preload_events']['interval_medians_us'][i]
            model=ma.get((c['decode_step'],c['layer']))
            matched=model and model['graph_rows']==c['graph_rows'] and model['actual']==c['actual_token_count']
            portmodel=mp.get((c['decode_step'],c['layer']))
            row=dict(requested_batch=b,decode_step=c['decode_step'],layer=c['layer'],
                actual_tokens=c['actual_token_count'],scheduled_rows=c['scheduled_rows'],graph_rows=c['graph_rows'],
                aiter_us=av,port_ew_us=pv,port_latency_reduction_percent=100*(1-pv/av),
                model_aiter_us=model['us'] if matched else '',
                replay_vs_model_percent=100*(av/model['us']-1) if matched else '',
                model_port_us=portmodel['us'] if portmodel and portmodel['graph_rows']==c['graph_rows'] and portmodel['actual']==c['actual_token_count'] else '')
            rows.append(row)
        entry=dict(requested_batch=b,calls=n,layers=len({c['layer'] for c in r['sequence']}),
            steps=len({c['decode_step'] for c in r['sequence']}),actual_tokens=sorted({c['actual_token_count'] for c in r['sequence']}))
        for variant in ('aiter','port_ew'):
            event=t[variant+'_preload_events'];plain=t[variant+'_preload_plain']
            entry[variant+'_moe_us']=st.mean(event['interval_medians_us'])
            entry[variant+'_preload_plain_us']=plain['graph_median_us']/n
            entry[variant+'_marker_graph_cost_us']=(event['graph_median_us']-plain['graph_median_us'])/n
            entry[variant+'_no_preload_moe_us']=st.mean(t[variant+'_no_preload_events']['interval_medians_us'])
        entry['port_latency_reduction_percent']=100*(1-entry['port_ew_moe_us']/entry['aiter_moe_us'])
        entry['plain_graph_latency_reduction_percent']=100*(1-entry['port_ew_preload_plain_us']/entry['aiter_preload_plain_us'])
        calibrated=[v['replay_vs_model_percent'] for v in rows if v['requested_batch']==b and v['replay_vs_model_percent']!='']
        repeats=[v for c in r['checks'] for v in c.get('native_router_repeats',[])]
        entry['native_router_repeat_checks']=len(repeats)
        entry['native_router_repeats_with_slot_changes']=sum(v['route_slots_changed']>0 for v in repeats)
        entry['max_router_logit_repeat_difference']=max((v['logit_max_abs'] for v in repeats),default=0)
        matched_rows=[v for v in rows if v['requested_batch']==b and v['model_aiter_us']!='' and v['model_port_us']!='']
        entry['model_aiter_us']=st.mean(v['model_aiter_us'] for v in matched_rows) if matched_rows else None
        entry['model_port_us']=st.mean(v['model_port_us'] for v in matched_rows) if matched_rows else None
        entry['model_port_latency_reduction_percent']=100*(1-entry['model_port_us']/entry['model_aiter_us']) if matched_rows else None
        entry['calibrated_calls']=len(calibrated)
        entry['calibration_median_percent']=st.median(calibrated) if calibrated else None
        entry['port_calibration_median_percent']=st.median(100*(v['port_ew_us']/v['model_port_us']-1) for v in matched_rows) if matched_rows else None
        ap,pp=prefixes(a.model_aiter,b),prefixes(a.model_port,b)
        shared=ap.keys() & pp.keys()
        entry['prefix_requests_compared']=len(shared)
        entry['equal_available_prefix_requests']=sum(ap[rid][:min(len(ap[rid]),len(pp[rid]))]==pp[rid][:min(len(ap[rid]),len(pp[rid]))] for rid in shared)
        summaries.append(entry)
    table(a.output/'per-call.csv',rows)
    table(a.output/'summary.csv',summaries)
    for fields,name in [(('actual_tokens','layer'),'by-actual-count-layer.csv'),(('requested_batch','decode_step'),'by-step.csv')]:
        groups={}
        for r in rows:groups.setdefault(tuple(r[k] for k in fields),[]).append(r)
        out=[]
        for key,rs in sorted(groups.items()):
            av=st.mean(r['aiter_us'] for r in rs);pv=st.mean(r['port_ew_us'] for r in rs)
            out.append(dict(zip(fields,key),calls=len(rs),aiter_us=av,port_ew_us=pv,port_latency_reduction_percent=100*(1-pv/av)))
        table(a.output/name,out)
    (a.output/'summary.json').write_text(json.dumps(dict(batches=summaries,total_calls=len(rows)),indent=2)+'\n')
    lines=['# Ordered multi-layer MoE replay','',
        'MI355X, GLM-5.2 MXFP4, TP8/EP1 rank 0. Native HIP event intervals cover router GEMM through local combine, '
        'including shared experts. Input preloads, TP communication, normalization and residuals are outside the interval.', '',
        '| Requested B | Calls | Actual token counts | AITER µs | Port-EW µs | Port latency reduction |',
        '|---:|---:|---|---:|---:|---:|']
    for r in summaries:lines.append(f"| {r['requested_batch']} | {r['calls']} | {r['actual_tokens']} | {r['aiter_moe_us']:.2f} | {r['port_ew_moe_us']:.2f} | {r['port_latency_reduction_percent']:.2f}% |")
    lines+=['','Values are means of per-call medians, keeping each captured step/layer equally weighted. '
        'Graph execution shape and actual live tokens are reported separately; padded or finished rows are not counted as useful tokens.', '',
        '| B | AITER / Port plain graph µs per call | Event-pair graph cost AITER / Port µs | Plain graph latency reduction |',
        '|---:|---:|---:|---:|']
    for r in summaries:lines.append(f"| {r['requested_batch']} | {r['aiter_preload_plain_us']:.2f} / {r['port_ew_preload_plain_us']:.2f} | {r['aiter_marker_graph_cost_us']:.2f} / {r['port_ew_marker_graph_cost_us']:.2f} | {r['plain_graph_latency_reduction_percent']:.2f}% |")
    lines+=['','Plain graphs include exactly the same input preloads but omit internal timer nodes. '
        'These are controls for instrumentation effects, not preload-subtracted MoE measurements. '
        'Event intervals retain their measurement overhead; no constant has been subtracted.', '',
        '| B | Matched in-model native intervals | Median replay vs model: AITER | Median replay vs model: Port |',
        '|---:|---:|---:|---:|']
    for r in summaries:
        delta='not available' if r['calibration_median_percent'] is None else f"{r['calibration_median_percent']:.2f}%"
        pd='not available' if r['port_calibration_median_percent'] is None else f"{r['port_calibration_median_percent']:.2f}%"
        lines.append(f"| {r['requested_batch']} | {r['calibrated_calls']} | {delta} | {pd} |")
    lines+=['', 'The Port model arm uses the benchmark override to exercise all seven supported shapes. Its capture audit confirms Port-EW on all 8 ranks and all 75 MoE layers; the default serving allowlist is unchanged.', '', '| B | In-model AITER / Port local µs | In-model Port latency reduction |', '|---:|---:|---:|']
    for r in summaries:
        if r['model_aiter_us'] is not None:
            lines.append(f"| {r['requested_batch']} | {r['model_aiter_us']:.2f} / {r['model_port_us']:.2f} | {r['model_port_latency_reduction_percent']:.2f}% |")
    lines+=['','In-model timing is a separate TP8 pass with no capture copies. It drains selected forwards to read event pairs; '
        'its request throughput is not a serving result. Matching shapes/steps do not alone prove identical hidden states between '
        'separate generations. The standalone pairs ran on MI355X node 2; the full TP8 pairs ran on node 3. '
        'This is a workload-level comparison, not a same-device proof of exact cache-state reproduction. '
        f"Available generated prefixes agree for {sum(r['equal_available_prefix_requests'] for r in summaries)} / "
        f"{sum(r['prefix_requests_compared'] for r in summaries)} compared requests. "
        'Thus matching prompts alone does not hold hidden states fixed. '
        'The standalone arms do use identical saved inputs. No generation-accuracy equivalence is established by these timings.', '',
        'See README and provenance for validation, exact runtime/source identities, raw samples and coverage limitations.','']
    lines += ['', 'Native BF16 router variability is measured in separate repeats. Exact route/output checks use captured logits; timed paths recompute the real router. Slot-order changes are not automatically changes to the selected expert set.', '', '| B | Native repeats with routing-slot changes / checks | Max logit difference |', '|---:|---:|---:|']
    for r in summaries:
        lines.append(f"| {r['requested_batch']} | {r['native_router_repeats_with_slot_changes']} / {r['native_router_repeat_checks']} | {r['max_router_logit_repeat_difference']:.6g} |")
    lines += ['', '![Per-layer latency reduction](by-layer.png)', '']
    (a.output/'REPORT.md').write_text('\n'.join(lines))
    plot(a.output,rows)


def plot(dest,rows):
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    batches=sorted({r['requested_batch'] for r in rows});layers=sorted({r['layer'] for r in rows})
    matrix=np.array([[st.mean(r['port_latency_reduction_percent'] for r in rows if r['requested_batch']==b and r['layer']==l) for l in layers] for b in batches])
    fig,ax=plt.subplots(figsize=(13,4),layout='constrained')
    bound=max(1,float(np.abs(matrix).max()))
    im=ax.imshow(matrix,cmap='RdBu',vmin=-bound,vmax=bound,aspect='auto')
    ax.set_xticks(range(len(layers)),layers,rotation=90);ax.set_yticks(range(len(batches)),batches)
    ax.set(xlabel='Model layer',ylabel='Requested batch',title='Port-EW latency reduction vs AITER (positive is faster)')
    fig.colorbar(im,ax=ax,label='Latency reduction (%)')
    fig.savefig(dest/'by-layer.png',dpi=160);plt.close(fig)


if __name__=='__main__':main()
