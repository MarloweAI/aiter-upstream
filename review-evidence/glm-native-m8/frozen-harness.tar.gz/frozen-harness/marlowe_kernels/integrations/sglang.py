"""Opt-in post-router hook for the SGLang revision recorded in runtime-lock.json.

This module never monkeypatches SGLang. The small accompanying source patch
calls try_moe before native top-k and preserves the surrounding TP collective.
"""
import logging
import json
import os
from dataclasses import replace
from functools import cache
from pathlib import Path

from marlowe_kernels import MoEConfig, MoEWeights, UnsupportedConfiguration, create_moe, supports

log = logging.getLogger(__name__)
# EAGLE 3-1-4 target verification uses four MoE rows per request. These row
# counts cover request concurrency 1-32; integration remains opt-in.
SERVING_BATCHES = (1, 2, 4, 8, 16, 32, 64, 128)


@cache
def enabled():
    return os.environ.get("SGLANG_USE_MARLOWE_KERNELS", "0") == "1"


@cache
def benchmark_all():
    return os.environ.get('MARLOWE_KERNELS_BENCHMARK_ALL','0')=='1'


@cache
def native_topk():
    """Preserve the target framework's route ordering and tie selection."""
    return (os.environ.get('MARLOWE_KERNELS_NATIVE_TOPK','0')=='1' or
            os.environ.get('MARLOWE_KERNELS_NATIVE_COMBINE','0')=='1')


@cache
def fp32_internal():
    """Opt-in until the FP32 selection and full-model quality are qualified."""
    return os.environ.get('MARLOWE_KERNELS_FP32_INTERNAL','0')=='1'


def selected_batch(batch):
    return supports(MoEConfig(),batch) and (batch in SERVING_BATCHES or benchmark_all())


def eligibility(block, x, config, *, skip_shared_experts, dispatch_info, num_token_non_padded):
    """Cheap host-metadata guards; never read values from a GPU tensor."""
    if not enabled():
        return "disabled"
    if getattr(block, "_marlowe_model_type", None) != "glm_moe_dsa":
        return "model"
    if block.tp_size != 8 or block.moe_ep_size != 1 or block._enable_a2a_moe:
        return "topology"
    if not supports(MoEConfig(), len(x)):
        return "batch"
    if not selected_batch(len(x)):
        return "native serving policy"
    if skip_shared_experts or block.num_fused_shared_experts != 1 or getattr(block, "_shared_expert_tp1", False):
        return "shared experts"
    if getattr(block, "_fuse_shared_experts_inside_sbo", False):
        return "shared expert overlap"
    if dispatch_info is not None or num_token_non_padded is not None or getattr(block, "is_hash", False):
        return "remapping/padding/hash routing"
    expected = dict(top_k=9, num_fused_shared_experts=1, use_grouped_topk=True,
                    topk_group=1, num_expert_group=1, renormalize=True,
                    routed_scaling_factor=2.5, apply_routed_scaling_factor_on_output=False)
    if any(getattr(config,k,None) != v for k,v in expected.items()):
        return "routing configuration"
    if config.custom_routing_function is not None or config.torch_native:
        return "custom routing"
    if config.scoring_func != "sigmoid" or config.fused_shared_experts_scaling_factor not in (None,1.0):
        return "score/shared scaling"
    if getattr(block.topk, "enable_waterfill", False) or getattr(block.topk, "waterfill_balancer", None) is not None:
        return "waterfill"
    return None


def try_moe(block, x, logits, *, skip_shared_experts=False, dispatch_info=None, num_token_non_padded=None):
    if not enabled():
        return None
    import torch
    from sglang.srt.layers.moe import topk as tk
    c = block.topk.topk_config
    reason = eligibility(block,x,c,skip_shared_experts=skip_shared_experts,
                         dispatch_info=dispatch_info,num_token_non_padded=num_token_non_padded)
    if reason:
        return None
    if (tk._eplb_remap_enabled() or tk.has_per_rank_fused_shared_slots(1)
        or tk.envs.SGLANG_SIMULATE_UNIFORM_EXPERTS.get()
        or tk.envs.SGLANG_SIMULATE_ROUND_ROBIN_EXPERTS.get()):
        return None
    if logits.dtype not in (torch.bfloat16,torch.float32) or not logits.is_contiguous():
        return None
    bias = c.correction_bias_for_dtype(logits.dtype)
    routing = ("supplied" if native_topk() else
               "internal_fp32" if logits.dtype == torch.float32 and fp32_internal() else
               "supplied" if logits.dtype == torch.float32 else "internal")
    if bias is None or not bias.is_contiguous() or (routing == 'internal' and bias.dtype != logits.dtype):
        return None
    handle = getattr(block, "_marlowe_handle", None)
    if handle is False:
        return None
    if handle is None:
        if torch.cuda.is_current_stream_capturing():
            raise RuntimeError("Marlowe MoE must execute an eager warmup before graph capture")
        layer = block.experts
        scheme = getattr(layer, "scheme", None)
        if type(scheme).__name__ != "QuarkW4A4MXFp4MoE":
            log.info("Marlowe fallback layer=%s: unsupported quantization scheme %s", block.layer_id, type(scheme).__name__)
            block._marlowe_handle = False
            return None
        if not all(getattr(t,"is_shuffled",False) for t in (layer.w13_weight,layer.w2_weight)):
            block._marlowe_handle = False
            return None
        try:
            handle = create_moe(MoEConfig(),MoEWeights(layer.w13_weight,layer.w2_weight,
                                                     layer.w13_weight_scale,layer.w2_weight_scale))
        except UnsupportedConfiguration as exc:
            log.info("Marlowe fallback layer=%s: %s", block.layer_id, exc)
            block._marlowe_handle = False
            return None
        block._marlowe_handle = handle
    b = len(x)
    if (b,routing) not in handle._prepared_modes:
        handle.warmup((b,),routing=routing)
        log.info("Marlowe Port-EW prepared rank=%s layer=%s tokens=%s", torch.distributed.get_rank(), block.layer_id, b)
        audit = os.environ.get("MARLOWE_KERNELS_AUDIT_DIR")
        if audit:
            from marlowe_kernels._runtime import source_digest
            root=Path(audit);root.mkdir(parents=True,exist_ok=True)
            rank=torch.distributed.get_rank()
            (root/f"rank{rank}-layer{block.layer_id}-b{b}.json").write_text(json.dumps(dict(
                rank=rank,layer=block.layer_id,tokens=b,implementation='port_ew',
                library_source=source_digest(),graph_capture=False,routing=routing,
                router_dtype=str(logits.dtype)))+"\n")
    if routing == "supplied":
        routed_config=getattr(block,"_marlowe_routed_config",None)
        if routed_config is None:
            routed_config=replace(c,top_k=8,num_fused_shared_experts=0,fused_shared_experts_scaling_factor=None)
            block._marlowe_routed_config=routed_config
        selected=tk.select_experts(x,logits,routed_config,layer_id=block.layer_id,
                                  num_token_non_padded=None,expert_location_dispatch_info=None)
        # Native selection already records routed experts. Preparation appends
        # the shared slot; there is no second native append or recorder call.
        output=handle.forward_routed(x,selected.topk_ids,selected.topk_weights)
        _record_capture(block,b,routing)
        _bridge(block,handle,x,logits,c,output,routing)
        return output
    output = handle.forward_fp32(x,logits,bias) if routing=='internal_fp32' else handle(x,logits,bias)
    ids, weights = handle.routing(b,routing=routing)
    # Preserve routed-expert capture and distribution recording. Shared append
    # and remapping are excluded by eligibility; Port-EW already appends 256/1.
    tk.capture_routed_experts_if_allowed(c,block.layer_id,ids[:,:8])
    tk.get_global_expert_distribution_recorder().on_select_experts(topk_ids=ids[:,:8])
    _record_capture(block,b,routing)
    _bridge(block,handle,x,logits,c,output,routing)
    return output


def _record_capture(block,b,routing):
    audit=os.environ.get('MARLOWE_KERNELS_AUDIT_DIR')
    if not audit:return
    import torch
    if not torch.cuda.is_current_stream_capturing():return
    seen=getattr(block,'_marlowe_captured',set())
    if (b,routing) in seen:return
    rank=torch.distributed.get_rank()
    (Path(audit)/f'capture-rank{rank}-layer{block.layer_id}-b{b}.json').write_text(json.dumps(dict(
        rank=rank,layer=block.layer_id,tokens=b,routing=routing,implementation='port_ew',graph_capture=True))+"\n")
    seen.add((b,routing));block._marlowe_captured=seen


def _bridge(block,handle,x,logits,c,output,routing):
    """One startup check on sampled layers, never inside a captured/timed graph."""
    if os.environ.get('MARLOWE_KERNELS_VALIDATE','0')!='1' or block.layer_id not in (3,40,48):return
    import torch
    key=(len(x),routing)
    seen=getattr(block,'_marlowe_bridged',set())
    if key in seen or torch.cuda.is_current_stream_capturing():return
    from sglang.srt.layers.moe import topk as tk
    import aiter
    from aiter.fused_moe import fused_moe
    native=tk.select_experts(x,logits,c,layer_id=block.layer_id,num_token_non_padded=None,expert_location_dispatch_info=None)
    w1,w2=handle.w13.view(handle.w13.dtype),handle.w2.view(handle.w2.dtype)
    w1.is_shuffled=w2.is_shuffled=True
    ids,weights=(v.clone() for v in handle.routing(len(x),routing=routing))
    aiter_same_routes=fused_moe(x.clone(),w1,w2,weights,ids,
                       activation=aiter.ActivationType.Silu,quant_type=aiter.QuantType.per_1x32,
                       w1_scale=handle.weights.w13_scale,w2_scale=handle.weights.w2_scale)
    native_expected=fused_moe(x.clone(),w1,w2,native.topk_weights,native.topk_ids,
                       activation=aiter.ActivationType.Silu,quant_type=aiter.QuantType.per_1x32,
                       w1_scale=handle.weights.w13_scale,w2_scale=handle.weights.w2_scale)
    from .moe_reference import expert_reference
    programs=(handle._fp32_programs if routing=='internal_fp32' else
              handle._native_programs if routing in ('supplied','native') and handle.implementation=='port_ew'
              else handle._programs)
    fp32_middle=programs[len(x)].fp32_middle
    old_tf32=torch.backends.cuda.matmul.allow_tf32
    try:
        torch.backends.cuda.matmul.allow_tf32=False
        expected=expert_reference(dict(w1=w1,w2=w2,w1_scale=handle.weights.w13_scale,
            w2_scale=handle.weights.w2_scale),x,ids,weights,fp32_middle)
    finally:
        torch.backends.cuda.matmul.allow_tf32=old_tf32
    torch.cuda.synchronize()
    selected=ids[:,:8].long()
    ordered=selected.sort(1).values
    valid_ids=bool(((selected>=0)&(selected<256)).all() and
                   (ordered[:,1:]!=ordered[:,:-1]).all() and (ids[:,8]==256).all())
    probabilities=torch.sigmoid(logits.float()).gather(1,selected.clamp(0,255))
    weight_reference=probabilities/probabilities.sum(1,keepdim=True)*2.5
    weight_error=float((weights[:,:8]-weight_reference).abs().max())
    valid_weights=bool(torch.isfinite(weights).all() and (weights[:,8]==1).all()) and weight_error<=2e-6
    error=(output.float()-expected.float())
    denom=expected.float().square().mean().sqrt().clamp_min(1e-12)
    nrmse=float(error.square().mean().sqrt()/denom)
    checks=dict(comparison='independent FP32 GEMM and MXFP4 algebra for the selected Port-EW rounding contract',
                fp32_middle=bool(fp32_middle),
                aiter_same_route_nrmse_diagnostic=float((output.float()-aiter_same_routes.float()).square().mean().sqrt()/
                    aiter_same_routes.float().square().mean().sqrt().clamp_min(1e-12)),
                valid_route_ids=valid_ids,valid_route_weights=valid_weights,
                route_weight_reference_max_abs=weight_error,
                native_route_diagnostic=dict(exact_ids=bool(torch.equal(ids,native.topk_ids)),
                    changed_expert_set_rows=int((ordered!=native.topk_ids[:,:8].sort(1).values).any(1).sum()),
                    weights_max_abs_by_slot=float((weights-native.topk_weights).abs().max()),
                    output_nrmse=float((output.float()-native_expected.float()).square().mean().sqrt()/
                                       native_expected.float().square().mean().sqrt().clamp_min(1e-12))),
                finite=bool(torch.isfinite(output).all()),
                elementwise=bool(torch.allclose(output,expected,rtol=.02,atol=.02)),nrmse=nrmse)
    checks['passed']=valid_ids and valid_weights and checks['finite'] and checks['elementwise'] and nrmse<=.01
    audit=os.environ.get('MARLOWE_KERNELS_AUDIT_DIR')
    if audit:
        path=Path(audit)/f'bridge-rank{torch.distributed.get_rank()}-layer{block.layer_id}-b{len(x)}.json'
        path.write_text(json.dumps(dict(checks, rank=torch.distributed.get_rank(),
            layer=block.layer_id, tokens=len(x), routing=routing,
            router_dtype=str(logits.dtype)))+'\n')
        if not checks['passed']:
            torch.save(dict(input=x.cpu(),logits=logits.cpu(),ids=ids.cpu(),weights=weights.cpu(),
                native_ids=native.topk_ids.cpu(),native_weights=native.topk_weights.cpu(),
                output=output.cpu(),independent_reference=expected.cpu(),
                same_route_reference=aiter_same_routes.cpu(),native_output=native_expected.cpu()),
                path.with_suffix('.pt'))
    if not checks['passed']:raise RuntimeError(f'Marlowe native startup bridge failed: {checks}')
    seen.add(key);block._marlowe_bridged=seen
