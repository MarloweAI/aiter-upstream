"""Bounded actual-checkpoint integration qualification, separate from serving timing.

One full native Engine is reused for all seven C values and padding boundaries.
Identical real token prefixes make
the high-concurrency check affordable without changing model depth, weights or
TP. This is explicitly a correctness workload, never a serving performance row.
"""

from __future__ import annotations

import argparse
import functools
import hashlib
import json
import os
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

TARGET_CONCURRENCIES = (1, 2, 4, 8, 16, 32)
COHORTS = (1, 2, 3, 4, 8, 9, 15, 16, 31, 32)


def native_worker(manifest: str, *args, **kwargs):
    from presentation_serving_adapter import NativeAdapter
    from sglang.srt.managers.scheduler import run_scheduler_process

    adapter = NativeAdapter(Path(manifest))
    adapter.install()
    return run_scheduler_process(*args, **kwargs)


def server_arguments(model: Path, *, graphs: bool = False) -> dict:
    return {
        "model_path": str(model),
        "served_model_name": "amd/GLM-5.2-MXFP4",
        "trust_remote_code": True,
        "dtype": "bfloat16",
        "quantization": "quark",
        "weight_loader_disable_mmap": True,
        "model_loader_extra_config": '{"enable_multithread_load":true,"num_threads":2}',
        "kv_cache_dtype": "fp8_e4m3",
        "dsa_prefill_backend": "tilelang",
        "dsa_decode_backend": "tilelang",
        "tool_call_parser": "glm47",
        "reasoning_parser": "glm45",
        "watchdog_timeout": 1800,
        "enable_metrics": True,
        "tp_size": 8,
        "ep_size": 1,
        "mem_fraction_static": 0.65,
        "speculative_algorithm": "EAGLE",
        "speculative_num_steps": 3,
        "speculative_eagle_topk": 1,
        "speculative_num_draft_tokens": 4,
        "chunked_prefill_size": 8192,
        "context_length": 10240,
        "max_total_tokens": 327680,
        "max_running_requests": 32,
        "random_seed": 355052,
        "cuda_graph_max_bs": 32,
        "cuda_graph_bs_decode": list(TARGET_CONCURRENCIES),
        "disable_radix_cache": True,
        # The diagnostic checker synchronizes/copies actual tensors. Keep it
        # outside graph capture. The separate clean serving run retains graphs.
        "disable_cuda_graph": not graphs,
    }


def server_cli_arguments(model: Path, *, graphs: bool = False) -> list[str]:
    """Use the same public CLI aliases as the frozen native serving protocol."""
    argv = []
    for name, value in server_arguments(model, graphs=graphs).items():
        cli_name = "cuda_graph_max_bs_decode" if name == "cuda_graph_max_bs" else name
        flag = "--" + cli_name.replace("_", "-")
        if isinstance(value, bool):
            if value:
                argv.append(flag)
        elif isinstance(value, list):
            argv.extend((flag, *map(str, value)))
        else:
            argv.extend((flag, str(value)))
    return argv


def validate_server_configuration(resolved: dict, *, graphs: bool) -> None:
    """Reject a parser/alias migration that changes the requested workload."""
    expected = {
        "tp_size": 8,
        "ep_size": 1,
        "max_running_requests": 32,
        "random_seed": 355052,
        "cuda_graph_max_bs_decode": 32,
        "speculative_num_steps": 3,
        "speculative_eagle_topk": 1,
        "speculative_num_draft_tokens": 4,
        "kv_cache_dtype": "fp8_e4m3",
        "chunked_prefill_size": 8192,
        "quantization": "quark",
        "dtype": "bfloat16",
    }
    for name, value in expected.items():
        if resolved.get(name) != value:
            raise ValueError(
                f"Resolved server setting changed: {name}={resolved.get(name)!r}, expected {value!r}"
            )
    decode = resolved.get("cuda_graph_config", {}).get("decode", {})
    if decode.get("backend") != ("full" if graphs else "disabled"):
        raise ValueError(f"Resolved decode graph backend differs: {decode!r}")
    if decode.get("bs") != list(TARGET_CONCURRENCIES):
        raise ValueError(f"Qualification graph buckets differ from serving: {decode!r}")


def eager_overlay_compatibility(
    manifest: dict, previous_sha: str, current_sha: str
) -> dict:
    """Permit the two reviewed graph repairs, preserving the eligible eager paths."""
    import ast

    from presentation_serving import checked_artifact, require

    parent_ref = manifest.get("eager_compatibility_parent", {})
    require(
        parent_ref.get("sha256") == previous_sha,
        "Graph/eager serving overlay differs: wrong compatibility parent",
    )
    parent = json.loads(checked_artifact(parent_ref).read_text())
    scope = manifest.get("native_scope_fallback")
    for field in (
        "recipe_sha256",
        "native_source_hashes",
        "operator_modules",
        "common_serving_wrapper",
        "excluded_serving_concurrencies",
    ):
        require(
            parent.get(field) == manifest.get(field),
            f"Eager compatibility changed {field}",
        )
    if scope is None:
        require(
            parent["routes"] == manifest["routes"], "Eager compatibility changed routes"
        )
    else:
        excluded = [16, 32, 64]
        require(
            scope.get("schema") == "presentation-excluded-native-scope-v1"
            and scope.get("concurrencies") == excluded
            and manifest.get("excluded_serving_concurrencies") == excluded,
            "Native scope compatibility is not the reviewed excluded set",
        )
        keys = {f"c{c}-{role}" for c in excluded for role in ("anchor", "shared")}
        require(
            scope.get("original_routes")
            == {key: parent["routes"][key] for key in keys},
            "Native scope compatibility lost its original routes",
        )
        expected = {key: dict(row) for key, row in parent["routes"].items()}
        for key in keys:
            expected[key].update(
                dict.fromkeys(
                    (
                        "preparation",
                        "query",
                        "query_projection",
                        "input",
                        "input_projection",
                        "indexer",
                        "output",
                        "value",
                        "index_stream",
                    ),
                    "native",
                ),
                core="native_tilelang",
            )
        require(
            manifest["routes"] == expected,
            "Native scope compatibility changed an eligible route or non-dispatch field",
        )

    def files(value):
        overlay_root = Path(value["adapter_root"]).parent
        result = {}
        for ref in value["files"]:
            path = Path(ref["path"])
            key = (
                str(path.relative_to(overlay_root))
                if path.is_relative_to(overlay_root)
                else str(path)
            )
            require(key not in result, "Duplicate compatibility source")
            result[key] = ref
        return result

    before, after = files(parent), files(manifest)
    require(
        before.keys() == after.keys(), "Eager compatibility changed source inventory"
    )
    adapter = "runner/presentation_serving_adapter.py"
    smoke = "runner/presentation_serving_smoke.py"
    for key in before.keys() - {adapter, smoke}:
        require(
            before[key]["sha256"] == after[key]["sha256"],
            f"Eager compatibility changed source: {key}",
        )
    old_adapter = checked_artifact(before[adapter]).read_text()
    new_adapter = checked_artifact(after[adapter]).read_text()
    guard = '        if self.mode == "qualify":\n            self.checks ='
    replacement = (
        '        if self.mode in ("qualify", "graph"):\n            self.checks ='
    )
    if scope is None:
        require(
            old_adapter.count(guard) == 1
            and new_adapter == old_adapter.replace(guard, replacement),
            "Adapter differs beyond the reviewed graph import guard",
        )
    else:
        require(
            old_adapter == new_adapter,
            "Native scope compatibility changed adapter source",
        )

    def eager_ast(ref):
        tree = ast.parse(checked_artifact(ref).read_text())
        tree.body = [
            node
            for node in tree.body
            if not (
                isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name in {"finish_graph_check", "eager_overlay_compatibility"}
            )
        ]
        return ast.dump(tree, include_attributes=False)

    require(
        eager_ast(before[smoke]) == eager_ast(after[smoke]),
        "Smoke changed its eager/configuration path",
    )
    return {
        "classification": (
            "reviewed excluded-C native dispatch; unchanged C1/2/4/8 eager and operator paths"
            if scope is not None
            else "reviewed graph-reference import repair; unchanged eager and operator paths"
        ),
        "native_scope_fallback": scope,
        "previous_overlay": parent_ref,
        "previous_overlay_sha256": previous_sha,
        "current_overlay_sha256": current_sha,
        "adapter_before": before[adapter],
        "adapter_after": after[adapter],
        "smoke_before": before[smoke],
        "smoke_after": after[smoke],
        "passed": True,
    }


def finish_graph_check(
    output: Path,
    reference: Path,
    manifest: dict,
    events: list,
    evidence: list,
    *,
    serving_overlay_sha256: str,
) -> None:
    from presentation_serving import (
        artifact,
        graph_numerical_coverage,
        reachable_buckets,
        require,
        write,
    )
    from presentation_serving_adapter import collect_engagement

    eager = json.loads((reference / "integration-receipt.json").read_text())
    require(
        eager["status"] in ("pending_graph_checks", "partial_eager"),
        "Missing eager qualification",
    )
    require(
        eager["recipe_sha256"] == manifest["recipe_sha256"],
        "Graph/eager recipe differs",
    )
    previous_sha = eager.get("serving_overlay_sha256")
    compatibility = None
    if previous_sha != serving_overlay_sha256:
        compatibility = eager_overlay_compatibility(
            manifest, previous_sha, serving_overlay_sha256
        )
    left = json.loads((reference / "integration-input.json").read_text())
    right = json.loads((output / "integration-input.json").read_text())
    require(
        left["input_sha256"] == right["input_sha256"]
        and left["output_tokens"] == right["output_tokens"],
        "Graph/eager request differs",
    )
    require(
        left["manifest"]["sha256"] == previous_sha
        and right["manifest"]["sha256"] == serving_overlay_sha256,
        "Graph/eager manifest evidence differs from the current overlay",
    )
    buckets = right["resolved_server_arguments"]["cuda_graph_config"]["decode"]["bs"]
    comparisons = {}
    for c in COHORTS:
        a = json.loads((reference / f"cohort-c{c}.json").read_text())
        b = json.loads((output / f"cohort-c{c}.json").read_text())
        require(
            len(a["outputs"]) == len(b["outputs"]) == c, "Incomplete graph/eager cohort"
        )
        comparisons[c] = all(
            x["text_sha256"] == y["text_sha256"]
            for x, y in zip(a["outputs"], b["outputs"])
        )
        evidence.extend(
            (
                artifact(reference / f"cohort-c{c}.json"),
                artifact(output / f"cohort-c{c}.json"),
            )
        )
    engagement = collect_engagement(output, manifest["recipe_sha256"])
    replay = [
        e
        for e in events
        if e["event"] == "model_execution"
        and e["phase"] == "TARGET_VERIFY"
        and e["can_run_graph"]
    ]
    live_state = [e for e in events if e["event"] == "graph_live_state"]
    numerical_events = [e for e in events if e["event"] == "graph_numerical_state"]
    fallback = [
        e
        for e in events
        if e["event"].endswith("_route")
        and e.get("selected") == "native"
        and e.get("phase") != "TARGET_VERIFY"
    ]
    require(
        {e["rank"] for e in fallback} == set(range(8)),
        "Native phase fallback not observed on every rank",
    )
    native_capture = [
        e
        for e in events
        if e["event"] == "core_route"
        and e.get("selected") == "native"
        and e.get("during_capture") is True
        and e["phase"] == "TARGET_VERIFY"
    ]
    numerical = eager.get("numerically_qualified_concurrencies", [])
    scopes = {}
    for c in TARGET_CONCURRENCIES:
        reachable = reachable_buckets(buckets, c)
        optimized = [b for b in reachable if b in TARGET_CONCURRENCIES]
        native = [b for b in reachable if b not in TARGET_CONCURRENCIES]
        # Every unsupported bucket retains the native path on every target layer/rank.
        native_missing = {
            str(b): sorted(
                {(rank, layer) for rank in range(8) for layer in range(78)}
                - {
                    (e["rank"], e["layer_id"])
                    for e in native_capture
                    if e["rows"] == b * 4
                }
            )
            for b in native
        }
        probes = list(optimized)
        padding_probes = [
            p
            for p in (9, 15, 31, 63)
            if p <= c and reachable_buckets(buckets, p)[-1] > p
        ]
        probes.extend(padding_probes)
        replay_checks = {}
        for p in probes:
            padded = reachable_buckets(buckets, p)[-1]
            execution = {
                e["rank"]
                for e in replay
                if e["requests"] == p and e["graph_batch_size"] == padded
            } == set(range(8))
            state = {
                e["rank"]
                for e in live_state
                if e["live_rows"] == 4 * p
                and e["padded_rows"] == 4 * padded
                and e["passed"]
            } == set(range(8))
            replay_checks[str(p)] = bool(
                execution
                and state
                and graph_numerical_coverage(numerical_events, p, padded)
            )
        passed = (
            c not in manifest.get("excluded_serving_concurrencies", [])
            and set(optimized) <= set(numerical)
            and not any(native_missing.values())
            and all(replay_checks.values())
        )
        scopes[str(c)] = {
            "excluded_by_effective_recipe": c
            in manifest.get("excluded_serving_concurrencies", []),
            "reachable_capture_buckets": reachable,
            "required_optimized_concurrencies": optimized,
            "native_fallback_buckets": native,
            "native_capture_missing": native_missing,
            "padding_required": any(b not in buckets for b in range(1, c + 1)),
            "padding_probe_concurrencies": padding_probes,
            "replay_checks": replay_checks,
            "passed": bool(passed),
        }
    qualified = [c for c in TARGET_CONCURRENCIES if scopes[str(c)]["passed"]]
    write(
        output / "graph-comparison.json",
        {
            "comparisons": comparisons,
            "text_comparison_classification": "diagnostic; actual captured tensors use inherited source-conformance gates",
            "graph_numerical_events": numerical_events,
            "replays": replay,
            "live_state": live_state,
            "native_fallback": fallback,
            "concurrency_scope": scopes,
        },
    )
    receipt = dict(eager)
    receipt.update(
        status="qualified" if qualified else "unqualified",
        serving_overlay_sha256=serving_overlay_sha256,
        qualified_concurrencies=qualified,
        decode_capture_buckets=buckets,
        concurrency_scope=scopes,
        graph_numerical_events=numerical_events,
    )
    if compatibility:
        receipt["eager_compatibility"] = {
            **compatibility,
            "parent_eager_receipt": artifact(reference / "integration-receipt.json"),
        }
        evidence.extend(
            compatibility[name]
            for name in (
                "previous_overlay",
                "adapter_before",
                "adapter_after",
                "smoke_before",
                "smoke_after",
            )
        )
        evidence.append(receipt["eager_compatibility"]["parent_eager_receipt"])
    receipt["checks"] = dict(
        eager["checks"],
        padded_rows=bool(qualified),
        native_fallback=True,
        graph_capture_and_replay=bool(qualified),
    )
    receipt["evidence"] = [
        *eager["evidence"],
        *evidence,
        artifact(output / "attest/engagement.json"),
        artifact(output / "graph-comparison.json"),
    ]
    receipt["engagement"] = {
        "status": engagement["status"],
        "checks": engagement["checks"],
    }
    write(output / "integration-receipt.json", receipt)
    require(
        qualified,
        "No requested concurrency passed all reachable numerical/graph checks",
    )
    print(f"INTEGRATION_SCOPED_PASS C={qualified}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--output-tokens", type=int, default=256)
    parser.add_argument("--graph-reference", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("Use a fresh integration output directory")
    args.output.mkdir(parents=True)
    os.environ["PRESENTATION_SERVING_RUN_ROOT"] = str(args.output.resolve())
    os.environ["PRESENTATION_SERVING_MODE"] = (
        "graph" if args.graph_reference else "qualify"
    )
    import torch
    from presentation_serving import artifact, checked_artifact, require, write
    from sglang.srt.entrypoints.engine import Engine
    from sglang.srt.server_args import prepare_server_args
    from transformers import AutoTokenizer

    require(torch.cuda.device_count() == 8, "Smoke requires8 GPUs and the full model")
    config = json.loads((args.model / "config.json").read_text())
    require(config["num_hidden_layers"] == 78, "Wrong checkpoint layer count")
    tokenizer = AutoTokenizer.from_pretrained(str(args.model), trust_remote_code=True)
    rng = random.Random(20260909)
    forbidden = set(tokenizer.all_special_ids)
    vocabulary = [value for value in range(len(tokenizer)) if value not in forbidden]
    prefix = [rng.choice(vocabulary) for _ in range(8192)]
    manifest = json.loads(args.manifest.read_text())
    server_argv = server_cli_arguments(args.model, graphs=bool(args.graph_reference))
    server_args = prepare_server_args(server_argv)
    server_args.resolve_once()
    resolved_server = server_args.resolved_dict()
    write(
        args.output / "server-configuration.json",
        {
            "argv": server_argv,
            "resolved": resolved_server,
            "cli_compatibility": {"--cuda-graph-max-bs": "--cuda-graph-max-bs-decode"},
        },
    )
    validate_server_configuration(resolved_server, graphs=bool(args.graph_reference))
    write(
        args.output / "integration-input.json",
        {
            "model_config": artifact(args.model / "config.json"),
            "manifest": artifact(args.manifest),
            "input_ids": prefix,
            "input_sha256": hashlib.sha256(json.dumps(prefix).encode()).hexdigest(),
            "concurrencies": list(COHORTS),
            "output_tokens": args.output_tokens,
            "classification": "actual native correctness requests; reused prefix; not timed serving evidence",
            "server_arguments": server_arguments(
                args.model, graphs=bool(args.graph_reference)
            ),
            "server_argv": server_argv,
            "resolved_server_arguments": resolved_server,
        },
    )
    worker = functools.partial(native_worker, str(args.manifest.resolve()))

    class CheckedEngine(Engine):
        run_scheduler_process_func = staticmethod(worker)

    engine = CheckedEngine(server_args=server_args)
    try:
        for concurrency in COHORTS:
            print(f"INTEGRATION_BEGIN C={concurrency}", flush=True)
            started = time.time()
            output = engine.generate(
                input_ids=[list(prefix) for _ in range(concurrency)],
                sampling_params={
                    "temperature": 0.0,
                    "max_new_tokens": args.output_tokens,
                    "ignore_eos": True,
                },
            )
            require(
                len(output) == concurrency,
                "Native engine returned incomplete integration cohort",
            )
            require(
                all(
                    item.get("meta_info", {}).get("completion_tokens")
                    == args.output_tokens
                    for item in output
                ),
                "Native integration cohort did not produce the requested tokens",
            )
            write(
                args.output / f"cohort-c{concurrency}.json",
                {
                    "concurrency": concurrency,
                    "started_unix": started,
                    "finished_unix": time.time(),
                    "outputs": [
                        {
                            "meta_info": item.get("meta_info"),
                            "output_token_count": len(item.get("output_ids", [])),
                            "output_ids": item.get("output_ids", []),
                            "text": item.get("text", ""),
                            "text_sha256": hashlib.sha256(
                                item.get("text", "").encode()
                            ).hexdigest(),
                        }
                        for item in output
                    ],
                },
            )
            print(f"INTEGRATION_DONE C={concurrency}", flush=True)
    finally:
        engine.shutdown()
    events = []
    evidence = [
        artifact(args.output / "integration-input.json"),
        artifact(args.output / "server-configuration.json"),
        *(artifact(path) for path in sorted(args.output.glob("cohort-c*.json"))),
    ]
    for path in sorted((args.output / "attest").glob("dispatch-*.jsonl")):
        evidence.append(artifact(path))
        events.extend(json.loads(line) for line in path.read_text().splitlines())
    for event in events:
        refs = event.get("evidence", [])
        for ref in [refs] if isinstance(refs, dict) else refs:
            checked_artifact(ref)
            if ref not in evidence:
                evidence.append(ref)
    models = [event for event in events if event["event"] == "model_registered"]
    checks = [event for event in events if event["event"] == "correctness"]
    if args.graph_reference:
        finish_graph_check(
            args.output,
            args.graph_reference,
            manifest,
            events,
            evidence,
            serving_overlay_sha256=artifact(args.manifest)["sha256"],
        )
        return
    ranks = sorted({event["rank"] for event in models})
    required = set()
    for concurrency in TARGET_CONCURRENCIES:
        for layer, role in ((26, "anchor"), (27, "shared")):
            rows = concurrency * 4
            route = manifest["routes"][f"c{concurrency}-{role}"]
            required.update((("core", layer, rows), ("chained_suffix", layer, rows)))
            if route.get("preparation") == "u02_dual":
                required.add(("preparation", layer, rows))
            if route.get("output") in ("pr5260", "pyg01"):
                required.add(("output_projection", layer, rows))
            if route.get("value") in ("fp8_value", "fused_core_value"):
                required.add(("value_projection", layer, rows))
            if route.get("indexer") in ("f01", "l02", "i01_i04"):
                required.add(("fused_indexer", layer, rows))
            elif route.get("indexer") == "l01":
                required.add(("merged_key_gate", layer, rows))
            if route.get("query", "native") != "native":
                required.add(("query_projection", layer, rows))
            if route.get("input", "native") != "native":
                required.add(("input_projection", layer, rows))
    missing = {
        str(rank): sorted(
            required
            - {
                (event["operation"], event["layer_id"], event["rows"])
                for event in checks
                if event["rank"] == rank
            }
        )
        for rank in ranks
    }
    # Emit observed coverage before refusing it; unsupported transfer remains a
    # truthful gap and cannot pass merely because another kernel was exercised.
    write(
        args.output / "integration-coverage.json",
        {"required": sorted(required), "missing_by_rank": missing, "checks": checks},
    )
    numerical_passed = bool(checks) and all(event["passed"] for event in checks)
    eager_passed = (
        ranks == list(range(8)) and numerical_passed and not any(missing.values())
    )
    numerical_concurrencies = []
    for c in TARGET_CONCURRENCIES:
        required_c = {item for item in required if item[2] == c * 4}
        observed_c = [event for event in checks if event["rows"] == c * 4]
        complete = all(
            required_c
            <= {
                (e["operation"], e["layer_id"], e["rows"])
                for e in observed_c
                if e["rank"] == rank
            }
            for rank in range(8)
        )
        if complete and observed_c and all(e["passed"] for e in observed_c):
            numerical_concurrencies.append(c)
    # Padded-row and graph-replay qualification is a separate required check;
    # eager observations alone deliberately cannot green-light clean timing.
    receipt = {
        "schema": "presentation-serving-integration-v1",
        "status": "pending_graph_checks"
        if eager_passed
        else ("partial_eager" if numerical_concurrencies else "unqualified"),
        "numerically_qualified_concurrencies": numerical_concurrencies,
        "qualified_concurrencies": [],
        "numerical_passed": numerical_passed,
        "serving_overlay_sha256": artifact(args.manifest)["sha256"],
        "failed_checks": [event for event in checks if not event["passed"]],
        "missing_by_rank": missing,
        "recipe_sha256": manifest["recipe_sha256"],
        "full_model_layers": 78,
        "tp_size": 8,
        "ep_size": 1,
        "ranks": ranks,
        "checked_concurrencies": list(TARGET_CONCURRENCIES),
        "checked_layer_roles": ["anchor", "shared"],
        "checks": {
            "checkpoint_weights": True,
            "checkpoint_scales": True,
            "causal_masks": True,
            "kv_history": True,
            "padded_rows": False,
            "native_fallback": False,
            "source_policy": True,
        },
        "evidence": [*evidence, artifact(args.output / "integration-coverage.json")],
    }
    write(args.output / "integration-receipt.json", receipt)
    require(ranks == list(range(8)), "Native integration omitted ranks")
    require(
        numerical_concurrencies, "No concurrency passed native numerical qualification"
    )
    print(
        f"INTEGRATION_EAGER_SCOPE C={numerical_concurrencies}; graph qualification still required",
        flush=True,
    )


if __name__ == "__main__":
    main()
