"""Real-operand adapters for the frozen private attention operators.

Each case has an isolated Python package and caches. No fixture constructor is
called: plans and packs are formed from actual checkpoint/forward operands.
"""

from __future__ import annotations

import hashlib
import importlib
import importlib.util
import os
import sys
from contextlib import suppress
from pathlib import Path
from typing import Any

from presentation_serving_adapter import logical_role, require


def source_alias_root() -> Path:
    root = Path(os.environ.get("MARLOWE_ATTENTION_ALIAS_ROOT", "/dev/shm"))
    root.mkdir(parents=True, exist_ok=True)
    return root


def shared_i04_logits(adapter, rows, columns, device, route):
    """Reuse consumed logits within one serialized stream role and Engine.

    The current-stream path queues scorer, top-k, then later layers in order.
    The R03 path joins before core and the next layer. topk_transform returns
    independent integer indices; no later consumer retains this FP32 buffer.
    Different roles, shapes and devices never share storage.
    """
    role = route.get("index_stream")
    require(role in ("r03", "native"), "Shared I04 logits require a serialized stream role")
    t = adapter.torch
    key = ("marlowe_i04_logits", role, str(device), rows, columns, t.float32)
    if key not in adapter.scratch:
        require(
            not t.cuda.is_current_stream_capturing(), "I04 logits cold during capture"
        )
        adapter.scratch[key] = t.empty((rows, columns), dtype=t.float32, device=device)
    return adapter.scratch[key]


class NativeMarlowe:
    def __init__(self, adapter: Any) -> None:
        self.a = adapter
        self.cases = adapter.manifest["marlowe_cases"]
        self.packages = {}
        self.plans = {}
        natives = {}
        for case, row in self.cases.items():
            name = "presentation_private_" + case.replace("-", "_")
            source_root = Path(row["source_root"])
            identity = hashlib.sha256(
                (source_root / "PRESENTATION_SOURCES.json").read_bytes()
            ).hexdigest()[:12]
            alias = source_alias_root() / ("pm" + identity)
            if not alias.exists():
                with suppress(FileExistsError):
                    alias.symlink_to(source_root / "kernel_search/attention")
            require(
                alias.is_symlink()
                and alias.resolve()
                == (source_root / "kernel_search/attention").resolve(),
                "Private package short alias points at different source",
            )
            native = alias / "native"
            natives[case] = native
            spec = importlib.util.spec_from_file_location(
                name, native / "__init__.py", submodule_search_locations=[str(native)]
            )
            require(spec and spec.loader, f"Cannot load frozen private package {case}")
            package = importlib.util.module_from_spec(spec)
            sys.modules[name] = package
            spec.loader.exec_module(package)
            self.packages[case] = name
        # Some exact donors predate PyHIP or contain only Triton operators. Bind
        # the common runtime and the two absolute imports to an actual selected
        # PYC03 donor, checking every retained copy for byte identity.
        runtime_case = next(
            row["case_id"]
            for row in adapter.manifest["routes"].values()
            if row["core"] == "pyc03"
        )
        runtime_root = natives[runtime_case].parent
        runtime = self.module(runtime_case, "verify_pyhip_runtime").validate()
        require(runtime["passed"], "Selected PyHIP runtime failed source checks")
        for case, native in natives.items():
            if (native / "verify_pyhip_runtime.py").exists():
                other = self.module(case, "verify_pyhip_runtime").validate()
                require(
                    other["passed"] and other["core_sha256"] == runtime["core_sha256"],
                    f"Private PyHIP runtime differs: {case}",
                )
            for relative in (
                "pyc01/separate_mla_fp8.py",
                "pyc03/grouped_mla_combine.py",
            ):
                path = native / relative
                if path.exists():
                    require(
                        path.read_bytes()
                        == (natives[runtime_case] / relative).read_bytes(),
                        f"Shared absolute PyHIP import differs: {case}/{relative}",
                    )
            if (native / "pr5260_paths.py").exists():
                self.module(case, "pr5260_paths").short_source = self.short_source
        from marlowe_kernels.integrations.attention_latest.private_imports import install
        install(runtime_root)

    @staticmethod
    def short_source(path: Path) -> Path:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        directory = source_alias_root() / ("ps" + digest[:12])
        directory.mkdir(parents=True, exist_ok=True)
        short = directory / "k.py"
        if not short.exists():
            with suppress(FileExistsError):
                short.symlink_to(path.resolve())
        require(
            short.is_symlink()
            and hashlib.sha256(short.read_bytes()).hexdigest() == digest,
            "Private short alias differs from its bound source",
        )
        return short

    def module(self, case: str, relative: str):
        return importlib.import_module(self.packages[case] + "." + relative)

    def preload_core_sources(self):
        """Exercise explicit-file loaders before any expensive model load."""
        records=[]
        for route in self.a.manifest['routes'].values():
            name,case=route['core'],route['case_id']
            if name not in ('pyc02','pyc03'):
                continue
            self.module(case,'verify_'+name)
            loader=self.module(case,name+'.source_loader')
            if name=='pyc03':
                module=loader.load()
            else:
                config=self.rowconfig(case)
                schedule=config.get('a02_pyc02_load_schedule','base')
                if config.get('a02b_pyc02_reduction')=='dpp_1_2_4_8':schedule='a02b_dpp'
                if config.get('a03_pyc02_request_split_mapping')=='paired':schedule='a03_request_split_pair'
                module=loader.load(schedule,config.get('a04b_combine_threads'))
            path=Path(module.__file__)
            records.append(dict(case=case,core=name,path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        return records

    def rowconfig(self, case: str) -> dict:
        return self.cases[case]["config"]

    def route(self, rows: int, layer_id: int) -> dict:
        a = self.a
        ctx = a.attention_context
        return a.selected(rows, layer_id, ctx["phase"] if ctx else "")

    def register(self, attn: Any) -> None:
        # The projection module owns only input/query hooks. It is intentionally
        # optional until that bounded family implementation is present.
        if self.a.manifest.get("projection_adapter"):
            from presentation_serving_projections import install_layer

            install_layer(self, attn)

    def install(self) -> None:
        a = self.a
        original = a.native.rocm_absorb_v_bmm

        def value(attn, latent):
            ctx = a.attention_context
            route = self.route(latent.shape[0], int(attn.layer_id))
            requested = route.get("value", "native")
            valid = (
                ctx is not None
                and not ctx.get("fused_core_fallback", False)
                and requested in ("fp8_value", "fused_core_value")
                and latent.dtype == a.torch.bfloat16
                and tuple(latent.shape[1:]) == (8, 512)
                and latent.is_contiguous()
                and attn.w_vc.dtype == a.torch.float8_e4m3fn
                and tuple(attn.w_vc.shape) == (8, 512, 256)
                and tuple(attn.w_vc.stride()) == (131072, 1, 512)
                and attn.o_proj.weight.dtype == a.torch.bfloat16
                and isinstance(attn.w_scale, a.torch.Tensor)
                and attn.w_scale.numel() == 1
            )
            if requested != "native":
                a.once(
                    "value_route",
                    phase=ctx["phase"],
                    layer_id=int(attn.layer_id),
                    rows=latent.shape[0],
                    requested=requested,
                    selected=requested if valid else "native",
                    reason=None if valid else "actual_value_ABI_outside_source",
                    during_capture=a.torch.cuda.is_current_stream_capturing(),
                )
            if not valid:
                return original(attn, latent)
            if requested == "fused_core_value":
                projected = ctx.pop("fused_value", None)
                require(
                    projected is not None, "Fused value has no matching core producer"
                )
            else:
                projected = self.module(route["case_id"], "fp8_value.component").absorb(
                    latent, attn.w_vc, attn.w_scale, "mi355x", True
                )
            if a.needs_check("value_projection", int(attn.layer_id), latent.shape[0]):
                expected = a.checks.absorb_reference(
                    latent, attn.w_vc, attn.w_scale, "mi355x"
                )
                a.checked_result(
                    "value_projection",
                    int(attn.layer_id),
                    latent.shape[0],
                    {"real_value": a.checks.strict_compare(projected, expected)},
                )
            return projected.flatten(1, 2)

        a.patch(a.native, "rocm_absorb_v_bmm", value)

    def core(self, route: dict, q, cache, selected, sm_scale: float):
        a, case = self.a, route["case_id"]
        name = route["core"]
        if name == "fused_core_value":
            ctx = a.attention_context
            attn = ctx["attn"]
            module = self.module(case, "fp8_value.fusion_component")
            # The retained source default is full_rows. Bind explicitly through
            # the exact producer and reducer entry points; no process-global knob.
            bridge = self.module(case, "fp8_value.partial_bridge")
            fuse = self.module(case, "fp8_value.fusion_kernel")
            provider = self.module(case, "verify_pr4919_provider")
            loader = self.module(case, "a01n.source_loader")
            provider.layout_contract(
                q, cache, selected, 2048, "mi355x", provider.ROUTE_4919
            )
            scratch = provider._scratch(provider.ROUTE_4919, q)
            partials = bridge.launch(
                loader.load_pr4919(),
                q,
                cache,
                scratch["indptr"],
                selected.reshape(-1),
                sm_scale,
                scratch["scale"],
            )
            latent, projected = fuse.launch(
                *partials, attn.w_vc, attn.w_scale, variant="full_rows"
            )
            ctx["fused_value"] = projected
            return latent
        require(name in ("pyc02", "pyc03"), "Unknown private complete core")
        key = (case, q.shape[0], cache.shape[0], str(q.device), float(sm_scale))
        if key not in self.plans:
            require(
                not a.torch.cuda.is_current_stream_capturing(),
                "Private core cold during graph capture",
            )
            config = self.rowconfig(case)
            wrapper = self.module(case, "verify_" + name)
            loader = self.module(case, name + ".source_loader")
            if name == "pyc03":
                module = loader.load()
                tuning = dict(
                    wrapper.CONFIG_BY_CELL[
                        logical_role(int(a.context["layer"].layer_id))
                    ]
                )
            else:
                schedule = config.get("a02_pyc02_load_schedule", "base")
                if config.get("a02b_pyc02_reduction") == "dpp_1_2_4_8":
                    schedule = "a02b_dpp"
                if config.get("a03_pyc02_request_split_mapping") == "paired":
                    schedule = "a03_request_split_pair"
                threads = config.get("a04b_combine_threads")
                module = loader.load(schedule, threads)
                tuning = dict(
                    wrapper.CONFIG_BY_CELL[
                        f"{q.shape[0] // 4}-{logical_role(int(a.context['layer'].layer_id))}"
                    ]
                )
                if config.get("a04_pyc02_kv_splits") is not None:
                    tuning["splits"] = config["a04_pyc02_kv_splits"]
                    if tuning["splits"] < 16:
                        tuning["s16_opt"] = 0
                if threads is not None:
                    tuning["combine_threads"] = threads
            tested_tuning = (
                self.cases[case]["core_contract"]
                .get("fused_fp8_trial_contract", {})
                .get("selected_config")
            )
            if tested_tuning is not None:
                tuning = dict(tested_tuning)
            out = a.torch.empty(
                (q.shape[0], 8, 512), dtype=a.torch.bfloat16, device=q.device
            )
            plan = module.Plan(q, cache.view(-1, 576), tuning, sm_scale, out=out)
            plan.ptr = a.torch.arange(
                0, (q.shape[0] + 1) * 2048, 2048, dtype=a.torch.int32, device=q.device
            )
            heads = int(
                self.cases[case].get("environment", {}).get("ATTN_GROUPED_HEADS", 0)
            )
            if heads:
                self.module(case, "grouped_head_combine").bind(plan, heads)
            self.plans[key] = plan
        plan = self.plans[key]
        return plan(q, cache.view(-1, 576), plan.out, plan.ptr, selected.reshape(-1))

    def core_contract(self, route: dict) -> dict:
        return dict(self.cases[route["case_id"]]["core_contract"])

    def output(self, route: dict, x, weight):
        a, case = self.a, route["case_id"]
        variant = route["output_variant"]
        identity = (weight.data_ptr(), int(weight._version), str(weight.device))
        key = ("output", case, identity)
        if key not in self.plans:
            require(
                not a.torch.cuda.is_current_stream_capturing(),
                "Private output weight is cold during capture",
            )
            provider = self.module(case, "pyg01.direct_provider")
            params = self.module(case, "pyg01.component").VARIANTS[variant]
            self.plans[key] = provider.Plan(x, weight, dict(params))
        return self.plans[key](x, weight)

    def indexer(self, indexer, ctx, original, args, kwargs):
        a, route = self.a, ctx["route"]
        selected = route.get("indexer")
        side = route.get("index_stream") == "r03"
        if selected not in ("f01", "l02", "i01_i04") and not side:
            return False, None
        stream_key = ("marlowe_index_stream", str(ctx["x"].device))
        if side and stream_key not in a.scratch:
            require(
                not a.torch.cuda.is_current_stream_capturing(),
                "Indexer side stream cold during capture",
            )
            a.scratch[stream_key] = a.torch.cuda.Stream(device=ctx["x"].device)

        def invoke():
            if selected == "f01":
                value = a.fused_indexer(indexer, ctx)
                return (
                    value if value is not None else original(indexer, *args, **kwargs)
                )
            if selected in ("l02", "i01_i04"):
                value = self.indexer_pipeline(indexer, ctx)
                return (
                    value if value is not None else original(indexer, *args, **kwargs)
                )
            return original(indexer, *args, **kwargs)

        if not side:
            return True, invoke()
        require(
            a.attention_context is not None,
            "Private side stream escaped attention prepare",
        )
        stream = a.scratch[stream_key]
        stream.wait_stream(a.torch.cuda.current_stream())
        with a.torch.cuda.stream(stream):
            output = invoke()
        a.attention_context["pending_index_stream"] = stream
        a.once(
            "index_stream_route",
            phase=ctx["phase"],
            layer_id=int(ctx["layer_id"]),
            rows=ctx["x"].shape[0],
            selected="r03",
            during_capture=a.torch.cuda.is_current_stream_capturing(),
        )
        return True, output

    def finish_preparation(self, attn):
        ctx = self.a.attention_context
        require(
            ctx is None or "fused_input_norm" not in ctx,
            "Fused input normalization did not reach its matching native consumer",
        )
        if ctx is not None and "pending_index_stream" in ctx:
            self.a.torch.cuda.current_stream().wait_stream(
                ctx.pop("pending_index_stream")
            )

    def indexer_pipeline(self, indexer, ctx):
        a, t, route = self.a, self.a.torch, ctx["route"]
        x, qlow, batch = ctx["x"], ctx["q_lora"], ctx["forward_batch"]
        rows, layer = x.shape[0], int(ctx["layer_id"])
        case, selected = route["case_id"], route["indexer"]
        pool = a.indexer.get_token_to_kv_pool()
        backend = a.indexer.get_attn_backend()
        metadata = backend.get_indexer_metadata(layer, batch)
        valid = (
            metadata is not None
            and x.dtype == qlow.dtype == t.bfloat16
            and tuple(x.shape) == (rows, 6144)
            and tuple(qlow.shape) == (rows, 2048)
            and ctx["return_indices"]
            and pool.page_size == 64
            and a.indexer._use_aiter_preshuffle
            and getattr(backend, "use_fused_topk", False)
            and indexer.block_size == 128
            and indexer.scale_fmt == "ue8m0"
            and not indexer.rotary_emb.is_neox_style
            and indexer.index_topk == 2048
            and not indexer.num_init_tokens
            and not indexer.num_local_tokens
            and not indexer.dsa_enable_prefill_cp
            and batch.attn_cp_metadata is None
            and not indexer.use_dsa_indexer_fusion
            and id(indexer) in a.prepared
            and indexer.wq_b.weight.dtype == t.bfloat16
        )
        if hasattr(pool, "_is_layer_owned") and not pool._is_layer_owned(layer):
            valid = False
        if valid:
            pages = metadata.get_page_table_64()
            lengths = metadata.get_seqlens_expanded().reshape(-1)
            valid = (
                pages.shape[0] == rows
                and lengths.numel() == rows
                and batch.out_cache_loc.numel() == rows
            )
        if not valid:
            a.once(
                "indexer_route",
                phase=ctx["phase"],
                layer_id=layer,
                rows=rows,
                requested=selected,
                selected="native",
                reason="actual_index_metadata_or_weight_ABI_outside_source",
                during_capture=t.cuda.is_current_stream_capturing(),
            )
            return None
        columns = pages.shape[1] * 64
        key = ("marlowe_indexer", case, id(indexer), rows, columns)
        if key not in a.scratch:
            require(
                not t.cuda.is_current_stream_capturing(),
                "Private indexer scratch cold during capture",
            )
            scratch = {
                "norm_weight": indexer.k_norm.weight.float().contiguous(),
                "norm_bias": indexer.k_norm.bias.float().contiguous(),
                "query_fp8": t.empty(
                    (rows, 32, 128), dtype=t.float8_e4m3fn, device=x.device
                ),
                "head_gates": t.empty((rows, 32), dtype=t.float32, device=x.device),
                "ghist": t.empty((0,), dtype=t.int32, device=x.device),
                "cursor": t.empty((0,), dtype=t.int32, device=x.device),
            }
            if selected == "i01_i04":
                owner = self.module(case, "i01.owner_stack")
                # L02 uses the native scorer's own output allocation. Retaining
                # an unused full-capacity logits tensor here costs one copy per
                # anchor and graph shape; only I04 accepts our explicit output.
                scratch.update(
                    logits=shared_i04_logits(a, rows, columns, x.device, route),
                    packed_weight=owner.producer.pack(
                        a.prepared[id(indexer)]["weight"]
                    ),
                    partial=t.empty((4, rows, 160), dtype=t.float32, device=x.device),
                    raw=t.empty((rows, 160), dtype=t.bfloat16, device=x.device),
                )
                owner.preparation_module()
            else:
                self.module(case, "l02.fused_prepare").module()
            a.scratch[key] = scratch
        scratch = a.scratch[key]
        cache = pool.get_index_k_with_scale_buffer(layer_id=layer)
        q_projected = a.attention_context.get("merged_index_query")
        if q_projected is not None:
            require(
                a.attention_context.get("merged_index_query_input") is qlow,
                "Merged index query consumer differs from producer input",
            )
        if q_projected is None:
            q_projected = indexer.wq_b(qlow)[0].view(rows, 32, 128)
        if hasattr(pool, "invalidate_index_buffer_for_layer"):
            pool.invalidate_index_buffer_for_layer(layer)
        if selected == "i01_i04":
            owner = self.module(case, "i01.owner_stack")
            owner.run_producer(x, scratch["packed_weight"], scratch["partial"])
            query, gates, projected_key, projected_gates = owner.run_preparation(
                q_projected,
                scratch["partial"],
                scratch["raw"],
                scratch["norm_weight"],
                scratch["norm_bias"],
                ctx["positions"],
                *a.rope_pair(indexer.rotary_emb, indexer.rope_head_dim),
                cache,
                batch.out_cache_loc,
                scratch["query_fp8"],
                scratch["head_gates"],
                float(indexer.k_norm.variance_epsilon),
            )
        else:
            projected_key, projected_gates = self.module(
                case, "l01.merged_projection"
            ).run(x, a.prepared[id(indexer)]["weight"])
            query, gates = self.module(case, "l02.fused_prepare").run(
                q_projected,
                projected_key,
                projected_gates,
                scratch["norm_weight"],
                scratch["norm_bias"],
                ctx["positions"],
                *a.rope_pair(indexer.rotary_emb, indexer.rope_head_dim),
                cache,
                batch.out_cache_loc,
                scratch["query_fp8"],
                scratch["head_gates"],
                float(indexer.k_norm.variance_epsilon),
            )
        if selected == "i01_i04":
            logits = self.module(case, "i04.scorer").run(
                query, cache, gates, lengths, pages, scratch["logits"]
            )
        else:
            logits = self.module(case, "verify_ops").index_score(
                query, cache, gates, lengths, pages, [], columns, rows // 4, "mi355x"
            )
        chosen = metadata.topk_transform(logits, indexer.index_topk)
        if a.needs_check("fused_indexer", layer, rows):
            a.check_fused_indexer(
                indexer,
                ctx,
                (
                    chosen,
                    query,
                    gates,
                    logits,
                    q_projected,
                    projected_key,
                    projected_gates,
                ),
                cache,
                pages,
                lengths,
                scratch,
            )
        a.once(
            "indexer_route",
            phase=ctx["phase"],
            layer_id=layer,
            rows=rows,
            selected=selected,
            during_capture=t.cuda.is_current_stream_capturing(),
        )
        return a.indexer.maybe_capture_indexer_topk(
            layer, a.indexer._broadcast_indexer_topk_from_rank0(chosen)
        )
