"""Diagnostic PR4919 references; these do not replace the harness acceptance oracle."""

from __future__ import annotations

from typing import Any

import torch


def combine_unnormalized(
    numerators: list[torch.Tensor],
    denominators: list[torch.Tensor],
    maxima: list[torch.Tensor],
) -> torch.Tensor:
    """PR4919 split epilogue: BF16 raw numerators, FP32 weighted sum, one divide.

    A single split bypasses the intermediate BF16 store in the actual kernel.
    Inputs are online-softmax values in each split's base-2 exponent domain.
    """
    if not numerators or not (len(numerators) == len(denominators) == len(maxima)):
        raise ValueError("Expected matching nonempty split components")
    if len(numerators) == 1:
        return (numerators[0] * denominators[0].reciprocal()[..., None]).to(
            torch.bfloat16
        )
    maximum = maxima[0]
    for value in maxima[1:]:
        maximum = torch.maximum(maximum, value)
    acc = torch.zeros_like(numerators[0], dtype=torch.float32)
    total = torch.zeros_like(denominators[0], dtype=torch.float32)
    for numerator, denominator, local_max in zip(
        numerators, denominators, maxima, strict=True
    ):
        weight = torch.exp2(local_max - maximum)
        total = total + weight * denominator
        acc = acc + weight[..., None] * numerator.to(torch.bfloat16).float()
    return (acc * total.reciprocal()[..., None]).to(torch.bfloat16)


def source_precision_attention(
    query: torch.Tensor,
    cache: torch.Tensor,
    selected: torch.Tensor,
    scale: float,
    contract: dict[str, Any],
) -> torch.Tensor:
    """Independent tensor algebra for the recorded PR4919 unit-scale FP8 route.

    Like the historical reference, float32 bmm models the dot arithmetic, not
    bit-exact MFMA accumulation. Unlike that reference, split partial rounding
    follows the actual PR4919 producer/reducer. No thresholds are applied here.
    """
    if contract.get("reference") != "source_fp8_unscaled_probability":
        raise ValueError("This diagnostic covers PR4919 raw FP8 probability only")
    if query.dtype != torch.float8_e4m3fn or cache.dtype != query.dtype:
        raise ValueError("Expected retained FP8 E4M3 query/cache values")
    if query.ndim != 3 or query.shape[1:] != (8, 576):
        raise ValueError("Expected the H8, D576 query contract")
    if selected.ndim != 2 or selected.shape[0] != query.shape[0]:
        raise ValueError("Selected rows differ from query rows")
    block, splits = int(contract["block_k"]), int(contract["kv_splits"])
    tiles = int(contract["tiles_per_split"])
    if min(block, splits, tiles) < 1 or splits * tiles * block < selected.shape[1]:
        raise ValueError("Split contract does not cover selection")
    cache = cache.reshape(-1, 576)
    if bool((selected < 0).any()) or bool((selected >= cache.shape[0]).any()):
        raise ValueError("This bounded diagnostic requires valid selected indices")
    outputs = []
    for first in range(0, query.shape[0], 16):
        q = query[first : first + 16].float()
        ids = selected[first : first + 16].long()
        numerators, denominators, maxima = [], [], []
        for split in range(splits):
            lo = split * tiles * block
            hi = min(ids.shape[-1], (split + 1) * tiles * block)
            if lo >= hi:
                raise ValueError("Empty split outside the recorded diagnostic domain")
            maximum = torch.full(q.shape[:2], -float("inf"), device=q.device)
            denominator = torch.zeros_like(maximum)
            numerator = torch.zeros((*q.shape[:2], 512), device=q.device)
            for offset in range(lo, hi, block):
                keys = cache[ids[:, offset : min(hi, offset + block)]].float()
                score = torch.bmm(q[..., :128], keys[..., :128].transpose(1, 2))
                for start in (128, 256, 384, 512):
                    score = score + torch.bmm(
                        q[..., start : start + 128],
                        keys[..., start : start + 128].transpose(1, 2),
                    )
                score = score * (scale * contract["log2e"])
                updated = torch.maximum(maximum, score.amax(-1))
                alpha = torch.exp2(maximum - updated)
                probability = torch.exp2(score - updated[..., None])
                denominator = denominator * alpha + probability.sum(-1)
                numerator = numerator * alpha[..., None] + torch.bmm(
                    probability.to(query.dtype).float(), keys[..., :512]
                )
                maximum = updated
            numerators.append(numerator)
            denominators.append(denominator)
            maxima.append(maximum)
        outputs.append(combine_unnormalized(numerators, denominators, maxima))
    return torch.cat(outputs)


def fp64_attention(
    query: torch.Tensor, cache: torch.Tensor, selected: torch.Tensor, scale: float
) -> torch.Tensor:
    """Ideal softmax on actual quantized values; no probability/partial rounding."""
    cache = cache.reshape(-1, query.shape[-1])
    outputs = []
    for row in range(query.shape[0]):
        q = query[row].double()
        keys = cache[selected[row].long()].double()
        score = (q @ keys.T) * scale
        probability = torch.softmax(score, dim=-1)
        outputs.append(probability @ keys[:, :512])
    return torch.stack(outputs)


def quantized_absorb_input(value: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Expose the existing MI absorption reference's per-128 FP8 code/scale step."""
    if value.shape[-1] % 128:
        raise ValueError("Expected complete groups of 128")
    groups = value.float().reshape(*value.shape[:-1], -1, 128)
    scales = groups.abs().amax(-1, keepdim=True).clamp_min(1e-10) / 448.0
    codes = (groups / scales).clamp(-448, 448).to(torch.float8_e4m3fn)
    return codes.reshape(value.shape), scales


def independent_metrics(actual: torch.Tensor, expected: torch.Tensor) -> dict[str, Any]:
    """FP64 metric cross-check; labels raw metrics without setting acceptance."""
    if actual.shape != expected.shape:
        return {"shape_equal": False}
    a, b = actual.double(), expected.double()
    if not bool(torch.isfinite(a).all() and torch.isfinite(b).all()):
        return {"shape_equal": True, "finite": False}
    delta = a - b
    rmse = delta.square().mean().sqrt()
    rms = b.square().mean().sqrt().clamp_min(1e-8)
    head = delta.square().mean(-1).sqrt() / b.square().mean(-1).sqrt().clamp_min(1e-8)
    norm = a.norm() * b.norm()
    return {
        "shape_equal": True,
        "finite": True,
        "nrmse": float(rmse / rms),
        "rmse": float(rmse),
        "rms": float(rms),
        "max_abs": float(delta.abs().max()),
        "max_head_nrmse": float(head.max()),
        "cosine": float((a * b).sum() / norm) if float(norm) > 0 else None,
        "allclose_002": bool((delta.abs() <= 0.02 + 0.02 * b.abs()).all()),
        "allclose_failure_count": int((delta.abs() > 0.02 + 0.02 * b.abs()).sum()),
        "classification": "independent FP64 metrics; not a replacement acceptance gate",
    }
