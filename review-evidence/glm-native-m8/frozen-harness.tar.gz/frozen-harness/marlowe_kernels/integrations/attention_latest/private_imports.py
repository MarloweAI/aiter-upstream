"""Load frozen attention dependencies without replacing Port-EW's PyHIP."""
import builtins
import fcntl
import functools
import importlib.abc
import importlib.machinery
import importlib.util
import os
from pathlib import Path
import sys
import types

ALIASES = {'pyhip': '_marlowe_attention_pyhip', 'native': '_marlowe_attention_native'}
NATIVE_BUILDERS = ('c01.fold_norm', 'c01b.b8_input_native_order',
                   'c01b.b16_shared_input_norm', 'c01b.b32_shared_input_norm',
                   'c07.b128_input_postgsu_fused', 'i05b.selector')


def serialize_native_build(module):
    """Protect archived shared-library builds without locking hot launches."""
    if not any(module.__name__.endswith('.'+name) for name in NATIVE_BUILDERS):
        return
    original = module.library
    assert callable(original) and hasattr(original, 'cache_info')
    lock = Path(os.environ.get('MARLOWE_ATTENTION_ALIAS_ROOT', '/tmp/marlowe-attention')) / 'native-build.lock'
    lock.parent.mkdir(parents=True, exist_ok=True)

    @functools.cache
    @functools.wraps(original)
    def library():
        # Hold through the existence check, compilation, dlopen and provenance
        # write. Merely locking the compiler would leave a load/rebuild race.
        with lock.open('a') as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            try:
                return original()
            finally:
                fcntl.flock(stream, fcntl.LOCK_UN)

    library.marlowe_build_lock = str(lock)
    module.library = library


def scoped_import(name, globals=None, locals=None, fromlist=(), level=0):
    requested = name
    if level == 0:
        root, dot, suffix = name.partition('.')
        if root in ALIASES:
            name = ALIASES[root] + (dot + suffix if dot else '')
    result = builtins.__import__(name, globals, locals, fromlist, level)
    if level == 0 and (requested == 'importlib' or requested.startswith('importlib.')):
        if not fromlist or requested == 'importlib':
            return _IMPORTLIB_PROXY
        if requested == 'importlib.util':
            return _UTIL_PROXY
    return result


class ScopedLoader:
    def __init__(self, loader):
        self.loader = loader

    def create_module(self, spec):
        return self.loader.create_module(spec)

    def exec_module(self, module):
        module.__dict__['__builtins__'] = dict(vars(builtins), __import__=scoped_import)
        exec(self.loader.get_code(module.__name__), module.__dict__)
        serialize_native_build(module)

    def __getattr__(self, name):
        return getattr(self.loader, name)


def scoped_spec_from_file_location(*args, **kwargs):
    spec = importlib.util.spec_from_file_location(*args, **kwargs)
    if spec is not None and isinstance(spec.loader, importlib.machinery.SourceFileLoader):
        spec.loader = ScopedLoader(spec.loader)
    return spec


def _alias(name):
    root, dot, suffix = name.partition('.')
    return ALIASES.get(root, root) + (dot + suffix if dot else '')


def scoped_import_module(name, package=None):
    return importlib.import_module(_alias(name), _alias(package) if package else package)


# Only private attention modules receive these proxies. Global importlib and
# the full installed PyHIP used by Port-EW are never modified.
_UTIL_PROXY = types.ModuleType('importlib.util')
_UTIL_PROXY.__dict__.update(vars(importlib.util))
_UTIL_PROXY.spec_from_file_location = scoped_spec_from_file_location
_IMPORTLIB_PROXY = types.ModuleType('importlib')
_IMPORTLIB_PROXY.__dict__.update(vars(importlib))
_IMPORTLIB_PROXY.util = _UTIL_PROXY
_IMPORTLIB_PROXY.import_module = scoped_import_module
_IMPORTLIB_PROXY.__getattr__ = lambda name: getattr(importlib, name)


class PrivateFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if not (fullname.startswith('presentation_private_') or
                any(fullname == v or fullname.startswith(v+'.') for v in ALIASES.values())):
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec is not None and isinstance(spec.loader, importlib.machinery.SourceFileLoader):
            spec.loader = ScopedLoader(spec.loader)
        return spec


def install(runtime_root):
    """Bind the two archived packages by private names; leave sys.path unchanged."""
    runtime_root = Path(runtime_root)
    if not any(isinstance(f, PrivateFinder) for f in sys.meta_path):
        sys.meta_path.insert(0, PrivateFinder())
    for original, alias in ALIASES.items():
        root = runtime_root/original
        if alias in sys.modules:
            if Path(sys.modules[alias].__file__).resolve() != (root/'__init__.py').resolve():
                raise RuntimeError(f'Private attention dependency changed: {alias}')
            continue
        spec = importlib.util.spec_from_file_location(alias, root/'__init__.py',
                                                     submodule_search_locations=[str(root)])
        if spec is None or spec.loader is None:
            raise ImportError(f'Missing frozen dependency {root}')
        spec.loader = ScopedLoader(spec.loader)
        module = importlib.util.module_from_spec(spec)
        sys.modules[alias] = module
        # The frozen compiler rewrites generated files in place. A shared cache
        # allows another TP rank to read a partially replaced code object (or
        # mismatched symbol-table reads). Give attention each worker's own cache;
        # do not change the installed Port-EW compiler's environment or globals.
        cache = Path(os.environ.get('MARLOWE_ATTENTION_ALIAS_ROOT', '/tmp/marlowe-attention')) / f'pyhip-{os.getpid()}'
        cache.mkdir(parents=True, exist_ok=True)
        previous = os.environ.get('PYHIP_CACHE_DIR')
        try:
            os.environ['PYHIP_CACHE_DIR'] = str(cache)
            spec.loader.exec_module(module)
        finally:
            if previous is None:
                os.environ.pop('PYHIP_CACHE_DIR', None)
            else:
                os.environ['PYHIP_CACHE_DIR'] = previous
