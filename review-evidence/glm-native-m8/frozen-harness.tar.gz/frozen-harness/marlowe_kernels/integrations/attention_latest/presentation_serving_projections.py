"""Guarded real-weight input/query projection adapters for frozen Marlowe cases.

No synthetic fixture is constructed. Weight packing is an exact layout change
performed before graph capture; calls preserve the donor's arithmetic and views.
"""

from __future__ import annotations

import functools
import importlib
from typing import Any

from presentation_serving_adapter import require

QUERY_FAMILIES = frozenset({"c03", "c04", "c04b", "l03", "x_projection"})
INPUT_FAMILIES = frozenset({"c01b", "c09", "input_revisit", "x_projection"})


def input_rows_supported(family: str, rows: int) -> bool:
    return rows in {
        "c01b": (16,),
        "c09": (128,),
        "input_revisit": (32,),
        "x_projection": (64,),
    }.get(family, ())


def _same_view(left, right) -> bool:
    return (
        left.data_ptr() == right.data_ptr()
        and left.shape == right.shape
        and left.stride() == right.stride()
        and left.dtype == right.dtype
        and left.device == right.device
    )


def _weight_identity(weight):
    return (
        weight.data_ptr(),
        int(weight._version),
        tuple(weight.shape),
        tuple(weight.stride()),
        str(weight.dtype),
        str(weight.device),
    )


def _shared_packed_weight(adapter, weight, n: int, k: int):
    # Packing is independent of query-row count and donor case. Preserve its
    # exact n/k layout contract and the original storage lifetime in this cache.
    key = (
        "presentation_immutable_weight",
        "n_outer_k_outer_n_inner_k_inner",
        n,
        k,
        _weight_identity(weight),
    )
    if key not in adapter.scratch:
        require(
            not adapter.torch.cuda.is_current_stream_capturing(),
            "Packed weight is cold during capture",
        )
        adapter.scratch[key] = (weight, _packed(weight, n, k, adapter.torch))
    return adapter.scratch[key][1]


def _shared_merged_weight(adapter, query_weight, index_weight):
    key = (
        "presentation_immutable_weight",
        "l03_query_then_index_rows",
        _weight_identity(query_weight),
        _weight_identity(index_weight),
    )
    if key not in adapter.scratch:
        require(
            not adapter.torch.cuda.is_current_stream_capturing(),
            "Merged weight is cold during capture",
        )
        adapter.scratch[key] = (
            query_weight,
            index_weight,
            adapter.torch.cat((query_weight, index_weight), dim=0).contiguous(),
        )
    return adapter.scratch[key][2]


def _input_plan(marlowe, attn, route, hidden):
    a, family, case = marlowe.a, route["input_projection"], route["case_id"]
    weight = attn.fused_qkv_a_proj_with_mqa.weight
    key = (
        "presentation_projection_input",
        int(attn.layer_id),
        case,
        family,
        hidden.shape[0],
        weight.data_ptr(),
        int(weight._version),
        str(weight.device),
    )
    if key not in a.scratch:
        require(
            not a.torch.cuda.is_current_stream_capturing(),
            "Marlowe input pack/scratch is cold during capture",
        )
        rows = hidden.shape[0]
        result = {
            "weight": weight,
            "raw": a.torch.empty(
                (rows, 2624), dtype=a.torch.bfloat16, device=hidden.device
            ),
        }
        if family != "x_projection":
            tile = (64, 64) if family == "c09" else (16, 32)
            result["weight"] = _shared_packed_weight(a, weight, *tile)
            result["partial"] = a.torch.empty(
                (6 if family == "c09" else 4, rows, 2624),
                dtype=a.torch.float32,
                device=hidden.device,
            )
            result["query"] = a.torch.empty(
                (rows, 2048), dtype=a.torch.bfloat16, device=hidden.device
            )
            result["key"] = a.torch.empty(
                (rows, 512), dtype=a.torch.bfloat16, device=hidden.device
            )
        a.scratch[key] = result
    return a.scratch[key]


def _input(marlowe, attn, route, hidden):
    a, family, case = marlowe.a, route["input_projection"], route["case_id"]
    plan = _input_plan(marlowe, attn, route, hidden)
    qw, kw = attn.q_a_layernorm.weight, attn.kv_a_layernorm.weight
    eps = attn.q_a_layernorm.variance_epsilon
    raw = plan["raw"]
    if family == "x_projection":
        variant = marlowe.cases[case]["environment"].get("ATTN_X_INPUT")
        require(
            variant == "c05-m32n32-prefetch2-stages1-default",
            "Unknown frozen input variant",
        )
        marlowe.module(case, "x_projection.c05_input").launch(
            hidden, plan["weight"], raw, variant
        )
    else:
        args = (
            hidden,
            plan["weight"],
            plan["partial"],
            raw,
            plan["query"],
            plan["key"],
            qw,
            kw,
            eps,
        )
        if family == "c01b":
            marlowe.module(case, "c01b.packed_stack").run(
                *args, marlowe.rowconfig(case)["c01b_variant"]
            )
        elif family == "c09":
            marlowe.module(case, "c09.input_stack").run(*args)
        else:
            variant = marlowe.cases[case]["environment"].get("ATTN_INPUT_REVISIT")
            require(
                variant == "b32-bn32-w2-stages2-default",
                "Unknown frozen input revisit variant",
            )
            marlowe.module(case, "input_revisit.b32_input").launch(
                hidden, plan["weight"], plan["partial"], variant
            )
            marlowe.module(case, "c01b.b32_shared_input_norm").norm(
                plan["partial"], raw, plan["query"], plan["key"], qw, kw, eps, eps
            )
        a.attention_context["fused_input_norm"] = {
            "raw_query": raw[:, :2048],
            "raw_key": raw[:, 2048:2560],
            "query": plan["query"],
            "key": plan["key"],
            "query_weight": qw,
            "key_weight": kw,
            "epsilon": eps,
        }
    if a.needs_check("input_projection", int(attn.layer_id), hidden.shape[0]):
        expected = a.reference.linear(hidden, attn.fused_qkv_a_proj_with_mqa.weight)
        checks = {
            "input_query_projection": a.checks.strict_compare(
                raw[:, :2048], expected[:, :2048]
            ),
            "input_key_projection": a.checks.strict_compare(
                raw[:, 2048:2560], expected[:, 2048:2560]
            ),
            "input_rope_projection": a.checks.strict_compare(
                raw[:, 2560:], expected[:, 2560:]
            ),
        }
        if family != "x_projection":
            # Preserve verify_preparation's independently checked stage inputs:
            # the norm consumes the producer's actual BF16 storage boundary.
            checks.update(
                query_norm=a.checks.strict_compare(
                    plan["query"], a.reference.rms_norm(raw[:, :2048], qw, eps)
                ),
                key_norm=a.checks.strict_compare(
                    plan["key"], a.reference.rms_norm(raw[:, 2048:2560], kw, eps)
                ),
            )
        a.checked_result(
            "input_projection", int(attn.layer_id), hidden.shape[0], checks
        )
    return raw


def _input_eligible(marlowe, attn, inputs, route, scattered: bool) -> bool:
    a, family, hidden = (
        marlowe.a,
        route.get("input_projection"),
        inputs.hidden_states_local,
    )
    projection = getattr(attn, "fused_qkv_a_proj_with_mqa", None)
    weight = getattr(projection, "weight", None)
    valid = (
        family in INPUT_FAMILIES
        and getattr(inputs.qkv_latent_func, "__self__", None) is attn
        and inputs.qkv_latent_ is None
        and not scattered
        and isinstance(hidden, a.torch.Tensor)
        and isinstance(weight, a.torch.Tensor)
        and hidden.ndim == 2
        and hidden.shape[1] == 6144
        and input_rows_supported(family, hidden.shape[0])
        and tuple(weight.shape) == (2624, 6144)
        and hidden.dtype == weight.dtype == a.torch.bfloat16
        and hidden.device == weight.device
        and hidden.is_contiguous()
        and weight.is_contiguous()
        and getattr(projection, "bias", None) is None
        and not hasattr(attn, "q_a_proj")
        and not a.native._SGLANG_EXPERIMENTAL_LORA_OPTI
        and not a.native.is_kv_b_lora_active(attn)
    )
    if valid and family != "x_projection":
        qnorm, knorm = attn.q_a_layernorm, attn.kv_a_layernorm
        valid = (
            a.native._use_aiter
            and attn.alt_stream is None
            and attn.q_b_proj.weight.dtype == a.torch.bfloat16
            and qnorm.variance_epsilon == knorm.variance_epsilon
            and tuple(qnorm.weight.shape) == (2048,)
            and tuple(knorm.weight.shape) == (512,)
            and qnorm.weight.dtype == knorm.weight.dtype == a.torch.bfloat16
            and qnorm.weight.device == knorm.weight.device == hidden.device
            and qnorm.weight.is_contiguous()
            and knorm.weight.is_contiguous()
        )
    return bool(valid)


def _install_input_hooks(marlowe, communicator=None):
    if getattr(marlowe, "_presentation_input_hooks", False):
        return
    a = marlowe.a
    communicator = communicator or importlib.import_module(
        "sglang.srt.layers.communicator"
    )
    original = communicator.AttentionInputs.fetch_qkv_latent

    @functools.wraps(original)
    def fetch(inputs):
        ctx = a.attention_context
        if ctx is None:
            return original(inputs)
        attn, hidden = ctx["attn"], inputs.hidden_states_local
        rows = hidden.shape[0] if isinstance(hidden, a.torch.Tensor) else 0
        route = a.selected(rows, int(attn.layer_id), ctx["phase"])
        family = route.get("input_projection", "native")
        if family == "native":
            return original(inputs)
        valid = _input_eligible(
            marlowe,
            attn,
            inputs,
            route,
            communicator.get_attn_tp_context().input_scattered,
        )
        a.once(
            "input_route",
            phase=ctx["phase"],
            layer_id=int(attn.layer_id),
            rows=rows,
            requested=family,
            selected=family if valid else "native",
            reason=None if valid else "actual_input_ABI_outside_source",
            during_capture=a.torch.cuda.is_current_stream_capturing(),
        )
        if not valid:
            return original(inputs)
        # The communicator retained a bound callback when the model was built.
        # Replace that callback for this fetch; do not run the original GEMM first.
        callback = inputs.qkv_latent_func
        inputs.qkv_latent_func = lambda x, batch: _input(marlowe, attn, route, x)
        try:
            return original(inputs)
        finally:
            inputs.qkv_latent_func = callback

    original_norm = a.native.fused_qk_rmsnorm_bf16

    @functools.wraps(original_norm)
    def norm(query, qw, qe, key, kw, ke, *args, **kwargs):
        ctx = a.attention_context
        saved = ctx.get("fused_input_norm") if ctx else None
        if saved is None:
            return original_norm(query, qw, qe, key, kw, ke, *args, **kwargs)
        require(
            not args
            and not kwargs
            and _same_view(query, saved["raw_query"])
            and _same_view(key, saved["raw_key"])
            and _same_view(qw, saved["query_weight"])
            and _same_view(kw, saved["key_weight"])
            and qe == ke == saved["epsilon"],
            "Fused input normalization lost its exact native consumer",
        )
        del ctx["fused_input_norm"]
        return saved["query"], saved["key"]

    a.patch(communicator.AttentionInputs, "fetch_qkv_latent", fetch)
    a.patch(a.native, "fused_qk_rmsnorm_bf16", norm)
    marlowe._presentation_input_hooks = True


def query_rows_supported(family: str, rows: int) -> bool:
    return rows in {
        "c03": (4,),
        "c04": (8,),
        "c04b": (16, 32),
        "l03": (32, 64, 128, 256),
        "x_projection": (64,),
    }.get(family, ())


def _packed(weight, n: int, k: int, torch):
    rows, columns = weight.shape
    result = weight.view(rows // n, n, columns // k, k).permute(0, 2, 1, 3).contiguous()
    inverse = result.permute(0, 2, 1, 3).contiguous().view_as(weight)
    require(
        torch.equal(inverse.view(torch.uint8), weight.view(torch.uint8)),
        "Checkpoint weight packing changed values",
    )
    return result


def _query_plan(marlowe, attn, case: str, family: str, query):
    a, weight = marlowe.a, attn.q_b_proj.weight
    key = (
        "presentation_projection_query",
        int(attn.layer_id),
        case,
        family,
        query.shape[0],
        weight.data_ptr(),
        int(weight._version),
        str(weight.device),
    )
    if key not in a.scratch:
        require(
            not a.torch.cuda.is_current_stream_capturing(),
            "Marlowe query projection pack/scratch is cold during capture",
        )
        result = {"weight": weight}
        if family in {"c04", "c04b"}:
            result["weight"] = _shared_packed_weight(a, weight, 16, 32)
        if family == "l03":
            index_weight = attn.indexer.wq_b.weight
            result["weight"] = _shared_merged_weight(a, weight, index_weight)
        else:
            result["out"] = a.torch.empty(
                (query.shape[0], 2048), dtype=a.torch.bfloat16, device=query.device
            )
        a.scratch[key] = result
    return a.scratch[key]


def _query(marlowe, attn, route: dict, query):
    a, case, family = marlowe.a, route["case_id"], route["query_projection"]
    plan = _query_plan(marlowe, attn, case, family, query)
    if family == "l03":
        q_nope, q_rope, index = marlowe.module(case, "l03.merged_query").run(
            query, plan["weight"]
        )
        # Both native consumers retain the Mx6144 producer's row stride. Do not
        # concatenate or recompute either projection.
        require(
            q_nope.untyped_storage().data_ptr() == q_rope.untyped_storage().data_ptr()
            and q_rope.storage_offset() == q_nope.storage_offset() + 192,
            "Merged query output views no longer share their producer",
        )
        result = q_nope.as_strided((query.shape[0], 8, 256), q_nope.stride())
        a.attention_context["merged_index_query"] = index
        a.attention_context["merged_index_query_input"] = query
    elif family == "x_projection":
        variant = marlowe.cases[case].get("environment", {}).get("ATTN_X_QUERY")
        require(variant in {"x05", "x06"}, "Unknown frozen query variant")
        name = (
            "x_projection.b64_shared_query_cooperative_tail_kernel"
            if variant == "x06"
            else "x_projection.b64_shared_query_weight_first_kernel"
        )
        provider = marlowe.module(case, name)
        provider.launch(query, plan["weight"], plan["out"], provider.CONFIG)
        result = plan["out"].view(-1, 8, 256)
    else:
        module = marlowe.module(case, family + ".query_stack")
        args = (query, plan["weight"], plan["out"])
        if family == "c04b":
            module.run(*args, marlowe.rowconfig(case)["c04b_variant"])
        else:
            module.run(*args)
        result = plan["out"].view(-1, 8, 256)
    if a.needs_check("query_projection", int(attn.layer_id), query.shape[0]):
        expected = a.reference.linear(query, attn.q_b_proj.weight).view(-1, 8, 256)
        checks = {
            "main_query_projection": a.checks.strict_compare(
                result[..., :192], expected[..., :192]
            ),
            "main_rope_projection": a.checks.strict_compare(
                result[..., 192:], expected[..., 192:]
            ),
        }
        if family == "l03":
            checks["index_query"] = a.checks.strict_compare(
                a.attention_context["merged_index_query"],
                a.reference.linear(query, attn.indexer.wq_b.weight).view(-1, 32, 128),
            )
        a.checked_result("query_projection", int(attn.layer_id), query.shape[0], checks)
    return result


def install_layer(marlowe: Any, attn: Any) -> None:
    """Install projection hooks after weight transforms and before graph capture."""
    if hasattr(attn, "fused_qkv_a_proj_with_mqa"):
        _install_input_hooks(marlowe)
    a, original = marlowe.a, attn.q_b_proj_forward

    @functools.wraps(original)
    def query(query, *args, **kwargs):
        ctx = a.attention_context
        route = (
            a.selected(query.shape[0], int(attn.layer_id), ctx["phase"])
            if ctx is not None and isinstance(query, a.torch.Tensor)
            else {}
        )
        family = route.get("query_projection", "native")
        weight = attn.q_b_proj.weight
        valid = (
            family in QUERY_FAMILIES
            and ctx.get("attn") is attn
            and not args
            and not kwargs
            and query.ndim == 2
            and query.shape[1] == 2048
            and query_rows_supported(family, query.shape[0])
            and query.dtype == weight.dtype == a.torch.bfloat16
            and query.device == weight.device
            and query.is_contiguous()
            and weight.is_contiguous()
            and tuple(weight.shape) == (2048, 2048)
            and getattr(attn.q_b_proj, "bias", None) is None
            and not a.native._SGLANG_EXPERIMENTAL_LORA_OPTI
            and not a.native.is_kv_b_lora_active(attn)
        )
        if valid and family == "l03":
            indexer = getattr(attn, "indexer", None)
            index_weight = getattr(getattr(indexer, "wq_b", None), "weight", None)
            valid = (
                isinstance(index_weight, a.torch.Tensor)
                and index_weight.dtype == a.torch.bfloat16
                and tuple(index_weight.shape) == (4096, 2048)
                and index_weight.is_contiguous()
                and index_weight.device == query.device
                and getattr(indexer.wq_b, "bias", None) is None
            )
        if family != "native":
            a.once(
                "query_route",
                phase=ctx["phase"],
                layer_id=int(attn.layer_id),
                rows=query.shape[0],
                requested=family,
                selected=family if valid else "native",
                reason=None if valid else "actual_query_ABI_outside_source",
                during_capture=a.torch.cuda.is_current_stream_capturing(),
            )
        return (
            _query(marlowe, attn, route, query)
            if valid
            else original(query, *args, **kwargs)
        )

    a.patch(attn, "q_b_proj_forward", query)
