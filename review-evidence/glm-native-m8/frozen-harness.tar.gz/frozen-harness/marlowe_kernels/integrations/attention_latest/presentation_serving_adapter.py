"""Phase-guarded native SGLang hooks for the presentation serving recipes.

No fixture, generated weight, request schedule, or synthetic KV is constructed.
Source operators are loaded from an immutable recipe package. The model owns all
weights, scales, caches, page tables, positions, and distributed communication.
"""

from __future__ import annotations

import ast
import functools
import hashlib
import importlib
import importlib.abc
import importlib.machinery
import inspect
import json
import os
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any


LATEST_U02_AITER_COMMIT = "52ffe895e64acc993a14b6af04a588fc5a448d56"
LATEST_U02_WRAPPER_SHA256 = "28d28b671ea8f87ec7bc25e98f82f77bc284e231f0719f332c9d9ab4959fe1ce"
U02_FP8_WITHOUT_LOGGER_AST_SHA256 = "370cefad5da178420b44c76b640e350e0dce63c065af5b1f25522727a2d023ef"


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value: Any, message: str) -> None:
    if not value:
        raise RuntimeError(message)


def latest_u02_source_proof(module: Any) -> dict[str, Any]:
    """Rebind U02 to the pinned AITER wrapper whose only FP8 change is logging."""
    from aiter.ops.triton._triton_kernels.fusions import (
        fused_bmm_rope_kv_cache as kernel,
    )
    from aiter.ops.triton.fusions import fused_bmm_rope_kv_cache as wrapper

    root = Path(module.__file__).resolve().parents[3]
    path = root / "configs/interim/u02_dual_output.json"
    manifest = json.loads(path.read_text())
    wrapper_source = Path(wrapper.__file__).read_text()
    wrapper_tree = ast.parse(wrapper_source)
    fp8_function = next(
        node
        for node in wrapper_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "fused_fp8_bmm_rope_cat_and_cache_mla"
    )
    fp8_function.body = [
        node
        for node in fp8_function.body
        if not (
            isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Attribute)
            and isinstance(node.value.func.value, ast.Name)
            and node.value.func.value.id == "_LOGGER"
            and node.value.func.attr == "info"
        )
    ]
    normalized_fp8_sha256 = hashlib.sha256(
        ast.dump(fp8_function, include_attributes=False).encode()
    ).hexdigest()
    checks = {
        "id": manifest["id"] == module.ID,
        "python_ast_schema": sys.version_info[:2] == (3, 12),
        "latest_native_wrapper": file_hash(Path(wrapper.__file__))
        == LATEST_U02_WRAPPER_SHA256,
        "fp8_wrapper_except_logger": normalized_fp8_sha256
        == U02_FP8_WITHOUT_LOGGER_AST_SHA256,
        "native_kernel_and_helpers": file_hash(Path(kernel.__file__))
        == manifest["source_kernel_sha256"],
        "local_kernel": file_hash(Path(module.__file__).with_name("u02_dual_kernel.py"))
        == manifest["local_module_sha256"],
        "exact_patch": file_hash(root / manifest["patch"])
        == manifest["patch_sha256"],
    }
    require(
        all(checks.values()),
        "Latest-runtime U02 source mismatch: "
        + ", ".join(name for name, passed in checks.items() if not passed),
    )
    return {
        "passed": True,
        "manifest_sha256": file_hash(path),
        "manifest": manifest,
        "checks": checks,
        "forward_port": {
            "aiter_commit": LATEST_U02_AITER_COMMIT,
            "wrapper_sha256": LATEST_U02_WRAPPER_SHA256,
            "classification": "exact pinned wrapper; FP8 function differs from the frozen parent only in logger formatting",
        },
    }


def native_selection_check(torch: Any, scores: Any, selected: Any, topk: int) -> dict:
    """Frozen verify_checks.algebra contract: causal unique IDs, exact score multiset."""
    valid = tuple(selected.shape) == (topk,) and bool(
        ((selected >= 0) & (selected < scores.numel())).all()
    )
    if valid:
        ordered = selected.sort().values
        valid = not bool((ordered[1:] == ordered[:-1]).any())
    exact = valid and torch.equal(
        scores[selected].sort().values, scores.topk(topk).values.sort().values
    )
    return {
        "passed": bool(exact),
        "causal_unique_ids": bool(valid),
        "exact_native_topk_score_multiset": bool(exact),
    }


def emit(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as stream:
        stream.write(json.dumps(event, sort_keys=True) + "\n")


def mode_name(batch: Any) -> str:
    mode = getattr(batch, "forward_mode", None)
    return str(getattr(mode, "name", mode))


def logical_role(layer_id: int) -> str:
    return "anchor" if layer_id < 3 or (layer_id - 2) % 4 == 0 else "shared"


def route_key(rows: int, layer_id: int) -> str | None:
    if rows % 4 or rows // 4 not in (1, 2, 4, 8, 16, 32, 64):
        return None
    return f"c{rows // 4}-{logical_role(layer_id)}"


class NativeAdapter:
    def __init__(self, manifest: Path) -> None:
        self.manifest_path = manifest
        self.manifest = json.loads(manifest.read_text())
        self.root = Path(os.environ["PRESENTATION_SERVING_RUN_ROOT"])
        self.mode = os.environ.get("PRESENTATION_SERVING_MODE", "measure")
        self.context: dict[str, Any] | None = None
        self.attention_context: dict[str, Any] | None = None
        self.index_context: dict[str, Any] | None = None
        self.rank: int | None = None
        self.seen: set[tuple[Any, ...]] = set()
        self.registered: set[int] = set()
        self.prepared: dict[int, dict[str, Any]] = {}
        self.scratch: dict[tuple[Any, ...], dict[str, Any]] = {}
        self.patches: list[tuple[Any, str, Any]] = []
        self.checked: set[tuple[Any, ...]] = set()
        self.marlowe = None
        self.graph_watch: dict[tuple[int, int], tuple[Any, ...]] = {}
        self.graph_checked: set[tuple[int, int]] = set()
        self.graph_numerical: dict[tuple[int, int], dict[str, Any]] = {}
        self.live_token_count = None

    def update_live_tokens(self, rows: int) -> None:
        require(
            self.live_token_count is not None and rows >= 0,
            "Missing native live-token counter",
        )
        self.live_token_count.fill_(rows)

    def safe_core_indices(self, indices):
        """Preserve live indices exactly; give only dead graph rows a safe address."""
        t = self.torch
        require(self.live_token_count is not None, "Core missing live-token counter")
        require(
            self.live_token_count.device == indices.device,
            "Live counter device differs",
        )
        key = ("safe_core_indices", tuple(indices.shape), str(indices.device))
        if key not in self.scratch:
            require(
                not t.cuda.is_current_stream_capturing(),
                "Dead-row scratch cold during capture",
            )
            self.scratch[key] = {
                "rows": t.arange(indices.shape[0], device=indices.device).reshape(
                    -1, 1
                ),
                "indices": t.empty_like(indices),
                "zero": t.zeros((), device=indices.device, dtype=indices.dtype),
            }
        scratch = self.scratch[key]
        t.where(
            scratch["rows"] < self.live_token_count,
            indices,
            scratch["zero"],
            out=scratch["indices"],
        )
        return scratch["indices"]

    def rope_pair(self, rotary: Any, rope_dim: int):
        """Match donor f01/upstream/fused_decode.py::_rope_2d on real caches.

        Native rotary caches can retain singleton broadcast dimensions. The
        fused kernels require [position, rope_dim / 2], contiguous BF16 halves.
        Cache this preparation before capture; token positions stay unchanged.
        """
        key = ("rope_pair", id(rotary), rope_dim)
        if key not in self.scratch:
            half = rope_dim // 2
            cos = getattr(rotary, "cos_cache", None)
            sin = getattr(rotary, "sin_cache", None)
            if cos is None or sin is None:
                cache = rotary.cos_sin_cache
                cos, sin = cache[..., :half], cache[..., half:]
            original_shapes = [list(cos.shape), list(sin.shape)]
            cos = cos.reshape(cos.shape[0], half).contiguous()
            sin = sin.reshape(sin.shape[0], half).contiguous()
            require(
                cos.dtype == sin.dtype == self.torch.bfloat16,
                "Fused native rotary cache must preserve BF16",
            )
            self.scratch[key] = {"pair": (cos, sin)}
            self.once(
                "rotary_cache_view",
                original_shapes=original_shapes,
                normalized_shape=list(cos.shape),
                rope_dim=rope_dim,
            )
        return self.scratch[key]["pair"]

    def event(self, event: str, **values: Any) -> None:
        emit(
            self.root / "attest" / f"dispatch-{os.getpid()}.jsonl",
            {
                "event": event,
                "pid": os.getpid(),
                "rank": self.rank,
                "recipe_sha256": self.manifest["recipe_sha256"],
                **values,
            },
        )

    def once(self, event: str, **values: Any) -> None:
        key = (event, json.dumps(values, sort_keys=True))
        if key not in self.seen:
            self.seen.add(key)
            self.event(event, **values)

    def patch(self, owner: Any, name: str, replacement: Any) -> None:
        self.patches.append((owner, name, getattr(owner, name)))
        setattr(owner, name, replacement)

    @contextmanager
    def scoped(self, name: str, value: dict[str, Any]):
        previous = getattr(self, name)
        setattr(self, name, value)
        try:
            yield
        finally:
            setattr(self, name, previous)

    def selected(self, rows: int, layer_id: int, phase: str) -> dict[str, Any]:
        if phase != "TARGET_VERIFY":
            return {}
        key = route_key(rows, layer_id)
        return self.manifest["routes"].get(key, {}) if key else {}

    def graph_copy(self, key, value):
        """Dedicated qualification storage: capture copies before producer reuse."""
        scratch_key = ("graph_snapshot", *key)
        if scratch_key not in self.scratch:
            require(
                not self.torch.cuda.is_current_stream_capturing(),
                "Graph numerical snapshot cold during capture",
            )
            self.scratch[scratch_key] = {"value": self.torch.empty_like(value)}
        snapshot = self.scratch[scratch_key]["value"]
        require(snapshot.shape == value.shape, "Graph snapshot shape changed")
        snapshot.copy_(value)
        return snapshot

    def watch_core(
        self,
        layer_id,
        rows,
        cache,
        indices,
        result,
        *,
        q=None,
        safe_indices=None,
        name=None,
        route=None,
        sm_scale=None,
    ):
        if not (
            self.mode == "graph"
            and layer_id in (26, 27)
            and self.context is not None
            and self.context["phase"] == "TARGET_VERIFY"
        ):
            return
        # Core outputs and index scratch are shared across layers. Retain copies,
        # not references that a later layer can overwrite before post-replay checks.
        latent = self.graph_copy(
            (rows, layer_id, "latent"), result.reshape(rows, 8, 512)
        )
        original = self.graph_copy((rows, layer_id, "indices"), indices)
        self.graph_watch[(rows, layer_id)] = (cache, original, latent)
        if q is not None:
            self.graph_numerical[(rows, layer_id)] = {
                "q": self.graph_copy((rows, layer_id, "q"), q),
                "safe_indices": self.graph_copy(
                    (rows, layer_id, "safe_indices"), safe_indices
                ),
                "name": name,
                "route": dict(route),
                "sm_scale": sm_scale,
            }

    def watch_graph_output(self, attn, x, output, phase):
        layer, rows = int(attn.layer_id), x.shape[0]
        if self.mode != "graph" or phase != "TARGET_VERIFY" or layer not in (26, 27):
            return
        record = self.graph_numerical.get((rows, layer))
        if record is not None:
            record.update(
                attn=attn,
                value=self.graph_copy((rows, layer, "value"), x),
                output=self.graph_copy((rows, layer, "output"), output),
            )

    def core_reference_spec(self, name, route, rows):
        if name in ("pyc02", "pyc03", "fused_core_value"):
            contract = self.marlowe.core_contract(route)
        elif name == "native_tilelang":
            inner = self.tilelang._pick_inner_iter(rows, 32, 256, 2)
            contract = {
                "reference": "source_fp8_online_probability",
                "block_k": 64,
                "tiles_per_split": inner,
                "kv_splits": 32 // inner,
                "fp8_max": 448.0,
                "log2e": 1.44269504,
            }
        else:
            route_name = (
                self.ops.ROUTE_4919 if name == "pr4919" else self.ops.ROUTE_5301
            )
            contract = self.ops.route_partition(route_name, rows)
            contract.update(
                reference="source_fp8_unscaled_probability"
                if name == "pr4919"
                else "source_fp8_online_probability",
                fp8_max=448.0,
                log2e=1.4426950408889634,
            )
        if name in ("pyc02", "pyc03"):
            reference = self.marlowe.module(
                route["case_id"], "verify_core_reference"
            ).attention
        elif name in ("pr4919", "fused_core_value"):
            reference = self.pr4919_reference.source_precision_attention
        else:
            reference = self.core_reference.attention
        return contract, reference

    def check_graph_numerical_state(self, live, padded):
        # The active presentation serving scope is the qualified low prefix.
        # Larger captures remain observable but cannot acquire fresh qualification
        # by a passing draw after their explicit historical exclusions.
        if padded // 4 not in (1, 2, 4, 8, 16, 32):
            return
        t = self.torch
        for layer in (26, 27):
            require(
                (padded, layer) in self.graph_numerical,
                "Graph omitted same-operand numerical snapshot",
            )
            snap = self.graph_numerical[(padded, layer)]
            cache, indices, latent = self.graph_watch[(padded, layer)]
            contract, reference = self.core_reference_spec(
                snap["name"], snap["route"], padded
            )
            actual_indices = indices[:live]
            valid = bool(
                ((actual_indices >= 0) & (actual_indices < cache.shape[0])).all()
            )
            require(valid, "Live graph numerical indices are invalid")
            expected = reference(
                snap["q"][:live],
                cache.reshape(-1, 576),
                actual_indices,
                snap["sm_scale"],
                contract,
            )
            attn = snap["attn"]
            expected_value = self.checks.absorb_reference(
                expected, attn.w_vc, attn.w_scale, "mi355x"
            )
            expected_output = self.reference.linear(
                expected_value.flatten(1), attn.o_proj.weight
            )
            actual_value_reference = self.checks.absorb_reference(
                latent[:live], attn.w_vc, attn.w_scale, "mi355x"
            )
            checks = {
                "core": self.checks.strict_compare(latent[:live], expected, heads=True),
                "value": self.checks.strict_compare(
                    snap["value"][:live], actual_value_reference.flatten(1)
                ),
                "output": self.checks.strict_compare(
                    snap["output"][:live],
                    self.reference.linear(snap["value"][:live], attn.o_proj.weight),
                ),
                "chained_suffix": self.checks.strict_compare(
                    snap["output"][:live], expected_output
                ),
                "live_counter": {"passed": int(self.live_token_count) == live},
                "sanitized_live_indices": {
                    "passed": bool(t.equal(snap["safe_indices"][:live], actual_indices))
                },
            }
            self.event(
                "graph_numerical_state",
                live_rows=live,
                padded_rows=padded,
                layer_id=layer,
                role=logical_role(layer),
                source_contract=contract,
                core_route=snap["name"],
                checks=checks,
                passed=all(value["passed"] for value in checks.values()),
            )

    def check_graph_live_state(self, batch, result, graph):
        if (
            self.mode != "graph"
            or mode_name(batch) != "TARGET_VERIFY"
            or not result.can_run_graph
        ):
            return
        live = int(batch.input_ids.shape[0])
        padded = int(graph.bs) * 4
        key = (live, padded)
        if key in self.graph_checked:
            return
        t = self.torch
        logits = result.logits_output.next_token_logits
        require(
            logits is not None and logits.shape[0] >= live, "Missing live target logits"
        )
        live_logits = logits[:live]
        checks = {
            "live_logits_no_nan_or_positive_inf": not bool(t.isnan(live_logits).any())
            and not bool(t.isposinf(live_logits).any()),
            "live_logits_have_finite_values": bool(
                t.isfinite(live_logits).any(-1).all()
            ),
        }
        slots = batch.out_cache_loc[:live].long()
        for layer in (26, 27):
            require(
                (padded, layer) in self.graph_watch, "Graph omitted watched native core"
            )
            cache, indices, latent = self.graph_watch[(padded, layer)]
            checks[f"layer{layer}_live_indices_in_bounds"] = bool(
                ((indices[:live] >= 0) & (indices[:live] < cache.shape[0])).all()
            )
            checks[f"layer{layer}_live_latent_finite"] = bool(
                t.isfinite(latent[:live]).all()
            )
            valid_slots = bool(((slots >= 0) & (slots < cache.shape[0])).all())
            checks[f"layer{layer}_live_cache_slots_in_bounds"] = valid_slots
            checks[f"layer{layer}_written_cache_finite"] = valid_slots and bool(
                t.isfinite(cache.view(t.uint8)[slots].view(cache.dtype).float()).all()
            )
        self.event(
            "graph_live_state",
            live_rows=live,
            padded_rows=padded,
            checks=checks,
            passed=all(checks.values()),
        )
        require(
            all(checks.values()), "Graph padding contaminated live outputs or KV state"
        )
        self.check_graph_numerical_state(live, padded)
        self.graph_checked.add(key)

    def needs_check(self, operation: str, layer_id: int, rows: int) -> bool:
        key = (operation, layer_id, rows)
        return (
            self.mode == "qualify"
            and layer_id in (26, 27)
            and rows in (4, 8, 16, 32, 64, 128, 256)
            and key not in self.checked
            and not self.torch.cuda.is_current_stream_capturing()
        )

    def checked_result(
        self, operation: str, layer_id: int, rows: int, checks: dict[str, Any]
    ) -> None:
        passed = all(row.get("passed") is True for row in checks.values())
        self.event(
            "correctness",
            operation=operation,
            layer_id=layer_id,
            role=logical_role(layer_id),
            rows=rows,
            checks=checks,
            passed=passed,
        )
        self.checked.add((operation, layer_id, rows))
        # Untimed qualification accumulates independent numerical failures so a
        # costly full-model load can expose all affected shapes. The smoke runner
        # rejects the complete receipt if any check failed; no failed arm is timed.

    def install(self) -> None:
        require(
            Path(__file__).resolve()
            == (
                Path(self.manifest["adapter_root"]) / "presentation_serving_adapter.py"
            ).resolve(),
            "Native adapter was not loaded from its immutable source overlay",
        )
        import torch

        self.torch = torch
        require(torch.version.hip is not None, "Presentation adapter is MI355X-only")
        source = Path(self.manifest["operator_source_root"])
        require(source.is_dir(), "Missing immutable operator package")
        for row in self.manifest["files"]:
            require(
                file_hash(Path(row["path"])) == row["sha256"],
                f"Changed source: {row['path']}",
            )
        sys.path.insert(0, str(source))
        self.ops = importlib.import_module("kernel_search.attention.native.verify_a01n")
        self.u02 = importlib.import_module(
            "kernel_search.attention.native.verify_u02_dual"
        )
        self.u02.source_proof = functools.lru_cache(maxsize=1)(
            functools.partial(latest_u02_source_proof, self.u02)
        )
        self.u02.source_proof()
        self.output = importlib.import_module(
            self.manifest.get("operator_modules", {}).get(
                "output", "staging.aiter5260.output_projection"
            )
        )
        self.merged = importlib.import_module(
            "kernel_search.attention.native.l01.merged_projection"
        )
        self.f01 = importlib.import_module(
            "kernel_search.attention.native.f01.fused_indexer"
        )
        if self.mode in ("qualify", "graph"):
            self.checks = importlib.import_module(
                "kernel_search.attention.native.verify_checks"
            )
            self.reference = importlib.import_module(
                "kernel_search.attention.native.reference"
            )
            self.cache_reference = importlib.import_module(
                "kernel_search.attention.native.cache"
            )
            self.preparation_reference = importlib.import_module(
                "kernel_search.attention.native.verify_preparation"
            )
            self.core_reference = importlib.import_module(
                "kernel_search.attention.native.verify_core_reference"
            )
            self.pr4919_reference = importlib.import_module("pr4919_reference")
        self.native = importlib.import_module(
            "sglang.srt.models.deepseek_common.attention_forward_methods.forward_mla_rocm"
        )
        self.dsa = importlib.import_module("sglang.srt.layers.attention.dsa_backend")
        self.indexer = importlib.import_module(
            "sglang.srt.layers.attention.dsa.dsa_indexer"
        )
        model = importlib.import_module("sglang.srt.model_executor.model_runner")
        native_modules = [self.native, self.dsa, self.indexer, model]
        graph_module = importlib.import_module(
            "sglang.srt.model_executor.runner.decode_cuda_graph_runner"
        )
        native_modules.append(graph_module)
        if any(
            row.get("core") == "native_tilelang"
            for row in self.manifest["routes"].values()
        ):
            self.tilelang = importlib.import_module(
                "sglang.kernels.ops.attention.dsa.tilelang_kernel"
            )
            native_modules.append(self.tilelang)
        if self.manifest.get("marlowe_cases"):
            native_modules.append(
                importlib.import_module("sglang.srt.layers.communicator")
            )
        require(
            self.manifest.get("native_source_hashes"),
            "Native hook source envelope is required",
        )
        for module in native_modules:
            actual = file_hash(Path(module.__file__))
            require(
                actual == self.manifest["native_source_hashes"].get(module.__name__),
                f"Native hook ABI source changed: {module.__name__}",
            )
            self.event(
                "loaded_source",
                module=module.__name__,
                path=module.__file__,
                sha256=actual,
            )
        # initialize finishes post-load transforms before any worker graph capture.
        original_initialize = model.ModelRunner.initialize

        @functools.wraps(original_initialize)
        def initialize(runner, *args, **kwargs):
            result = original_initialize(runner, *args, **kwargs)
            self.register_model(runner)
            return result

        self.patch(model.ModelRunner, "initialize", initialize)
        original_capture = graph_module.DecodeCudaGraphRunner.capture_one_shape

        @functools.wraps(original_capture)
        def capture_one_shape(graph, *args, **kwargs):
            if not getattr(graph.model_runner, "is_draft_worker", False):
                self.update_live_tokens(0)
            return original_capture(graph, *args, **kwargs)

        self.patch(
            graph_module.DecodeCudaGraphRunner, "capture_one_shape", capture_one_shape
        )
        original_forward = model.ModelRunner.forward

        @functools.wraps(original_forward)
        def forward(runner, *args, **kwargs):
            self.register_model(runner)
            batch = args[0] if args else kwargs.get("forward_batch")
            if (
                batch is not None
                and not getattr(runner, "is_draft_worker", False)
                and mode_name(batch) == "TARGET_VERIFY"
            ):
                # Enqueued on the same stream before native graph load/replay.
                # The captured sanitizer reads this stable device address.
                self.update_live_tokens(int(batch.input_ids.numel()))
            result = original_forward(runner, *args, **kwargs)
            if batch is not None and not getattr(runner, "is_draft_worker", False):
                graph = getattr(runner, "decode_cuda_graph_runner", None)
                self.once(
                    "model_execution",
                    phase=mode_name(batch),
                    rows=int(batch.input_ids.shape[0]),
                    requests=int(batch.batch_size),
                    can_run_graph=bool(result.can_run_graph),
                    graph_batch_size=getattr(graph, "bs", None),
                )
                self.check_graph_live_state(batch, result, graph)
            return result

        self.patch(model.ModelRunner, "forward", forward)
        self.install_backend()
        self.install_preparation()
        self.install_indexer()
        if self.manifest.get("marlowe_cases"):
            from presentation_serving_marlowe import NativeMarlowe

            self.marlowe = NativeMarlowe(self)
            self.marlowe.install()
        self.event(
            "hooks_installed",
            mode=self.mode,
            source_manifest_sha256=file_hash(self.manifest_path),
            requested_routes={
                key: {
                    op: value[op]
                    for op in (
                        "core",
                        "preparation",
                        "indexer",
                        "output",
                        "value",
                        "input",
                        "query",
                        "index_stream",
                    )
                    if op in value
                }
                for key, value in self.manifest["routes"].items()
            },
        )

    def register_model(self, runner: Any) -> None:
        if getattr(runner, "is_draft_worker", False) or id(runner) in self.registered:
            return
        from sglang.srt.runtime_context import get_parallel

        parallel = get_parallel()
        self.rank = int(parallel.tp_rank)
        layers = runner.model.model.layers
        require(len(layers) == 78, "Serving requires the full78-layer target model")
        require(
            int(parallel.tp_size) == 8 and int(runner.server_args.ep_size) == 1,
            "Wrong serving TP/EP mapping",
        )
        self.registered.add(id(runner))
        self.live_token_count = self.torch.zeros(
            (), dtype=self.torch.int32, device=layers[0].self_attn.o_proj.weight.device
        )
        self.event(
            "live_token_counter",
            device=str(self.live_token_count.device),
            initial_value=0,
            scope="target_only",
            update="before each target verify forward; zero for dummy capture",
        )
        inventory = []
        for layer_id, layer in enumerate(layers):
            attn = layer.self_attn
            require(int(attn.layer_id) == layer_id, "Target layer mapping differs")
            expected_role = logical_role(layer_id)
            skip_topk = getattr(attn, "skip_topk", None)
            indexer_present = getattr(attn, "indexer", None) is not None
            require(
                type(skip_topk) is bool
                and skip_topk == (expected_role == "shared")
                and indexer_present == (expected_role == "anchor"),
                f"Loaded target layer {layer_id} does not match {expected_role} policy",
            )
            if layer_id in (26, 27):
                require(
                    attn.next_skip_topk is True, "Qualification layer sharing differs"
                )
            require(
                attn.o_proj.reduce_results is False,
                "Output hook may not replace a TP collective",
            )
            if getattr(attn, "indexer", None) is not None:
                indexer = attn.indexer
                self.rope_pair(indexer.rotary_emb, indexer.rope_head_dim)
                if hasattr(indexer, "wk") and hasattr(indexer, "weights_proj"):
                    key, gate = indexer.wk.weight, indexer.weights_proj.weight
                    if (
                        key.dtype == gate.dtype == self.torch.bfloat16
                        and tuple(key.shape) == (128, 6144)
                        and tuple(gate.shape) == (32, 6144)
                    ):
                        self.prepared[id(indexer)] = {
                            "weight": self.torch.cat((key, gate), dim=0).contiguous()
                        }
                        self.install_merged_projection(indexer)
            self.install_output(attn)
            if self.marlowe is not None:
                self.marlowe.register(attn)
            inventory.append(
                {
                    "layer_id": layer_id,
                    "role": expected_role,
                    "skip_topk": skip_topk,
                    "indexer_present": indexer_present,
                    "wk_shape": list(attn.w_kc.shape),
                    "wk_dtype": str(attn.w_kc.dtype),
                    "wv_shape": list(attn.w_vc.shape),
                    "wv_dtype": str(attn.w_vc.dtype),
                    "absorbed_weight_scale": float(attn.w_scale),
                    "kv_scale": float(attn.attn_mqa.k_scale)
                    if attn.attn_mqa.k_scale is not None
                    else 1.0,
                    "o_proj_shape": list(attn.o_proj.weight.shape),
                    "o_proj_dtype": str(attn.o_proj.weight.dtype),
                }
            )
        self.event(
            "model_registered",
            full_model_layers=len(layers),
            tp_size=8,
            ep_size=1,
            layers=inventory,
        )

    def install_backend(self) -> None:
        cls = self.dsa.DeepseekSparseAttnBackend
        original_extend = cls.forward_extend
        signature = inspect.signature(original_extend)

        @functools.wraps(original_extend)
        def extend(backend, *args, **kwargs):
            values = signature.bind(backend, *args, **kwargs).arguments
            layer, batch = values["layer"], values["forward_batch"]
            self.once(
                "native_phase",
                phase=mode_name(batch),
                layer_id=int(layer.layer_id),
                rows=values["q"].shape[0],
                during_capture=self.torch.cuda.is_current_stream_capturing(),
            )
            with self.scoped(
                "context", {"layer": layer, "batch": batch, "phase": mode_name(batch)}
            ):
                return original_extend(backend, *args, **kwargs)

        self.patch(cls, "forward_extend", extend)
        original_tile = cls._forward_tilelang

        @functools.wraps(original_tile)
        def tile(backend, q_all, kv_cache, v_head_dim, page_table_1, sm_scale):
            ctx = self.context
            layer_id = int(ctx["layer"].layer_id) if ctx else -1
            phase = ctx["phase"] if ctx else "outside_target_extend"
            route = self.selected(q_all.shape[0], layer_id, phase)
            name = route.get("core")
            valid = (
                ctx is not None
                and name
                in (
                    "pr4919",
                    "pr5301",
                    "pyc02",
                    "pyc03",
                    "fused_core_value",
                    "native_tilelang",
                )
                and q_all.dtype == self.torch.float8_e4m3fn
                and kv_cache.dtype == q_all.dtype
                and q_all.ndim == 3
                and tuple(q_all.shape[1:]) == (8, 576)
                and kv_cache.ndim == 3
                and tuple(kv_cache.shape[1:]) == (1, 576)
                and tuple(page_table_1.shape) == (q_all.shape[0], 2048)
                and page_table_1.dtype == self.torch.int32
                and v_head_dim == 512
            )
            k_scale = getattr(ctx["layer"], "k_scale", None) if ctx else None
            # Installed TileLang's native FP8 path does not carry a nonunit Q scale.
            # PR4919 accepts the checkpoint-owned KV scalar directly. FlyDSL's exact
            # source has no scale input; retain native fallback for that unsupported ABI.
            scale_value = self.scale_value(layer_id, k_scale)
            if name != "pr4919" and scale_value != 1.0:
                valid = False
            self.once(
                "core_route",
                phase=phase,
                layer_id=layer_id,
                role=logical_role(layer_id),
                rows=q_all.shape[0],
                selected=name if valid else "native",
                requested=name,
                kv_scale=scale_value,
                during_capture=self.torch.cuda.is_current_stream_capturing(),
            )
            if not valid:
                if name == "fused_core_value" and self.attention_context is not None:
                    self.attention_context["fused_core_fallback"] = True
                result = original_tile(
                    backend, q_all, kv_cache, v_head_dim, page_table_1, sm_scale
                )
                self.watch_core(
                    layer_id, q_all.shape[0], kv_cache, page_table_1, result
                )
                return result
            watched_indices = page_table_1
            page_table_1 = self.safe_core_indices(page_table_1)
            if name in ("pyc02", "pyc03", "fused_core_value"):
                require(self.marlowe is not None, "Private core has no source adapter")
                result = self.marlowe.core(
                    route, q_all, kv_cache, page_table_1, sm_scale
                )
            elif name == "native_tilelang":
                result = original_tile(
                    backend, q_all, kv_cache, v_head_dim, page_table_1, sm_scale
                )
            elif name == "pr4919":
                scratch = self.ops._ensure_scratch(
                    self.ops.ROUTE_4919, q_all.shape[0], q_all.device
                )
                scalar = scratch["scale"] if k_scale is None else k_scale
                if not isinstance(scalar, self.torch.Tensor):
                    scalar = self.scalar_tensor(layer_id, scale_value, q_all.device)
                result, _ = self.ops.load_pr4919().sparse_mla_fwd(
                    q_all,
                    kv_cache,
                    scratch["indptr"],
                    page_table_1.reshape(-1),
                    sm_scale,
                    kv_scale=scalar,
                    q_scale=scratch["scale"],
                    kv_lora_rank=512,
                    qk_rope_head_dim=64,
                    out=scratch["out"],
                    dot_precision="fp8",
                )
                result = result[..., :512]
            else:
                result = self.ops.core_pr5301(
                    q_all,
                    kv_cache,
                    page_table_1,
                    None,
                    None,
                    None,
                    sm_scale,
                    0,
                    2048,
                    "mi355x",
                )
            if self.needs_check("core", layer_id, q_all.shape[0]):
                require(
                    scale_value == 1.0,
                    "Actual nonunit core scale needs a source-specific reference before qualification",
                )
                require(
                    bool((page_table_1 >= 0).all()),
                    "Integration reference requires actual fully populated selected rows",
                )
                contract, reference = self.core_reference_spec(
                    name, route, q_all.shape[0]
                )
                expected = reference(
                    q_all, kv_cache.reshape(-1, 576), page_table_1, sm_scale, contract
                )
                checked = (
                    result.reshape_as(expected) if name == "native_tilelang" else result
                )
                metrics = self.checks.strict_compare(checked, expected, heads=True)
                if not metrics["passed"]:
                    self.dump_core_failure(
                        layer_id,
                        name,
                        q_all,
                        kv_cache,
                        page_table_1,
                        sm_scale,
                        contract,
                        checked,
                        expected,
                        metrics,
                    )
                self.checked_result(
                    "core", layer_id, q_all.shape[0], {"latent": metrics}
                )
                require(
                    self.attention_context is not None,
                    "Core lost native attention boundary",
                )
                self.attention_context["expected_latent"] = expected
            self.watch_core(
                layer_id,
                q_all.shape[0],
                kv_cache,
                watched_indices,
                result,
                q=q_all,
                safe_indices=page_table_1,
                name=name,
                route=route,
                sm_scale=sm_scale,
            )
            return result

        self.patch(cls, "_forward_tilelang", tile)

    def dump_core_failure(
        self,
        layer,
        name,
        q,
        cache,
        selected,
        sm_scale,
        contract,
        actual,
        expected,
        metrics,
    ):
        """Preserve exact failing operands without serializing the full model KV pool."""
        t = self.torch
        slots, inverse = t.unique(selected.reshape(-1).long(), return_inverse=True)
        compact = cache.reshape(-1, 576)[slots]
        delta = actual.float() - expected.float()
        denominator = expected.float().square().mean(-1).sqrt()
        numerator = delta.square().mean(-1).sqrt()
        ratio = numerator / denominator.clamp_min(1e-8)
        worst = int(ratio.reshape(-1).argmax())
        row, head = divmod(worst, ratio.shape[-1])
        path = (
            self.root
            / "attest"
            / f"core-failure-r{self.rank}-l{layer}-m{q.shape[0]}.pt"
        )
        t.save(
            {
                "query": q.detach().cpu(),
                "compact_kv": compact.detach().cpu(),
                "selected": inverse.reshape_as(selected).to(t.int32).cpu(),
                "original_selected": selected.detach().cpu(),
                "original_slots": slots.cpu(),
                "actual": actual.detach().cpu(),
                "expected": expected.detach().cpu(),
                "reference_rms": denominator.cpu(),
                "error_rmse": numerator.cpu(),
                "actual_rms": actual.float().square().mean(-1).sqrt().cpu(),
                "head_max_abs": delta.abs().amax(-1).cpu(),
                "sm_scale": sm_scale,
                "contract": contract,
                "core": name,
                "original_cache_shape": tuple(cache.shape),
                "original_cache_stride": tuple(cache.stride()),
                "launch_kwargs": {
                    "kv_lora_rank": 512,
                    "qk_rope_head_dim": 64,
                    "dot_precision": "fp8",
                    "q_scale": 1.0,
                    "kv_scale": 1.0,
                },
            },
            path,
        )
        self.event(
            "core_failure_diagnostic",
            layer_id=layer,
            rows=q.shape[0],
            core=name,
            contract=contract,
            metrics=metrics,
            float32_matmul_precision=t.get_float32_matmul_precision(),
            allow_tf32=t.backends.cuda.matmul.allow_tf32,
            worst_head={
                "row": row,
                "head": head,
                "reference_rms": float(denominator[row, head]),
                "error_rmse": float(numerator[row, head]),
                "nrmse": float(ratio[row, head]),
                "max_abs": float(delta[row, head].abs().max()),
            },
            evidence={"path": str(path), "sha256": file_hash(path)},
        )

    def scale_value(self, layer_id: int, value: Any) -> float:
        key = ("scale_value", layer_id)
        if key not in self.scratch:
            require(
                not self.torch.cuda.is_current_stream_capturing(),
                "KV scale identity is cold during capture",
            )
            self.scratch[key] = {"value": 1.0 if value is None else float(value)}
        return self.scratch[key]["value"]

    def scalar_tensor(self, layer_id: int, value: float, device: Any):
        key = ("scale_tensor", layer_id, value, str(device))
        if key not in self.scratch:
            require(
                not self.torch.cuda.is_current_stream_capturing(),
                "KV scalar is cold during capture",
            )
            self.scratch[key] = {
                "value": self.torch.tensor(
                    value, dtype=self.torch.float32, device=device
                )
            }
        return self.scratch[key]["value"]

    def install_preparation(self) -> None:
        cls = self.native.DeepseekMLARocmForwardMixin
        for method in ("forward_absorb_rocm_prepare", "forward_absorb_rocm_core"):
            original = getattr(cls, method)
            signature = inspect.signature(original)

            @functools.wraps(original)
            def wrapped(
                attn, *args, _original=original, _signature=signature, **kwargs
            ):
                values = _signature.bind(attn, *args, **kwargs).arguments
                batch = values["forward_batch"]
                with self.scoped(
                    "attention_context",
                    {"attn": attn, "phase": mode_name(batch), "batch": batch},
                ):
                    result = _original(attn, *args, **kwargs)
                    if (
                        self.marlowe is not None
                        and _original.__name__ == "forward_absorb_rocm_prepare"
                    ):
                        self.marlowe.finish_preparation(attn)
                    return result

            self.patch(cls, method, wrapped)
        original_absorb = self.native.rocm_absorb_q_bmm

        @functools.wraps(original_absorb)
        def absorb(attn, q_nope, *, is_capture_mode):
            ctx = self.attention_context
            route = self.selected(
                q_nope.shape[0], int(attn.layer_id), ctx["phase"] if ctx else ""
            )
            from sglang.srt.runtime_context import get_parallel

            valid = (
                route.get("preparation") == "u02_dual"
                and not get_parallel().dcp_enabled
                and not attn.use_deep_gemm_bmm
                and not self.native._SGLANG_EXPERIMENTAL_LORA_OPTI
                and not self.native.is_kv_b_lora_active(attn)
                and attn._skip_rope_for_dsa_tilelang_fused()
                and attn.rotary_emb is not None
                and not attn.rotary_emb.is_neox_style
                and attn.w_kc.dtype == self.torch.float8_e4m3fn
                and attn.w_scale.numel() == 1
                and tuple(q_nope.shape[1:]) == (8, 192)
                and tuple(attn.w_kc.shape) == (8, 192, 512)
            )
            attn._presentation_deferred_q_absorb = valid
            if valid:
                # The guarded native path only transposes this value before its
                # fused-preparation helper. Defer the multiplication to U02; no
                # speculative copy or duplicate absorbed GEMM is performed.
                return q_nope.transpose(0, 1)
            return original_absorb(attn, q_nope, is_capture_mode=is_capture_mode)

        self.patch(self.native, "rocm_absorb_q_bmm", absorb)
        original_prepare = self.native._fused_rope_cat_and_cache

        @functools.wraps(original_prepare)
        def prepare(attn, q_nope_out, q_pe, k_nope, k_pe, positions, out_cache_loc):
            if not getattr(attn, "_presentation_deferred_q_absorb", False):
                return original_prepare(
                    attn, q_nope_out, q_pe, k_nope, k_pe, positions, out_cache_loc
                )
            attn._presentation_deferred_q_absorb = False
            cache = self.native.get_token_to_kv_pool().get_key_buffer(
                attn.attn_mqa.layer_id
            )
            check = self.needs_check(
                "preparation", int(attn.layer_id), q_nope_out.shape[0]
            )
            if check:
                require(
                    bool((out_cache_loc >= 0).all()),
                    "Integration preparation requires real active cache writes",
                )
                before = cache[out_cache_loc.long()].clone()
                expected_absorbed = original_absorb(
                    attn, q_nope_out, is_capture_mode=False
                ).transpose(0, 1)
                expected_q = original_prepare(
                    attn,
                    expected_absorbed,
                    q_pe,
                    k_nope,
                    k_pe,
                    positions,
                    out_cache_loc,
                )[0].clone()
                expected_cache = cache[out_cache_loc.long()].clone()
                cache[out_cache_loc.long()] = before
            q, witness, _ = self.u02.prepare_dual(
                q_nope_out,
                q_pe,
                k_nope.squeeze(1),
                k_pe.squeeze(1),
                attn.w_kc,
                attn.w_scale,
                cache,
                out_cache_loc,
                positions,
                attn.rotary_emb.cos_cache,
                attn.rotary_emb.sin_cache,
                attn.attn_mqa.k_scale,
                attn.rotary_emb.is_neox_style,
            )
            if check:
                checks = {
                    "query": self.checks.strict_compare(
                        q.float(), expected_q.float(), heads=True
                    ),
                    "cache_writes": {
                        "passed": bool(
                            self.torch.equal(
                                cache[out_cache_loc.long()].view(self.torch.uint8),
                                expected_cache.view(self.torch.uint8),
                            )
                        )
                    },
                    "actual_weight_scale": {
                        "passed": attn.w_scale.numel() == 1,
                        "value": float(attn.w_scale),
                    },
                }
                self.checked_result(
                    "preparation", int(attn.layer_id), q.shape[0], checks
                )
            self.once(
                "preparation_route",
                phase="TARGET_VERIFY",
                layer_id=int(attn.layer_id),
                rows=q.shape[0],
                selected="u02_dual",
                during_capture=self.torch.cuda.is_current_stream_capturing(),
            )
            # Native TARGET_VERIFY consumes only q_cat; K was written by U02 and
            # save_kv_cache=False, so its otherwise unused k_rope return is None.
            return q, witness[..., 512:], None, None

        self.patch(self.native, "_fused_rope_cat_and_cache", prepare)

    def install_output(self, attn: Any) -> None:
        original = attn.o_proj.forward

        @functools.wraps(original)
        def project(x, *args, **kwargs):
            ctx = self.attention_context
            route = (
                self.selected(
                    x.shape[0],
                    int(attn.layer_id),
                    ctx["phase"] if ctx and hasattr(x, "shape") else "",
                )
                if hasattr(x, "shape")
                else {}
            )
            valid = (
                route.get("output") in ("pr5260", "pyg01")
                and not args
                and not kwargs
                and x.dtype == self.torch.bfloat16
                and attn.o_proj.weight.dtype == x.dtype
                and tuple(attn.o_proj.weight.shape) == (6144, 2048)
                and x.shape[-1] == 2048
                and x.is_contiguous()
                and attn.o_proj.weight.is_contiguous()
                and getattr(attn.o_proj, "bias", None) is None
            )
            if not valid:
                if route.get("output") in ("pr5260", "pyg01"):
                    self.once(
                        "output_route",
                        phase=ctx["phase"],
                        layer_id=int(attn.layer_id),
                        rows=x.shape[0],
                        selected="native",
                        requested=route["output"],
                        reason="actual_output_ABI_outside_source",
                        during_capture=self.torch.cuda.is_current_stream_capturing(),
                    )
                result = original(x, *args, **kwargs)
            else:
                self.once(
                    "output_route",
                    phase=ctx["phase"],
                    layer_id=int(attn.layer_id),
                    rows=x.shape[0],
                    selected=route["output"],
                    during_capture=self.torch.cuda.is_current_stream_capturing(),
                )
                result = (
                    self.marlowe.output(route, x, attn.o_proj.weight)
                    if route["output"] == "pyg01"
                    else self.output.output_projection(x, attn.o_proj.weight, "mi355x"),
                    None,
                )
                if self.needs_check(
                    "output_projection", int(attn.layer_id), x.shape[0]
                ):
                    expected = self.reference.linear(x, attn.o_proj.weight)
                    self.checked_result(
                        "output_projection",
                        int(attn.layer_id),
                        x.shape[0],
                        {"output": self.checks.strict_compare(result[0], expected)},
                    )
            if ctx is not None and "expected_latent" in ctx:
                expected_value = self.checks.absorb_reference(
                    ctx.pop("expected_latent"), attn.w_vc, attn.w_scale, "mi355x"
                )
                expected_output = self.reference.linear(
                    expected_value.flatten(1), attn.o_proj.weight
                )
                self.checked_result(
                    "chained_suffix",
                    int(attn.layer_id),
                    x.shape[0],
                    {"output": self.checks.strict_compare(result[0], expected_output)},
                )
            self.watch_graph_output(attn, x, result[0], ctx["phase"] if ctx else "")
            return result

        self.patch(attn.o_proj, "forward", project)

    def install_indexer(self) -> None:
        cls = self.indexer.Indexer
        original = cls.forward_cuda
        signature = inspect.signature(original)

        @functools.wraps(original)
        def forward(indexer, *args, **kwargs):
            bound = signature.bind(indexer, *args, **kwargs)
            bound.apply_defaults()
            values = bound.arguments
            values.setdefault("return_indices", True)
            values["phase"] = mode_name(values["forward_batch"])
            x = values["x"]
            rows = x.shape[0] if hasattr(x, "shape") else -1
            values["route"] = self.selected(
                rows, int(values["layer_id"]), values["phase"]
            )
            with self.scoped("index_context", values):
                if self.marlowe is not None:
                    handled, result = self.marlowe.indexer(
                        indexer, values, original, args, kwargs
                    )
                    if handled:
                        return result
                if values["route"].get("indexer") == "f01":
                    result = self.fused_indexer(indexer, values)
                    if result is not None:
                        return result
                return original(indexer, *args, **kwargs)

        self.patch(cls, "forward_cuda", forward)
        requested = {row.get("indexer") for row in self.manifest["routes"].values()} - {
            None,
            "native",
        }
        require(
            requested <= {"f01", "l01", "l02", "i01_i04"},
            f"Unknown native indexer integration: {sorted(requested)}",
        )
        original_gates = cls._weights_proj_bf16_in_fp32_out

        @functools.wraps(original_gates)
        def gates(indexer, x):
            ctx = self.index_context
            if ctx and ctx.get("merged_result") is not None:
                require(
                    ctx["self"] is indexer and x is ctx["x"],
                    "Merged gate consumer input differs",
                )
                return ctx["merged_result"][1]
            return original_gates(indexer, x)

        self.patch(cls, "_weights_proj_bf16_in_fp32_out", gates)

    def install_merged_projection(self, indexer: Any) -> None:
        original = indexer.wk.forward

        @functools.wraps(original)
        def key(x, *args, **kwargs):
            ctx = self.index_context
            valid = (
                ctx
                and ctx["self"] is indexer
                and ctx["route"].get("indexer") == "l01"
                and ctx["phase"] == "TARGET_VERIFY"
                and not args
                and not kwargs
                and x is ctx["x"]
                and x.dtype == self.torch.bfloat16
                and x.ndim == 2
                and x.shape[1] == 6144
                and x.is_contiguous()
                and not indexer.use_dsa_indexer_fusion
                and (
                    indexer.alt_stream is None
                    or self.indexer.DUAL_STREAM_TOKEN_THRESHOLD == 0
                )
            )
            if not valid:
                return original(x, *args, **kwargs)
            pair = self.merged.run(x, self.prepared[id(indexer)]["weight"])
            if self.needs_check("merged_key_gate", int(indexer.layer_id), x.shape[0]):
                expected = self.reference.linear(
                    x, self.prepared[id(indexer)]["weight"]
                )
                self.checked_result(
                    "merged_key_gate",
                    int(indexer.layer_id),
                    x.shape[0],
                    {
                        "key": self.checks.strict_compare(pair[0], expected[:, :128]),
                        "gates": self.checks.strict_compare(pair[1], expected[:, 128:]),
                    },
                )
            ctx["merged_result"] = pair
            self.once(
                "indexer_route",
                phase=ctx["phase"],
                layer_id=int(indexer.layer_id),
                rows=x.shape[0],
                selected="l01",
                during_capture=self.torch.cuda.is_current_stream_capturing(),
            )
            return pair[0], None

        self.patch(indexer.wk, "forward", key)

    def fused_indexer(self, indexer: Any, ctx: dict[str, Any]):
        x, qlow, batch = ctx["x"], ctx["q_lora"], ctx["forward_batch"]
        layer_id, rows = int(ctx["layer_id"]), qlow.shape[0]
        pool = self.indexer.get_token_to_kv_pool()
        backend = self.indexer.get_attn_backend()
        metadata = backend.get_indexer_metadata(layer_id, batch)
        valid = (
            metadata is not None
            and 0 < rows <= 48
            and rows == x.shape[0]
            and x.dtype == qlow.dtype == self.torch.bfloat16
            and x.shape[1] == 6144
            and qlow.shape[1] == 2048
            and id(indexer) in self.prepared
            and not indexer.use_dsa_indexer_fusion
            and ctx["return_indices"]
            and pool.page_size == 64
            and self.indexer._use_aiter_preshuffle
            and getattr(backend, "use_fused_topk", False)
            and indexer.block_size == 128
            and indexer.scale_fmt == "ue8m0"
            and not indexer.rotary_emb.is_neox_style
            and indexer.index_topk == 2048
            and not indexer.num_init_tokens
            and not indexer.num_local_tokens
            and not indexer.dsa_enable_prefill_cp
            and batch.attn_cp_metadata is None
            and not getattr(indexer.wq_b, "set_lora", False)
            and indexer.wq_b.weight.dtype == self.torch.bfloat16
            and tuple(indexer.wq_b.weight.shape) == (4096, 2048)
        )
        if hasattr(pool, "_is_layer_owned") and not pool._is_layer_owned(layer_id):
            valid = False
        if not valid:
            self.once(
                "indexer_route",
                phase=ctx["phase"],
                layer_id=layer_id,
                rows=rows,
                selected="native",
                requested="f01",
                reason="real_shape_cache_or_distribution_outside_source_ABI",
                during_capture=self.torch.cuda.is_current_stream_capturing(),
            )
            return None
        pages = metadata.get_page_table_64()
        lengths = metadata.get_seqlens_expanded()
        cache = pool.get_index_k_with_scale_buffer(layer_id=layer_id)
        if lengths.ndim == 2:
            lengths = lengths.reshape(-1)
        if (
            pages.shape[0] != rows
            or lengths.numel() != rows
            or batch.out_cache_loc.numel() != rows
        ):
            self.once(
                "indexer_route",
                phase=ctx["phase"],
                layer_id=layer_id,
                rows=rows,
                selected="native",
                requested="f01",
                reason="native_metadata_rows_differ_from_padded_query",
                during_capture=self.torch.cuda.is_current_stream_capturing(),
            )
            return None
        columns = pages.shape[1] * 64
        scratch = self.f01_scratch(
            indexer, rows, columns, x.device,
            shared_stream=self.f01_workspace_stream(ctx, layer_id, rows),
        )
        if hasattr(pool, "invalidate_index_buffer_for_layer"):
            pool.invalidate_index_buffer_for_layer(layer_id)
        values = self.f01.run(
            qlow,
            x,
            indexer.wq_b.weight,
            self.prepared[id(indexer)]["weight"],
            scratch["norm_weight"],
            scratch["norm_bias"],
            ctx["positions"],
            *self.rope_pair(indexer.rotary_emb, indexer.rope_head_dim),
            cache,
            batch.out_cache_loc,
            lengths,
            pages,
            scratch["query_projected"],
            scratch["key_gate_projected"],
            scratch["query_fp8"],
            scratch["head_gates"],
            scratch["logits"],
            scratch["ghist"],
            scratch["cursor"],
            scratch["candidate_indices"],
            scratch["candidate_values"],
            float(indexer.k_norm.variance_epsilon),
        )
        if self.needs_check("fused_indexer", layer_id, rows):
            self.check_fused_indexer(
                indexer, ctx, values, cache, pages, lengths, scratch
            )
        self.once(
            "indexer_route",
            phase=ctx["phase"],
            layer_id=layer_id,
            rows=rows,
            columns=columns,
            selected="f01",
            during_capture=self.torch.cuda.is_current_stream_capturing(),
        )
        selected = self.indexer._broadcast_indexer_topk_from_rank0(values[0])
        return self.indexer.maybe_capture_indexer_topk(layer_id, selected)

    def check_fused_indexer(self, indexer, ctx, values, cache, pages, lengths, scratch):
        t, ref = self.torch, self.reference
        selected, query, gates, scores, projected_q, projected_k, projected_g = values
        rows, layer_id = query.shape[0], int(ctx["layer_id"])
        slots = ctx["forward_batch"].out_cache_loc
        require(
            bool((slots >= 0).all()) and bool((lengths >= 2048).all()),
            "F01 real-input check requires populated active histories",
        )
        checks = {
            "query_projection": self.checks.strict_compare(
                projected_q,
                ref.linear(ctx["q_lora"], indexer.wq_b.weight).reshape(rows, 32, 128),
            ),
            "key_projection": self.checks.strict_compare(
                projected_k, ref.linear(ctx["x"], indexer.wk.weight)
            ),
            "gate_projection": self.checks.strict_compare(
                projected_g, ref.linear(ctx["x"], indexer.weights_proj.weight)
            ),
        }
        rope_cos, rope_sin = self.rope_pair(indexer.rotary_emb, indexer.rope_head_dim)
        cos = rope_cos[ctx["positions"]].float()
        sin = rope_sin[ctx["positions"]].float()
        iq = t.cat(
            (ref.rope(projected_q[..., :64], cos, sin, False), projected_q[..., 64:]),
            -1,
        )
        ik = t.nn.functional.layer_norm(
            projected_k.float(),
            (128,),
            indexer.k_norm.weight.float(),
            indexer.k_norm.bias.float(),
            float(indexer.k_norm.variance_epsilon),
        ).to(t.bfloat16)
        ik = t.cat((ref.rope(ik[..., :64], cos, sin, False), ik[..., 64:]), -1)
        iq, ik = ref.hadamard(iq), ref.hadamard(ik)
        _, qs, _ = ref.quantize_rows(iq, t.float8_e4m3fn, round_scale=True)
        _, ks, _ = ref.quantize_rows(ik, t.float8_e4m3fn, round_scale=True)
        keys, stored_scales = self.cache_reference.index_rows(
            cache, slots, 64, t.float8_e4m3fn, preshuffle=16
        )
        checks.update(
            {
                "query_quantization": self.preparation_reference.fp8_rounding(
                    query, iq, qs
                ),
                "written_keys": self.preparation_reference.fp8_rounding(keys, ik, ks),
                "written_scales": self.preparation_reference.scale_compare(
                    stored_scales, ks
                ),
                "scaled_gates": self.checks.strict_compare(
                    gates,
                    (
                        (projected_g * 32**-0.5).float().unsqueeze(-1) * qs * 128**-0.5
                    ).squeeze(-1),
                ),
                "zero_scratch": {
                    "passed": int(t.count_nonzero(scratch["ghist"])) == 0
                    and int(t.count_nonzero(scratch["cursor"])) == 0
                },
            }
        )
        selection_rows, cutoff_diagnostics, score_evidence = [], [], []
        for row in range(rows):
            visible = int(lengths[row])
            logical = t.arange(visible, device=query.device)
            physical = pages[row, logical // 64].long() * 64 + logical % 64
            keys, scales = self.cache_reference.index_rows(
                cache, physical, 64, t.float8_e4m3fn, preshuffle=16
            )
            expected_scores = (
                t.relu(query[row].float() @ keys.float().T) * gates[row, :, None]
            ).sum(0) * scales[:, 0]
            checks[f"scores_row{row}"] = self.checks.strict_compare(
                scores[row, :visible], expected_scores
            )
            chosen = self.cache_reference.logical_selection(
                selected[row : row + 1], physical.unsqueeze(0)
            )
            selection_rows.append(
                native_selection_check(t, scores[row, :visible], chosen[0], 2048)
            )
            cutoff_diagnostics.append(
                importlib.import_module(
                    "kernel_search.attention.native.numerics"
                ).selection_check(expected_scores.unsqueeze(0), chosen, 2048)
            )
            score_evidence.append(
                {
                    "native_scores": scores[row, :visible].detach().cpu(),
                    "independent_fp32_scores": expected_scores.detach().cpu(),
                    "logical_selected": chosen[0].detach().cpu(),
                    "physical_selected": selected[row].detach().cpu(),
                    "visible_physical_slots": physical.detach().cpu(),
                }
            )
        score_path = (
            self.root / "attest" / f"index-scores-r{self.rank}-l{layer_id}-m{rows}.pt"
        )
        t.save(score_evidence, score_path)
        self.once(
            "indexer_cutoff_diagnostic",
            layer_id=layer_id,
            rows=rows,
            admission=False,
            classification="frozen v3: separately checked native-score topk and independent scorer; FP32 cutoff is diagnostic",
            checks=cutoff_diagnostics,
            evidence={"path": str(score_path), "sha256": file_hash(score_path)},
        )
        checks["selection"] = {
            "passed": all(row["passed"] for row in selection_rows),
            "rows": selection_rows,
        }
        self.checked_result("fused_indexer", layer_id, rows, checks)

    def f01_workspace_stream(self, ctx, layer_id, rows):
        route = ctx.get("route", {})
        if (
            self.manifest.get("share_f01_workspace", False)
            and ctx["phase"] == "TARGET_VERIFY"
            and rows in (4, 8, 16)
            and logical_role(layer_id) == "anchor"
            and route.get("indexer") == "f01"
            and route.get("index_stream", "native") in ("native", "r03")
            and self.attention_context is not None
            and int(self.attention_context["attn"].layer_id) == layer_id
            and not self.native.get_parallel().dcp_enabled
        ):
            return route.get("index_stream", "native")
        return None

    def f01_workspace(self, rows: int, columns: int, device: Any, stream_role: str):
        """Only transient F01 scores/candidates; finalized indices never alias it.

        Layer calls on the admitted native/R03 paths are serialized. Keep exact
        shape and stream role separate so capture does not introduce a stride
        change or cross-stream alias; a different Engine owns another scratch map.
        """
        require(stream_role in ("native", "r03"), "Unknown F01 workspace stream")
        t = self.torch
        key = ("f01_workspace", str(device), rows, columns, stream_role)
        if key not in self.scratch:
            require(
                not t.cuda.is_current_stream_capturing(),
                "Shared F01 workspace cold during capture",
            )
            self.scratch[key] = {
                "logits": t.empty((rows, columns), dtype=t.float32, device=device),
                "candidate_indices": t.empty(
                    (rows, max(2048, columns)), dtype=t.int32, device=device
                ),
                "candidate_values": t.empty(
                    (rows, max(2048, columns)), dtype=t.float32, device=device
                ),
            }
        return self.scratch[key]

    def f01_scratch(
        self, indexer: Any, rows: int, columns: int, device: Any, *, shared_stream=None
    ):
        key = ("f01", id(indexer), rows, columns, str(device), shared_stream)
        if key in self.scratch:
            return self.scratch[key]
        require(
            not self.torch.cuda.is_current_stream_capturing(),
            "F01 scratch cold during capture",
        )
        _, _, _, topk = self.f01.loader.modules()
        t = self.torch
        scratch = {
            "norm_weight": indexer.k_norm.weight.float().contiguous(),
            "norm_bias": indexer.k_norm.bias.float().contiguous(),
            "query_projected": t.empty((rows, 4096), dtype=t.bfloat16, device=device),
            "key_gate_projected": t.empty((rows, 160), dtype=t.bfloat16, device=device),
            "query_fp8": t.empty((rows, 32, 128), dtype=t.float8_e4m3fn, device=device),
            "head_gates": t.empty((rows, 32), dtype=t.float32, device=device),
            "ghist": t.zeros((rows, topk.hist_stride()), dtype=t.int32, device=device),
            "cursor": t.zeros((rows, 32), dtype=t.int32, device=device),
        }
        workspace = (
            self.f01_workspace(rows, columns, device, shared_stream)
            if shared_stream is not None
            else {
                "logits": t.empty((rows, columns), dtype=t.float32, device=device),
                "candidate_indices": t.empty(
                    (rows, max(2048, columns)), dtype=t.int32, device=device
                ),
                "candidate_values": t.empty(
                    (rows, max(2048, columns)), dtype=t.float32, device=device
                ),
            }
        )
        scratch.update(workspace)
        self.scratch[key] = scratch
        return scratch


def scheduler_process(*args, **kwargs):
    module = importlib.import_module("sglang.srt.managers.scheduler")
    # Spawn imports a fresh scheduler module, without the parent's loader alias.
    # Fork/in-process launch retains the alias. Both must reach the native entry.
    native = getattr(module, "_presentation_native_run_scheduler_process", module.run_scheduler_process)
    require(native is not scheduler_process, "Native scheduler entry was lost")
    adapter = NativeAdapter(Path(os.environ["PRESENTATION_SERVING_MANIFEST"]))
    adapter.install()
    return native(*args, **kwargs)


class SchedulerLoader(importlib.abc.Loader):
    def __init__(self, wrapped):
        self.wrapped = wrapped

    def create_module(self, spec):
        return self.wrapped.create_module(spec)

    def exec_module(self, module):
        self.wrapped.exec_module(module)
        module._presentation_native_run_scheduler_process = module.run_scheduler_process
        module.run_scheduler_process = scheduler_process


class SchedulerFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname != "sglang.srt.managers.scheduler":
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        require(
            spec is not None and spec.loader is not None,
            "Cannot resolve native scheduler",
        )
        spec.loader = SchedulerLoader(spec.loader)
        return spec


def install_import_hook() -> None:
    require(
        "sglang.srt.managers.scheduler" not in sys.modules,
        "Scheduler imported before recipe hook",
    )
    sys.meta_path.insert(0, SchedulerFinder())


def translate_launch_arguments() -> None:
    """Preserve the archived protocol's graph capacity on the pinned newer CLI."""
    old, new = "--cuda-graph-max-bs", "--cuda-graph-max-bs-decode"
    if old not in sys.argv:
        return
    require(
        new not in sys.argv and sys.argv.count(old) == 1,
        "Ambiguous graph capacity flags",
    )
    index = sys.argv.index(old)
    require(sys.argv[index + 1] == "64", "Unexpected presentation graph capacity")
    original = list(sys.argv)
    sys.argv[index] = new
    emit(
        Path(os.environ["PRESENTATION_SERVING_RUN_ROOT"])
        / "attest"
        / "launch-compatibility.jsonl",
        {
            "original_argv": original,
            "resolved_argv": list(sys.argv),
            "mapping": {old: new},
            "semantic_value": 64,
            "reason": "Pinned ExecGraph exposes explicit per-phase decode capacity",
        },
    )


def collect_engagement(root: Path, recipe_sha256: str) -> dict[str, Any]:
    events, files = [], []
    for path in sorted((root / "attest").glob("dispatch-*.jsonl")):
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        require(
            all(row["recipe_sha256"] == recipe_sha256 for row in rows),
            "Mixed recipe engagement",
        )
        events.extend(rows)
        files.append({"path": str(path), "sha256": file_hash(path)})
    models = [event for event in events if event["event"] == "model_registered"]
    ranks = sorted({event["rank"] for event in models})
    require(ranks == list(range(8)), "Target model registration omitted ranks")
    require(
        all(event["full_model_layers"] == 78 for event in models),
        "Partial target model",
    )
    routes = [event for event in events if event["event"].endswith("_route")]
    require(routes, "No source operator engagement")
    require(
        all(
            event["phase"] == "TARGET_VERIFY"
            for event in routes
            if event.get("selected") != "native"
        ),
        "Optimized operator escaped target verify",
    )
    capture = [row for row in routes if row.get("during_capture") is True]
    eager = [row for row in routes if row.get("during_capture") is not True]
    hooks = [row for row in events if row["event"] == "hooks_installed"]
    require(
        hooks
        and all(
            row["requested_routes"] == hooks[0]["requested_routes"] for row in hooks
        ),
        "Mixed capture route plans",
    )
    requirements = []
    missing = []
    for key, selected in hooks[0]["requested_routes"].items():
        c, role = key.split("-")
        rows = 4 * int(c[1:])
        for operation, wanted in selected.items():
            if wanted == "native":
                continue
            event_name = {
                "core": "core_route",
                "preparation": "preparation_route",
                "indexer": "indexer_route",
                "output": "output_route",
                "value": "value_route",
                "input": "input_route",
                "query": "query_route",
                "index_stream": "index_stream_route",
            }[operation]
            for rank in range(8):
                matching = [
                    row
                    for row in capture
                    if row["rank"] == rank
                    and row["event"] == event_name
                    and row["rows"] == rows
                    and logical_role(row["layer_id"]) == role
                ]
                active = [row for row in matching if row["selected"] == wanted]
                fallback = [
                    row
                    for row in matching
                    if row["selected"] == "native" and row.get("requested") == wanted
                ]
                record = {
                    "rank": rank,
                    "case": key,
                    "operation": operation,
                    "requested": wanted,
                    "captured_layers": sorted({row["layer_id"] for row in active}),
                    "native_fallbacks": fallback,
                }
                expected_layers = {
                    layer["layer_id"]
                    for model in models
                    if model["rank"] == rank
                    for layer in model["layers"]
                    if layer["role"] == role
                }
                covered_layers = {row["layer_id"] for row in (*active, *fallback)}
                record["expected_layers"] = sorted(expected_layers)
                record["omitted_layers"] = sorted(expected_layers - covered_layers)
                requirements.append(record)
                if not expected_layers or record["omitted_layers"]:
                    missing.append(record)
    require(
        not missing,
        f"Requested recipe routes absent from target graph capture: {missing[:5]}",
    )
    value = {
        "schema": "presentation-serving-engagement-v1",
        "status": "qualified",
        "recipe_sha256": recipe_sha256,
        "full_model_layers": 78,
        "ranks": ranks,
        "checks": {
            "phase_and_shape_guards": True,
            "source_routes_during_capture": True,
        },
        "capture_coverage": requirements,
        "captured_events": capture,
        "eager_events": eager,
        "events": routes,
        "evidence": files,
    }
    (root / "attest/engagement.json").write_text(json.dumps(value, indent=2) + "\n")
    return value
