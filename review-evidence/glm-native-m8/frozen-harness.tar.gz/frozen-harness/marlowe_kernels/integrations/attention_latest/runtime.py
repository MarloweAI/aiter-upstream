"""Materialize and activate the forward-ported GLM-5.2 attention package."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

HERE = Path(__file__).resolve().parent
SOURCE_COMMIT = "af6d068c1d5384522ed01766dd98fdc954125791"
SGLANG_COMMIT = "5f017ffabb6ab8d214f6a4616ee8bd98a376034a"
AITER_COMMIT = "52ffe895e64acc993a14b6af04a588fc5a448d56"
U02_WRAPPER_SHA256 = "28d28b671ea8f87ec7bc25e98f82f77bc284e231f0719f332c9d9ab4959fe1ce"
SCHEMA = "marlowe-attention-fp8-slide-v1"
LATEST_NATIVE_HASHES = {
    "sglang.kernels.ops.attention.dsa.tilelang_kernel": "ea9afa8b2dfeed08a4840c0d82622909bac15bf8a752f084ba9d260421c573bf",
    "sglang.srt.layers.attention.dsa.dsa_indexer": "2ef40cb12637f8c4a0cd8f5428cea87c3091690a942eebc57adcafdbd7809a3a",
    "sglang.srt.layers.attention.dsa_backend": "312f8477a9ddb9fcb358595b6c986ee825e0a773d9e5d185224f37972bee5d8c",
    "sglang.srt.layers.communicator": "6b0c09495e18bc4853bb028a2950d71a49c09aca41cf3c5ddadceceed1fee985",
    "sglang.srt.model_executor.model_runner": "b342b248f56d34a28ed82911375393412117de5e6ff430641be661f821b26e83",
    "sglang.srt.model_executor.runner.decode_cuda_graph_runner": "2f404622b5c19d766cd6b3acca9fb0fffcebf69855267aef52ab6036be390337",
    "sglang.srt.models.deepseek_common.attention_forward_methods.forward_mla_rocm": "7dee225463aef00c4255bd41769541d28760b46a982cf68c52e9b00fe8090ca7",
}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def _relocate(value, legacy: str, payload: Path):
    if isinstance(value, str) and value.startswith(legacy + "/"):
        return str(payload / value.removeprefix(legacy + "/"))
    if isinstance(value, list):
        return [_relocate(item, legacy, payload) for item in value]
    if isinstance(value, dict):
        return {key: _relocate(item, legacy, payload) for key, item in value.items()}
    return value


def materialize(workspace: Path) -> Path:
    workspace = workspace.resolve()
    bundle = HERE / "bundle"
    index = json.loads((bundle / "manifest.json").read_text())
    archive = bundle / index["archive"]["name"]
    require(digest(archive) == index["archive"]["sha256"], "Attention archive changed")
    marker = workspace / "materialized.json"
    manifest_path = workspace / "serving-overlay.json"
    identity = {
        "schema": SCHEMA,
        "source_commit": SOURCE_COMMIT,
        "sglang_commit": SGLANG_COMMIT,
        "aiter_commit": AITER_COMMIT,
        "archive_sha256": index["archive"]["sha256"],
    }
    if marker.exists():
        require(json.loads(marker.read_text()) == identity, "Attention workspace identity differs")
        require(manifest_path.is_file(), "Attention workspace is incomplete")
        return manifest_path
    require(not workspace.exists(), "Attention workspace exists without a valid marker")
    payload = workspace / "payload"
    files = index["files"]
    with zipfile.ZipFile(archive) as source:
        require(set(source.namelist()) == set(files.values()), "Attention archive inventory changed")
        blobs = {}
        for name in source.namelist():
            data = source.read(name)
            require(hashlib.sha256(data).hexdigest() == name, "Attention source blob changed")
            blobs[name] = data
    for relative, blob in files.items():
        path = payload / relative
        require(not Path(relative).is_absolute() and ".." not in Path(relative).parts, "Unsafe attention path")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(blobs[blob])
    manifest = _relocate(
        json.loads((payload / "metadata/high-overlay.json").read_text()),
        index["legacy_root"],
        payload,
    )
    manifest["adapter_root"] = str(HERE)
    manifest["native_source_hashes"] = LATEST_NATIVE_HASHES
    manifest["routes"] = {
        key: value
        for key, value in manifest["routes"].items()
        if int(key.split("-")[0][1:]) <= 32
    }
    manifest["excluded_serving_concurrencies"] = []
    manifest["unqualified_concurrencies"] = []
    manifest["qualification_status"] = "fresh_latest_runtime_required"
    manifest["forward_port"] = {
        **identity,
        "slide_commit": "30dd65ace9c2bd32f0d885a434ae7f8650902ecd",
        "slide_url": "https://github.com/MarloweAI/glm-attention-block-optimizations/blob/30dd65ace9c2bd32f0d885a434ae7f8650902ecd/att_summary_slide.md",
        "kv_cache_dtype": "fp8_e4m3",
        "policy": "R03 disabled for every retained route; no historical qualification inherited",
        "retained_concurrencies": [1, 2, 4, 8, 16, 32],
        "u02_wrapper_sha256": U02_WRAPPER_SHA256,
        "adapter_sha256": digest(HERE / "presentation_serving_adapter.py"),
        "marlowe_adapter_sha256": digest(HERE / "presentation_serving_marlowe.py"),
    }
    workspace.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    marker.write_text(json.dumps(identity, indent=2) + "\n")
    return manifest_path


def install() -> Path | None:
    if os.environ.get("SGLANG_USE_MARLOWE_ATTENTION", "0") != "1":
        return None
    workspace_value = os.environ.get("MARLOWE_ATTENTION_WORKSPACE")
    require(workspace_value, "Set MARLOWE_ATTENTION_WORKSPACE for optimized attention")
    manifest = materialize(Path(workspace_value))
    run_root = os.environ.get("MARLOWE_ATTENTION_AUDIT_DIR")
    require(run_root, "Set MARLOWE_ATTENTION_AUDIT_DIR for route evidence")
    os.environ["PRESENTATION_SERVING_MANIFEST"] = str(manifest)
    os.environ["PRESENTATION_SERVING_RUN_ROOT"] = str(Path(run_root).resolve())
    os.environ["PRESENTATION_SERVING_MODE"] = os.environ.get(
        "MARLOWE_ATTENTION_MODE", "measure"
    )
    if str(HERE) not in sys.path:
        sys.path.insert(0, str(HERE))
    from presentation_serving_adapter import install_import_hook

    install_import_hook()
    return manifest
