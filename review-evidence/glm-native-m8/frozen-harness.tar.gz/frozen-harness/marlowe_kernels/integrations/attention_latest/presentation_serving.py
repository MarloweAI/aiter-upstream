"""Run and qualify the retained GLM TP8 serving protocol inside an owned allocation.

This launcher does not allocate GPUs, replace the client, or synthesize serving
results from replay. ``--prepare-only`` writes the exact launch contract without
loading a model. Actual execution requires a qualified, source-bound real-model
adapter and eight visible GPUs in the pinned container.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CONCURRENCIES = (1, 2, 4, 8, 16, 32, 64)
PROTOCOL = Path(__file__).resolve().parent / "presentation_protocol"
COUNTER = "sglang:generation_tokens_total"
FORBIDDEN = re.compile(
    r"gpu fault|HSA_STATUS_ERROR|out of memory|CUDA error", re.IGNORECASE
)


def require(value: Any, message: str) -> None:
    if not value:
        raise ValueError(message)


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def artifact(path: Path) -> dict[str, str]:
    return {"path": str(path.resolve()), "sha256": digest(path)}


def write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def counter(path: Path) -> float:
    lines = [
        line
        for line in path.read_text().splitlines()
        if line.startswith((COUNTER + "{", COUNTER + " "))
    ]
    require(lines, f"Missing {COUNTER}: {path}")
    labels = [line.rsplit(None, 1)[0] for line in lines]
    require(len(labels) == len(set(labels)), "Duplicate generation counter series")
    require(
        all('model_name="amd/GLM-5.2-MXFP4"' in x for x in labels),
        "Wrong counter model",
    )
    require(all('engine_type="unified"' in x for x in labels), "Wrong counter engine")
    values = [float(line.rsplit(None, 1)[1]) for line in lines]
    require(
        all(math.isfinite(x) and x >= 0 for x in values), "Invalid generation counter"
    )
    return sum(values)


def checked_artifact(entry: dict[str, Any]) -> Path:
    path = Path(entry["path"])
    require(
        path.is_file() and digest(path) == entry["sha256"],
        f"Artifact hash changed: {path}",
    )
    return path


def reachable_buckets(buckets: list[int], concurrency: int) -> list[int]:
    from bisect import bisect_left

    require(
        buckets == sorted(set(buckets))
        and all(type(b) is int and b > 0 for b in buckets),
        "Invalid decode capture buckets",
    )
    require(buckets and buckets[-1] >= concurrency, "Graph capacity omits requested C")
    return sorted(
        {buckets[bisect_left(buckets, live)] for live in range(1, concurrency + 1)}
    )


def graph_numerical_coverage(events: list[dict], live: int, padded: int) -> bool:
    """Validate the captured layer boundaries, never merely finite graph outputs."""
    rows = [
        event
        for event in events
        if event.get("event") == "graph_numerical_state"
        and event.get("live_rows") == 4 * live
        and event.get("padded_rows") == 4 * padded
    ]
    expected = {(rank, layer) for rank in range(8) for layer in (26, 27)}
    return (
        bool(rows)
        and {(event.get("rank"), event.get("layer_id")) for event in rows} == expected
        and all(
            event.get("passed") is True
            and bool(event.get("source_contract"))
            and all(
                event.get("checks", {}).get(name, {}).get("passed") is True
                for name in (
                    "core",
                    "value",
                    "output",
                    "chained_suffix",
                    "live_counter",
                    "sanitized_live_indices",
                )
            )
            for event in rows
        )
    )


def integration_scope(value: dict, concurrency: int) -> dict:
    """Require every optimized bucket reachable during this serving population."""
    require(concurrency in CONCURRENCIES, "Unsupported serving concurrency")
    reachable = reachable_buckets(value.get("decode_capture_buckets", []), concurrency)
    optimized = [b for b in reachable if b in CONCURRENCIES]
    native = [b for b in reachable if b not in CONCURRENCIES]
    scope = value.get("concurrency_scope", {}).get(str(concurrency), {})
    require(
        concurrency in value.get("qualified_concurrencies", [])
        and scope.get("passed") is True,
        "Requested concurrency is not graph/numerically qualified",
    )
    require(
        scope.get("reachable_capture_buckets") == reachable
        and scope.get("required_optimized_concurrencies") == optimized
        and scope.get("native_fallback_buckets") == native,
        "Serving scope differs from actual reachable graph buckets",
    )
    require(
        set(optimized) <= set(value.get("numerically_qualified_concurrencies", [])),
        "Reachable optimized bucket failed numerical qualification",
    )
    require(
        set(scope.get("native_capture_missing", {})) == {str(b) for b in native}
        and not any(scope["native_capture_missing"].values()),
        "Native fallback bucket omitted captured layers/ranks",
    )
    require(
        {str(b) for b in optimized} <= set(scope.get("replay_checks", {}))
        and all(scope["replay_checks"].values()),
        "Reachable graph replay/state proof failed",
    )
    for live in [*optimized, *scope.get("padding_probe_concurrencies", [])]:
        padded = reachable_buckets(value["decode_capture_buckets"], live)[-1]
        require(
            graph_numerical_coverage(
                value.get("graph_numerical_events", []), live, padded
            ),
            "Captured numerical proof omitted or failed a watched layer/rank",
        )
    return scope


def integration_gate(
    path: Path, recipe_sha256: str, serving_overlay_sha256: str, concurrency: int
) -> dict[str, Any]:
    value = read(path)
    require(
        value.get("status") == "qualified", "Real-model integration is not qualified"
    )
    require(
        value.get("recipe_sha256") == recipe_sha256,
        "Integration qualified a different recipe",
    )
    require(
        value.get("serving_overlay_sha256") == serving_overlay_sha256,
        "Integration qualified a different serving overlay",
    )
    require(
        value.get("full_model_layers") == 78,
        "Integration did not use the full target model",
    )
    require(
        value.get("tp_size") == 8 and value.get("ep_size") == 1,
        "Integration is not TP8/EP1",
    )
    require(
        set(value.get("ranks", [])) == set(range(8)), "Integration omitted TP ranks"
    )
    require(
        concurrency in value.get("checked_concurrencies", []),
        "Integration omitted the requested concurrency",
    )
    require(
        set(value.get("checked_layer_roles", [])) == {"anchor", "shared"},
        "Integration omitted a layer role",
    )
    for name in (
        "checkpoint_weights",
        "checkpoint_scales",
        "causal_masks",
        "kv_history",
        "padded_rows",
        "native_fallback",
        "source_policy",
        "graph_capture_and_replay",
    ):
        require(
            value.get("checks", {}).get(name) is True, f"Integration missing {name}"
        )
    integration_scope(value, concurrency)
    require(value.get("evidence"), "Integration has no evidence")
    for item in value["evidence"]:
        checked_artifact(item)
    return value


def resolved_server_from_log(path: Path) -> dict:
    """Extract the pinned runtime's resolved dict without changing its raw log."""
    import ast

    from presentation_serving_smoke import validate_server_configuration

    candidates = []
    for line in path.read_text(errors="replace").splitlines():
        if "server_args=" not in line:
            continue
        raw = line.split("server_args=", 1)[1].strip()
        require(raw.startswith("{"), "Unsupported resolved server log format")
        resolved = ast.literal_eval(raw)
        require(isinstance(resolved, dict), "Resolved server arguments are not a dict")
        validate_server_configuration(resolved, graphs=True)
        candidates.append(resolved)
    require(candidates, "Missing resolved server arguments in the native log")
    return {
        "schema": "presentation-resolved-server-v1",
        "source_log": artifact(path),
        "resolved": candidates[0],
        "validated_log_entries": len(candidates),
    }


def analyze(
    root: Path,
    concurrency: int,
    *,
    integration: Path,
    recipe_sha256: str,
    serving_overlay_sha256: str,
) -> dict[str, Any]:
    """Retain the existing metric definitions and generalize only C1 population gates."""
    integration_gate(integration, recipe_sha256, serving_overlay_sha256, concurrency)
    return analyze_measurement(root, concurrency, recipe_sha256=recipe_sha256)


def analyze_measurement(
    root: Path, concurrency: int, *, recipe_sha256: str
) -> dict[str, Any]:
    """Validate only the unchanged measured workload, health and route evidence."""
    require(concurrency in CONCURRENCIES, "Concurrency outside presentation contract")
    for name, expected in (("workload.marker", "passed"), ("exit_code", "0")):
        require(
            (root / name).read_text().strip() == expected, f"Failed protocol {name}"
        )
    for name in (
        "terminal.marker",
        "windows/warmup-1/terminal.marker",
        "windows/measure-1/terminal.marker",
    ):
        require((root / name).is_file(), f"Missing protocol completion: {name}")
    log = (root / "logs/server.log").read_text(errors="replace")
    require(not FORBIDDEN.search(log), "GPU failure marker in server log")
    require(
        "Capture target verify CUDA graph end" in log,
        "Target verify graph capture missing",
    )
    window = root / "windows/measure-1"
    bench = read(window / "bench.json")
    require(bench["completed"] == 83 * concurrency, "Incomplete measured requests")
    lengths = bench["output_lens"]
    require(len(lengths) == 83 * concurrency, "Incomplete measured length population")
    require(
        all(isinstance(x, int) and not isinstance(x, bool) and x > 0 for x in lengths),
        "Invalid output lengths",
    )
    for key in ("mean_tpot_ms", "median_tpot_ms", "median_itl_ms", "output_throughput"):
        require(
            math.isfinite(bench[key])
            and (bench[key] >= 0 if key == "median_itl_ms" else bench[key] > 0),
            f"Invalid client metric: {key}",
        )
    tokens = sum(lengths)
    delta = counter(window / "metrics-after.prom") - counter(
        window / "metrics-before.prom"
    )
    require(delta == tokens, "Client/engine output token count mismatch")
    summary = read(root / "run-summary.json")
    require(summary["tokens"] == tokens, "Analyzer/client token count mismatch")
    require(
        summary["quoted"]["completed"] == bench["completed"],
        "Analyzer population mismatch",
    )
    require(
        summary["quoted"]["output_throughput"] == bench["output_throughput"],
        "Analyzer throughput mismatch",
    )
    require(
        summary["accept"]["n"] > 0 and summary["per_iteration_ms"]["n"] > 0,
        "Missing acceptance/engine observations",
    )
    engagement = read(root / "attest/engagement.json")
    require(
        engagement.get("status") == "qualified",
        "Serving route engagement is not qualified",
    )
    require(
        engagement.get("recipe_sha256") == recipe_sha256, "Engagement recipe differs"
    )
    require(
        set(engagement.get("ranks", [])) == set(range(8)),
        "Serving engagement omitted a rank",
    )
    require(engagement.get("full_model_layers") == 78, "Serving used a partial model")
    require(
        engagement.get("checks", {}).get("phase_and_shape_guards") is True,
        "Serving did not attest guards",
    )
    require(engagement.get("evidence"), "Serving engagement has no evidence")
    for item in engagement["evidence"]:
        checked_artifact(item)
    resolved_path = root / "attest/resolved-server.json"
    write(resolved_path, resolved_server_from_log(root / "logs/server.log"))
    return {
        "status": "qualified",
        "metrics": {
            "median_itl_ms": bench["median_itl_ms"],
            "output_throughput": bench["output_throughput"],
            "completed": bench["completed"],
            "output_tokens": tokens,
            "engine_token_delta": delta,
            "engine_iteration_median_ms": summary["per_iteration_ms"]["median"],
            "primary_statistic": "engine_iteration_median_ms"
            if concurrency <= 4
            else "median_itl_ms",
        },
        "health": {
            "passed": True,
            "accepted_length": summary["accept"],
            "window_medians": summary["window_medians"],
        },
        "artifacts": {
            "bench": artifact(window / "bench.json"),
            "analysis": artifact(root / "run-summary.json"),
            "engagement": artifact(root / "attest/engagement.json"),
            "resolved_server": artifact(resolved_path),
        },
    }


def protocol_environment(
    concurrency: int, model: Path, source_overlay: Path, root: Path, *, port: int
) -> dict[str, str]:
    require(concurrency in CONCURRENCIES, "Concurrency outside presentation contract")
    env = dict(os.environ)
    # Do not inherit older arms' opt-in knobs or server-argument strings.
    for key in list(env):
        if key.startswith(
            ("PROTO_", "GLM53_", "HERO_", "A13_", "PRESENTATION_", "ATTN_", "PYC02_")
        ):
            env.pop(key)
    env.update(
        {
            "PROTO_SERVER_PROFILE": "goal",
            "PROTO_MAX_BS": "64",
            "PROTO_CONC": str(concurrency),
            "PROTO_SPEC_STEPS": "3",
            "PROTO_SPEC_DRAFT": "4",
            "PROTO_PROMPTS": "33",
            "PROTO_MEASURE_PROMPTS": str(83 * concurrency),
            "PROTO_SEED": "20260909",
            "PROTO_RANGE_RATIO": "0.8",
            "PROTO_WARMUP_WINDOWS": "1",
            "PROTO_REQUIRE_CAPTURE": "1",
            "PROTO_TP_FLAG": "--tp-size",
            "GLM53_MODEL_DIR": str(model),
            "GLM53_EXTRA_SERVER_ARGS": "--random-seed 20260909",
            "GLM53_INFERENCEX": str(PROTOCOL / "client"),
            "GLM53_PORT": str(port),
            "SGLANG_USE_AITER": "1",
            "SGLANG_ENABLE_SPEC_V2": "1",
            "SGLANG_ROCM_FUSED_DECODE_MLA": "0",
            "SGLANG_TIMEOUT_KEEP_ALIVE": "900",
            "SGLANG_OPT_USE_TOPK_V2": "false",
            "SGLANG_SET_CPU_AFFINITY": "0",
            "ROCM_QUICK_REDUCE_QUANTIZATION": "INT4",
            "SAFETENSORS_FAST_GPU": "1",
            "PYTHONNOUSERSITE": "1",
            "PRESENTATION_SERVING_MANIFEST": str(
                source_overlay / "serving-overlay.json"
            ),
            "PRESENTATION_SERVING_RUN_ROOT": str(root),
            "PRESENTATION_SERVING_MODE": "measure",
        }
    )
    # A fresh named bootstrap path supplies the checked hook in every spawned worker.
    env["PYTHONPATH"] = os.pathsep.join(
        (
            str(source_overlay / "bootstrap"),
            str(source_overlay / "runner"),
            str(Path(__file__).resolve().parent),
            env.get("PYTHONPATH", ""),
        )
    )
    return env


def check_protocol(protocol: Path, analyzer: Path) -> None:
    manifest = read(PROTOCOL / "manifest.json")
    for relative, row in manifest["files"].items():
        require(
            digest(PROTOCOL / relative) == row["sha256"],
            f"Frozen protocol source changed: {relative}",
        )
    require(
        digest(protocol) == manifest["files"]["protocol_lifecycle.sh"]["sha256"],
        "Lifecycle differs from frozen protocol",
    )
    require(
        digest(analyzer) == manifest["files"]["protocol_analysis.py"]["sha256"],
        "Analyzer differs from corrected A13 protocol",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "campaign",
        "recipe-manifest",
        "image",
        "model",
        "source-overlay",
        "run-root",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--recipe", choices=("upstream", "marlowe"), required=True)
    parser.add_argument("--concurrency", type=int, choices=CONCURRENCIES, required=True)
    parser.add_argument(
        "--protocol-source", type=Path, default=PROTOCOL / "protocol_lifecycle.sh"
    )
    parser.add_argument(
        "--analyzer-source", type=Path, default=PROTOCOL / "protocol_analysis.py"
    )
    parser.add_argument("--integration-receipt", type=Path)
    parser.add_argument("--experiment-manifest", type=Path)
    parser.add_argument("--runtime-proof", type=Path)
    parser.add_argument("--epoch", required=True)
    parser.add_argument("--port", type=int, default=31000)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    root = args.run_root.resolve()
    require(
        not root.exists(), "Use a fresh attempt directory; never overwrite evidence"
    )
    campaign, recipe = read(args.campaign), read(args.recipe_manifest)
    require(
        recipe.get("campaign_id") == campaign["campaign_id"], "Recipe campaign differs"
    )
    require(
        recipe.get("workload_sha256") == campaign["workload_sha256"],
        "Recipe workload differs",
    )
    require(recipe.get("recipe_id") == args.recipe, "Recipe arm differs")
    check_protocol(args.protocol_source, args.analyzer_source)
    source = args.source_overlay / "serving-overlay.json"
    overlay = read(source)
    require(
        overlay["recipe_sha256"] == digest(args.recipe_manifest),
        "Overlay recipe source differs",
    )
    require(overlay["status"] == "ready", "Native source overlay is not ready")
    for item in overlay["files"]:
        checked_artifact(item)
    env = protocol_environment(
        args.concurrency, args.model, args.source_overlay, root, port=args.port
    )
    import presentation_serving_smoke

    execution_sources = {
        "driver_and_resolved_log_parser": artifact(Path(__file__).resolve()),
        "resolved_configuration_validator": artifact(
            Path(presentation_serving_smoke.__file__).resolve()
        ),
    }
    record = {
        "schema": "presentation-serving-attempt-v1",
        "campaign_id": campaign["campaign_id"],
        "record_id": f"{args.epoch}/c{args.concurrency}/{args.recipe}/{root.name}",
        "epoch": args.epoch,
        "recipe": args.recipe,
        "recipe_id": recipe["recipe_id"],
        "concurrency": args.concurrency,
        "attempt_id": root.name,
        "workload_sha256": campaign["workload_sha256"],
        "status": "pending",
        "source_manifest": artifact(source),
        "execution_sources": execution_sources,
        "recipe_manifest": artifact(args.recipe_manifest),
        "campaign_manifest": artifact(args.campaign),
        "started_utc": datetime.now(timezone.utc).isoformat(),
    }
    root.mkdir(parents=True)
    write(
        root / "launch-contract.json",
        {
            "protocol": artifact(args.protocol_source),
            "analyzer": artifact(args.analyzer_source),
            "execution_sources": execution_sources,
            "argv": ["bash", str(args.protocol_source), str(root)],
            "model": str(args.model),
            "image": str(args.image),
            "environment": {
                key: env[key]
                for key in env
                if key.startswith(("PROTO_", "GLM53_", "PRESENTATION_", "SGLANG_"))
            },
        },
    )
    write(root / "attempt.json", record)
    if args.prepare_only:
        print(json.dumps({"status": "prepared", "run_root": str(root)}))
        return
    try:
        experiment = None
        if args.experiment_manifest is not None:
            from presentation_serving_experiment import experiment_gate

            import presentation_serving_experiment

            record["execution_sources"]["experimental_authorization_validator"] = (
                artifact(Path(presentation_serving_experiment.__file__).resolve())
            )
            experiment = experiment_gate(
                args.experiment_manifest,
                campaign,
                source,
                args.recipe,
                args.concurrency,
                args.epoch,
            )
            record.update(
                experiment_manifest=artifact(args.experiment_manifest),
                failed_integration_receipts=experiment["failed_integration_receipts"],
                correctness_status="unqualified",
            )
        else:
            require(
                args.integration_receipt is not None,
                "Serving requires its real-model integration receipt",
            )
            integration_gate(
                args.integration_receipt,
                record["recipe_manifest"]["sha256"],
                record["source_manifest"]["sha256"],
                args.concurrency,
            )
        require(args.runtime_proof is not None, "Serving requires pinned runtime proof")
        runtime = read(args.runtime_proof)
        require(
            runtime["image_sha256"] == digest(args.image), "Pinned image bytes differ"
        )
        require(
            runtime["job_id"] == os.environ.get("SLURM_JOB_ID"),
            "Allocation does not match runtime proof",
        )
        require(runtime["model_path"] == str(args.model), "Runtime model path differs")
        import torch

        require(torch.cuda.device_count() == 8, "Serving requires eight visible GPUs")
        require(
            read(args.model / "config.json")["num_hidden_layers"] == 78,
            "Checkpoint is not full78 target model",
        )
        record.update(runtime=runtime, status="running")
        if experiment is None:
            record["integration_receipt"] = {
                **artifact(args.integration_receipt),
                "status": "qualified",
            }
        write(root / "attempt.json", record)
        with (root / "driver.log").open("w") as log:
            subprocess.run(
                ["bash", str(args.protocol_source), str(root)],
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
            subprocess.run(
                [sys.executable, str(args.analyzer_source), str(root), "150"],
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
        from presentation_serving_adapter import collect_engagement

        collect_engagement(root, record["recipe_manifest"]["sha256"])
        if experiment is None:
            record.update(
                analyze(
                    root,
                    args.concurrency,
                    integration=args.integration_receipt,
                    recipe_sha256=record["recipe_manifest"]["sha256"],
                    serving_overlay_sha256=record["source_manifest"]["sha256"],
                )
            )
        else:
            from presentation_serving_experiment import experimental_engagement

            experimental_engagement(root, args.concurrency)
            record.update(
                analyze_measurement(
                    root,
                    args.concurrency,
                    recipe_sha256=record["recipe_manifest"]["sha256"],
                )
            )
            record.update(
                status="measured_performance_only", correctness_status="unqualified"
            )
    except Exception as error:
        record.update(status="unqualified", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        record["finished_utc"] = datetime.now(timezone.utc).isoformat()
        write(root / "attempt.json", record)
        print(
            json.dumps(
                {"status": record["status"], "attempt": str(root / "attempt.json")}
            )
        )


if __name__ == "__main__":
    main()
