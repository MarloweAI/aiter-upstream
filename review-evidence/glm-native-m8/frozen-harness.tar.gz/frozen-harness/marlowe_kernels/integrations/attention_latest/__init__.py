"""Opt-in optimized GLM-5.2 attention integration."""

from .runtime import install, materialize

__all__ = ["install", "materialize"]
