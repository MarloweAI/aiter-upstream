"""Exercise private compiler isolation on all TP ranks before loading weights.

Synthetic output projections are a loader/compiler regression check only;
actual-checkpoint eager and graph qualification remain mandatory.
"""
import argparse
import json
import os
from pathlib import Path
import sys


def worker(rank, manifest, output):
    import torch
    torch.cuda.set_device(rank)
    torch.manual_seed(355052 + rank)
    sys.path.insert(0, str(Path(__file__).parent))
    from presentation_serving_adapter import NativeAdapter
    adapter = NativeAdapter(Path(manifest))
    adapter.install()
    sources = adapter.marlowe.preload_core_sources()
    from .private_imports import NATIVE_BUILDERS
    # This donor retains all six wrappers; their compiled sources are unchanged.
    build_case = adapter.manifest['routes']['c1-anchor']['case_id']
    libraries = []
    for name in NATIVE_BUILDERS:
        module = adapter.marlowe.module(build_case, name)
        assert module.library.marlowe_build_lock
        module.library()
        libraries.append(name)
    import pyhip.contrib.moe
    from pyhip.core import hiptools as port_tools
    from _marlowe_attention_pyhip.core import hiptools as attention_tools
    assert port_tools.PYHIP_CACHE_DIR != attention_tools.PYHIP_CACHE_DIR
    x = torch.randn((8, 2048), device='cuda', dtype=torch.bfloat16) * .02
    weight = torch.randn((6144, 2048), device='cuda', dtype=torch.bfloat16) * .02
    torch.backends.cuda.matmul.allow_tf32 = False
    reference = x.float() @ weight.float().T
    records = []
    for key, route in adapter.manifest['routes'].items():
        if route.get('output') != 'pyg01':
            continue
        actual = adapter.marlowe.output(route, x, weight).float()
        nrmse = ((actual-reference).square().mean()/reference.square().mean()).sqrt().item()
        assert torch.isfinite(actual).all() and nrmse <= .01, (key, nrmse)
        records.append(dict(route=key, nrmse=nrmse, passed=True))
    assert len(records) == 2
    torch.cuda.synchronize()
    Path(output, f'rank-{rank}.json').write_text(json.dumps(dict(
        rank=rank, pid=os.getpid(), cache=attention_tools.PYHIP_CACHE_DIR,
        sources=sources, libraries=libraries, projections=records, passed=True), indent=2)+'\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    import torch.multiprocessing as mp
    mp.spawn(worker, args=(args.manifest, str(args.output)), nprocs=8, join=True)
    records = [json.loads((args.output/f'rank-{rank}.json').read_text()) for rank in range(8)]
    assert len({row['cache'] for row in records}) == 8
    print(json.dumps(dict(passed=True, ranks=records)), flush=True)


if __name__ == '__main__':
    main()
