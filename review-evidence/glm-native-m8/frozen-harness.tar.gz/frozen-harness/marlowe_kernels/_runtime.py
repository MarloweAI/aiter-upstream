"""Small shared JIT cache identity; device allocations belong to each prepared call."""
import hashlib
import os
from functools import cache
from pathlib import Path
import shutil
import subprocess
import threading

PYHIP_REVISION = "270225149dec3436923959554f50f363bf7057cf"
_device_lock = threading.Lock()
_process_device = None


def bind_process_device(index):
    """PyHIP's loaded HIP function cache is process-local, not device-keyed."""
    global _process_device
    with _device_lock:
        if _process_device is None:_process_device=index
        return _process_device==index


@cache
def source_digest():
    root = Path(__file__).parent
    h = hashlib.sha256(PYHIP_REVISION.encode())
    for path in sorted(root.rglob("*.py")):
        h.update(str(path.relative_to(root)).encode())
        h.update(path.read_bytes())
    return h.hexdigest()


@cache
def compiler_identity():
    import torch
    compiler = shutil.which("amdclang++") or shutil.which("clang++")
    if not compiler:
        candidate = Path(os.environ.get("ROCM_PATH", "/opt/rocm")) / "llvm/bin/clang++"
        compiler = str(candidate) if candidate.exists() else None
    version = subprocess.check_output([compiler, "--version"], text=True) if compiler else "unresolved"
    return f"{torch.__version__}|{torch.version.hip}|{compiler}|{version}"


@cache
def cache_identity():
    # Initial implementation supports gfx950 only. Device pointers and rank never
    # enter this identity. PyHIP adds the emitter's compile-time arguments.
    return hashlib.sha256((source_digest() + "|gfx950|" + compiler_identity()).encode()).hexdigest()[:16]


def jit(*args, **kwargs):
    """Namespace this package's own emitters without modifying the PyHIP runtime."""
    os.environ.setdefault("PYHIP_SIMPLE_GEN_FILENAME", "1")
    os.environ.setdefault("PYHIP_JIT_LOG", "0")
    from pyhip import jit as pyhip_jit

    def decorate(fn):
        kernel = pyhip_jit(*args, **kwargs)(fn)
        kernel.func_name = f"mk_{cache_identity()}_{fn.__name__}"
        # Avoid embedding installation paths in filenames, including for a
        # process that imported PyHIP before this library.
        kernel.gen_func_unique_id = cache_identity()
        return kernel

    return decorate
