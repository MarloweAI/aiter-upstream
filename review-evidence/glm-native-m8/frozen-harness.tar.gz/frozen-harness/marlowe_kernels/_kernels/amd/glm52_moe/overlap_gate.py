# SPDX-License-Identifier: MIT
"""Overlap direct G1 input quantization with its weight prefetch.

The selected gate64/split6 shape keeps all four K256 pairs resident.
Input BF16 loads precede weight requests; vmcnt(48) exposes the input for
quantization while weights remain in flight. Narrower split slices are
retained as explicit experimental configurations.
"""
from dataclasses import dataclass
from .inline_program import InlineProgram,InlineConfig,RoutingCoordinates
from .safe_inline_program import SafeInlineProgram,ordered_overlap_down,ordered_combine

@dataclass(frozen=True)
class OverlapG1Config(InlineConfig):
    pack_overlap: bool=True
    prefetch_input: bool=False
    drain_before: bool=False
    predecode_scales: bool=False

from .block_fused import Coordinates,pointer
from .native_prepare import pack_fp4
from .prepare import topk
from marlowe_kernels._runtime import jit


def emit_overlap_gate(J,B,BN,SK,NT,PAIR_DEPTH,OVERLAP,EARLY_INPUT,DRAIN,PREDECODE,raw,X,W,WS,PART,expert,input_base,slice_k):
    pairs=24//SK
    assert BN==64 and SK in (6,12,24) and PAIR_DEPTH==pairs and slice_k==pairs*256
    # The optional drain is an ablation. Without it, the later vmcnt
    # threshold still retires every older input/publication/clear request.
    if DRAIN:J.s_waitcnt(mod='vmcnt(0) lgkmcnt(0)')
    lane=J.gpr(J.threadIdx.x[0])
    row=J.gpr(lane[0]%16);part=J.gpr(lane[0]//16)
    if not EARLY_INPUT:
        raw=J.gpr(8,'vu32')
        input_offset=J.gpr('vu32',(input_base[0]+lane[0]*16)*2)
        if SK>6:
            with J.ExecMask(lane[0]<slice_k//16,early_skip=False):
                for i in (0,4):J.global_load_dwordx4(raw[i:i+3],input_offset[0]+i*4,X)
        else:
            for i in (0,4):J.global_load_dwordx4(raw[i:i+3],input_offset[0]+i*4,X)
    wp,sp=pointer(J,W),pointer(J,WS)
    wp[:]+=J.s_mul_u32_u64(expert,512*6144//2)
    sp[:]+=expert*(512*192)
    kbase=J.gpr('su32',J.blockIdx.z[0]*slice_k)
    weights=J.gpr(pairs,2,4,4,'vu32');scales=J.gpr(pairs,4,'vu32')
    shifts=[];qb=[];sb=[]
    for n in range(4):
        col=J.gpr('vu32',J.blockIdx.x[0]*32+(n%2)*16+(256 if n>=2 else 0))
        qb.append(J.gpr(col*3072+lane*16))
        sb.append(J.gpr((col//32)*(32*192)+lane*4))
        shifts.append(J.gpr((col[0]%32)//16*8))
    for unit in range(pairs):
        for half in range(2):
            koff=J.gpr('su32',(kbase[0]//128+unit*2+half)*1024)
            for n in range(4):
                J.global_load_dwordx4(weights[unit,half,n],qb[n][0]+koff[0],wp,mod='sc0 nt' if NT else '')
        soff=J.gpr('su32',(kbase[0]//256+unit)*256)
        for n in range(4):J.global_load_dword(scales[unit,n],sb[n][0]+soff[0],sp)
    J.s_waitcnt(mod=f'vmcnt({pairs*12})' if OVERLAP else 'vmcnt(0)')
    def pack_input():
        values=[]
        for i in range(8):values.extend([J.gpr(raw[i]<<16),J.gpr(raw[i]&0xffff0000)])
        codes,exponent=pack_fp4(J,values,(1,),False)
        encoded=J.gpr(2,'vu32',0)
        for i,code in enumerate(codes):encoded[i//4]=encoded[i//4]|(code[0]<<(8*(i%4)))
        J.ds_write_b64(J.gpr('vu32',lane[0]*8),encoded)
        with J.ExecMask(lane[0]%2==0,early_skip=False):
            J.ds_write_b8(J.gpr('vu32',slice_k//2+lane[0]//2),exponent)
    if SK>6:
        with J.ExecMask(lane[0]<slice_k//16,early_skip=False):pack_input()
    else:pack_input()
    J.s_waitcnt(mod='lgkmcnt(0)')
    J.Label('overlap_matrix_begin')
    av=J.gpr(pairs,2,4,'vu32',0);asc=J.gpr(pairs,2,'vu32',127)
    with J.ExecMask(row[0]==0,early_skip=False):
        for unit in range(pairs):
            for half in range(2):
                J.ds_read_b128(av[unit,half],J.gpr('vu32',part[0]*16+unit*128+half*64))
                J.ds_read_u8(asc[unit,half],J.gpr('vu32',slice_k//2+part[0]+unit*8+half*4))
    J.s_waitcnt(mod='lgkmcnt(0)')
    accum=J.gpr(4,4,'vf32',0.)
    for unit in range(pairs):
        J.s_waitcnt(mod=f'vmcnt({(pairs-unit-1)*12})')
        for half in range(2):
            # Four independent scale writes precede four MFMAs. Even if each
            # extraction compiles to one instruction, each use is separated
            # from its last write by at least three independent instructions.
            decoded=[J.gpr((scales[unit,n][0]>>(half*16+shifts[n][0]))&255) for n in range(4)] if PREDECODE else None
            for n in range(4):
                scale=decoded[n] if PREDECODE else J.gpr((scales[unit,n][0]>>(half*16+shifts[n][0]))&255)
                if not PREDECODE:
                    # CDNA4 ISA Table 38: two VALU-to-MFMA wait states.
                    J.s_nop(1)
                J.v_mfma_scale_f32_16x16x128_f8f6f4(accum[n],weights[unit,half,n],av[unit,half],accum[n],scale,asc[unit,half],
                    mod='op_sel:[0,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4')
    split=J.gpr('su32',J.blockIdx.z[0]*B*9*512*4)
    for n in range(4):
        col=J.gpr('vu32',J.blockIdx.x[0]*32+(n%2)*16+(256 if n>=2 else 0)+part[0]*4)
        dst=J.gpr('vu32',J.blockIdx.y[0]*(512*4)+split[0]+col[0]*4)
        with J.ExecMask(row[0]==0,early_skip=False):J.global_store_dwordx4(dst,accum[n],PART)


@jit()
def overlap_gate(J,B,BN,SK,NT,DEPTH,SUPPLIED,DEBUG,PRELOAD,AXIS,REUSE,PAIR_DEPTH,SLOT_ROUTING,OVERLAP,EARLY_INPUT,DRAIN,PREDECODE,FP32_ROUTING,
    L:'void*',C:'void*',X:'void*',SI:'void*',SW:'void*',
    IDS:'void*',RW:'void*',OUT:'void*',W:'void*',WS:'void*',PART:'void*',MID:'void*',MS:'void*'):
    from pyhip.core.mem_allocator import SimpleMemoryAllocator
    assert J.gfx==950 and BN in (32,64) and SK>1 and 48%SK==0
    J.lds_allocator=SimpleMemoryAllocator(160*1024)
    slice_k=6144//SK
    ng=512//BN;clear_bytes=12288//(ng*SK)
    assert clear_bytes%16==0
    route_base=slice_k//2+slice_k//32
    J.alloc_lds(route_base+80,align=16)
    assert sorted(AXIS)==['x','y','z']
    if AXIS!='xyz':
        axes=dict(zip(AXIS,(J.blockIdx.x,J.blockIdx.y,J.blockIdx.z)))
        J=Coordinates(J,'inline_axis_',axes['x'],axes['y'],axes['z'],J.threadIdx.x)
    lane=J.gpr(J.threadIdx.x[0])
    token=J.gpr('su32',J.blockIdx.y[0]//9)
    slot=J.gpr('su32',J.blockIdx.y[0]-token[0]*9)
    publish_s=J.gpr('su32',J.blockIdx.x[0]|J.blockIdx.z[0]|slot[0])
    publish=J.gpr('vu32',publish_s[0])[0]==0
    slot_v=J.gpr('vu32',slot[0])
    input_base=J.gpr('su32',token[0]*6144+J.blockIdx.z[0]*slice_k)
    output_base=J.gpr('su32',token[0]*12288+(J.blockIdx.z[0]*ng+J.blockIdx.x[0])*clear_bytes)
    input_packed_base=J.gpr('su32',token[0]*3072+J.blockIdx.z[0]*(slice_k//2))
    input_scale_base=J.gpr('su32',token[0]*192+J.blockIdx.z[0]*(slice_k//32))
    shared_offset=J.gpr('su32',(token[0]*9+8)*4)
    raw=None
    if EARLY_INPUT:
        raw=J.gpr(8,'vu32')
        input_offset=J.gpr('vu32',(input_base[0]+lane[0]*16)*2)
        if SK>6:
            with J.ExecMask(lane[0]<slice_k//16,early_skip=False):
                for i in (0,4):J.global_load_dwordx4(raw[i:i+3],input_offset[0]+i*4,X)
        else:
            for i in (0,4):J.global_load_dwordx4(raw[i:i+3],input_offset[0]+i*4,X)
    J.Label('inline_routing_begin')
    expert=J.gpr('su32',256)
    if SLOT_ROUTING:
        J.Jump('inline_full_metadata',publish_s[0]==0)
        if SUPPLIED:
            J.Jump('inline_routing_complete',slot[0]==8)
            J.s_load_dword(expert,SI,(token[0]*8+slot[0])*4)
            J.s_waitcnt(mod='lgkmcnt(0)')
        else:
            from .slot_topk import select_slot
            selected=select_slot(J,L,C,token[0],slot,preload=PRELOAD,fp32=FP32_ROUTING)
            expert[:]=selected[0]
        J.Jump('inline_routing_complete')
        J.Label('inline_full_metadata')
    route=RoutingCoordinates(J,'route_',J.blockIdx.x,J.blockIdx.y,J.blockIdx.z,J.threadIdx.x,
        ids=IDS,rw=RW,base=route_base,publish=publish)
    if SUPPLIED:
        with J.ExecMask(lane[0]<8,early_skip=False):
            ids=J.gpr('vu32');rw=J.gpr('vf32')
            J.global_load_dword(ids,J.gpr('vu32',(token[0]*8+lane[0])*4),SI)
            J.global_load_dword(rw,J.gpr('vu32',(token[0]*8+lane[0])*4),SW)
            J.s_waitcnt(mod='vmcnt(0)')
            route.global_store_dword(J.gpr('vu32',(token[0]*9+lane[0])*4),ids,IDS)
            route.global_store_dword(J.gpr('vu32',(token[0]*9+lane[0])*4),rw,RW)
    elif REUSE:
        assert not FP32_ROUTING
        from .reuse_topk import reuse_topk
        reuse_topk(route,L,C,IDS,RW,token[0],preload=PRELOAD)
    elif FP32_ROUTING:
        from .prepare_fp32 import topk_fp32
        topk_fp32(route,L,C,IDS,RW,token[0],preload=PRELOAD)
    else:topk(route,L,C,IDS,RW,token[0],preload=PRELOAD)
    # Use lane zero and explicit addresses. The emitter's common-expression
    # cache is not ExecMask-aware, so reusing top-k's lane<8 addresses in lane8
    # would read undefined registers.
    with J.ExecMask(lane[0]==0,early_skip=False):
        shared_id=J.gpr('vu32',256);shared_weight=J.gpr('vf32',1.)
        J.ds_write_b32(J.gpr('vu32',route_base+32),shared_id)
        J.ds_write_b32(J.gpr('vu32',route_base+68),shared_weight)
        with J.ExecMask(publish,early_skip=False):
            dst=J.gpr('vu32',shared_offset[0])
            J.global_store_dword(dst,shared_id,IDS)
            J.global_store_dword(dst,shared_weight,RW)
    J.s_waitcnt(mod='lgkmcnt(0) vmcnt(0)')
    expert_v=J.gpr('vu32')
    J.ds_read_b32(expert_v,J.gpr('vu32',route_base+slot[0]*4))
    J.s_waitcnt(mod='lgkmcnt(0)')
    J.v_readfirstlane_b32(expert,expert_v)
    if SLOT_ROUTING:J.Label('inline_routing_complete')
    # Every split/feature CTA for slot zero participates in output clearing,
    # including those taking the shortened routing path.
    with J.ExecMask((slot_v[0]==0)&(lane[0] < clear_bytes//16),early_skip=False):
        offset=J.gpr('vu32',output_base[0]+lane[0]*16)
        J.global_store_dwordx4(offset,J.gpr(4,'vu32',0),OUT)
    if DEBUG:
        with J.ExecMask(lane[0]==0,early_skip=False):
            dst=J.gpr('vu32',((J.blockIdx.z[0]*B*9+J.blockIdx.y[0])*ng+J.blockIdx.x[0])*4)
            J.global_store_dword(dst,J.gpr('vu32',expert[0]),PART)
        return
    # End the routing basic block so the pinned emitter cannot reuse an
    # address computed under lane<8 for all-lane matrix weight loads.
    J.Label('inline_matrix_begin')
    emit_overlap_gate(J,B,BN,SK,NT,PAIR_DEPTH,OVERLAP,EARLY_INPUT,DRAIN,PREDECODE,raw,X,W,WS,PART,expert,input_base,slice_k)


class OverlapG1Program(SafeInlineProgram):
    def __init__(self,owner,batch,config=OverlapG1Config()):
        super().__init__(owner,batch,InlineConfig(**{k:v for k,v in config.__dict__.items() if k not in ('pack_overlap','prefetch_input','drain_before','predecode_scales')}))
        self.oc=config
        assert config.direct is True and not config.dispatch
        assert not getattr(config,'packed_input_scales',False)
        assert config.gate_n==64 and config.split_k in (6,12,24) and config.pair_depth==24//config.split_k
        assert config.overlap_weights and config.fuse_middle
        self.info.update(algorithm='route-first G1 weights overlap input pack')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        from .overlap_consumer import OverlapProgram
        b,c,p=self.b,self.cc,self.p
        output=p['output'] if out is None else out
        target=self.route_output if supplied_ids is not None else output
        shape=dict(x=512//c.gate_n,y=self.grid,z=c.split_k)
        overlap_gate([shape[axis] for axis in self.ic.gate_axis],[64],b,c.gate_n,c.split_k,c.non_temporal,c.depth or 2,supplied_ids is not None,False,self.ic.route_preload,self.ic.gate_axis,self.ic.reuse_probabilities,self.ic.pair_depth,self.ic.slot_routing,self.oc.pack_overlap,self.oc.prefetch_input,self.oc.drain_before,self.oc.predecode_scales,getattr(self,'router_fp32',False),
            logits.data_ptr(),bias.data_ptr(),x.data_ptr(),0 if supplied_ids is None else supplied_ids.data_ptr(),
            0 if supplied_weights is None else supplied_weights.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
            target.data_ptr(),self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),
            self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr())
        if supplied_ids is None:
            OverlapProgram._stage(self,self.partial,self.mid_scale.data_ptr(),output,False)
        else:
            ordered_overlap_down([6144//c.down_n,self.grid],[64*c.down_waves],b,c.down_n,c.down_waves,c.split_k,self.fp32_middle,c.non_temporal,
                self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),
                target.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr())
            ordered_combine([12,b],[256],target.data_ptr(),output.data_ptr())
        return output
