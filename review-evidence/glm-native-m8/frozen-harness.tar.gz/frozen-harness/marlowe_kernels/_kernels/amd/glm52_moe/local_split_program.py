# SPDX-License-Identifier: MIT
"""Split G1's K reduction across waves of one CTA, then pack locally.

Each CTA owns one expert-row/feature tile. Waves read disjoint K ranges,
write compact LDS partials, and the first wave performs the established
reduction/activation/FP4 packing. G2 retains its independent large grid.
"""
from dataclasses import dataclass
from marlowe_kernels._runtime import jit
from .block_fused import Coordinates,LocalCoordinates,pointer
from .fused_dispatch import valid_pointer
from .native_pairprefetch import paired_projection
from .last_split import finish_feature
from .front_program import FrontProgram,FrontConfig

class TilePartials(LocalCoordinates):
    def __init__(self,*args,BN,**kw):
        super().__init__(*args,**kw);self.BN=BN
        tile_scalar=self.J.gpr('su32',self.blockIdx.x[0]*(BN*2))
        self.tile_byte_base=self.J.gpr('vu32',tile_scalar[0])
        self.row_stride=self.J.gpr('su32',BN*4+16)
    def address(self,kind,offset):
        assert kind=='partial'
        J=self.J;row=self.threadIdx.x[0]%16
        whole=J.gpr(offset>>(11+self.B.bit_length()-1))
        split=J.gpr('vu32');J.v_mul_hi_u32(split,whole,J.gpr('su32',0x38e38e39));split[:]=split[0]>>1
        # Original partials separate gate/up by256features. Compact each
        # CTA's halves next to each other and pad rows to avoid LDS bank alias.
        feature=J.gpr((offset&1023)-self.tile_byte_base[0]+(((offset>>10)&1)<<((self.BN*2).bit_length()-1)))
        return J.gpr('vu32',(split[0]*16+row)*self.row_stride[0]+feature[0])

@dataclass(frozen=True)
class LocalSplitConfig(FrontConfig):
    direct: bool=False
    dispatch: bool=True
    local_splits: int=4
    local_depth: int=3

@jit()
def local_split_g1(J,B,BN,SK,FP32,NT,DEPTH,MAXIMUM,
                   X:'void*',XS:'void*',W:'void*',WS:'void*',PART:'void*',MID:'void*',MS:'void*',
                   IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*'):
    from pyhip.core.mem_allocator import SimpleMemoryAllocator
    assert BN in (64,128,256) and 48%SK==0 and (48//SK)%2==0 and SK<=8
    J.lds_allocator=SimpleMemoryAllocator(160*1024)
    size=SK*16*(BN*4+16);assert size<=160*1024
    J.alloc_lds(size,align=16)
    lane=J.gpr(J.threadIdx.x[0]%64);wave=J.gpr(J.threadIdx.x[0]//64)
    swave=J.gpr('su32');J.v_readfirstlane_b32(swave,wave)
    valid,bank=valid_pointer(J,STATE)
    ids=pointer(J,IDS,bank[0]*(MAXIMUM*4));rw=pointer(J,RW,bank[0]*(MAXIMUM*4))
    partial=pointer(J,PART)
    ctx=TilePartials(J,'producer_',J.blockIdx.x,J.blockIdx.y,swave,lane,
        mapping=[(partial,'partial')],B=B,rows=16,partial_base=0,mid_base=0,scale_base=0,BN=BN)
    paired_projection.gen_func(ctx,6144,512,BN,True,SK,FP32,1,False,True,NT,DEPTH,'lds',
        pointer(J,X),pointer(J,XS),pointer(J,W),pointer(J,WS),partial,pointer(J,MS),
        pointer(J,ids),pointer(J,rw),pointer(J,EXP),pointer(J,valid),J.gpr('su32',B))
    J.s_waitcnt(mod='lgkmcnt(0) vmcnt(0)');J.s_barrier()
    J.Jump('local_split_done',swave[0]!=0)
    J.Label('local_split_finish')
    # All producers write before the barrier. Only the first wave consumes
    # these partials; there is no publication counter or inter-CTA wait.
    finish_partial=pointer(J,PART)
    finish=TilePartials(J,'finish_',J.blockIdx.x,J.blockIdx.y,J.gpr('su32',0),lane,
        mapping=[(finish_partial,'partial')],B=B,rows=16,partial_base=0,mid_base=0,scale_base=0,BN=BN)
    finish_feature.gen_func(finish,finish_partial,pointer(J,MID),pointer(J,MS),pointer(J,ids),B,SK,BN,1,False,FP32)
    J.Label('local_split_done')

class LocalSplitProgram(FrontProgram):
    def __init__(self,owner,batch,config=LocalSplitConfig()):
        assert config.dispatch and not config.direct and config.split_k==1 and config.gate_waves==1
        self.lsc=config
        super().__init__(owner,batch,FrontConfig(**{k:v for k,v in config.__dict__.items() if k not in ('local_splits','local_depth')}))
        self.info.update(config=config.__dict__,algorithm='CTA-local split K / LDS reduction / fused activation and pack')
    def _stage(self,inp,scale,out,first):
        if not first:return super()._stage(inp,scale,out,first)
        c,p,b=self.c,self.p,self.b
        local_split_g1([512//c.gate_n,self.grid],[64*self.lsc.local_splits],b,c.gate_n,self.lsc.local_splits,self.fp32_middle,c.non_temporal,self.lsc.local_depth,self.maximum,
            inp.data_ptr(),scale,self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),
            out.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.state.data_ptr())
