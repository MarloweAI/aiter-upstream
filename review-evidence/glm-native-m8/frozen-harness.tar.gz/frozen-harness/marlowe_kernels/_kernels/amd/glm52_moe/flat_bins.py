# SPDX-License-Identifier: MIT
"""Direct expert-index grids for internally unique top-k routes.

More empty consumer workgroups replace the compact task allocator and one
metadata dependency. Supplied routes retain FixedBinProgram so repeated slots
remain supported. The counter-bank transition is identical in both modes.
"""
from marlowe_kernels._runtime import jit
from .block_fused import pointer
from .fused_dispatch import valid_pointer,TopkBins
from .prepare import topk
from .native_prepare import pack_fp4,middle_packed
from .fixed_bins import FixedBinProgram,FixedBinConfig,clear_fixed_next
from .native_prefetch import prefetch_projection
from .native_pairprefetch import paired_projection
from .native_coalesced import coalesced_projection

FlatBinConfig=FixedBinConfig

def flat_bin_routes(J,expert,weight,token,B,counts,SORT,RW):
    lane=J.threadIdx.x[0]%64;position=J.gpr('vu32')
    J.global_atomic_add(position,expert[0]*4,J.gpr('vu32',1),counts,mod='sc0')
    J.s_waitcnt(mod='vmcnt(0)')
    destination=J.gpr(expert[0]*(B*8)+position[0])
    J.global_store_dword(destination[0]*4,J.gpr(token|(lane<<24)),SORT)
    J.global_store_dword(destination[0]*4,weight,RW)

@jit()
def flat_prepare(J,B,MAXIMUM,PRELOAD,L:'void*',C:'void*',X:'void*',IDS:'void*',W:'void*',
                  Q:'void*',S:'void*',O:'void*',SI:'void*',SW:'void*',STATE:'void*',
                  SORT:'void*',RW:'void*',EXP:'void*',SUPPLIED):
    token,tid=J.blockIdx.x[0],J.threadIdx.x[0]
    valid,which=valid_pointer(J,STATE,False)
    sort=pointer(J,SORT,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    counts=pointer(J,STATE,16+which[0]*(257*4))
    J.Jump('fixed_snapshot_done',token!=0)
    with J.ExecMask(tid==0,early_skip=False):
        J.global_store_dword(J.gpr('vu32',4),J.gpr('vu32',which[0]),STATE)
    J.Label('fixed_snapshot_done')
    zero=J.gpr(4,'vu32',0)
    for part in (0,16):J.global_store_dwordx4((token*3*2048+tid*16)*2+part,zero,O)
    data=J.gpr(8,'vu32')
    for part in (0,4):J.global_load_dwordx4(data[part:part+3],(token*3*2048+tid*16)*2+part*4,X)
    J.s_waitcnt(mod='vmcnt(0)')
    values=[]
    for i in range(8):values.extend([J.gpr(data[i]<<16),J.gpr(data[i]&0xffff0000)])
    codes,exponent=pack_fp4(J,values,(1,),False)
    encoded=J.gpr(2,'vu32',0)
    for i,code in enumerate(codes):encoded[i//4]=encoded[i//4]|(code[0]<<(8*(i%4)))
    J.global_store_dwordx2(token*3*1024+tid*8,encoded,Q)
    with J.ExecMask(tid%2==0,early_skip=False):J.global_store_byte(256+token*3*64+tid//2,exponent,S)
    def bins(expert,weight):flat_bin_routes(J,expert,weight,token,B,counts,sort,rw)
    with J.ExecMask(tid<64):
        if SUPPLIED:
            expert=J.gpr('vu32');weight=J.gpr('vf32')
            with J.ExecMask(tid<8,early_skip=False):
                J.global_load_dword(expert,(token*8+tid)*4,SI)
                J.global_load_dword(weight,(token*8+tid)*4,SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4,expert,IDS)
                J.global_store_dword((token*9+tid)*4,weight,W)
                bins(expert,weight)
        else:topk(TopkBins(J,IDS,W,bins),L,C,IDS,W,token,preload=PRELOAD)
        with J.ExecMask(tid==0,early_skip=False):
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vu32',256),IDS)
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vf32',1.),W)


def resolve_flat_routes(J,IDS,RW,EXP,STATE,B,FIRST):
    _,bank=valid_pointer(J,STATE)
    # The supported batch sizes are powers of two and >=16.
    chunks=J.gpr('su32',B[0]//16)
    # Variable division is avoided: derive the log2 from compile-time shape
    # passed by the wrapper as an attribute on the assembler proxy.
    size=J.flat_batch;shared=(size+15)//16
    expert=J.gpr('su32');chunk=J.gpr('su32')
    J.Jump('flat_routed',J.blockIdx.y[0]>=shared)
    expert[:]=256;chunk[:]=J.blockIdx.y[0]
    J.Jump('flat_identity_ready')
    J.Label('flat_routed')
    task=J.gpr('su32',J.blockIdx.y[0]-shared)
    expert[:]=task[0]//shared;chunk[:]=task[0]%shared
    J.Label('flat_identity_ready')
    counts=pointer(J,STATE,16+bank[0]*(257*4));count=J.gpr('su32')
    J.s_load_dword(count,counts,expert[0]*4);J.s_waitcnt(mod='lgkmcnt(0)')
    J.Jump('flat_active',chunk[0]*16<count[0])
    J.s_endpgm();J.Label('flat_active')
    offset=J.gpr('su32',((bank[0]*257+expert[0])*(size*8)+chunk[0]*16)*4)
    ids=pointer(J,IDS,offset[0]);weights=pointer(J,RW,offset[0])
    row=J.gpr(J.threadIdx.x[0]%16)
    sentinel=J.gpr('su32',(9<<24)|B[0]);packed=J.gpr('vu32',sentinel[0]);routing=J.gpr('vf32',0.)
    with J.ExecMask(row[0]<(count[0]-chunk[0]*16),early_skip=False):
        J.global_load_dword(packed,row[0]*4,ids)
        if not FIRST:J.global_load_dword(routing,row[0]*4,weights)
    J.s_waitcnt(mod='vmcnt(0)');J.Label('flat_matrix_ready')
    return expert,J.gpr(packed[0]&0xffffff),J.gpr(packed[0]>>24),routing

class FlatShape:
    def __init__(self,J,batch):self.J,self.flat_batch=J,batch
    def __getattr__(self,name):return getattr(self.J,name)

@jit()
def flat_projection(J,K,N,BN,FIRST,SK,FP32,NW,NT,DEPTH,PAIR,COMBINE,BATCH,
                    X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                    IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    ctx=FlatShape(J,BATCH)
    pointers=(X,XS,W,WS,Y,YS,IDS,RW,EXP,STATE,B)
    common=(K,N,BN,FIRST,SK,FP32,NW,'flat',True,NT)
    if PAIR:paired_projection.gen_func(ctx,*common,DEPTH,COMBINE,*pointers)
    elif FIRST:prefetch_projection.gen_func(ctx,*common,DEPTH,*pointers)
    else:coalesced_projection.gen_func(ctx,*common,DEPTH,COMBINE,*pointers)
    if not FIRST:clear_fixed_next(J,STATE,BATCH,64*NW)

class FlatBinProgram(FixedBinProgram):
    def __init__(self,owner,batch,config=FlatBinConfig()):
        super().__init__(owner,batch,config)
        self.fixed_grid=self.grid;self.flat_grid=257*((batch+15)//16)
        self.grid=self.flat_grid;self._flat_mode=True
        self.info.update(grid=self.grid,algorithm='direct expert grid for internal unique top-k / fixed-bin supplied fallback')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        self._flat_mode=supplied_ids is None
        self.grid=self.flat_grid if self._flat_mode else self.fixed_grid
        try:
            if not self._flat_mode:return super().run(x,logits,bias,out=out,supplied_ids=supplied_ids,supplied_weights=supplied_weights)
            b,c,p=self.b,self.fc,self.p;output=p['output'] if out is None else out
            flat_prepare([b],[384],b,self.maximum,c.route_preload,logits.data_ptr(),bias.data_ptr(),x.data_ptr(),
                p['ids'].data_ptr(),p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),
                0,0,self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),False)
            self._stage(p['packed'],p['workspace'].data_ptr()+256,self.partial,True)
            if c.split_k>1:middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
            self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
            return output
        finally:self._flat_mode=True;self.grid=self.flat_grid
    def _stage(self,inp,scale,out,first):
        if not self._flat_mode:return super()._stage(inp,scale,out,first)
        c,p,b=self.fc,self.p,self.b
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1;pair=bool(c.pair_depth) if first else c.pair_g2
        depth=c.pair_depth if first and pair else c.depth if first else 1 if pair else c.down_depth or 2
        w,s=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        flat_projection([n//bn,self.grid,sk],[64*nw],k,n,bn,first,sk,self.fp32_middle,nw,c.non_temporal,depth,pair,c.combine,b,
            inp.data_ptr(),scale,w.data_ptr(),s.data_ptr(),out.data_ptr(),self.mid_scale.data_ptr(),
            p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.state.data_ptr(),b)
