# SPDX-License-Identifier: MIT
"""Experimental device-scheduled G1 -> packed intermediate -> G2 pipeline.

Preparation remains separately launched in the first experiment. Existing
qualified PyHIP matrix bodies are embedded in a HIP worker so synchronization
uses the compiler's device-scope acquire/release atomics. No grid barrier or
wait on an unclaimed producer is used. This is opt-in research code.
"""
import ctypes
import hashlib
import json
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import torch
from .native_program import NativeProgram, NativeConfig
from .native_fp4 import native_projection
from .native_prepare import middle_packed
from .persistent_middle import grouped_middle
from marlowe_kernels._runtime import jit


@jit()
def persistent_prepare(J,L:'void*',C:'void*',X:'void*',IDS:'void*',W:'void*',
                      Q:'void*',S:'void*',O:'void*',SI:'void*',SW:'void*',
                      STATE:'void*',WORDS,STRIDE,SUPPLIED):
    from .native_prepare import native_phase1
    native_phase1.gen_func(J,L,C,X,IDS,W,Q,S,O,SI,SW,SUPPLIED)
    base=J.gpr('su32',J.blockIdx.x[0]*384)
    idx=J.gpr(base[0]+J.threadIdx.x[0])
    for offset in range(0,WORDS,STRIDE):
        with J.ExecMask(idx[0]+offset<WORDS,early_skip=False):
            J.global_store_dword((idx[0]+offset)*4,J.gpr('vu32',0),STATE)


@dataclass(frozen=True)
class PersistentConfig:
    direct: bool = False
    gate_n: int = 64
    down_n: int = 64
    split_k: int = 2
    workers_per_cu: int = 2
    non_temporal: bool = True
    grouped_finish: bool = True
    down_chunk: int = 4
    schedule: str = 'queue'
    coherent_intermediate: bool = False
    group_parts: int = 0
    consumer_parts: int = 0
    coalesced_down: bool = False
    counter_stride: int = 1
    profile: bool = False


def worker_group_size(config):
    producers = (512 // config.gate_n) * config.split_k
    size = min(config.group_parts or producers, producers)
    if config.consumer_parts:
        assert config.schedule == 'groups'
        assert 0 < config.consumer_parts <= 6144 // config.down_n
        size = max(size, config.consumer_parts)
    return size


def _artifact(kernel, args):
    compile_args, _, key = kernel.split_args(args)
    old = kernel.force_recompile
    try:
        kernel.force_recompile = True
        _, artifact = kernel.build(compile_args, key)
    finally:
        kernel.force_recompile = old
    return artifact['asm'], artifact['used_gprs']


def _inline(lines, registers, name, args, x, y, z, coherent=False):
    """Embed unmodified matrix arithmetic with virtual task coordinates."""
    labels = {m.group(1) for line in lines if (m := re.match(r'\s*([.$\w]+):', line))}
    mapping = {label: f'{name}_label_{i}_%=' for i,label in enumerate(sorted(labels))}
    saved_exec = (max(int(r[1:]) for r in registers if r.startswith('s'))+2)//2*2
    result = [f's_mov_b64 s[{saved_exec}:{saved_exec+1}], exec',
              's_mov_b64 s[0:1], %0', 's_mov_b32 s2, %1', 's_mov_b32 s3, %2',
              's_mov_b32 s4, %3', 'v_mov_b32 v0, %4']
    for line in lines:
        for label,replacement in mapping.items():
            line=re.sub(r'(?<![\w.$])'+re.escape(label)+r'(?![\w.$])',replacement,line)
        if line=='s_endpgm':line=f's_branch {name}_end_%='
        if coherent:
            # gfx950 SC1=1, SC0=0 requests device-scope coherent-cache bypass.
            # Inter-worker payloads then need completion ordering, not a flush
            # of unrelated cached data. Waitcnt below completes these stores.
            instruction,sep,comment=line.partition(';')
            store=name in ('g','m') and instruction.lstrip().startswith('global_store_')
            load=(name=='m' and instruction.lstrip().startswith('global_load_')) or (
                name=='d' and instruction.lstrip().startswith('global_load_') and
                ('avec' in comment or 'ascale' in comment))
            if store or load:
                assert 'sc1' not in instruction
                line=instruction.rstrip()+' sc1'+(' ;'+comment if sep else '')
        result.append(line)
    result += [f'{name}_end_%=:', 's_waitcnt vmcnt(0) lgkmcnt(0)',
               f's_mov_b64 exec, s[{saved_exec}:{saved_exec+1}]']
    clobbers=list(dict.fromkeys(registers+[f's{saved_exec}',f's{saved_exec+1}','memory','scc','vcc']))
    assembly='\n'.join(json.dumps(line+'\n') for line in result)
    return ('asm volatile(\n'+assembly+'\n::'
            f'"s"({args}),"s"(__builtin_amdgcn_readfirstlane({x})),"s"(__builtin_amdgcn_readfirstlane({y})),"s"(__builtin_amdgcn_readfirstlane({z})),"v"(threadIdx.x)\n:'
            +','.join(json.dumps(r) for r in clobbers)+');')


@lru_cache(None)
def build(batch, config):
    from pyhip.core.hiptools import module,PYHIP_CACHE_DIR,get_lib,hip_check_error
    c=config; fused=batch in (1,4,8,32)
    assert c.schedule in ('queue','groups')
    ng,nd=512//c.gate_n,6144//c.down_n
    assert nd%c.down_chunk==0
    pieces=[]
    for first,n,k,bn,sk in ((True,512,6144,c.gate_n,c.split_k),(False,6144,256,c.down_n,1)):
        args=([1,1,1],[64],k,n,bn,first,sk,fused,1,c.direct,True,c.non_temporal,*([0]*10),batch)
        kernel=native_projection
        if not first and c.coalesced_down:
            from .native_coalesced import coalesced_projection
            kernel=coalesced_projection;args=(*args[:12],2,'wave',*args[12:])
        pieces.append(_artifact(kernel,args))
    gate=_inline(*pieces[0],'g','ka',f'task % {ng}',f'task / {ng*c.split_k}',
                 f'(task / {ng}) % {c.split_k}',c.coherent_intermediate)
    down=_inline(*pieces[1],'d','ka + 88',f'task % {nd}','tile','0',c.coherent_intermediate)
    middle=''
    if c.split_k>1 and c.grouped_finish and not c.direct:
        body,regs=_artifact(grouped_middle,([1],[64],0,0,0,0,batch,c.split_k,fused))
        middle=_inline(body,regs,'m','ka + 176','tile','0','0',c.coherent_intermediate)
    elif c.split_k>1:
        body,regs=_artifact(middle_packed,([1,1],[64],0,0,0,batch,c.split_k,fused))
        inline=_inline(body,regs,'m','ka + 176','route','col','0',c.coherent_intermediate)
        middle=f'''
        for (unsigned row=0; row<{1 if c.direct else 16}; ++row) {{
            unsigned route;
            if constexpr ({str(c.direct).lower()}) route=tile;
            else {{
                unsigned id=((const unsigned*)g_ids)[tile*16+row];
                if ((id&0xffffff)>={batch}) continue;
                route=(id&0xffffff)*9+(id>>24);
            }}
            for (unsigned col=0; col<2; ++col) {{ {inline} }}
        }}'''
    names=['x','xs','w','ws','y','ys','ids','rw','exp','valid']
    parameters=[]
    for stage in ('g','d'):parameters += [f'void* {stage}_{n}' for n in names]+[f'int {stage}_b']
    parameters += ['void* partial','void* mid','void* mids','void* m_ids','void* state','int max_tiles','void* profile']
    # Four queue counters, then one G1 completion counter and one ready entry
    # per tile. A ready entry is tile+1; zero means not published yet.
    source=f'''#include <hip/hip_runtime.h>
__device__ __forceinline__ unsigned ld(unsigned* p) {{
 return __hip_atomic_load(p,__ATOMIC_RELAXED,__HIP_MEMORY_SCOPE_AGENT);
}}
__device__ __forceinline__ unsigned add(unsigned* p,unsigned v) {{
 return __hip_atomic_fetch_add(p,v,__ATOMIC_RELAXED,__HIP_MEMORY_SCOPE_AGENT);
}}
__device__ __forceinline__ void st(unsigned* p,unsigned v) {{
 __hip_atomic_store(p,v,__ATOMIC_RELEASE,__HIP_MEMORY_SCOPE_AGENT);
}}
__global__ __launch_bounds__(64) void persistent({','.join(parameters)}) {{
 auto ka=(const unsigned char*)__builtin_amdgcn_kernarg_segment_ptr();
 unsigned* counters=(unsigned*)state;
 unsigned* done=counters+4;
 unsigned* ready=done+max_tiles*{c.counter_stride};
 const unsigned tiles={f'{batch*9}' if c.direct else '((const unsigned*)g_valid)[0]/16'};
 unsigned lane=threadIdx.x;
 while (true) {{
   unsigned task=0xffffffffu,kind=0,tile=0;
   if (lane==0) {{
     unsigned head=ld(counters+1),tail=ld(counters+2);
     if(head<tail) {{
       unsigned entry=ld(ready+(head/{nd})*{c.counter_stride});
       if(entry) {{
         unsigned expected=head;
         if(__hip_atomic_compare_exchange_strong(counters+1,&expected,head+{c.down_chunk},
                __ATOMIC_RELAXED,__ATOMIC_RELAXED,__HIP_MEMORY_SCOPE_AGENT)) {{
           task=head;kind=2;tile=entry-1;
         }}
       }}
     }}
     if(kind==0 && ld(counters)<tiles*{ng*c.split_k}) {{
       task=add(counters,1);
       if(task<tiles*{ng*c.split_k}) kind=1;
     }}
     if(kind==0 && ld(counters+3)==tiles && ld(counters+1)>=tiles*{nd}) kind=3;
   }}
   kind=__builtin_amdgcn_readfirstlane(kind);
   task=__builtin_amdgcn_readfirstlane(task);
   tile=__builtin_amdgcn_readfirstlane(tile);
   if(kind==3) return;
   if(kind==0) continue;
   if(kind==2) {{
     // Acquire data only after successfully claiming a published task.
     // Polling queue counters never invalidates the data cache.
     __atomic_thread_fence(__ATOMIC_ACQUIRE);
     for(unsigned chunk=0;chunk<{c.down_chunk};++chunk,++task) {{ {down} }}
   }}
   else {{
     {gate}
     tile=task/{ng*c.split_k};
     // Wait/fence from every lane before lane zero publishes completion.
     __threadfence(); __syncthreads();
     unsigned last=0;
     if(lane==0) last=add(done+tile*{c.counter_stride},1)=={ng*c.split_k-1};
     last=__builtin_amdgcn_readfirstlane(last);
     if(last) {{
       __atomic_thread_fence(__ATOMIC_ACQUIRE);
       {middle}
       __threadfence(); __syncthreads();
       if(lane==0) {{
         unsigned slot=add(counters+2,{nd})/{nd};
         st(ready+slot*{c.counter_stride},tile+1);
         add(counters+3,1);
       }}
     }}
   }}
 }}
}}
'''
    if c.schedule=='groups':
        # Fixed cooperative worker groups remove global task-queue contention.
        # Each group advances independently through expert/token tiles, with
        # one G1 completion counter and one packed-intermediate ready flag.
        begin=source.index(' while (true)')
        source=source[:begin]+f'''
 const unsigned group_size={worker_group_size(c)};
 const unsigned producer_parts={min(worker_group_size(c),ng*c.split_k)};
 const unsigned group=blockIdx.x/group_size,part=blockIdx.x%group_size;
 const unsigned groups=gridDim.x/group_size;
 for(unsigned tile=group;tile<tiles;tile+=groups) {{
   {'unsigned long long t0=__builtin_amdgcn_s_memrealtime();' if c.profile else ''}
   unsigned task;
   for(unsigned work=part;work<{ng*c.split_k};work+=group_size) {{
     task=tile*{ng*c.split_k}+work;
     {gate}
   }}
   __threadfence(); __syncthreads();
   {'unsigned long long t1=__builtin_amdgcn_s_memrealtime();' if c.profile else ''}
   unsigned last=0;
   if(lane==0 && part<producer_parts) last=add(done+tile*{c.counter_stride},1)==producer_parts-1;
   last=__builtin_amdgcn_readfirstlane(last);
   if(last) {{
     __atomic_thread_fence(__ATOMIC_ACQUIRE);
     {middle}
     __threadfence(); __syncthreads();
     if(lane==0) st(ready+tile*{c.counter_stride},1);
   }}
   unsigned available=0;
   do {{
     if(lane==0) available=ld(ready+tile*{c.counter_stride});
     available=__builtin_amdgcn_readfirstlane(available);
   }} while(!available);
   __atomic_thread_fence(__ATOMIC_ACQUIRE);
   {'unsigned long long t2=__builtin_amdgcn_s_memrealtime();' if c.profile else ''}
   for(task=part;task<{nd};task+=group_size) {{ {down} }}
   {'unsigned long long t3=__builtin_amdgcn_s_memrealtime(); if(lane==0) { auto p=(unsigned long long*)profile+(tile*group_size+part)*4;p[0]=t0;p[1]=t1;p[2]=t2;p[3]=t3; }' if c.profile else ''}
 }}
}}
'''
    if c.coherent_intermediate:
        # Payload accesses are explicitly device coherent, all producer lanes
        # wait for VMEM completion, and the block barrier precedes publication.
        # Consumer payload reads bypass stale private caches. Retain the HIP
        # atomic queue/count operations; remove only redundant cache fences.
        source=source.replace('__threadfence();','').replace('__atomic_thread_fence(__ATOMIC_ACQUIRE);','')
        source=source.replace('__hip_atomic_store(p,v,__ATOMIC_RELEASE,','__hip_atomic_store(p,v,__ATOMIC_RELAXED,')
    digest=hashlib.sha256(source.encode()).hexdigest()[:16]
    path=Path(PYHIP_CACHE_DIR)/f'persistent_{digest}.cpp';path.write_text(source)
    fn=getattr(module(str(path)),'persistent').build();fn.lazy_load_func()
    assembly=path.with_suffix('.s').read_text()
    scratch=int(re.search(r'\.amdhsa_private_segment_fixed_size (\d+)',assembly).group(1))
    lib=get_lib();lib.hipModuleOccupancyMaxActiveBlocksPerMultiprocessor.argtypes=[ctypes.POINTER(ctypes.c_int),ctypes.c_void_p,ctypes.c_int,ctypes.c_size_t]
    lib.hipModuleOccupancyMaxActiveBlocksPerMultiprocessor.restype=ctypes.c_int
    resident=ctypes.c_int();hip_check_error(lib.hipModuleOccupancyMaxActiveBlocksPerMultiprocessor(ctypes.byref(resident),fn.p_func,64,0))
    assert getattr(type(fn.args),'arg_11').offset==88
    assert getattr(type(fn.args),'arg_22').offset==176
    info=dict(source_sha256=digest,scratch_bytes=scratch,blocks_per_cu=resident.value,config=c.__dict__)
    path.with_suffix('.json').write_text(json.dumps(info,indent=2))
    return fn,info


class PersistentProgram(NativeProgram):
    def __init__(self,owner,batch,config=PersistentConfig()):
        self.pc=config
        super().__init__(owner,batch,NativeConfig(direct=config.direct,gate_n=config.gate_n,
            gate_waves=1,down_n=config.down_n,down_waves=1,split_k=config.split_k,
            non_temporal=config.non_temporal))
        self.state=torch.zeros(4+2*self.grid*config.counter_stride,device=owner.device,dtype=torch.int32)
        group_size=worker_group_size(config)
        self.profile=torch.zeros((self.grid,group_size,4),device=owner.device,dtype=torch.int64) if config.profile else None
        self.fn,self.info=build(batch,config)
        self.workers=owner._cu_count*min(config.workers_per_cu,self.info['blocks_per_cu'])
        if config.schedule=='groups':
            group_size=worker_group_size(config)
            self.workers=min(self.workers,self.grid*group_size)
            self.workers=self.workers//group_size*group_size
            assert self.workers>0
            from pyhip.core.hiptools import get_lib
            lib=get_lib()
            lib.hipModuleLaunchCooperativeKernel.argtypes=[ctypes.c_void_p]+[ctypes.c_uint]*7+[ctypes.c_void_p,ctypes.c_void_p]
            lib.hipModuleLaunchCooperativeKernel.restype=ctypes.c_int
            fields=self.fn.args._fields_
            self.arg_pointers=(ctypes.c_void_p*len(fields))(*[ctypes.addressof(self.fn.args)+getattr(type(self.fn.args),n).offset for n,_ in fields])

    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        from .native_prepare import native_phase1
        from .prepare import phase23
        b,c,p=self.b,self.c,self.p;output=p['output'] if out is None else out
        # First prototype isolates scheduling. Reset will be fused into prep
        # after the worker pipeline establishes correctness and value.
        persistent_prepare([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),
            p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),
            0 if supplied_weights is None else supplied_weights.data_ptr(),self.state.data_ptr(),self.state.numel(),b*384,supplied_ids is not None)
        if not c.direct:
            phase23([self.group_grid],[384],p['ids'].data_ptr(),p['weights'].data_ptr(),p['sorted_ids'].data_ptr(),
                p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),p['valid'].data_ptr(),b,self.group_grid,p['sorted_ids'].numel())
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                         (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        args=[]
        for inp,scale,w,ws,target in ((p['packed'],p['workspace'].data_ptr()+256,self.owner.w13,self.owner.weights.w13_scale,self.partial),
                                     (self.mid,self.mid_scale.data_ptr(),self.owner.w2,self.owner.weights.w2_scale,output)):
            args += [inp.data_ptr(),scale,w.data_ptr(),ws.data_ptr(),target.data_ptr(),self.mid_scale.data_ptr(),
                     ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b]
        args += [self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),ids.data_ptr(),self.state.data_ptr(),self.grid,
                 self.profile.data_ptr() if self.profile is not None else 0]
        if self.pc.schedule=='groups':
            from pyhip.core.hiptools import get_lib,hip_check_error
            for (name,_),value in zip(self.fn.args._fields_,args):setattr(self.fn.args,name,value)
            stream=ctypes.cast(torch.cuda.current_stream(),ctypes.c_void_p)
            hip_check_error(get_lib().hipModuleLaunchCooperativeKernel(self.fn.p_func,self.workers,1,1,64,1,1,0,stream,self.arg_pointers))
        else:self.fn([self.workers],[64],*args)
        return output
