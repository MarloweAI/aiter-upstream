# SPDX-License-Identifier: MIT
"""Packed-only preparation; retains the established routing and scale rules."""
from marlowe_kernels._runtime import jit
from .prepare import topk
from .quant import block_scale, bf16, silu


def pack_fp4(J, values, distances, fused=False):
    exponent, scale = block_scale(J, values, distances, fused)
    codes = []
    for i in range(0, len(values), 2):
        code = J.gpr('vu32')
        J.v_cvt_scalef32_pk_fp4_f32(code, values[i], values[i+1], scale,
                                  mod='op_sel:[0,0,0,0]')
        code[:] = code[0] & 255
        codes.append(code)
    return codes, exponent


@jit()
def native_phase1(J, L:'void*', C:'void*', X:'void*', IDS:'void*', W:'void*',
           Q:'void*', S:'void*', O:'void*', SI:'void*', SW:'void*', SUPPLIED):
    token, tid = J.blockIdx.x[0], J.threadIdx.x[0]
    zero = J.gpr(4, 'vu32', 0)
    for part in (0,16):
        J.global_store_dwordx4((token*3*2048+tid*16)*2+part, zero, O)
    data = J.gpr(8, 'vu32')
    for part in (0,4):
        J.global_load_dwordx4(data[part:part+3], (token*3*2048+tid*16)*2+part*4, X)
    J.s_waitcnt(mod='vmcnt(0)')
    values = []
    for i in range(8):
        values.extend([J.gpr(data[i] << 16), J.gpr(data[i] & 0xffff0000)])
    encoded = J.gpr(2, 'vu32', 0)
    codes, exponent = pack_fp4(J, values, (1,), False)
    for i, code in enumerate(codes):
        encoded[i//4] = encoded[i//4] | (code[0] << (8*(i%4)))
    J.global_store_dwordx2(token*3*1024+tid*8, encoded, Q)
    with J.ExecMask(tid%2 == 0, early_skip=False):
        J.global_store_byte(256+token*3*64+tid//2, exponent, S)
    with J.ExecMask(tid < 64):
        if SUPPLIED:
            ids, weights = J.gpr('vu32'), J.gpr('vf32')
            with J.ExecMask(tid < 8, early_skip=False):
                J.global_load_dword(ids, (token*8+tid)*4, SI)
                J.global_load_dword(weights, (token*8+tid)*4, SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4, ids, IDS)
                J.global_store_dword((token*9+tid)*4, weights, W)
        else:
            topk(J, L, C, IDS, W, token)
        with J.ExecMask(tid == 0, early_skip=False):
            J.global_store_dword(J.gpr("vu32",(token*9+8)*4), J.gpr('vu32',256), IDS)
            J.global_store_dword(J.gpr("vu32",(token*9+8)*4), J.gpr('vf32',1.), W)



@jit()
def middle_packed(J, P:'void*', Y:'void*', YS:'void*', B, SK, FUSED):
    """Match the accepted split reduction tree and activation/storage rounding."""
    row = J.gpr("vu32", J.blockIdx.x[0])[0]
    col = J.blockIdx.y[0] * 128 + J.threadIdx.x[0] * 2
    assert SK > 1
    pairs = []
    for offset in (0, 256):
        parts = []
        for split in range(1 << (SK - 1).bit_length()):
            value = J.gpr(2, 'vf32', 0.)
            if split < SK:
                J.global_load_dwordx2(value, ((split*B*9+row)*512+col+offset)*4, P)
            parts.append(value)
        J.s_waitcnt(mod='vmcnt(0)')
        # tl.sum over the padded split dimension: halves, then quarters.
        stride = len(parts)//2
        while stride:
            for i in range(stride):
                for j in range(2):
                    J.v_add_f32(parts[i][j], parts[i][j], parts[i+stride][j])
            stride //= 2
        pairs.append(parts[0])
    values = [silu(J, pairs[0][i], pairs[1][i]) for i in range(2)]
    if not FUSED:
        values = [bf16(J, x) for x in values]
    codes,exponent=pack_fp4(J,values,(1,2,4,8),FUSED)
    J.global_store_byte(row*128+col//2,codes[0],Y)
    with J.ExecMask(J.threadIdx.x[0]%16==0,early_skip=False):
        J.global_store_byte(row*8+col//32,exponent,YS)
