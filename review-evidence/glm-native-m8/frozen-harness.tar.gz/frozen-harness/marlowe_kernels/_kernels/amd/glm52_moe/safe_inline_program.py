# SPDX-License-Identifier: MIT
"""Keep inline internal routing fast and combine supplied slots in fixed order."""
import torch
from marlowe_kernels._runtime import jit
from .inline_program import InlineProgram, InlineConfig, inline_gate
from .overlap_consumer import overlap_down
from .ordered_program import ordered_combine


class DirectRouteStores:
    """Redirect direct G2's rounded atomic operands into private route rows."""
    def __init__(self, context, delta):
        object.__setattr__(self, 'context', context)
        object.__setattr__(self, 'delta', delta)

    def __getattr__(self, name):
        return getattr(self.context, name)

    def __setattr__(self, name, value):
        setattr(self.context, name, value)

    def global_atomic_pk_add_bf16(self, address, value, base):
        target = self.context.gpr(address[0] + self.delta[0])
        return self.context.global_store_dword(target, value, base)


@jit()
def ordered_overlap_down(J, B, BN, NW, SK, FP32, NT,
    PART:'void*', MID:'void*', MS:'void*', W:'void*', WS:'void*',
    OUT:'void*', IDS:'void*', RW:'void*'):
    # The original address selects token*N. Each CTA owns exactly one route,
    # so add (route-token)*N without changing its BF16 conversion or MFMA.
    route = J.blockIdx.y[0]
    delta = J.gpr('su32', (route - route // 9) * 12288)
    context = DirectRouteStores(J, delta)
    overlap_down.gen_func(context, B, BN, NW, SK, FP32, NT,
        PART, MID, MS, W, WS, OUT, IDS, RW)


class SafeInlineProgram(InlineProgram):
    def __init__(self, owner, batch, config=InlineConfig()):
        super().__init__(owner, batch, config)
        assert config.fuse_middle and config.overlap_weights
        self.route_output = torch.empty((batch, 9, 6144), device=owner.device,
                                        dtype=torch.bfloat16)
        self.info.update(supplied_combination='BF16 operand rounding, ordered FP32 sum')

    def run(self, x, logits, bias, *, out=None, supplied_ids=None, supplied_weights=None):
        if supplied_ids is None:
            return super().run(x, logits, bias, out=out)
        b, c, p, ic = self.b, self.cc, self.p, self.ic
        output = p['output'] if out is None else out
        target = self.route_output
        shape = dict(x=512 // c.gate_n, y=self.grid, z=c.split_k)
        inline_gate([shape[axis] for axis in ic.gate_axis], [64], b, c.gate_n,
            c.split_k, c.non_temporal, c.depth or 2, True, False,
            ic.route_preload, ic.gate_axis, ic.reuse_probabilities,
            ic.pair_depth, ic.slot_routing, ic.packed_input_scales,
            logits.data_ptr(), bias.data_ptr(), x.data_ptr(), supplied_ids.data_ptr(),
            supplied_weights.data_ptr(), p['ids'].data_ptr(), p['weights'].data_ptr(),
            target.data_ptr(), self.owner.w13.data_ptr(), self.owner.weights.w13_scale.data_ptr(),
            self.partial.data_ptr(), self.mid.data_ptr(), self.mid_scale.data_ptr())
        ordered_overlap_down([6144 // c.down_n, self.grid], [64 * c.down_waves],
            b, c.down_n, c.down_waves, c.split_k, self.fp32_middle, c.non_temporal,
            self.partial.data_ptr(), self.mid.data_ptr(), self.mid_scale.data_ptr(),
            self.owner.w2.data_ptr(), self.owner.weights.w2_scale.data_ptr(),
            target.data_ptr(), p['ids'].data_ptr(), p['weights'].data_ptr())
        ordered_combine([12, b], [256], target.data_ptr(), output.data_ptr())
        return output
