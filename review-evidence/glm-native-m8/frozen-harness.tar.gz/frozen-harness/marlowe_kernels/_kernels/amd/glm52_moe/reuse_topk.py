# SPDX-License-Identifier: MIT
"""Top-k variant retaining original sigmoid values for exact routing weights."""
from .prepare import sigmoid,key,select_max


def reuse_topk(J, L, C, IDS, WEIGHTS, token, preload=False):
    lane = J.threadIdx.x[0] % 64
    keys = []
    probabilities = []
    if preload:
        raw_logits=J.gpr(4,'vu32');raw_bias=J.gpr(4,'vu32')
        for j in range(4):
            expert=J.gpr(lane+j*64)
            J.global_load_ushort(raw_logits[j],(token*256+expert[0])*2,L)
            J.global_load_ushort(raw_bias[j],expert[0]*2,C)
        J.s_waitcnt(mod='vmcnt(0)')
    for j in range(4):
        expert = J.gpr(lane + j*64)
        logit, bias = J.gpr('vu32'), J.gpr('vu32')
        if preload:
            logit[:]=raw_logits[j];bias[:]=raw_bias[j]
        else:
            J.global_load_ushort(logit, (token*256+expert[0])*2, L)
            J.global_load_ushort(bias, expert[0]*2, C)
            J.s_waitcnt(mod='vmcnt(0)')
        logit[:] = logit[0] << 16; bias[:] = bias[0] << 16
        score = sigmoid(J, logit)
        probabilities.append(J.gpr('vf32',score[0]))
        J.v_add_f32(score, score, bias)
        keys.append(key(J, score, expert))
    # The native per-lane sorting network and six DPP reductions. Only lane
    # 63 is defined after the row broadcasts; broadcast its winning key.
    for i in range(4):
        for j in range(i+1,4):
            left = J.gpr(2,'vu32')
            for part in range(2):left[part]=keys[i][part]
            J.v_cmp_gt_u64('vcc',keys[j],left)
            for part in range(2):
                J.v_cndmask_b32(keys[i][part],left[part],keys[j][part],'vcc')
                J.v_cndmask_b32(keys[j][part],keys[j][part],left[part],'vcc')
    winner_id = J.gpr('vu32', 0)
    winner_probability = J.gpr('vf32',0.)
    controls=('quad_perm:[1,0,3,2]','quad_perm:[2,3,0,1]',
              'row_half_mirror','row_mirror','row_bcast:15','row_bcast:31')
    for k in range(8):
        winner = J.gpr(2, 'vu32')
        for i in range(2):winner[i]=keys[0][i]
        for control in controls:
            # CDNA4 ISA Table 11: a DPP source needs two wait states
            # after a VALU write; the pinned JIT does not insert these.
            J.s_nop(1)
            other=J.gpr(2,'vu32')
            for part in range(2):
                J.v_mov_b32_dpp(other[part],winner[part],mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
            select_max(J,winner,other)
        broadcast=J.gpr(2,'su32')
        J.s_nop(0)
        for part in range(2):J.v_readlane_b32(broadcast[part],winner[part],63)
        J.s_nop(1)  # VALU-produced SGPR -> VALU constant source
        expert=J.gpr('vu32',(broadcast[0]^0xffffffff)&511)
        J.v_cmp_eq_u32('vcc',J.gpr(lane),k)
        J.v_cndmask_b32(winner_id,winner_id,expert,'vcc')
        # Recover the original sigmoid from the winning lane/register rather
        # than issue another dependent global logit read and sigmoid.
        which=J.gpr('su32',(broadcast[0]^0xffffffff)&511)
        component=J.gpr('vu32',which[0]>>6)
        probability=J.gpr('vf32',probabilities[0][0])
        for j in range(1,4):
            J.v_cmp_eq_u32('vcc',component,j)
            J.v_cndmask_b32(probability,probability,probabilities[j],'vcc')
        src_lane=J.gpr('su32',which[0]&63)
        selected_probability=J.gpr('sf32')
        J.s_nop(0)
        J.v_readlane_b32(selected_probability,probability,src_lane)
        J.s_nop(1)
        J.v_cmp_eq_u32('vcc',J.gpr(lane),k)
        J.v_cndmask_b32(winner_probability,winner_probability,J.gpr('vf32',selected_probability[0]),'vcc')
        J.v_cmp_eq_u64('vcc',keys[0],broadcast)
        for j in range(3):
            for part in range(2):J.v_cndmask_b32(keys[j][part],keys[j][part],keys[j+1][part],'vcc')
        for part in range(2):J.v_cndmask_b32(keys[3][part],keys[3][part],0,'vcc')
    probability = winner_probability
    J.v_cmp_lt_u32('vcc', J.gpr(lane), 8)
    J.v_cndmask_b32(probability, 0, probability, 'vcc')
    total = J.gpr('vf32'); total[:] = probability
    for control in controls:
        J.s_nop(1)
        J.v_add_f32_dpp(total,total,total,mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
    sum_scalar=J.gpr('sf32')
    J.s_nop(0)
    J.v_readlane_b32(sum_scalar,total,63)
    J.s_nop(1)
    J.v_rcp_f32(total,sum_scalar)
    J.v_mul_f32(total,J.gpr('sf32',2.5),total)
    J.v_mul_f32(probability, probability, total)
    with J.ExecMask(lane < 8, early_skip=False):
        J.global_store_dword((token*9+lane)*4, winner_id, IDS)
        J.global_store_dword((token*9+lane)*4, probability, WEIGHTS)

