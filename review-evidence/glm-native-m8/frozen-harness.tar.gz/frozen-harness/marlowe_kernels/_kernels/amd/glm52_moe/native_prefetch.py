# SPDX-License-Identifier: MIT
# Weight/MFMA layout follows the earlier Port-EW native_projection experiment
# and upstream PyHIP 270225149dec3436923959554f50f363bf7057cf (MIT).
"""Experimental deeper operand prefetch; preserves native FP4 arithmetic.

Derived from native_fp4.py. Wait counts include input, input-scale, weight,
and weight-scale instructions, keeping younger requests in flight.
"""
from marlowe_kernels._runtime import jit
from .native_prepare import pack_fp4
from .quant import bf16, silu


@jit()
def prefetch_projection(J, K,N,BN,FIRST,SK,FP32_OUT,NW,DIRECT,PIPE,NT,DEPTH,
                      X:'void*', XS:'void*', W:'void*', WS:'void*', Y:'void*', YS:'void*',
                      IDS:'void*', RW:'void*', EXP:'void*', VALID:'void*', B:'int'):
    assert K%128==0 and N%BN==0 and BN in (32,64,128,256) and BN%NW==0
    # A split producer may own only 16 gate/up features. Packing still spans
    # a complete 32-feature scale group in the subsequent consumer.
    assert not FIRST or (BN//NW)%(32 if SK>1 else 64)==0
    assert SK==1 or FIRST
    assert K%SK==0 and (K//SK)%128==0
    lane=J.gpr(J.threadIdx.x[0]%64)
    row=J.gpr(lane[0]%16)
    part=J.gpr(lane[0]//16)
    packed_stride=J.gpr('su32',K//2)
    scale_stride=J.gpr('su32',K//32)
    output_stride=J.gpr('su32',N)
    expert=J.gpr('su32')
    routing=J.gpr('vf32')
    if DIRECT == "flat":
        from .flat_bins import resolve_flat_routes
        expert,token,slot,routing=resolve_flat_routes(J,IDS,RW,EXP,VALID,B,FIRST)
    elif DIRECT == "fixed":
        from .fixed_bins import resolve_fixed_routes
        expert,token,slot,routing=resolve_fixed_routes(J,IDS,RW,EXP,VALID,B,FIRST)
    elif DIRECT == "merge8":
        from .merged_routes8 import resolve_merged_routes8
        expert,token,slot,routing=resolve_merged_routes8(J,IDS,RW,B,NW,FIRST)
    elif DIRECT:
        J.s_load_dword(expert,EXP,J.blockIdx.y[0]*4)
        token_scalar=J.gpr(J.blockIdx.y[0]//9)
        token=J.gpr('vu32',token_scalar[0])
        slot_scalar=J.gpr(J.blockIdx.y[0]-token_scalar[0]*9)
        slot=J.gpr('vu32',slot_scalar[0])
        with J.ExecMask(row[0] != 0, early_skip=False):
            token[:]=B[0]
        if not FIRST:
            J.global_load_dword(routing,J.gpr('vu32',J.blockIdx.y[0]*4),RW)
        J.s_waitcnt(mod='lgkmcnt(0) vmcnt(0)')
    else:
        valid=J.gpr('su32')
        J.s_load_dword(expert,EXP,J.blockIdx.y[0]*4)
        J.s_load_dword(valid,VALID,0)
        J.s_waitcnt(mod='lgkmcnt(0)')
        J.Jump('native_active',J.blockIdx.y[0]*16<valid)
        J.s_endpgm();J.Label('native_active')
        IDS[:]+=J.blockIdx.y[0]*64
        RW[:]+=J.blockIdx.y[0]*64
        sorted_id=J.gpr('vu32')
        J.global_load_dword(sorted_id,row*4,IDS)
        if not FIRST:
            J.global_load_dword(routing,row*4,RW)
        J.s_waitcnt(mod='vmcnt(0)')
        token=J.gpr(sorted_id[0]&0xffffff)
        slot=J.gpr(sorted_id[0]>>24)
    route=J.gpr(token*9+slot)
    wave=J.gpr(J.threadIdx.x[0]//64)
    wave_n=wave[0]*(BN//NW//2 if FIRST else BN//NW)
    xrow=token if FIRST else route
    extent=J.s_mul_u32_u64(expert,N*K//2)
    W[:]+=extent
    stride_scale=(K//32+7)//8*8
    WS[:]+=expert*(N*stride_scale)
    blocks=BN//NW//16
    accum=J.gpr(blocks,4,'vf32',0.)
    # Hoist route/N-dependent addresses out of the reduction loop. Two slots
    # optionally overlap the next packed weight/scale loads with current MFMA.
    steps=(K//SK)//128
    depth=max(d for d in range(1,min(DEPTH,steps)+1)
              if steps%d==0 and (d-1)*(2+2*blocks)<=63)
    slots=depth if PIPE else 1
    avec=J.gpr(slots,4,'vu32')
    bvec=J.gpr(slots,blocks,4,'vu32')
    ascale=J.gpr(slots,'vu32')
    bscale=J.gpr(slots,blocks,'vu32')
    qa_base=J.gpr(xrow*packed_stride[0]+part*16)
    sa_base=J.gpr(xrow*scale_stride[0]+part)
    qb_base=[];sb_base=[]
    for n in range(blocks):
        if FIRST:
            n_offset=(n%(blocks//2))*16+(N//2 if n>=blocks//2 else 0)
            col=J.gpr('vu32',J.blockIdx.x[0]*(BN//2)+wave_n+n_offset)
        else:
            col=J.gpr('vu32',J.blockIdx.x[0]*BN+wave_n+n*16)
        qb_base.append(J.gpr(col*packed_stride[0]+lane*16))
        sb_base.append(J.gpr((col//32)*(32*stride_scale)+lane*4+(col%32)//16))
    kstep=J.gpr('su32',0)
    kbase=J.gpr(J.blockIdx.z[0]*(K//SK)) if SK>1 else J.gpr('su32',0)
    def load(slot,step):
        k=J.gpr(kbase[0]+step*128)
        avec[slot]=0;ascale[slot]=127
        with J.ExecMask(token<B[0],early_skip=False):
            J.global_load_dwordx4(avec[slot],qa_base[0]+k[0]//2,X)
            J.global_load_ubyte(ascale[slot],sa_base[0]+k[0]//32,XS)
        for n in range(blocks):
            J.global_load_dwordx4(bvec[slot,n],qb_base[n][0]+(k[0]//128)*1024,W,mod="sc0 nt" if NT else "")
            J.global_load_ubyte(bscale[slot,n],sb_base[n][0]+(k[0]//256)*256+((k[0]//128)%2)*2,WS)
    def compute(slot):
        for n in range(blocks):
            J.v_mfma_scale_f32_16x16x128_f8f6f4(accum[n],bvec[slot,n],avec[slot],accum[n],bscale[slot,n],ascale[slot],
                                              mod='op_sel:[0,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4')
    steps=(K//SK)//128
    if PIPE:
        pending=(depth-1)*(2+2*blocks)
        assert pending<=63
        for slot in range(depth):load(slot,slot)
        if steps>depth:
            with J.While(kstep[0]<steps-depth):
                for slot in range(depth):
                    J.s_waitcnt(mod=f'vmcnt({pending})')
                    compute(slot)
                    load(slot,kstep[0]+depth+slot)
                kstep[:]+=depth
        for slot in range(depth):
            J.s_waitcnt(mod=f'vmcnt({(depth-slot-1)*(2+2*blocks)})')
            compute(slot)
    else:
        with J.While(kstep[0]<steps):
            load(0,kstep[0]);J.s_waitcnt(mod='vmcnt(0)')
            compute(0)
            kstep[:]+=1
    if FIRST and SK>1:
        split=J.gpr('su32')
        J.s_mul_i32(split,J.blockIdx.z,B[0])
        split[:]*=9*N*4
        for n in range(blocks):
            col=J.gpr('vu32',J.blockIdx.x[0]*(BN//2)+wave_n+(n%(blocks//2))*16+
                      (N//2 if n>=blocks//2 else 0)+part*4)
            dst=J.gpr(route*(N*4)+split[0]+col*4)
            with J.ExecMask(token<B[0],early_skip=False):
                J.global_store_dwordx4(dst,accum[n],Y)
    elif FIRST:
        # The first SiLU multiply has only blocks-1 later MFMAs and its
        # constant materialization separating it from fragment zero.
        if blocks < 8:J.s_nop(7-blocks)
        activated=[]
        for n in range(blocks//2):
            values=[silu(J,accum[n,i],accum[n+blocks//2,i]) for i in range(4)]
            if not FP32_OUT:
                values=[bf16(J,value) for value in values]
            activated.append(values)
        for group in range(blocks//4):
            values=activated[group*2]+activated[group*2+1]
            codes,exponent=pack_fp4(J,values,(16,32),FP32_OUT)
            for n in range(2):
                col=J.gpr(J.blockIdx.x[0]*(BN//2)+wave_n+(group*2+n)*16+part*4)
                packed=J.gpr(codes[n*2][0] | (codes[n*2+1][0]<<8))
                with J.ExecMask(token<B[0],early_skip=False):
                    J.global_store_short(route*(N//4)+col[0]//2,packed,Y)
            col=J.gpr(J.blockIdx.x[0]*(BN//2)+wave_n+group*32)
            with J.ExecMask((token<B[0]) & (part[0]==0),early_skip=False):
                J.global_store_byte(route*(N//64)+col[0]//32,exponent,YS)
    else:
        # gfx950 scaled-MFMA results need eight issue slots before ordinary
        # VALU use. The first fragment has only blocks-1 later MFMAs.
        if blocks < 9:J.s_nop(8-blocks)
        for n in range(blocks):
            packed=J.gpr(2,'vbf16x2')
            for i in range(4):
                accum[n,i]*=routing[0]
            J.v_cvt_pk_bf16_f32(packed[0],accum[n,0],accum[n,1])
            J.v_cvt_pk_bf16_f32(packed[1],accum[n,2],accum[n,3])
            dst=J.gpr((token*output_stride[0]+J.blockIdx.x[0]*BN+wave_n+n*16+part*4)*2)
            with J.ExecMask(token<B[0],early_skip=False):
                J.global_atomic_pk_add_bf16(dst,packed[0],Y)
                J.global_atomic_pk_add_bf16(dst+4,packed[1],Y)
