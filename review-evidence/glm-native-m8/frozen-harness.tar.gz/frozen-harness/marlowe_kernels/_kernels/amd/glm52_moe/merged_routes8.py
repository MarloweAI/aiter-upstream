# SPDX-License-Identifier: MIT
"""Consumer-side route merging for B8: 64 routed slots plus one shared tile.

Derived from the B4 ballot experiment. Routed slots fit in one wave; the shared
expert uses a separate dense tile, avoiding a second ballot over 72 slots.
No global route allocator, publication polling, or sort launch is required.
"""
def resolve_merged_routes8(J,IDS,RW,B,NW,FIRST):
    lane=J.gpr(J.threadIdx.x[0]%64);row=J.gpr(lane[0]%16);wave=J.gpr(J.threadIdx.x[0]//64)
    # Hoist reused address expressions before EXEC masks and divergent paths.
    lane_bytes=J.gpr(lane[0]*4);row_bytes=J.gpr(row[0]*4);wave_bytes=J.gpr(wave[0]*64)
    lane_token=J.gpr(lane[0]>>3);route_bytes=J.gpr((lane[0]+lane_token[0])*4)
    ids_lds=J.alloc_lds(NW*64);weights_lds=J.alloc_lds(NW*64) if not FIRST else None
    ids_base=J.gpr(ids_lds+wave_bytes[0]);weights_base=J.gpr(weights_lds+wave_bytes[0]) if not FIRST else None
    sentinel_s=J.gpr('su32',(9<<24)|B[0]);sentinel=J.gpr('vu32',sentinel_s[0])
    expert=J.gpr('su32');packed=J.gpr('vu32');routing=J.gpr('vf32',1.)
    J.Jump('merge8_shared',J.blockIdx.y[0]==64)
    compact=J.gpr('su32',J.blockIdx.y[0]);actual=J.gpr('su32',compact[0]+compact[0]//8)
    J.s_load_dword(expert,IDS,actual[0]*4)
    candidate=J.gpr('vu32');weight=J.gpr('vf32',0.)
    J.global_load_dword(candidate,route_bytes,IDS)
    if not FIRST:J.global_load_dword(weight,route_bytes,RW)
    J.s_waitcnt(mod='lgkmcnt(0) vmcnt(0)')
    J.v_cmp_eq_u32('vcc',candidate,expert)
    mask=J.gpr(2,'su32');J.s_mov_b64(mask,'vcc')
    rank=J.gpr('vu32');J.v_mbcnt_lo_u32_b32(rank,mask[0],0);J.v_mbcnt_hi_u32_b32(rank,mask[1],rank)
    leader_rank=J.gpr('su32');J.v_readlane_b32(leader_rank,rank,compact);J.s_nop(1)
    J.Jump('merge8_leader',(leader_rank[0]%16)==0)
    J.s_endpgm();J.Label('merge8_leader')
    with J.ExecMask(lane[0]<16,early_skip=False):
        J.ds_write_b32(ids_base[0]+lane_bytes[0],sentinel)
        if not FIRST:J.ds_write_b32(weights_base[0]+lane_bytes[0],J.gpr('vf32',0.))
    J.s_waitcnt(mod='lgkmcnt(0)')
    value=J.gpr(lane_token[0]|((lane[0]&7)<<24))
    with J.ExecMask((candidate[0]==expert[0])&((rank[0]//16)==(leader_rank[0]//16)),early_skip=False):
        J.ds_write_b32(ids_base[0]+(rank[0]%16)*4,value)
        if not FIRST:J.ds_write_b32(weights_base[0]+(rank[0]%16)*4,weight)
    J.s_waitcnt(mod='lgkmcnt(0)')
    J.ds_read_b32(packed,ids_base[0]+row_bytes[0])
    if not FIRST:J.ds_read_b32(routing,weights_base[0]+row_bytes[0])
    J.s_waitcnt(mod='lgkmcnt(0)')
    J.Jump('merge8_ready')
    J.Label('merge8_shared')
    expert[:]=256
    packed[:]=row[0]|(8<<24)
    with J.ExecMask(row[0]>=B[0],early_skip=False):packed[:]=sentinel[0]
    J.Label('merge8_ready')
    return expert,J.gpr(packed[0]&0xffffff),J.gpr(packed[0]>>24),routing
