# SPDX-License-Identifier: MIT
"""Fuse split-K completion into the last G1 producer; G2 keeps its own grid.

No spinning consumers and no persistent queue. A counter per intermediate
feature tile allows its last split to reduce, activate and pack immediately.
"""
import ctypes,hashlib,json,re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import torch
from marlowe_kernels._runtime import jit
from .native_program import NativeConfig,NativeProgram
from .native_fp4 import native_projection
from .native_prepare import pack_fp4
from .quant import bf16,silu
from .persistent import _artifact,_inline,persistent_prepare
from .prepare import phase23

@jit()
def finish_feature(J,P:'void*',Y:'void*',YS:'void*',IDS:'void*',B,SK,BN,NW,DIRECT,FUSED):
    lane=J.threadIdx.x[0]%64;row=J.gpr(lane%16);part=J.gpr(lane//16)
    wave=J.gpr(J.threadIdx.x[0]//64)
    if DIRECT:
        token_scalar=J.gpr('su32',J.blockIdx.y[0]//9)
        token=J.gpr('vu32',token_scalar[0])
        route=J.gpr('vu32',J.blockIdx.y[0])
        with J.ExecMask(row[0]!=0,early_skip=False):token[:]=B
    else:
        identity=J.gpr('vu32')
        J.global_load_dword(identity,J.blockIdx.y[0]*64+row*4,IDS)
        J.s_waitcnt(mod='vmcnt(0)')
        token=J.gpr(identity[0]&0xffffff);route=J.gpr(token*9+(identity[0]>>24))
    for group in range(BN//NW//64):
        col=J.gpr(J.blockIdx.x[0]*(BN//2)+wave*(BN//NW//2)+group*32)
        pairs=[]
        for offset in (0,256):
            cols=[]
            for n in range(2):
                parts=[]
                for split in range(1<<(SK-1).bit_length()):
                    value=J.gpr(4,'vf32',0.)
                    if split<SK:
                        with J.ExecMask(token<B,early_skip=False):
                            J.global_load_dwordx4(value,((split*B*9+route)*512+col+n*16+part*4+offset)*4,P,mod='sc1')
                    parts.append(value)
                J.s_waitcnt(mod='vmcnt(0)')
                stride=len(parts)//2
                while stride:
                    for i in range(stride):
                        for j in range(4):J.v_add_f32(parts[i][j],parts[i][j],parts[i+stride][j])
                    stride//=2
                cols.extend(parts[0][i] for i in range(4))
            pairs.append(cols)
        values=[silu(J,pairs[0][i],pairs[1][i]) for i in range(8)]
        if not FUSED:values=[bf16(J,v) for v in values]
        codes,scale=pack_fp4(J,values,(16,32),FUSED)
        for n in range(2):
            word=J.gpr(codes[2*n][0]|(codes[2*n+1][0]<<8))
            with J.ExecMask(token<B,early_skip=False):
                J.global_store_short(route*128+col[0]//2+n*8+part*2,word,Y)
        with J.ExecMask((token<B)&(part[0]==0),early_skip=False):J.global_store_byte(route*8+col[0]//32,scale,YS)

@dataclass(frozen=True)
class LastSplitConfig:
    direct: bool=False
    gate_n: int=64
    gate_waves: int=1
    down_n: int=128
    down_waves: int=2
    split_k: int=2
    non_temporal: bool=True
    counter_stride: int=1

@lru_cache(None)
def build(batch,c):
    from pyhip.core.hiptools import PYHIP_CACHE_DIR,module
    assert c.split_k>1
    first=batch in (1,4,8,32);ng=512//c.gate_n
    gbody,greg=_artifact(native_projection,([1,1,1],[c.gate_waves*64],6144,512,c.gate_n,True,c.split_k,first,c.gate_waves,c.direct,True,c.non_temporal,*([0]*10),batch))
    gate=_inline(gbody,greg,'g','ka','blockIdx.x','blockIdx.y','blockIdx.z',True)
    mbody,mreg=_artifact(finish_feature,([1,1],[c.gate_waves*64],0,0,0,0,batch,c.split_k,c.gate_n,c.gate_waves,c.direct,first))
    middle=_inline(mbody,mreg,'m','ka + 88','blockIdx.x','blockIdx.y','0',False)
    params=[f'void* g_{n}' for n in ('x','xs','w','ws','y','ys','ids','rw','exp','valid')]+['int b',
            'void* partial','void* mid','void* mids','void* mids_ids','void* counters']
    source=f'''#include <hip/hip_runtime.h>
__global__ __launch_bounds__({64*c.gate_waves}) void last_split({','.join(params)}) {{
 auto ka=(const unsigned char*)__builtin_amdgcn_kernarg_segment_ptr();
 {'if(blockIdx.y*16>=((const unsigned*)g_valid)[0]) return;' if not c.direct else ''}
 {gate}
 __syncthreads();
 __shared__ unsigned complete;
 if(threadIdx.x==0) complete=__hip_atomic_fetch_add((unsigned*)counters+(blockIdx.y*{ng}+blockIdx.x)*{c.counter_stride},1,__ATOMIC_RELAXED,__HIP_MEMORY_SCOPE_AGENT)=={c.split_k-1};
 __syncthreads();
 if(complete) {{ {middle} }}
}}
'''
    digest=hashlib.sha256(source.encode()).hexdigest()[:16]
    path=Path(PYHIP_CACHE_DIR)/f'last_split_{digest}.cpp';path.write_text(source)
    fn=getattr(module(str(path)),'last_split').build();fn.lazy_load_func()
    assert getattr(type(fn.args),'arg_11').offset==88
    asm=path.with_suffix('.s').read_text()
    info=dict(config=c.__dict__,source_sha256=digest,scratch_bytes=int(re.search(r'\.amdhsa_private_segment_fixed_size (\d+)',asm).group(1)))
    return fn,info

class LastSplitProgram(NativeProgram):
    def __init__(self,owner,batch,config=LastSplitConfig()):
        self.lc=config
        super().__init__(owner,batch,NativeConfig(**{k:v for k,v in config.__dict__.items() if k!='counter_stride'}))
        self.state=torch.zeros(self.grid*(512//config.gate_n)*config.counter_stride,device=owner.device,dtype=torch.int32)
        self.fn,self.info=build(batch,config)
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.c,self.p;output=p['output'] if out is None else out
        persistent_prepare([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),
            p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),0 if supplied_weights is None else supplied_weights.data_ptr(),
            self.state.data_ptr(),self.state.numel(),b*384,supplied_ids is not None)
        if not c.direct:
            phase23([self.group_grid],[384],p['ids'].data_ptr(),p['weights'].data_ptr(),p['sorted_ids'].data_ptr(),
                p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),p['valid'].data_ptr(),b,self.group_grid,p['sorted_ids'].numel())
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                        (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        args=[p['packed'].data_ptr(),p['workspace'].data_ptr()+256,self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),
              self.partial.data_ptr(),self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b,
              self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),ids.data_ptr(),self.state.data_ptr()]
        self.fn([512//c.gate_n,self.grid,c.split_k],[64*c.gate_waves],*args)
        self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
        return output
