# SPDX-License-Identifier: MIT
"""Opt-in Port-EW front end with unchanged AITER-selected fused FP4 experts.

Uses AITER's selector, not a private kernel-name table. This experimental ABI
is qualified against the pinned replay runtime; unsupported selections fail.
"""
import importlib
import math
import torch
from .hybrid_prepare import hybrid_front, hybrid_group
from .native_prepare import native_phase1


class HybridProgram:
    def __init__(self, owner, batch):
        import aiter
        from marlowe_kernels.moe import _require
        self.owner, self.b = owner, batch
        self.fm = fm = importlib.import_module('aiter.fused_moe')
        self.w1, self.w2 = owner.w13, owner.w2
        self.w1.is_shuffled = self.w2.is_shuffled = True
        self.metadata = fm.get_2stage_cfgs(
            fm.get_padded_M(batch), 6144, 256, 257, 9, torch.bfloat16,
            torch.float4_e2m1fn_x2, torch.float4_e2m1fn_x2,
            aiter.QuantType.per_1x32, True, aiter.ActivationType.Silu,
            False, 0, 0, True, opus_weights_shuffled=True,
            input_dtype=torch.bfloat16)
        m = self.metadata
        self.bm = int(m.block_m)
        k1, k2 = m.stage1.keywords, m.stage2.keywords
        self.selection = dict(stage1=str(k1), stage2=str(k2), block_m=self.bm,
                              fuse_quant=m.fuse_quant, skip_inter_quant=m.skip_inter_quant)
        n1 = k1.get('kernelName1', k1.get('kernelName', ''))
        n2 = k2.get('kernelName2', k2.get('kernelName', ''))
        _require(not m.run_1stage and m.fuse_quant == 'fp4' and self.bm in (16,32)
                 and n1.startswith(('flydsl_mxmoe_g1_a4w4_', 'flydsl_moe1_afp4_wfp4_'))
                 and 'atomic' in n2, 'Unqualified AITER hybrid expert selection')
        self.prequant = bool(m.prequant)
        _require((self.bm == 32 and self.prequant and m.skip_inter_quant) or
                 (self.bm == 16 and not self.prequant and '_f16in' in n1),
                 'AITER input/scale ABI changed')
        device = owner.device
        def empty(shape, dtype): return torch.empty(shape, device=device, dtype=dtype)
        ids = torch.zeros((batch,9), device=device, dtype=torch.int32)
        weights = torch.ones((batch,9), device=device, dtype=torch.float32)
        # Allocate exactly the buffers native AITER would allocate. This call
        # runs only at preparation time; runtime grouping is our fused emitter.
        buffers = fm.moe_sorting(ids, weights, 257, 6144, torch.bfloat16,
                                 self.bm, accumulate=True, output_aux=m.output_aux)
        si, sw, se, nv, out = buffers[:5]
        mind = buffers[5] if len(buffers)>5 else empty(si.shape, torch.int32)
        self.p = dict(ids=ids, weights=weights, sorted_ids=si, sorted_weights=sw,
                      experts=se, valid=nv, output=out, mind=mind,
                      packed=empty((batch,3072),torch.uint8),
                      workspace=empty(256+batch*256,torch.uint8))
        self.input_scale = self.p['workspace'][256:256+batch*192].view(batch,192).view(torch.float8_e8m0fnu)
        occupied = math.ceil(257*(1-(1-1/257)**(batch*9)))
        self.group_grid = min(max(16,(occupied*16+19)//20), max(16,owner._cu_count//2),owner._cu_count)

    def run(self, x, logits, bias, *, out=None, supplied_ids=None, supplied_weights=None):
        import aiter
        p, b = self.p, self.b
        output = p['output'] if out is None else out
        supplied = supplied_ids is not None
        si = supplied_ids.data_ptr() if supplied else 0
        sw = supplied_weights.data_ptr() if supplied else 0
        if self.prequant:
            native_phase1([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),
                p['ids'].data_ptr(),p['weights'].data_ptr(),p['packed'].data_ptr(),
                p['workspace'].data_ptr(),output.data_ptr(),si,sw,supplied)
            activation = p['packed'].view(torch.float4_e2m1fn_x2)
            scale = self.input_scale
        else:
            hybrid_front([b],[384],logits.data_ptr(),bias.data_ptr(),p['ids'].data_ptr(),
                         p['weights'].data_ptr(),output.data_ptr(),si,sw,supplied)
            activation, scale = x, None
        hybrid_group([self.group_grid],[384],p['ids'].data_ptr(),p['weights'].data_ptr(),
            p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),
            p['valid'].data_ptr(),p['mind'].data_ptr(),b,self.group_grid,p['sorted_ids'].numel(),self.bm)
        # The existing AITER orchestration retains native intermediate packing,
        # scale layouts, G2 weighting/combine, and all selected expert kernels.
        return self.fm.fused_moe_2stages(
            activation,self.w1,self.w2,9,p['sorted_ids'],p['sorted_weights'],
            p['experts'],p['valid'],output,True,self.bm,
            activation=aiter.ActivationType.Silu,quant_type=aiter.QuantType.per_1x32,
            q_dtype_a=torch.float4_e2m1fn_x2,q_dtype_w=torch.float4_e2m1fn_x2,
            w1_scale=self.owner.weights.w13_scale,w2_scale=self.owner.weights.w2_scale,
            a1_scale=scale,topk_ids=p['ids'],topk_weights=p['weights'],
            m_indices=p['mind'] if self.metadata.output_aux else None,
            _metadata_transform=lambda _:self.metadata,routing_num_experts=257)
