# SPDX-License-Identifier: MIT
"""FP32-logit variant of the frozen Port-EW top-k selection network.

Keep prepare.topk's BF16 emitter/provenance unchanged. Only operand width and
addressing differ here; the selected slot order, FP32 weight normalization and
shared-expert publication follow the same algorithm.
"""
from .prepare import sigmoid,key,select_max


def topk_fp32(J,L,C,IDS,WEIGHTS,token,preload=False):
    lane=J.threadIdx.x[0]%64
    keys=[]
    if preload:
        raw_logits=J.gpr(4,'vu32');raw_bias=J.gpr(4,'vu32')
        for j in range(4):
            expert=J.gpr(lane+j*64)
            J.global_load_dword(raw_logits[j],(token*256+expert[0])*4,L)
            J.global_load_dword(raw_bias[j],expert[0]*4,C)
        J.s_waitcnt(mod='vmcnt(0)')
    for j in range(4):
        expert=J.gpr(lane+j*64)
        logit,bias=J.gpr('vu32'),J.gpr('vu32')
        if preload:
            logit[:]=raw_logits[j];bias[:]=raw_bias[j]
        else:
            J.global_load_dword(logit,(token*256+expert[0])*4,L)
            J.global_load_dword(bias,expert[0]*4,C)
            J.s_waitcnt(mod='vmcnt(0)')
        score=sigmoid(J,logit)
        J.v_add_f32(score,score,bias)
        keys.append(key(J,score,expert))
    for i in range(4):
        for j in range(i+1,4):
            left=J.gpr(2,'vu32')
            for part in range(2):left[part]=keys[i][part]
            J.v_cmp_gt_u64('vcc',keys[j],left)
            for part in range(2):
                J.v_cndmask_b32(keys[i][part],left[part],keys[j][part],'vcc')
                J.v_cndmask_b32(keys[j][part],keys[j][part],left[part],'vcc')
    winner_id=J.gpr('vu32',0)
    controls=('quad_perm:[1,0,3,2]','quad_perm:[2,3,0,1]',
              'row_half_mirror','row_mirror','row_bcast:15','row_bcast:31')
    for k in range(8):
        winner=J.gpr(2,'vu32')
        for i in range(2):winner[i]=keys[0][i]
        for control in controls:
            J.s_nop(1)
            other=J.gpr(2,'vu32')
            for part in range(2):
                J.v_mov_b32_dpp(other[part],winner[part],mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
            select_max(J,winner,other)
        broadcast=J.gpr(2,'su32')
        J.s_nop(0)
        for part in range(2):J.v_readlane_b32(broadcast[part],winner[part],63)
        J.s_nop(1)
        expert=J.gpr('vu32',(broadcast[0]^0xffffffff)&511)
        J.v_cmp_eq_u32('vcc',J.gpr(lane),k)
        J.v_cndmask_b32(winner_id,winner_id,expert,'vcc')
        J.v_cmp_eq_u64('vcc',keys[0],broadcast)
        for j in range(3):
            for part in range(2):J.v_cndmask_b32(keys[j][part],keys[j][part],keys[j+1][part],'vcc')
        for part in range(2):J.v_cndmask_b32(keys[3][part],keys[3][part],0,'vcc')
    value=J.gpr('vu32',0)
    with J.ExecMask(lane<8,early_skip=False):
        J.global_load_dword(value,(token*256+winner_id[0])*4,L)
    J.s_waitcnt(mod='vmcnt(0)')
    probability=sigmoid(J,value)
    J.v_cmp_lt_u32('vcc',J.gpr(lane),8)
    J.v_cndmask_b32(probability,0,probability,'vcc')
    total=J.gpr('vf32');total[:]=probability
    for control in controls:
        J.s_nop(1)
        J.v_add_f32_dpp(total,total,total,mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
    sum_scalar=J.gpr('sf32')
    J.s_nop(0)
    J.v_readlane_b32(sum_scalar,total,63)
    J.s_nop(1)
    J.v_rcp_f32(total,sum_scalar)
    J.v_mul_f32(total,J.gpr('sf32',2.5),total)
    J.v_mul_f32(probability,probability,total)
    with J.ExecMask(lane<8,early_skip=False):
        J.global_store_dword((token*9+lane)*4,winner_id,IDS)
        J.global_store_dword((token*9+lane)*4,probability,WEIGHTS)
