# SPDX-License-Identifier: MIT
"""Build canonical BM16 expert tiles directly from top-k register results.

Counts and chunk maps are reset during G2 after their last consumer
(preparation). Routing rows/weights and the valid-row allocator are double
buffered, allowing G2 to pad the next bank while consuming the current bank.
No CPU epoch update, statistics pass, or separate grouping launch is required.
Calls sharing this workspace are serial.
"""
from dataclasses import dataclass,replace
import torch
from marlowe_kernels._runtime import jit
from .block_fused import pointer
from .prepare import topk
from .quant import round_packed,middle
from .native_fp4 import native_projection
from .native_prefetch import prefetch_projection
from .native_prepare import middle_packed
from .native_program import NativeProgram,NativeConfig
from .program import Program
from .experts import emit_moe_stage

def valid_pointer(J,state,current=True):
    which=J.gpr('su32')
    J.s_load_dword(which,state,4 if current else 0)
    J.s_waitcnt(mod='lgkmcnt(0)')
    return pointer(J,state,8+which[0]*4),which

def bin_routes(J,expert,weight,token,B,counts,maps,valid,SORT,RW,EXP,MIND,ERROR):
    """Called with only lanes 0..7 active, before routing values leave registers."""
    lane=J.threadIdx.x[0]%64;chunks=(B+15)//16
    slot=J.gpr('vu32')
    J.global_atomic_add(slot,expert[0]*4,J.gpr('vu32',1),counts,mod='sc0')
    J.s_waitcnt(mod='vmcnt(0)')
    map_offset=J.gpr((expert[0]*chunks+slot[0]//16)*4)
    J.v_cmp_eq_u32('vcc',slot[0]&15,0)
    mask=J.gpr(2,'su32');J.s_and_b64(mask,'vcc','exec')
    number=J.gpr('su32');J.s_bcnt1_i32_b64(number,mask)
    J.Jump('bins_no_new',number[0]==0)
    base=J.gpr('vu32',0)
    with J.ExecMask(lane==0,early_skip=False):
        J.global_atomic_add(base,J.gpr('vu32',0),J.gpr('vu32',number[0]*16),valid,mod='sc0')
    J.s_waitcnt(mod='vmcnt(0)')
    scalar=J.gpr('su32');J.v_readfirstlane_b32(scalar,base)
    prefix=J.gpr('vu32');lower=J.gpr('vu32')
    J.v_lshlrev_b32(lower,J.gpr(lane),1);lower[:]-=1
    J.v_bcnt_u32_b32(prefix,mask[0]&lower[0],0)
    row=J.gpr(scalar[0]+prefix*16)
    with J.ExecMask((slot[0]&15)==0,early_skip=False):
        J.global_store_dword((row[0]//16)*4,expert,EXP,mod='sc1')
    # Publish every locally owned chunk before waiting for another producer.
    # This prevents cycles between two tokens selecting the same expert pair.
    J.s_waitcnt(mod='vmcnt(0)')
    with J.ExecMask((slot[0]&15)==0,early_skip=False):
        J.global_store_dword(map_offset,J.gpr(row[0]+1),maps,mod='sc1')
    J.s_waitcnt(mod='vmcnt(0)')
    J.Label('bins_no_new')
    mapped=J.gpr('vu32',0)
    spins=J.gpr('su32',4096)
    with J.While() as loop:
        with J.ExecMask(mapped[0]==0,early_skip=False):
            J.global_load_dword(mapped,map_offset,maps,mod='sc1')
        J.s_waitcnt(mod='vmcnt(0)')
        J.v_cmp_eq_u32('vcc',mapped,0)
        pending=J.gpr(2,'su32');J.s_and_b64(pending,'vcc','exec')
        J.Jump(loop['end'],pending[0]==0)
        spins[:]-=1
        J.Jump('bins_timeout',spins[0]==0)
    destination=J.gpr(mapped[0]-1+(slot[0]&15))
    packed=J.gpr(token|(lane<<24))
    J.global_store_dword(destination*4,packed,SORT,mod='sc1')
    J.global_store_dword(destination*4,weight,RW,mod='sc1')
    if MIND is not None:J.global_store_dword(destination*4,J.gpr('vu32',token),MIND,mod='sc1')
    J.Jump('bins_done')
    J.Label('bins_timeout')
    with J.ExecMask(lane==0,early_skip=False):
        old=J.gpr('vu32')
        J.global_atomic_or(old,J.gpr('vu32',0),J.gpr('vu32',1),ERROR,mod='sc0')
    J.Label('bins_done')

class TopkBins:
    def __init__(self,J,IDS,W,callback):self.J,self.IDS,self.W,self.callback=J,IDS,W,callback
    def __getattr__(self,name):return getattr(self.J,name)
    def global_store_dword(self,offset,value,base,**kw):
        self.J.global_store_dword(offset,value,base,**kw)
        if base is self.IDS:self.expert=value
        elif base is self.W:self.callback(self.expert,value)

@jit()
def dispatch_prepare(J,L:'void*',C:'void*',X:'void*',IDS:'void*',W:'void*',
                     Q:'void*',S:'void*',QDQ:'void*',O:'void*',SI:'void*',SW:'void*',
                     STATE:'void*',SORT:'void*',RW:'void*',EXP:'void*',MIND:'void*',B,BF16,MAXIMUM,AUX,QUANT,SUPPLIED):
    token,tid=J.blockIdx.x[0],J.threadIdx.x[0]
    valid,which=valid_pointer(J,STATE,False)
    sort=pointer(J,SORT,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    J.Jump('snapshot_done',token!=0)
    with J.ExecMask(tid==0,early_skip=False):
        J.global_store_dword(J.gpr('vu32',4),J.gpr('vu32',which[0]),STATE)
    J.Label('snapshot_done')
    mind=pointer(J,MIND,which[0]*(MAXIMUM*4)) if AUX else None
    counts=pointer(J,STATE,16);maps=pointer(J,STATE,16+256*4)
    error=pointer(J,STATE,(4+256+256*((B+15)//16))*4)
    zero=J.gpr(4,'vu32',0)
    for offset in (0,16):J.global_store_dwordx4((token*3*2048+tid*16)*2+offset,zero,O)
    if QUANT:
        data=J.gpr(8,'vu32')
        for part in (0,4):J.global_load_dwordx4(data[part:part+3],(token*3*2048+tid*16)*2+part*4,X)
        J.s_waitcnt(mod='vmcnt(0)')
        values=[]
        for i in range(8):values.extend([J.gpr(data[i]<<16),J.gpr(data[i]&0xffff0000)])
        codes,exponent,pairs=round_packed(J,values,(1,),False)
        encoded=J.gpr(2,'vu32',0)
        for i,code in enumerate(codes):encoded[i//4]=encoded[i//4]|(code[0]<<(8*(i%4)))
        J.global_store_dwordx2(token*3*1024+tid*8,encoded,Q)
        with J.ExecMask(tid%2==0,early_skip=False):J.global_store_byte(256+token*3*64+tid//2,exponent,S)
        if BF16:
            for i,pair in enumerate(pairs):J.global_store_dword((token*3*2048+tid*16+i*2)*2,pair,QDQ)
    def bins(expert,weight):bin_routes(J,expert,weight,token,B,counts,maps,valid,sort,rw,EXP,mind,error)
    with J.ExecMask(tid<64):
        if SUPPLIED:
            expert,weight=J.gpr('vu32'),J.gpr('vf32')
            with J.ExecMask(tid<8,early_skip=False):
                J.global_load_dword(expert,(token*8+tid)*4,SI)
                J.global_load_dword(weight,(token*8+tid)*4,SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4,expert,IDS)
                J.global_store_dword((token*9+tid)*4,weight,W)
                bins(expert,weight)
        else:topk(TopkBins(J,IDS,W,bins),L,C,IDS,W,token)
        with J.ExecMask(tid==0,early_skip=False):
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vu32',256),IDS)
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vf32',1.),W)

def clear_next(J,state,SORT,RW,B,threads,columns,MAXIMUM):
    # Shared-expert tile zero has one block per output-column tile. Use those
    # blocks to clear the next routing bank while other G2 work is running.
    J.Jump('reset_done',J.blockIdx.y[0]!=0)
    valid,current=valid_pointer(J,state)
    nxt=J.gpr('su32',current[0]^1)
    total=256+256*((B+15)//16)
    zero=J.gpr('vu32',0)
    base=J.gpr('su32',J.blockIdx.x[0]*threads)
    tid=J.gpr(base[0]+J.threadIdx.x[0])[0];stride=columns*threads
    # The pinned JIT does CSE across EXEC masks. Materialize every reused
    # address under full EXEC; counts cover fewer lanes than routing padding.
    indices={offset:J.gpr('vu32',tid+offset) for offset in range(0,max(total,MAXIMUM),stride)}
    addresses={offset:J.gpr('vu32',index[0]*4) for offset,index in indices.items()}
    for offset in range(0,total,stride):
        with J.ExecMask(indices[offset][0]<total,early_skip=False):J.global_store_dword(16+addresses[offset][0],zero,state)
    other_sort=pointer(J,SORT,nxt[0]*(MAXIMUM*4));other_rw=pointer(J,RW,nxt[0]*(MAXIMUM*4))
    invalid=J.gpr('vu32',(9<<24)|B);shared=((B+15)//16)*16
    for offset in range(0,MAXIMUM,stride):
        with J.ExecMask((indices[offset][0]>=shared)&(indices[offset][0]<MAXIMUM),early_skip=False):
            J.global_store_dword(addresses[offset],invalid,other_sort)
            J.global_store_dword(addresses[offset],zero,other_rw)
    J.Jump('reset_done',J.blockIdx.x[0]!=0)
    with J.ExecMask(J.threadIdx.x[0]==0,early_skip=False):
        J.global_store_dword(J.gpr('vu32',8+nxt[0]*4),J.gpr('vu32',((B+15)//16)*16),state)
        J.global_store_dword(J.gpr('vu32',0),J.gpr('vu32',nxt[0]),state)
    J.Label('reset_done')

@jit()
def dispatched_native(J,K,N,BN,FIRST,SK,FUSED,NW,NT,DEPTH,BATCH,MAXIMUM,
                      X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                      IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    valid,which=valid_pointer(J,STATE)
    ids=pointer(J,IDS,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    if DEPTH:prefetch_projection.gen_func(J,K,N,BN,FIRST,SK,FUSED,NW,False,True,NT,DEPTH,X,XS,W,WS,Y,YS,ids,rw,EXP,valid,B)
    else:native_projection.gen_func(J,K,N,BN,FIRST,SK,FUSED,NW,False,True,NT,X,XS,W,WS,Y,YS,ids,rw,EXP,valid,B)
    if not FIRST:clear_next(J,STATE,IDS,RW,BATCH,64*NW,N//BN,MAXIMUM)

@jit()
def dispatched_bf16(J,WD,K,N,FIRST,BN,SK,SCHEDULE,FUSE,FP32,NT,BATCH,MAXIMUM,
                    X:'void*',W:'void*',Y:'void*',IDS:'void*',RW:'float*',EXP:'void*',STATE:'void*',WS:'float*',B:'int'):
    valid,which=valid_pointer(J,STATE)
    ids=pointer(J,IDS,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    emit_moe_stage(J,WD,9,K,N,FIRST,16,BN,X,W,Y,ids,rw,EXP,valid,WS,B,
        False,False,False,NT,True,False,SK,False,schedule=SCHEDULE,fp32_activation=FP32,fuse_middle=FUSE)
    if not FIRST:clear_next(J,STATE,IDS,RW,BATCH,64,N//BN,MAXIMUM)

@dataclass(frozen=True)
class DispatchConfig:
    direct: bool=False
    gate_n: int=64
    gate_waves: int=1
    down_n: int=128
    down_waves: int=2
    split_k: int=2
    non_temporal: bool=True
    depth: int=0
    down_depth: int=0
    bf16: bool=False

class DispatchProgram(NativeProgram):
    def __init__(self,owner,batch,config=DispatchConfig()):
        self.dc=config
        if config.bf16:
            Program.__init__(self,owner,batch);self.c=replace(self.c,direct=False)
        else:
            super().__init__(owner,batch,NativeConfig(**{k:v for k,v in config.__dict__.items() if k in NativeConfig.__dataclass_fields__ and k!='direct'},direct=False))
            self.p['qdq']=torch.empty(1,device=owner.device,dtype=torch.bfloat16)
        b=batch;shared=(b+15)//16
        self.maximum=self.p['sorted_ids'].numel()
        self.p['sorted_ids']=torch.full((self.maximum*2,),(9<<24)|b,device=owner.device,dtype=torch.int32)
        self.p['sorted_weights']=torch.zeros(self.maximum*2,device=owner.device,dtype=torch.float32)
        self.state=torch.zeros(4+256+256*shared+1,device=owner.device,dtype=torch.int32)
        self.state[2:4]=shared*16
        # Shared-expert layout is constant across every invocation.
        ids=[(token|(8<<24)) if token<b else (b|(9<<24)) for token in range(shared*16)]
        for bank in range(2):
            start=bank*self.maximum
            self.p['sorted_ids'][start:start+shared*16]=torch.tensor(ids,device=owner.device,dtype=torch.int32)
            self.p['sorted_weights'][start:start+shared*16]=torch.tensor([1. if t<b else 0. for t in range(shared*16)],device=owner.device)
        self.p['experts'][:shared]=256
        self.info=dict(config=config.__dict__,metadata='top-k register binning, wave-aggregated tile allocation')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.c,self.p;output=p['output'] if out is None else out
        dispatch_prepare([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
            p['packed'].data_ptr(),p['workspace'].data_ptr(),p['qdq'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),0 if supplied_weights is None else supplied_weights.data_ptr(),
            self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),0,b,self.dc.bf16,self.maximum,False,True,supplied_ids is not None)
        if self.dc.bf16:
            self._bf16_stage(p['qdq'],self.partial,True)
            if c.split_k>1 or not c.fuse_middle:
                middle([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),b,c.split_k,self.fp32_middle,self.fp32_middle and c.split_k==1,True)
                mid=self.mid
            else:mid=self.partial
            self._bf16_stage(mid,output,False)
        else:
            self._stage(p['packed'],p['workspace'].data_ptr()+256,self.partial,True)
            if c.split_k>1:middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
            self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
        return output
    def _stage(self,inp,scale,out,first):
        p,c,b=self.p,self.c,self.b
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1
        w,ws=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        dispatched_native([n//bn,self.grid,sk],[64*nw],k,n,bn,first,sk,self.fp32_middle,nw,c.non_temporal,self.dc.depth if first else self.dc.down_depth,b,self.maximum,
            inp.data_ptr(),scale,w.data_ptr(),ws.data_ptr(),out.data_ptr(),self.mid_scale.data_ptr(),p['sorted_ids'].data_ptr(),
            p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.state.data_ptr(),b)
    def _bf16_stage(self,inp,out,first):
        c,p,b=self.c,self.p,self.b
        n,k,bn=(512,6144,c.gate_n) if first else (6144,256,c.down_n)
        sk=c.split_k if first else 1;schedule=c.gate_schedule if first else c.down_schedule
        w,ws=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        dispatched_bf16([n//bn,self.grid,sk],[256 if first else 64],w.dtype,k,n,first,bn,sk,schedule,
            first and c.fuse_middle and sk==1,self.fp32_middle and first,c.non_temporal,b,self.maximum,
            inp.data_ptr(),w.data_ptr(),out.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),
            self.state.data_ptr(),ws.data_ptr(),b)
