# SPDX-License-Identifier: MIT
"""Paired-K weight-scale pipeline on canonical fused-dispatch expert tiles."""
from dataclasses import dataclass
from marlowe_kernels._runtime import jit
from .block_fused import pointer
from .fused_dispatch import valid_pointer,clear_next
from .front_program import FrontProgram,FrontConfig
from .native_pairprefetch import paired_projection

@dataclass(frozen=True)
class GroupedPairConfig(FrontConfig):
    direct: bool=False
    dispatch: bool=True
    pair_depth: int=3
    pair_g2: bool=False
    stream_weights: bool=False

@jit()
def grouped_paired(J,K,N,BN,FIRST,SK,FP32,NW,NT,DEPTH,COMBINE,STREAM,BATCH,MAXIMUM,
                   X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                   IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    valid,bank=valid_pointer(J,STATE)
    ids=pointer(J,IDS,bank[0]*(MAXIMUM*4));rw=pointer(J,RW,bank[0]*(MAXIMUM*4))
    emit=paired_projection
    if STREAM:
        from .native_pairprefetch_stream import streamed_projection
        emit=streamed_projection
    emit.gen_func(J,K,N,BN,FIRST,SK,FP32,NW,False,True,NT,DEPTH,COMBINE,
        pointer(J,X),pointer(J,XS),pointer(J,W),pointer(J,WS),pointer(J,Y),pointer(J,YS),
        ids,rw,pointer(J,EXP),valid,B)
    if not FIRST:clear_next(J,STATE,IDS,RW,BATCH,64*NW,N//BN,MAXIMUM)

class GroupedPairProgram(FrontProgram):
    def __init__(self,owner,batch,config=GroupedPairConfig()):
        assert config.dispatch and not config.direct
        self.gpc=config
        super().__init__(owner,batch,FrontConfig(**{k:v for k,v in config.__dict__.items() if k not in ('pair_depth','pair_g2','stream_weights')}))
        self.info.update(config=config.__dict__,algorithm='fused dispatch / paired K128 scale loads / sparse coalesced output')
    def _stage(self,inp,scale,out,first):
        if (first and self.gpc.pair_depth==0) or (not first and not self.gpc.pair_g2):
            return super()._stage(inp,scale,out,first)
        c,p,b=self.c,self.p,self.b
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1
        assert (k//sk)%256==0
        w,s=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        grouped_paired([n//bn,self.grid,sk],[64*nw],k,n,bn,first,sk,self.fp32_middle,nw,c.non_temporal,
            self.gpc.pair_depth if first else 1,self.cc.combine,self.gpc.stream_weights,b,self.maximum,
            inp.data_ptr(),scale,w.data_ptr(),s.data_ptr(),out.data_ptr(),self.mid_scale.data_ptr(),
            p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.state.data_ptr(),b)
