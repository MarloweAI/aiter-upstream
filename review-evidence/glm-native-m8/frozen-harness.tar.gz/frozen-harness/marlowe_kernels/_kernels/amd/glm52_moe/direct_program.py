# SPDX-License-Identifier: MIT
"""Direct routed tiles with AITER's native-FP4 expert kernels, no grouping.

One routed pair per tile; the always-present shared expert may use fixed dense
tiles. Neither expert histograms nor a route-dependent policy pass is needed.
The AITER G1 grid is explicitly sized to this work list: its normal distinct-
expert upper bound would underlaunch direct work at large batches.
"""
import importlib
import torch
from .direct_prepare import direct_front


class DirectProgram:
    def __init__(self,owner,batch,*,share=True,bm16=False,kernel_batch=None,native_g1=False):
        import aiter
        from marlowe_kernels.moe import _require
        self.owner,self.b,self.share=owner,batch,share
        self.native_g1=native_g1
        self.fm=fm=importlib.import_module('aiter.fused_moe')
        self.w1,self.w2=owner.w13,owner.w2
        self.w1.is_shuffled=self.w2.is_shuffled=True
        selection_batch=kernel_batch if kernel_batch is not None else max(batch,4) if bm16 else batch
        self.metadata=fm.get_2stage_cfgs(
            fm.get_padded_M(selection_batch),6144,256,257,9,
            torch.bfloat16,torch.float4_e2m1fn_x2,torch.float4_e2m1fn_x2,
            aiter.QuantType.per_1x32,True,aiter.ActivationType.Silu,False,0,0,True,
            opus_weights_shuffled=True,input_dtype=torch.bfloat16)
        m=self.metadata;self.bm=BM=int(m.block_m)
        n1=m.stage1.keywords.get('kernelName1',m.stage1.keywords.get('kernelName',''))
        n2=m.stage2.keywords.get('kernelName2',m.stage2.keywords.get('kernelName',''))
        _require(not m.run_1stage and m.fuse_quant=='fp4' and 'atomic' in n2,
                 'Unqualified direct expert selection')
        self.prequant=bool(m.prequant)
        self.g2_cfg=fm.parse_flydsl_v2_gemm2_kernel(n2)
        _require((BM==32 and self.prequant and m.skip_inter_quant and n1.startswith('flydsl_moe1_afp4_wfp4_'))
                 or (BM==16 and not self.prequant and '_f16in' in n1), 'Unsupported direct input ABI')
        self.tiles=batch*8+(batch+BM-1)//BM if share else batch*9
        rows=self.tiles*BM;device=owner.device
        def empty(shape,dtype):return torch.empty(shape,device=device,dtype=dtype)
        # All token/slot locations are fixed by batch/top-k, not expert choices.
        static_ids=[(9<<24)|batch]*rows
        static_weights=[0.]*rows
        for token in range(batch):
            for slot in range(8):
                static_ids[(token*(8 if share else 9)+slot)*BM]=token|(slot<<24)
            shared_row=batch*8*BM+token if share else (token*9+8)*BM
            static_ids[shared_row]=token|(8<<24);static_weights[shared_row]=1.
        ids=torch.tensor(static_ids,device=device,dtype=torch.int32)
        sw=torch.tensor(static_weights,device=device,dtype=torch.float32)
        self.p=dict(ids=empty((batch,9),torch.int32),weights=empty((batch,9),torch.float32),
            sorted_ids=ids,sorted_weights=sw,experts=torch.full((self.tiles,),256,device=device,dtype=torch.int32),
            valid=torch.tensor([rows,batch],device=device,dtype=torch.int32),mind=ids&0xffffff,
            packed=empty((batch,3072),torch.uint8),
            sorted_scale=torch.zeros(((rows+31)//32*32,192),device=device,dtype=torch.uint8),
            output=empty((batch,6144),torch.bfloat16))
        self.scale1=owner.weights.w13_scale.view(torch.float8_e8m0fnu)
        self.scale2=owner.weights.w2_scale.view(torch.float8_e8m0fnu)
        self.g1_launch=None
        if BM==16 and not native_g1:
            from aiter.ops.flydsl.mxfp4_gemm1_kernels import _get_compiled_mxfp4_gemm1_port
            from aiter.ops.flydsl.kernels.mxfp4_gemm_common import kas_per_chunk_dw_for
            k=fm._parse_mxfp4_g1_kname(n1)
            native_scale=fm.native_scale_layout_for(BM,'fp4')
            self.g1_launch=_get_compiled_mxfp4_gemm1_port(
                BM,k['use_nt'],True,k.get('prefetch_hidden',False),6144,256,257,k['BN'],k['BK'],
                interleave=False,xcd_swizzle=k.get('xcd_swizzle',0),native_scale_layout=native_scale,
                num_waves=k.get('num_waves',4),k_wave=k.get('k_wave',1))
            self.g1_grid=self.tiles*(512//k['BN'])
            self.mid=empty((rows,128),torch.uint8)
            scale_bytes=max(rows*64,self.tiles*kas_per_chunk_dw_for(256)*4)
            self.mid_scale=empty((((scale_bytes+7)//8+31)//32*32,8),torch.uint8)
        if native_g1:
            from dataclasses import replace
            from .native_program import NativeProgram,NATIVE_CONFIGS
            self.port_gate=NativeProgram(owner,batch,replace(NATIVE_CONFIGS[batch],direct=True))
            self.port_gate.p['ids']=self.p['ids'];self.port_gate.p['weights']=self.p['weights']
            assert self.port_gate.c.split_k>1
            self.mid=empty((rows,128),torch.uint8)
            self.mid_scale=torch.zeros((self.tiles*32,8),device=device,dtype=torch.uint8)
            self.prequant=True
        self.selection=dict(stage1=n1,stage2=n2,block_m=BM,tiles=self.tiles,
            direct=True,static_shared_tiles=share,input_quantization='fused-preparation' if self.prequant else 'inline-G1',
            policy=f'AITER tuning row for B{selection_batch}' if selection_batch!=batch else 'native AITER selection',
            native_g1=native_g1)
        if native_g1:
            self.selection['stage1']=f'Port-EW native FP4 direct G1, split-K={self.port_gate.c.split_k}'
            self.selection['intermediate']='FP32 activation, fused AITER scale rounding, direct packed tile layout'

    def stage1(self,x):
        p=self.p
        if self.native_g1:
            from .direct_middle import middle_direct
            gate=self.port_gate
            gate._stage(p['packed'],p['sorted_scale'].data_ptr(),gate.partial,True)
            middle_direct([self.b*9,2],[64],gate.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),
                          self.b,gate.c.split_k,self.bm,self.share)
            return self.mid,self.mid_scale
        if self.g1_launch is not None:
            from aiter.ops.flydsl.moe_kernels import _run_compiled
            _run_compiled(self.g1_launch,(
                p['packed'].data_ptr(),p['sorted_scale'].data_ptr(),self.w1.data_ptr(),self.scale1.data_ptr(),
                p['experts'].data_ptr(),p['valid'].data_ptr(),p['mind'].data_ptr(),self.b,self.g1_grid,
                self.mid.data_ptr(),self.mid_scale.data_ptr(),x.data_ptr(),0,torch.cuda.current_stream()))
            return self.mid,self.mid_scale
        return self.metadata.stage1(p['packed'].view(torch.float4_e2m1fn_x2),self.w1,self.w2,
            p['sorted_ids'],p['experts'],p['valid'],None,9,block_m=self.bm,
            a1_scale=p['sorted_scale'].view(torch.float8_e8m0fnu),w1_scale=self.scale1,
            sorted_weights=None,v2_output_layout=True)

    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        p=self.p;output=p['output'] if out is None else out
        supplied=supplied_ids is not None
        direct_front([self.b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),
            p['ids'].data_ptr(),p['weights'].data_ptr(),p['experts'].data_ptr(),p['sorted_weights'].data_ptr(),
            p['packed'].data_ptr(),p['sorted_scale'].data_ptr(),output.data_ptr(),
            supplied_ids.data_ptr() if supplied else 0,supplied_weights.data_ptr() if supplied else 0,
            self.b,self.bm,self.share,self.prequant,supplied,self.native_g1)
        if self.fm.kernel_bench_callable is not None:self.fm.kernel_bench_callable.append(('stage1',self.stage1))
        mid,scale=self.stage1(x)
        if self.fm.kernel_bench_callable is not None:self.fm.kernel_bench_callable.append(('stage2',self.stage2))
        return self.stage2(mid,scale,output)

    def stage2(self,mid,scale,output):
        p=self.p;c=self.g2_cfg
        if c is not None:
            from aiter.ops.flydsl.kernels.mxmoe_dispatcher import mxfp4_moe_gemm2
            return mxfp4_moe_gemm2(
                inter_sorted_quant=mid.view(torch.uint8),inter_sorted_shuffled_scale=scale.view(torch.uint8),
                w2_u8=self.w2.view(torch.uint8),w2_scale_u8=self.scale2.view(torch.uint8),
                sorted_expert_ids=p['experts'],cumsum_tensor=p['valid'],sorted_token_ids=p['sorted_ids'],
                sorted_weights=p['sorted_weights'],out=output,M_logical=self.b,
                max_sorted=p['sorted_ids'].numel(),n_sorted_padded=p['sorted_ids'].numel(),
                NE=257,D_HIDDEN=6144,D_INTER=256,topk=9,BM=c['tile_m'],BN=c['tile_n'],BK=c['tile_k'],
                use_nt=c['use_nt'],a_dtype=c['a_dtype'],b_dtype=c['b_dtype'],epilog=c['epilog'],
                SBM=c['sort_block_m'] or self.bm,persist=c['persist'])
        return self.metadata.stage2(mid,self.w1,self.w2,p['sorted_ids'],p['experts'],p['valid'],output,9,
            w2_scale=self.scale2,a2_scale=scale,block_m=self.bm,sorted_weights=p['sorted_weights'])
