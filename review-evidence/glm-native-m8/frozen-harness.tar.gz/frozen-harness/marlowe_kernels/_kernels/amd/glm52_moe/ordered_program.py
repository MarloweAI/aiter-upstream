# SPDX-License-Identifier: MIT
"""Ordered FP32 reduction of unchanged rounded BF16 expert contributions."""
from dataclasses import dataclass
from .prefetch_program import PrefetchConfig
from .native_program import NativeProgram,NativeConfig
from .native_prefetch import prefetch_projection
from .fused_dispatch import DispatchProgram,DispatchConfig,valid_pointer,clear_next
from .block_fused import pointer
from .native_ordered import ordered_projection
from marlowe_kernels._runtime import jit

@jit()
def ordered_combine(J,X:'void*',Y:'void*'):
    # One thread per output BF16 pair, all nine rounded contributions loaded
    # before adding in a fixed route-slot order using FP32 accumulators.
    token=J.blockIdx.y[0]
    stride=J.gpr('su32',3072)
    output_base=J.gpr('su32',token*stride[0])
    pair=J.gpr(J.blockIdx.x[0]*256+J.threadIdx.x[0])
    words=J.gpr(9,'vu32')
    for slot in range(9):
        route_base=J.gpr('su32',(token*9+slot)*stride[0])
        J.global_load_dword(words[slot],(route_base[0]+pair[0])*4,X)
    J.s_waitcnt(mod='vmcnt(0)')
    sums=J.gpr(2,'vf32',0.)
    for slot in range(9):
        lo=J.gpr(words[slot]<<16);hi=J.gpr(words[slot]&0xffff0000)
        J.v_add_f32(sums[0],sums[0],lo);J.v_add_f32(sums[1],sums[1],hi)
    packed=J.gpr('vbf16x2');J.v_cvt_pk_bf16_f32(packed,sums[0],sums[1])
    J.global_store_dword((output_base[0]+pair[0])*4,packed,Y)

@dataclass(frozen=True)
class OrderedConfig(PrefetchConfig):
    dispatch: bool=False
    combine: str="ordered"

@jit()
def ordered_down(J,BN,NW,DIRECT,NT,DEPTH,COMBINE,DISPATCH,BATCH,MAXIMUM,
                   X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                   IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    if DISPATCH:
        valid,bank=valid_pointer(J,STATE)
        ids=pointer(J,IDS,bank[0]*(MAXIMUM*4));rw=pointer(J,RW,bank[0]*(MAXIMUM*4))
    else:valid,ids,rw=STATE,IDS,RW
    ordered_projection.gen_func(J,256,6144,BN,False,1,False,NW,DIRECT,True,NT,DEPTH,COMBINE,
                                 X,XS,W,WS,Y,YS,ids,rw,EXP,valid,B)
    if DISPATCH:clear_next(J,STATE,IDS,RW,BATCH,64*NW,6144//BN,MAXIMUM)

class OrderedProgram(DispatchProgram):
    def __init__(self,owner,batch,config=OrderedConfig()):
        assert config.combine=="ordered"
        self.cc=config
        d={k:v for k,v in config.__dict__.items() if k not in ('dispatch','combine')}
        if config.dispatch:DispatchProgram.__init__(self,owner,batch,DispatchConfig(**d))
        else:NativeProgram.__init__(self,owner,batch,NativeConfig(**{k:v for k,v in d.items() if k not in ('depth','down_depth')}))
        if config.combine=='ordered':
            import torch
            self.route_output=torch.empty((batch,9,6144),device=owner.device,dtype=torch.bfloat16)
        self.info=dict(config=config.__dict__,epilogue='BF16 route stores -> ordered FP32 sum -> BF16 output',
                       intermediate_rounding='unchanged',expert_operand_rounding='BF16',accumulator='FP32')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        output=self.p['output'] if out is None else out
        ordered=self.cc.combine=='ordered';target=self.route_output if ordered else output
        run=DispatchProgram.run if self.cc.dispatch else NativeProgram.run
        run(self,x,logits,bias,out=target,supplied_ids=supplied_ids,supplied_weights=supplied_weights)
        if ordered:ordered_combine([12,self.b],[256],target.data_ptr(),output.data_ptr())
        return output
    def _stage(self,inp,scale,out,first):
        if first:
            if self.cc.dispatch:return DispatchProgram._stage(self,inp,scale,out,first)
            if not self.cc.depth:return NativeProgram._stage(self,inp,scale,out,first)
            c,p,b=self.c,self.p,self.b
            ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                             (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
            return prefetch_projection([512//c.gate_n,self.grid,c.split_k],[64*c.gate_waves],
                6144,512,c.gate_n,True,c.split_k,self.fp32_middle,c.gate_waves,c.direct,True,c.non_temporal,self.cc.depth,
                inp.data_ptr(),scale,self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),out.data_ptr(),
                self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b)
        c,p,b=self.c,self.p,self.b
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                         (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        if self.cc.dispatch:valid=self.state
        ordered_down([6144//c.down_n,self.grid],[64*c.down_waves],c.down_n,c.down_waves,c.direct,
            c.non_temporal,self.cc.down_depth or 2,self.cc.combine,self.cc.dispatch,b,self.maximum if self.cc.dispatch else 0,
            inp.data_ptr(),scale,self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),out.data_ptr(),
            self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b)
