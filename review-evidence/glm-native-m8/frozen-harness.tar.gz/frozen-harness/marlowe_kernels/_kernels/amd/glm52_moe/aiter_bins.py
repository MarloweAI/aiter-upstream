# SPDX-License-Identifier: MIT
"""Fused top-k tile construction feeding the unchanged AITER expert stages.

A small reset launch is explicit and timed: vendor G2 has no reset epilogue.
"""
from dataclasses import dataclass
import torch
from marlowe_kernels._runtime import jit
from .hybrid_program import HybridProgram
from .fused_dispatch import dispatch_prepare

@jit()
def reset_bins(J,STATE:'void*',IDS:'void*',RW:'void*',MIND:'void*',B,MAXIMUM):
    base=J.gpr('su32',J.blockIdx.x[0]*256)
    row=J.gpr(base[0]+J.threadIdx.x[0]);address=J.gpr(row[0]*4)
    total=256+256*((B+15)//16);shared=((B+15)//16)*16
    # Constants reused by the header must also be defined before masking:
    # for B16, for example, padding's token sentinel equals header row count.
    constants={v:J.gpr('vu32',v) for v in (0,4,8,12,B,shared,(9<<24)|B)}
    zero=constants[0]
    with J.ExecMask(row[0]<total,early_skip=False):J.global_store_dword(address[0]+16,zero,STATE)
    with J.ExecMask((row[0]>=shared)&(row[0]<MAXIMUM),early_skip=False):
        J.global_store_dword(address,constants[(9<<24)|B],IDS)
        J.global_store_dword(address,zero,RW)
        J.global_store_dword(address,constants[B],MIND)
    with J.ExecMask(row[0]==0,early_skip=False):
        J.global_store_dword(constants[0],zero,STATE)
        J.global_store_dword(constants[4],zero,STATE)
        J.global_store_dword(constants[8],constants[shared],STATE)
        J.global_store_dword(constants[12],constants[B],STATE)

@dataclass(frozen=True)
class AiterBinsConfig:
    direct: bool=False

class AiterBinsProgram(HybridProgram):
    def __init__(self,owner,batch,config=AiterBinsConfig()):
        super().__init__(owner,batch)
        assert self.bm==16 and not self.prequant,'First implementation requires native inline-quantized BM16 kernels'
        self.fp32_middle=True
        self.state=torch.zeros(4+256+256*((batch+15)//16)+1,device=owner.device,dtype=torch.int32)
        self.p['valid']=self.state[2:4];self.maximum=self.p['sorted_ids'].numel()
        self.p['qdq']=torch.empty(1,device=owner.device,dtype=torch.bfloat16)
        shared=(batch+15)//16
        ids=[t|(8<<24) if t<batch else batch|(9<<24) for t in range(shared*16)]
        self.p['sorted_ids'][:shared*16]=torch.tensor(ids,device=owner.device,dtype=torch.int32)
        self.p['sorted_weights'][:shared*16]=torch.tensor([1. if t<batch else 0. for t in range(shared*16)],device=owner.device)
        self.p['mind'][:shared*16]=torch.arange(shared*16,device=owner.device,dtype=torch.int32)
        self.p['experts'][:shared]=256
        self.info=dict(config=config.__dict__,selection=self.selection,arithmetic='AITER',reset='explicit timed kernel')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        import aiter
        p,b=self.p,self.b;output=p['output'] if out is None else out
        total=max(self.maximum,256+256*((b+15)//16))
        reset_bins([(total+255)//256],[256],self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['mind'].data_ptr(),b,self.maximum)
        dispatch_prepare([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
            p['packed'].data_ptr(),p['workspace'].data_ptr(),p['qdq'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),0 if supplied_weights is None else supplied_weights.data_ptr(),
            self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),p['mind'].data_ptr(),
            b,False,self.maximum,True,False,supplied_ids is not None)
        return self.fm.fused_moe_2stages(x,self.w1,self.w2,9,p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid'],output,True,self.bm,
            activation=aiter.ActivationType.Silu,quant_type=aiter.QuantType.per_1x32,
            q_dtype_a=torch.float4_e2m1fn_x2,q_dtype_w=torch.float4_e2m1fn_x2,
            w1_scale=self.owner.weights.w13_scale,w2_scale=self.owner.weights.w2_scale,a1_scale=None,
            topk_ids=p['ids'],topk_weights=p['weights'],m_indices=p['mind'] if self.metadata.output_aux else None,
            _metadata_transform=lambda _:self.metadata,routing_num_experts=257)
