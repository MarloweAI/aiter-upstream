# SPDX-License-Identifier: MIT
"""Select only the requested deterministic top-k slot for a direct producer."""
from .prepare import sigmoid,key,select_max


def select_slot(J, L, C, token, slot, preload=True, fp32=False):
    lane = J.threadIdx.x[0] % 64
    selected=J.gpr('su32',256)
    J.Jump('slot_topk_done',slot[0]==8)
    keys = []
    if preload:
        raw_logits=J.gpr(4,'vu32');raw_bias=J.gpr(4,'vu32')
        for j in range(4):
            expert=J.gpr(lane+j*64)
            if fp32:
                J.global_load_dword(raw_logits[j],(token*256+expert[0])*4,L)
                J.global_load_dword(raw_bias[j],expert[0]*4,C)
            else:
                J.global_load_ushort(raw_logits[j],(token*256+expert[0])*2,L)
                J.global_load_ushort(raw_bias[j],expert[0]*2,C)
        J.s_waitcnt(mod='vmcnt(0)')
    for j in range(4):
        expert = J.gpr(lane + j*64)
        logit, bias = J.gpr('vu32'), J.gpr('vu32')
        if preload:
            logit[:]=raw_logits[j];bias[:]=raw_bias[j]
        else:
            if fp32:
                J.global_load_dword(logit,(token*256+expert[0])*4,L)
                J.global_load_dword(bias,expert[0]*4,C)
            else:
                J.global_load_ushort(logit,(token*256+expert[0])*2,L)
                J.global_load_ushort(bias,expert[0]*2,C)
            J.s_waitcnt(mod='vmcnt(0)')
        if not fp32:
            logit[:] = logit[0] << 16; bias[:] = bias[0] << 16
        score = sigmoid(J, logit)
        J.v_add_f32(score, score, bias)
        keys.append(key(J, score, expert))
    # The native per-lane sorting network and six DPP reductions. Only lane
    # 63 is defined after the row broadcasts; broadcast its winning key.
    for i in range(4):
        for j in range(i+1,4):
            left = J.gpr(2,'vu32')
            for part in range(2):left[part]=keys[i][part]
            J.v_cmp_gt_u64('vcc',keys[j],left)
            for part in range(2):
                J.v_cndmask_b32(keys[i][part],left[part],keys[j][part],'vcc')
                J.v_cndmask_b32(keys[j][part],keys[j][part],left[part],'vcc')
    controls=('quad_perm:[1,0,3,2]','quad_perm:[2,3,0,1]',
              'row_half_mirror','row_mirror','row_bcast:15','row_bcast:31')
    for k in range(8):
        winner = J.gpr(2, 'vu32')
        for i in range(2):winner[i]=keys[0][i]
        for control in controls:
            # CDNA4 ISA Table 11: a DPP source needs two wait states
            # after a VALU write; the pinned JIT does not insert these.
            J.s_nop(1)
            other=J.gpr(2,'vu32')
            for part in range(2):
                J.v_mov_b32_dpp(other[part],winner[part],mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
            select_max(J,winner,other)
        broadcast=J.gpr(2,'su32')
        J.s_nop(0)
        for part in range(2):J.v_readlane_b32(broadcast[part],winner[part],63)
        J.s_nop(1)  # VALU-produced SGPR -> VALU constant source
        selected[:]=(broadcast[0]^0xffffffff)&511
        J.Jump('slot_topk_done',slot[0]==k)
        J.v_cmp_eq_u64('vcc',keys[0],broadcast)
        for j in range(3):
            for part in range(2):J.v_cndmask_b32(keys[j][part],keys[j][part],keys[j+1][part],'vcc')
        for part in range(2):J.v_cndmask_b32(keys[3][part],keys[3][part],0,'vcc')
    J.Label('slot_topk_done')
    return selected
