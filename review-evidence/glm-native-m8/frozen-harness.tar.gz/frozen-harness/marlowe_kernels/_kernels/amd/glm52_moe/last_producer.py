# SPDX-License-Identifier: MIT
"""Last split producer packs its intermediate, keeping an independent G2 grid.

Experimental B8 path: fused dispatch, split G1, device-coherent partial
publication and one returned atomic per feature tile, then coalesced G2.
No consumer polling or cross-workgroup barrier is used.
"""
from dataclasses import dataclass
import torch
from marlowe_kernels._runtime import jit
from .block_fused import pointer
from .coalesced_program import CoalescedProgram,CoalescedConfig
from .fused_dispatch import dispatch_prepare,valid_pointer
from .native_prefetch import prefetch_projection
from .last_split import finish_feature

@dataclass(frozen=True)
class LastProducerConfig(CoalescedConfig):
    counter_stride: int=1

class PublishPartials:
    def __init__(self,J,partial):self.J,self.partial=J,partial
    def __getattr__(self,name):return getattr(self.J,name)
    def global_store_dwordx4(self,offset,value,base,**kw):
        if base is self.partial:kw['mod']='sc1'
        return self.J.global_store_dwordx4(offset,value,base,**kw)

@jit()
def producer_prepare(J,B,MAXIMUM,COUNT,
                     L:'void*',C:'void*',X:'void*',IDS:'void*',RW:'void*',Q:'void*',S:'void*',O:'void*',
                     SI:'void*',SW:'void*',STATE:'void*',SORT:'void*',SRW:'void*',EXP:'void*',COUNTERS:'void*',SUPPLIED):
    dispatch_prepare.gen_func(J,L,C,X,IDS,RW,Q,S,Q,O,SI,SW,STATE,SORT,SRW,EXP,0,
                              B,False,MAXIMUM,False,True,SUPPLIED)
    base=J.gpr('su32');J.s_mul_i32(base,J.blockIdx.x,384)
    index=J.gpr(base[0]+J.threadIdx.x[0])
    with J.ExecMask(index[0]<COUNT,early_skip=False):
        J.global_store_dword(index[0]*4,J.gpr('vu32',0),COUNTERS)

@jit()
def last_producer_g1(J,B,BN,NW,SK,FP32,NT,DEPTH,MAXIMUM,STRIDE,
                     X:'void*',XS:'void*',W:'void*',WS:'void*',PART:'void*',MID:'void*',MS:'void*',
                     IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',COUNTERS:'void*'):
    assert SK>1
    valid,bank=valid_pointer(J,STATE)
    ids=pointer(J,IDS,bank[0]*(MAXIMUM*4));rw=pointer(J,RW,bank[0]*(MAXIMUM*4))
    partial=pointer(J,PART)
    proxy=PublishPartials(J,partial)
    prefetch_projection.gen_func(proxy,6144,512,BN,True,SK,FP32,NW,False,True,NT,DEPTH,
        pointer(J,X),pointer(J,XS),pointer(J,W),pointer(J,WS),partial,pointer(J,MS),
        pointer(J,ids),pointer(J,rw),pointer(J,EXP),pointer(J,valid),J.gpr('su32',B))
    # Every producer finishes its device-coherent payload stores before it
    # increments the completion counter. The last producer reads with SC1.
    J.s_waitcnt(mod='vmcnt(0)')
    if NW>1:J.s_barrier()
    old=J.gpr('vu32',0)
    offset=J.gpr('vu32',(J.blockIdx.y[0]*(512//BN)+J.blockIdx.x[0])*STRIDE*4)
    with J.ExecMask(J.threadIdx.x[0]==0,early_skip=False):
        J.global_atomic_add(old,offset,J.gpr('vu32',1),COUNTERS,mod='sc0')
    J.s_waitcnt(mod='vmcnt(0)')
    if NW==1:
        complete=J.gpr('su32');J.v_readfirstlane_b32(complete,old)
    else:
        status=J.alloc_lds(4,align=4)
        with J.ExecMask(J.threadIdx.x[0]==0,early_skip=False):J.ds_write_b32(status,old)
        J.s_waitcnt(mod='lgkmcnt(0)');J.s_barrier()
        value=J.gpr('vu32');J.ds_read_b32(value,status);J.s_waitcnt(mod='lgkmcnt(0)')
        complete=J.gpr('su32');J.v_readfirstlane_b32(complete,value)
    J.Jump('producer_done',complete[0]!=SK-1)
    finish_feature.gen_func(J,pointer(J,PART),pointer(J,MID),pointer(J,MS),pointer(J,ids),B,SK,BN,NW,False,FP32)
    J.Label('producer_done')

class LastProducerProgram(CoalescedProgram):
    def __init__(self,owner,batch,config=LastProducerConfig()):
        assert config.dispatch and not config.direct and config.split_k>1
        assert config.gate_n//config.gate_waves>=64
        self.lpc=config
        super().__init__(owner,batch,CoalescedConfig(**{k:v for k,v in config.__dict__.items() if k!='counter_stride'}))
        self.completion=torch.zeros(self.grid*(512//config.gate_n)*config.counter_stride,device=owner.device,dtype=torch.int32)
        assert self.completion.numel()<=batch*384
        self.info.update(algorithm='fused dispatch + last-producer split reduction + coalesced G2')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.cc,self.p;output=p['output'] if out is None else out
        producer_prepare([b],[384],b,self.maximum,self.completion.numel(),logits.data_ptr(),bias.data_ptr(),x.data_ptr(),
            p['ids'].data_ptr(),p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),0 if supplied_weights is None else supplied_weights.data_ptr(),
            self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.completion.data_ptr(),supplied_ids is not None)
        last_producer_g1([512//c.gate_n,self.grid,c.split_k],[64*c.gate_waves],b,c.gate_n,c.gate_waves,c.split_k,self.fp32_middle,c.non_temporal,c.depth or 2,self.maximum,self.lpc.counter_stride,
            p['packed'].data_ptr(),p['workspace'].data_ptr()+256,self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),
            self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.state.data_ptr(),self.completion.data_ptr())
        self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
        return output
