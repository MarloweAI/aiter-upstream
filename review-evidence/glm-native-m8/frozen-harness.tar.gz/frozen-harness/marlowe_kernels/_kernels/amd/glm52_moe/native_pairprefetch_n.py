# SPDX-License-Identifier: MIT
# Weight/MFMA layout follows the earlier Port-EW native_projection experiment
# and upstream PyHIP 270225149dec3436923959554f50f363bf7057cf (MIT).
"""Share aligned packed scales across K128 pairs and adjacent N16 blocks."""
from marlowe_kernels._runtime import jit
from .native_prepare import pack_fp4
from .quant import bf16, silu


@jit()
def paired_n_projection(J, K,N,BN,FIRST,SK,FP32_OUT,NW,DIRECT,PIPE,NT,PAIR_DEPTH,COMBINE,
                      X:'void*', XS:'void*', W:'void*', WS:'void*', Y:'void*', YS:'void*',
                      IDS:'void*', RW:'void*', EXP:'void*', VALID:'void*', B:'int'):
    assert K%128==0 and N%BN==0 and BN in (64,128,256) and BN%NW==0
    assert not FIRST or (BN//NW)%64==0
    assert SK==1 or FIRST
    assert K%SK==0 and (K//SK)%128==0
    lane=J.gpr(J.threadIdx.x[0]%64)
    row=J.gpr(lane[0]%16)
    part=J.gpr(lane[0]//16)
    packed_stride=J.gpr('su32',K//2)
    scale_stride=J.gpr('su32',K//32)
    output_stride=J.gpr('su32',N)
    expert=J.gpr('su32')
    routing=J.gpr('vf32')
    if DIRECT == "merge8":
        from .merged_routes8 import resolve_merged_routes8
        expert,token,slot,routing=resolve_merged_routes8(J,IDS,RW,B,NW,FIRST)
    elif DIRECT:
        J.s_load_dword(expert,EXP,J.blockIdx.y[0]*4)
        token_scalar=J.gpr(J.blockIdx.y[0]//9)
        token=J.gpr('vu32',token_scalar[0])
        slot_scalar=J.gpr(J.blockIdx.y[0]-token_scalar[0]*9)
        slot=J.gpr('vu32',slot_scalar[0])
        with J.ExecMask(row[0] != 0, early_skip=False):
            token[:]=B[0]
        if not FIRST:
            J.global_load_dword(routing,J.gpr('vu32',J.blockIdx.y[0]*4),RW)
        J.s_waitcnt(mod='lgkmcnt(0) vmcnt(0)')
    else:
        valid=J.gpr('su32')
        J.s_load_dword(expert,EXP,J.blockIdx.y[0]*4)
        J.s_load_dword(valid,VALID,0)
        J.s_waitcnt(mod='lgkmcnt(0)')
        J.Jump('native_active',J.blockIdx.y[0]*16<valid)
        J.s_endpgm();J.Label('native_active')
        IDS[:]+=J.blockIdx.y[0]*64
        RW[:]+=J.blockIdx.y[0]*64
        sorted_id=J.gpr('vu32')
        J.global_load_dword(sorted_id,row*4,IDS)
        if not FIRST:
            J.global_load_dword(routing,row*4,RW)
        J.s_waitcnt(mod='vmcnt(0)')
        token=J.gpr(sorted_id[0]&0xffffff)
        slot=J.gpr(sorted_id[0]>>24)
    route=J.gpr(token*9+slot)
    wave=J.gpr(J.threadIdx.x[0]//64)
    wave_n=wave[0]*(BN//NW//2 if FIRST else BN//NW)
    xrow=token if FIRST else route
    extent=J.s_mul_u32_u64(expert,N*K//2)
    W[:]+=extent
    stride_scale=(K//32+7)//8*8
    WS[:]+=expert*(N*stride_scale)
    blocks=BN//NW//16
    accum=J.gpr(blocks,4,'vf32',0.)
    # Pair adjacent K128 iterations. Their shuffled scale bytes share a
    # aligned four-byte word at offsets 0/2 or 1/3. Load that aligned word once per pair, while
    # preserving the exact low-byte scale operands used by the old emitter.
    assert (K//SK)%256==0
    pairs=(K//SK)//256
    share=blocks%2==0 and (not FIRST or blocks%4==0)
    scale_blocks=blocks//2 if share else blocks
    requests=4+2*blocks+scale_blocks
    depth=max(d for d in range(1,min(PAIR_DEPTH,pairs)+1) if pairs%d==0 and (d-1)*requests<=63)
    avec=J.gpr(depth,2,4,'vu32');bvec=J.gpr(depth,2,blocks,4,'vu32')
    ascale=J.gpr(depth,2,'vu32');packed_scale=J.gpr(depth,scale_blocks,'vu32')
    qa_base=J.gpr(xrow*packed_stride[0]+part*16)
    sa_base=J.gpr(xrow*scale_stride[0]+part)
    qb_base=[];sb_base=[];scale_shift=[]
    for n in range(blocks):
        if FIRST:
            n_offset=(n%(blocks//2))*16+(N//2 if n>=blocks//2 else 0)
            col=J.gpr('vu32',J.blockIdx.x[0]*(BN//2)+wave_n+n_offset)
        else:col=J.gpr('vu32',J.blockIdx.x[0]*BN+wave_n+n*16)
        qb_base.append(J.gpr(col*packed_stride[0]+lane*16))
        sb_base.append(J.gpr((col//32)*(32*stride_scale)+lane*4))
        scale_shift.append(J.gpr((col[0]%32)//16*8))
    cursor=J.gpr('su32',0)
    kbase=J.gpr('su32',J.blockIdx.z[0]*(K//SK)) if SK>1 else J.gpr('su32',0)
    def load(unit,step):
        for half in range(2):
            k=J.gpr('su32',kbase[0]+step*256+half*128)
            avec[unit,half]=0;ascale[unit,half]=127
            with J.ExecMask(token<B[0],early_skip=False):
                J.global_load_dwordx4(avec[unit,half],qa_base[0]+k[0]//2,X)
                J.global_load_ubyte(ascale[unit,half],sa_base[0]+k[0]//32,XS)
            for n in range(blocks):
                J.global_load_dwordx4(bvec[unit,half,n],qb_base[n][0]+(k[0]//128)*1024,W,mod='sc0 nt' if NT else '')
        scale_offset=J.gpr('su32',(kbase[0]//256+step)*256)
        for n in range(0,blocks,2 if share else 1):
            J.global_load_dword(packed_scale[unit,n//2 if share else n],sb_base[n][0]+scale_offset[0],WS)
    def compute(unit):
        for half in range(2):
            for n in range(blocks):
                scale=J.gpr((packed_scale[unit,n//2 if share else n][0]>>(half*16+scale_shift[n][0]))&255)
                J.v_mfma_scale_f32_16x16x128_f8f6f4(accum[n],bvec[unit,half,n],avec[unit,half],accum[n],scale,ascale[unit,half],
                    mod='op_sel:[0,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4')
    for unit in range(depth):load(unit,unit)
    if pairs>depth:
        with J.While(cursor[0]<pairs-depth):
            for unit in range(depth):
                J.s_waitcnt(mod=f'vmcnt({(depth-1)*requests})');compute(unit);load(unit,cursor[0]+depth+unit)
            cursor[:]+=depth
    for unit in range(depth):
        J.s_waitcnt(mod=f'vmcnt({(depth-unit-1)*requests})');compute(unit)
    if FIRST and SK>1:
        split=J.gpr('su32')
        J.s_mul_i32(split,J.blockIdx.z,B[0])
        split[:]*=9*N*4
        for n in range(blocks):
            col=J.gpr('vu32',J.blockIdx.x[0]*(BN//2)+wave_n+(n%(blocks//2))*16+
                      (N//2 if n>=blocks//2 else 0)+part*4)
            dst=J.gpr(route*(N*4)+split[0]+col*4)
            with J.ExecMask(token<B[0],early_skip=False):
                J.global_store_dwordx4(dst,accum[n],Y)
    elif FIRST:
        activated=[]
        for n in range(blocks//2):
            values=[silu(J,accum[n,i],accum[n+blocks//2,i]) for i in range(4)]
            if not FP32_OUT:
                values=[bf16(J,value) for value in values]
            activated.append(values)
        for group in range(blocks//4):
            values=activated[group*2]+activated[group*2+1]
            codes,exponent=pack_fp4(J,values,(16,32),FP32_OUT)
            for n in range(2):
                col=J.gpr(J.blockIdx.x[0]*(BN//2)+wave_n+(group*2+n)*16+part*4)
                packed=J.gpr(codes[n*2][0] | (codes[n*2+1][0]<<8))
                with J.ExecMask(token<B[0],early_skip=False):
                    J.global_store_short(route*(N//4)+col[0]//2,packed,Y)
            col=J.gpr(J.blockIdx.x[0]*(BN//2)+wave_n+group*32)
            with J.ExecMask((token<B[0]) & (part[0]==0),early_skip=False):
                J.global_store_byte(route*(N//64)+col[0]//32,exponent,YS)
    else:
        # MFMA lanes own different token rows. Transpose register ownership
        # so eight neighboring lanes issue all eight BF16 pairs of one row.
        # ds_bpermute uses the wave crossbar, without LDS storage or a barrier.
        from .coalesced_epilogue import emit_coalesced,emit_lds_coalesced
        assert COMBINE in ('wave','lds','lds_sparse')
        if COMBINE in ('lds','lds_sparse') and DIRECT is not True:
            emit_lds_coalesced(J,accum,blocks,token,routing,Y,B,N,BN,NW,wave_n,lane,sparse=COMBINE=='lds_sparse')
        else:emit_coalesced(J,accum,blocks,token,routing,Y,B,N,BN,wave_n,lane,DIRECT is True)
