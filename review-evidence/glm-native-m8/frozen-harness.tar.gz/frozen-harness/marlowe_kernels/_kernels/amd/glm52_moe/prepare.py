# SPDX-License-Identifier: MIT
"""gfx950 assembly generators for Combined's two preparation launches.

Only workgroup barriers are used. Phase 2/3 is launched after phase 1 on the
same stream. Buffers, packed IDs, quantization and native tie priority match
Combined. The grouping emitter uses wave-owned experts within the same grid.
"""
import math
import struct
from marlowe_kernels._runtime import jit
from .quant import round_values, round_packed, shuffle


def sigmoid(J, value):
    wide = J.gpr(2, 'vu32')
    constant = J.gpr(2, 'su32')
    bits = struct.unpack('<II', struct.pack('<d', -1.44269504088896340736))
    constant[0] = bits[0]; constant[1] = bits[1]
    J.v_cvt_f64_f32(wide, value)
    J.v_mul_f64(wide, wide, constant)
    result = J.gpr('vf32')
    J.v_cvt_f32_f64(result, wide)
    J.v_exp_f32(result, result)
    J.v_add_f32(result, 1., result)
    J.v_rcp_f32(result, result)
    return result


def key(J, score, expert):
    result = J.gpr(2, 'vu32')
    ordered = J.gpr((score[0] ^ 0x80000000))
    negative = J.gpr((score[0] ^ 0xffffffff))
    J.v_cmp_lt_f32('vcc', score, 0.)
    J.v_cndmask_b32(result[1], ordered, negative, 'vcc')
    rank = J.gpr((expert[0] // 4) ^ 63)
    flip = J.gpr(rank[0] ^ 7)
    J.v_cmp_ne_u32('vcc', rank[0] & 8, 0)
    J.v_cndmask_b32(rank, rank, flip, 'vcc')
    flip[:] = rank[0] ^ 3
    J.v_cmp_ne_u32('vcc', rank[0] & 4, 0)
    J.v_cndmask_b32(rank, rank, flip, 'vcc')
    priority = J.gpr(rank[0] * 4 + (expert[0] & 3))
    result[0] = ((255 - priority[0]) << 9) | (((expert[0] ^ 0xffffffff)) & 511)
    return result


def select_max(J, left, right):
    J.v_cmp_gt_u64('vcc', right, left)
    for i in range(2):
        J.v_cndmask_b32(left[i], left[i], right[i], 'vcc')


def topk(J, L, C, IDS, WEIGHTS, token, preload=False):
    lane = J.threadIdx.x[0] % 64
    keys = []
    if preload:
        raw_logits=J.gpr(4,'vu32');raw_bias=J.gpr(4,'vu32')
        for j in range(4):
            expert=J.gpr(lane+j*64)
            J.global_load_ushort(raw_logits[j],(token*256+expert[0])*2,L)
            J.global_load_ushort(raw_bias[j],expert[0]*2,C)
        J.s_waitcnt(mod='vmcnt(0)')
    for j in range(4):
        expert = J.gpr(lane + j*64)
        logit, bias = J.gpr('vu32'), J.gpr('vu32')
        if preload:
            logit[:]=raw_logits[j];bias[:]=raw_bias[j]
        else:
            J.global_load_ushort(logit, (token*256+expert[0])*2, L)
            J.global_load_ushort(bias, expert[0]*2, C)
            J.s_waitcnt(mod='vmcnt(0)')
        logit[:] = logit[0] << 16; bias[:] = bias[0] << 16
        score = sigmoid(J, logit)
        J.v_add_f32(score, score, bias)
        keys.append(key(J, score, expert))
    # The native per-lane sorting network and six DPP reductions. Only lane
    # 63 is defined after the row broadcasts; broadcast its winning key.
    for i in range(4):
        for j in range(i+1,4):
            left = J.gpr(2,'vu32')
            for part in range(2):left[part]=keys[i][part]
            J.v_cmp_gt_u64('vcc',keys[j],left)
            for part in range(2):
                J.v_cndmask_b32(keys[i][part],left[part],keys[j][part],'vcc')
                J.v_cndmask_b32(keys[j][part],keys[j][part],left[part],'vcc')
    winner_id = J.gpr('vu32', 0)
    controls=('quad_perm:[1,0,3,2]','quad_perm:[2,3,0,1]',
              'row_half_mirror','row_mirror','row_bcast:15','row_bcast:31')
    for k in range(8):
        winner = J.gpr(2, 'vu32')
        for i in range(2):winner[i]=keys[0][i]
        for control in controls:
            # CDNA4 ISA Table 11: a DPP source needs two wait states
            # after a VALU write; the pinned JIT does not insert these.
            J.s_nop(1)
            other=J.gpr(2,'vu32')
            for part in range(2):
                J.v_mov_b32_dpp(other[part],winner[part],mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
            select_max(J,winner,other)
        broadcast=J.gpr(2,'su32')
        J.s_nop(0)
        for part in range(2):J.v_readlane_b32(broadcast[part],winner[part],63)
        J.s_nop(1)  # VALU-produced SGPR -> VALU constant source
        expert=J.gpr('vu32',(broadcast[0]^0xffffffff)&511)
        J.v_cmp_eq_u32('vcc',J.gpr(lane),k)
        J.v_cndmask_b32(winner_id,winner_id,expert,'vcc')
        J.v_cmp_eq_u64('vcc',keys[0],broadcast)
        for j in range(3):
            for part in range(2):J.v_cndmask_b32(keys[j][part],keys[j][part],keys[j+1][part],'vcc')
        for part in range(2):J.v_cndmask_b32(keys[3][part],keys[3][part],0,'vcc')
    value = J.gpr('vu32', 0)
    with J.ExecMask(lane < 8, early_skip=False):
        J.global_load_ushort(value, (token*256+winner_id[0])*2, L)
    J.s_waitcnt(mod='vmcnt(0)')
    value[:] = value[0] << 16
    probability = sigmoid(J, value)
    J.v_cmp_lt_u32('vcc', J.gpr(lane), 8)
    J.v_cndmask_b32(probability, 0, probability, 'vcc')
    total = J.gpr('vf32'); total[:] = probability
    for control in controls:
        J.s_nop(1)
        J.v_add_f32_dpp(total,total,total,mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
    sum_scalar=J.gpr('sf32')
    J.s_nop(0)
    J.v_readlane_b32(sum_scalar,total,63)
    J.s_nop(1)
    J.v_rcp_f32(total,sum_scalar)
    J.v_mul_f32(total,J.gpr('sf32',2.5),total)
    J.v_mul_f32(probability, probability, total)
    with J.ExecMask(lane < 8, early_skip=False):
        J.global_store_dword((token*9+lane)*4, winner_id, IDS)
        J.global_store_dword((token*9+lane)*4, probability, WEIGHTS)


@jit()
def phase1(J, L:'void*', C:'void*', X:'void*', IDS:'void*', W:'void*',
           Q:'void*', S:'void*', Y:'void*', O:'void*', SI:'void*', SW:'void*', SUPPLIED, HW):
    token, tid = J.blockIdx.x[0], J.threadIdx.x[0]
    zero = J.gpr(4, 'vu32', 0)
    for part in (0,16):
        J.global_store_dwordx4((token*3*2048+tid*16)*2+part, zero, O)
    data = J.gpr(8, 'vu32')
    for part in (0,4):
        J.global_load_dwordx4(data[part:part+3], (token*3*2048+tid*16)*2+part*4, X)
    J.s_waitcnt(mod='vmcnt(0)')
    values = []
    for i in range(8):
        values.extend([J.gpr(data[i] << 16), J.gpr(data[i] & 0xffff0000)])
    encoded = J.gpr(2, 'vu32', 0)
    if HW:
        codes, exponent, pairs = round_packed(J, values, (1,), False)
        for i,code in enumerate(codes):
            encoded[i//4] = encoded[i//4] | (code[0] << (8*(i%4)))
    else:
        codes, exponent, rounded = round_values(J, values, (1,), False)
        for i,code in enumerate(codes):
            encoded[i//8] = encoded[i//8] | (code[0] << (4*(i%8)))
        pairs=[]
        for i in range(0,16,2):
            packed = J.gpr('vbf16x2')
            J.pk_f32_to_bf16(packed, rounded[i], rounded[i+1])
            pairs.append(packed)
    J.global_store_dwordx2(token*3*1024+tid*8, encoded, Q)
    with J.ExecMask(tid%2 == 0, early_skip=False):
        J.global_store_byte(256+token*3*64+tid//2, exponent, S)
    for i,packed in enumerate(pairs):
        J.global_store_dword((token*3*2048+tid*16+i*2)*2, packed, Y)
    with J.ExecMask(tid < 64):
        if SUPPLIED:
            ids, weights = J.gpr('vu32'), J.gpr('vf32')
            with J.ExecMask(tid < 8, early_skip=False):
                J.global_load_dword(ids, (token*8+tid)*4, SI)
                J.global_load_dword(weights, (token*8+tid)*4, SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4, ids, IDS)
                J.global_store_dword((token*9+tid)*4, weights, W)
        else:
            topk(J, L, C, IDS, W, token)
        with J.ExecMask(tid == 0, early_skip=False):
            J.global_store_dword(J.gpr("vu32",(token*9+8)*4), J.gpr('vu32',256), IDS)
            J.global_store_dword(J.gpr("vu32",(token*9+8)*4), J.gpr('vf32',1.), W)


@jit()
def phase23(J, IDS:'void*', W:'void*', SORT:'void*', WEIGHTS:'void*',
            EXPERTS:'void*', VALID:'void*', B, GRID, MAXIMUM):
    tid, lane = J.threadIdx.x[0], J.threadIdx.x[0] % 64
    # Materialize across the full EXEC mask: PyHIP expression CSE must not
    # first define this value inside the lane-63 wave-total store.
    wave_id = J.gpr(tid//64)[0]
    hist = J.alloc_lds(384*4)
    scans = J.alloc_lds(384*4)
    waves = J.alloc_lds(6*4)
    zero = J.gpr('vu32',0)
    J.ds_write_b32(hist+tid*4, zero)
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    for start in range(0,B*9,384):
        expert = J.gpr('vu32')
        with J.ExecMask(tid+start < B*9):
            J.global_load_dword(expert, (tid+start)*4, IDS)
            J.s_waitcnt(mod='vmcnt(0)')
            J.ds_add_u32(hist+expert[0]*4, J.gpr('vu32',1))
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    count = J.gpr('vu32')
    J.ds_read_b32(count, hist+tid*4)
    J.s_waitcnt(mod='lgkmcnt(0)')
    rows = J.gpr(((count[0]+15)//16)*16)
    prefix = J.gpr(rows[0])
    for distance in (1,2,4,8,16,32):
        other = J.gpr('vu32')
        J.ds_bpermute_b32(other, ((lane-distance)%64)*4, prefix)
        J.s_waitcnt(mod='lgkmcnt(0)')
        with J.ExecMask(lane >= distance, early_skip=False):
            J.v_add_u32(prefix, prefix, other)
    with J.ExecMask(lane == 63, early_skip=False):
        J.ds_write_b32(waves+wave_id*4, prefix)
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    for wave in range(5):
        other = J.gpr('vu32')
        J.ds_read_b32(other, J.gpr('vu32',waves+wave*4))
        J.s_waitcnt(mod='lgkmcnt(0)')
        with J.ExecMask(wave_id > wave, early_skip=False):
            J.v_add_u32(prefix, prefix, other)
    J.ds_write_b32(scans+tid*4, prefix)
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    total = J.gpr('vu32')
    J.ds_read_b32(total, J.gpr('vu32',scans+256*4))
    J.s_waitcnt(mod='lgkmcnt(0)')
    sentinel = J.gpr('vu32', (9<<24)|B)
    global_tid = J.blockIdx.x[0]*3*128+tid
    with J.If(J.blockIdx.x[0] == 0):
        with J.ExecMask(tid == 0, early_skip=False):
            J.global_store_dword(J.gpr('vu32',0), total, VALID)
            J.global_store_dword(J.gpr('vu32',4), J.gpr('vu32',B), VALID)
    for start in range(0,MAXIMUM,GRID*384):
        index = total[0]+global_tid+start
        with J.ExecMask(index < MAXIMUM):
            J.global_store_dword(index*4, sentinel, SORT)
            J.global_store_dword(index*4, zero, WEIGHTS)
    index = total[0]//16+global_tid
    with J.ExecMask(index < (MAXIMUM+15)//16):
        J.global_store_dword(index*4, zero, EXPERTS)
    # All workgroup barriers precede expert-dependent wave exits.
    for base in range(0,257,GRID*6):
        expert_v = J.gpr(J.blockIdx.x[0]*6+wave_id+base)
        expert = J.gpr('su32')
        J.v_readfirstlane_b32(expert, expert_v)
        with J.If(expert[0] < 257):
            end, count = J.gpr('vu32'), J.gpr('vu32')
            J.ds_read_b32(end, J.gpr('vu32',scans+expert[0]*4))
            J.ds_read_b32(count, J.gpr('vu32',hist+expert[0]*4))
            J.s_waitcnt(mod='lgkmcnt(0)')
            count_scalar = J.gpr('su32')
            J.v_readfirstlane_b32(count_scalar,count)
            with J.If(count_scalar[0] > 0):
                begin = J.gpr(end[0]-((count[0]+15)//16)*16)
                offset = J.gpr('su32',0)
                for start in range(0,B*9,64):
                    route = J.gpr('vu32',0xffffffff)
                    weight = J.gpr('vf32',0.)
                    with J.ExecMask(lane+start < B*9, early_skip=False):
                        J.global_load_dword(route, (lane+start)*4, IDS)
                        J.global_load_dword(weight, (lane+start)*4, W)
                    J.s_waitcnt(mod='vmcnt(0)')
                    J.v_cmp_eq_u32('vcc', route, expert)
                    mask = J.gpr(2,'su32')
                    J.s_mov_b64(mask, 'vcc')
                    rank = J.gpr('vu32')
                    J.v_mbcnt_lo_u32_b32(rank, mask[0], 0)
                    J.v_mbcnt_hi_u32_b32(rank, mask[1], rank)
                    with J.ExecMask(route[0] == expert[0], early_skip=False):
                        token = J.gpr("vu32")
                        J.v_mul_hi_u32(token, J.gpr("su32",0x38e38e39), J.gpr(lane+start))
                        token[:] = token[0] >> 1
                        packed = J.gpr(token[0] | ((lane+start-token[0]*9)<<24))
                        J.global_store_dword((begin[0]+offset[0]+rank[0])*4, packed, SORT)
                        J.global_store_dword((begin[0]+offset[0]+rank[0])*4, weight, WEIGHTS)
                    hits = J.gpr('su32')
                    J.s_bcnt1_i32_b64(hits, mask)
                    offset[0] += hits[0]
                with J.ExecMask(begin[0]+count[0]+lane < end[0], early_skip=False):
                    J.global_store_dword((begin[0]+count[0]+lane)*4, sentinel, SORT)
                    J.global_store_dword((begin[0]+count[0]+lane)*4, zero, WEIGHTS)
                with J.ExecMask(lane < (count[0]+15)//16, early_skip=False):
                    J.global_store_dword((begin[0]//16+lane)*4, expert_v, EXPERTS)


