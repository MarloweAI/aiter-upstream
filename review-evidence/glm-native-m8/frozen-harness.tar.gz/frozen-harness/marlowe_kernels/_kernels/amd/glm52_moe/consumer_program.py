# SPDX-License-Identifier: MIT
"""Direct-route G2 consumer that reduces and quantizes G1 partials in LDS.

Each G2 CTA recreates its expert's 136-byte packed intermediate. This trades
small, cache-resident repeated partial loads for a separate sparse launch.
The reduction tree, activation rounding and FP4 packing are unchanged.
"""
from dataclasses import dataclass
import re

from marlowe_kernels._runtime import jit
from .block_fused import LocalCoordinates, pointer
from .coalesced_program import CoalescedProgram, CoalescedConfig
from .native_coalesced import coalesced_projection
from .native_prepare import middle_packed, native_phase1


@dataclass(frozen=True)
class ConsumerConfig(CoalescedConfig):
    pass


class ConsumerCoordinates(LocalCoordinates):
    def s_waitcnt(self, mod=''):
        # Input operands now come from LDS; their completion is independent
        # of the pipelined VMEM threshold used for weight prefetch.
        if 'lgkmcnt' not in mod:
            mod += ' lgkmcnt(0)'
        if 'vmem_per_stage' in self.__dict__:
            def adjust(match):
                pending=int(match.group(1))
                pending-=self.__dict__.get('vmem_inputs_per_stage',2)*(pending//self.vmem_per_stage)
                return f'vmcnt({pending})'
            mod=re.sub(r'vmcnt\((\d+)\)',adjust,mod)
        return self.J.s_waitcnt(mod=mod)


@jit()
def consumer_down(J, B, BN, NW, SK, FP32, NT, DEPTH, COMBINE,
                  PART:'void*', MID:'void*', MS:'void*',
                  W:'void*', WS:'void*', OUT:'void*', IDS:'void*', RW:'void*'):
    from pyhip.core.mem_allocator import SimpleMemoryAllocator
    assert J.gfx == 950
    J.lds_allocator = SimpleMemoryAllocator(160*1024)
    J.alloc_lds(160, align=16)
    lane=J.gpr(J.threadIdx.x[0]%64)
    wave=J.gpr(J.threadIdx.x[0]//64)
    swave=J.gpr('su32')
    J.v_readfirstlane_b32(swave,wave)
    def coords(name,x,y,z,thread,mapping):
        return ConsumerCoordinates(J,name,x,y,z,thread,mapping=mapping,B=B,rows=1,
                                   partial_base=0,mid_base=0,scale_base=144)
    if NW==1:
        for half in range(2):
            mid,scale=pointer(J,MID),pointer(J,MS)
            c=coords(f'middle{half}_',J.blockIdx.y,J.gpr('su32',half),J.gpr('su32',0),lane,
                     [(mid,'mid'),(scale,'scale')])
            middle_packed.gen_func(c,pointer(J,PART),mid,scale,B,SK,FP32)
    else:
        with J.ExecMask(wave[0]<2):
            mid,scale=pointer(J,MID),pointer(J,MS)
            c=coords('middle_',J.blockIdx.y,swave,J.gpr('su32',0),lane,
                     [(mid,'mid'),(scale,'scale')])
            middle_packed.gen_func(c,pointer(J,PART),mid,scale,B,SK,FP32)
    J.s_waitcnt(mod='lgkmcnt(0) vmcnt(0)')
    J.s_barrier()
    mid,scale=pointer(J,MID),pointer(J,MS)
    c=coords('down_',J.blockIdx.x,J.blockIdx.y,J.gpr('su32',0),J.threadIdx.x,
             [(mid,'mid'),(scale,'scale')])
    c.vmem_per_stage=2+2*(BN//NW//16)
    coalesced_projection.gen_func(c,256,6144,BN,False,1,FP32,NW,True,True,NT,DEPTH,COMBINE,
        mid,scale,pointer(J,W),pointer(J,WS),pointer(J,OUT),pointer(J,MS),
        pointer(J,IDS),pointer(J,RW),pointer(J,IDS),pointer(J,IDS),J.gpr('su32',B))


class ConsumerProgram(CoalescedProgram):
    def __init__(self,owner,batch,config=ConsumerConfig()):
        assert config.direct and not config.dispatch and config.split_k>1
        super().__init__(owner,batch,config)
        self.info.update(algorithm='G1 split partials -> G2 local reduce/pack + coalesced combine')

    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.cc,self.p
        output=p['output'] if out is None else out
        native_phase1([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),
            p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),
            0 if supplied_weights is None else supplied_weights.data_ptr(),supplied_ids is not None)
        self._stage(p['packed'],p['workspace'].data_ptr()+256,self.partial,True)
        self._stage(self.partial,self.mid_scale.data_ptr(),output,False)
        return output

    def _stage(self,inp,scale,out,first):
        if first:
            return super()._stage(inp,scale,out,first)
        b,c,p=self.b,self.cc,self.p
        consumer_down([6144//c.down_n,self.grid],[64*c.down_waves],b,c.down_n,c.down_waves,
            c.split_k,self.fp32_middle,c.non_temporal,c.down_depth or 2,c.combine,
            self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),
            self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),out.data_ptr(),
            p['ids'].data_ptr(),p['weights'].data_ptr())
