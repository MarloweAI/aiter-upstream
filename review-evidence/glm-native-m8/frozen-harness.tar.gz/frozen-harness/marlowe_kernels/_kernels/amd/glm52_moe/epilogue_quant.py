# SPDX-License-Identifier: MIT
# Copyright (C) 2024-2026, Advanced Micro Devices, Inc. All rights reserved.
def emit_roundtrip_pair(J, out0, out1, amax_override=None):
    """32-value FP32 FlyDSL quantization block across 16 lanes, two values/lane."""
    abs_mask=J.gpr('su32',0x7fffffff)
    sign_mask=J.gpr('su32',0x80000000)
    amax=J.gpr('vf32')
    tmp=J.gpr('vf32')
    if amax_override is None:
        J.v_and_b32(amax,abs_mask,out0)
        J.v_and_b32(tmp,abs_mask,out1)
        J.v_max_f32(amax,amax,tmp)
        for distance in (1,2,4,8):
            index=J.gpr(((J.threadIdx.x[0]%64)^distance)*4)
            J.ds_bpermute_b32(tmp,index,amax)
            J.s_waitcnt(mod='lgkmcnt(0)')
            J.v_max_f32(amax,amax,tmp)
    else:
        amax[:]=amax_override
    bias=J.gpr('su32',0x400000)
    exponent=J.gpr('vu32')
    J.v_add_u32(exponent,amax,bias)
    J.v_lshrrev_b32(exponent,23,exponent)
    J.v_sub_u32(exponent,exponent,2)
    J.v_max_i32(exponent,exponent,0)
    inverse=J.gpr('vf32')
    inv_bias=J.gpr('su32',254)
    J.v_sub_u32(inverse,inv_bias,exponent)
    J.v_lshlrev_b32(inverse,23,inverse)
    scale=J.gpr('vf32')
    J.v_lshlrev_b32(scale,23,exponent)
    tiny=J.gpr('vu32',0x00400000)
    J.v_cmp_eq_u32('vcc',exponent,0)
    J.v_cndmask_b32(scale,scale,tiny,'vcc')
    values=[]
    for source in (out0,out1):
        magnitude=J.gpr('vf32')
        J.v_and_b32(magnitude,abs_mask,source)
        J.v_mul_f32(magnitude,magnitude,inverse)
        rounded=J.gpr('vf32',0.0)
        # Ties choose the even E2M1 encoding. These are exact FP32 constants.
        for threshold,level,inclusive in ((.25,.5,False),(.75,1.,True),(1.25,1.5,False),
                                           (1.75,2.,True),(2.5,3.,False),(3.5,4.,True),(5.,6.,False)):
            threshold_reg=J.gpr('sf32',threshold)
            level_reg=J.gpr('vf32',level)
            compare=J.v_cmp_ge_f32 if inclusive else J.v_cmp_gt_f32
            compare('vcc',magnitude,threshold_reg)
            J.v_cndmask_b32(rounded,rounded,level_reg,'vcc')
        J.v_mul_f32(rounded,rounded,scale)
        sign=J.gpr('vu32')
        J.v_and_b32(sign,source,sign_mask)
        J.v_or_b32(rounded,rounded,sign)
        values.append(rounded)
    packed=J.gpr('vbf16x2')
    J.pk_f32_to_bf16(packed,values[0],values[1])
    return packed
