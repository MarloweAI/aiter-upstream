"""Default Port-EW selections from 3720644 plus B2 split-K job 57976.

Keep this small table in the installed package; benchmarks/evidence is not a
runtime dependency. Device emitters are imported only when a batch is warmed.
The historical BF16 and first native-FP4 programs remain explicit alternatives.
"""

SELECTION_REVISION = "37206449827ecf068a57e60f3cfca1fc62d0d9d3+b2-native-split-57976"

SELECTED_CONFIGS = {
    1: {"family": "coalesced", "config": {
        "direct": True, "gate_n": 64, "gate_waves": 1,
        "down_n": 256, "down_waves": 4, "split_k": 6,
        "non_temporal": True, "depth": 4, "down_depth": 2, "dispatch": False}},
    2: {"family": "prefetch", "config": {
        "direct": True, "gate_n": 64, "gate_waves": 1,
        "down_n": 64, "down_waves": 1, "split_k": 16,
        "non_temporal": True, "depth": 3, "down_depth": 2}},
    4: {"family": "coalesced", "config": {
        "direct": True, "gate_n": 64, "gate_waves": 1,
        "down_n": 64, "down_waves": 1, "split_k": 8,
        "non_temporal": True, "depth": 0, "down_depth": 2, "dispatch": False}},
    8: {"family": "coalesced", "config": {
        "direct": False, "gate_n": 64, "gate_waves": 1,
        "down_n": 64, "down_waves": 1, "split_k": 1,
        "non_temporal": True, "depth": 6, "down_depth": 2,
        "dispatch": True, "combine": "lds"}},
    16: {"family": "coalesced", "config": {
        "direct": False, "gate_n": 64, "gate_waves": 1,
        "down_n": 64, "down_waves": 1, "split_k": 1,
        "non_temporal": True, "depth": 6, "down_depth": 2,
        "dispatch": True, "combine": "lds"}},
    32: {"family": "coalesced", "config": {
        "direct": False, "gate_n": 64, "gate_waves": 1,
        "down_n": 64, "down_waves": 1, "split_k": 1,
        "non_temporal": True, "depth": 6, "down_depth": 2,
        "dispatch": True, "combine": "lds"}},
    64: {"family": "coalesced", "config": {
        "direct": False, "gate_n": 64, "gate_waves": 1,
        "down_n": 256, "down_waves": 4, "split_k": 1,
        "non_temporal": True, "depth": 6, "down_depth": 2,
        "dispatch": True, "combine": "lds"}},
    128: {"family": "coalesced", "config": {
        "direct": False, "gate_n": 64, "gate_waves": 1,
        "down_n": 64, "down_waves": 1, "split_k": 1,
        "non_temporal": True, "depth": 6, "down_depth": 2,
        "dispatch": True, "combine": "lds_sparse"}},
}


def create_selected_program(owner, batch):
    entry = SELECTED_CONFIGS[batch]
    if entry["family"] == "prefetch":
        from .prefetch_program import PrefetchProgram, PrefetchConfig
        return PrefetchProgram(owner, batch, PrefetchConfig(**entry["config"]))
    if entry["family"] == "mixed":
        from .mixed_packed import MixedProgram, MixedConfig
        return MixedProgram(owner, batch, MixedConfig(**entry["config"]))
    from .coalesced_program import CoalescedProgram, CoalescedConfig
    return CoalescedProgram(owner, batch, CoalescedConfig(**entry["config"]))
