# SPDX-License-Identifier: MIT
"""Isolate tile ordering, XCD locality, and dense shared-expert work."""
from dataclasses import dataclass
from marlowe_kernels._runtime import jit
from .native_program import NativeProgram,NativeConfig
from .native_fp4 import native_projection
from .native_shared import shared_projection
from .native_prefetch import prefetch_projection
from .block_fused import Coordinates

def unsigned_divide(J,value,divisor):
    """Exact u32 division (including add-marker divisors such as 275)."""
    assert 0<divisor<2**32
    n=J.gpr('su32',value)
    shift=divisor.bit_length()-1
    if divisor&(divisor-1)==0:return J.gpr('su32',n[0]>>shift)
    proposed,rem=divmod(1<<(32+shift),divisor)
    add=divisor-rem >= 1<<shift
    if add:proposed=2*proposed+int(2*rem>=divisor)
    magic=(proposed+1)&0xffffffff
    q=J.gpr('su32');J.s_mul_hi_u32(q,n,J.gpr('su32',magic))
    if add:q[:]=((n[0]-q[0])>>1)+q[0]
    q[:]=q[0]>>shift
    return q

@dataclass(frozen=True)
class ScheduledConfig:
    direct: bool=False
    gate_n: int=64
    gate_waves: int=1
    down_n: int=128
    down_waves: int=2
    split_k: int=2
    non_temporal: bool=True
    order: int=1
    xcd: int=0
    shared: bool=False
    depth: int=0

@jit()
def scheduled_projection(J,K,N,BN,FIRST,SK,FUSED,NW,DIRECT,NT,GRID,ORDER,XCD,SHARED,DEPTH,
                         X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                         IDS:'void*',RW:'void*',EXP:'void*',VALID:'void*',B:'int'):
    ng=N//BN;total=ng*GRID*SK
    def remainder(value,divisor):
        quotient=unsigned_divide(J,value,divisor)
        return J.gpr('su32',value-quotient[0]*divisor)
    task=J.gpr('su32',J.blockIdx.x[0])
    if XCD:
        chip=J.gpr('su32',task[0]%XCD)
        extra=J.gpr('su32');J.s_min_u32(extra,chip,total%XCD)
        task[:]=(task[0]//XCD)+chip[0]*(total//XCD)+extra[0]
    if ORDER==0:
        x=remainder(task[0],ng);y=remainder(unsigned_divide(J,task[0],ng)[0],GRID);z=unsigned_divide(J,task[0],ng*GRID)
    elif ORDER==1:
        x=remainder(unsigned_divide(J,task[0],SK)[0],ng);y=unsigned_divide(J,task[0],SK*ng);z=remainder(task[0],SK)
    else:
        y=remainder(task[0],GRID);x=remainder(unsigned_divide(J,task[0],GRID)[0],ng);z=unsigned_divide(J,task[0],GRID*ng)
    proxy=Coordinates(J,'scheduled_',x,y,z,J.threadIdx.x)
    if SHARED:
        assert DIRECT and DEPTH==0
        shared_projection.gen_func(proxy,K,N,BN,FIRST,SK,FUSED,NW,DIRECT,True,NT,X,XS,W,WS,Y,YS,IDS,RW,EXP,VALID,B)
    elif DEPTH:
        prefetch_projection.gen_func(proxy,K,N,BN,FIRST,SK,FUSED,NW,DIRECT,True,NT,DEPTH,X,XS,W,WS,Y,YS,IDS,RW,EXP,VALID,B)
    else:native_projection.gen_func(proxy,K,N,BN,FIRST,SK,FUSED,NW,DIRECT,True,NT,X,XS,W,WS,Y,YS,IDS,RW,EXP,VALID,B)

class ScheduledProgram(NativeProgram):
    def __init__(self,owner,batch,config=ScheduledConfig()):
        self.pc=config
        assert not config.shared or config.direct
        keys=NativeConfig.__dataclass_fields__
        super().__init__(owner,batch,NativeConfig(**{k:v for k,v in config.__dict__.items() if k in keys}))
        if config.shared:self.grid=batch*8+(batch+15)//16
        self.info=dict(config=config.__dict__)
    def _stage(self,inp,inp_scale,out,first):
        p,c,b=self.p,self.c,self.b
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                        (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1
        w,s=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        pc=self.pc
        scheduled_projection([n//bn*self.grid*sk],[64*nw],k,n,bn,first,sk,self.fp32_middle,nw,c.direct,c.non_temporal,
            self.grid,pc.order,pc.xcd,pc.shared,pc.depth if first else 0,
            inp.data_ptr(),inp_scale,w.data_ptr(),s.data_ptr(),out.data_ptr(),self.mid_scale.data_ptr(),
            ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b)
