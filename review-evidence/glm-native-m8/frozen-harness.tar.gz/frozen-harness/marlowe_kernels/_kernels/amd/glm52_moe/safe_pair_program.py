# SPDX-License-Identifier: MIT
"""Ordered supplied-route combination for the B8 consumer-merged program."""
import torch
from .pair_program import PairProgram, PairConfig
from .native_ordered import ordered_projection
from .ordered_program import ordered_combine


class SafePairProgram(PairProgram):
    def __init__(self, owner, batch, config=PairConfig()):
        super().__init__(owner, batch, config)
        assert config.direct == 'merge8' and not config.dispatch
        self._ordered_mode = False
        self.route_output = torch.empty((batch, 9, 6144), device=owner.device,
                                        dtype=torch.bfloat16)
        self.info.update(supplied_combination='BF16 operand rounding, ordered FP32 sum')

    def run(self, x, logits, bias, *, out=None, supplied_ids=None, supplied_weights=None):
        self._ordered_mode = supplied_ids is not None
        output = self.p['output'] if out is None else out
        try:
            target = self.route_output if self._ordered_mode else output
            super().run(x, logits, bias, out=target,
                        supplied_ids=supplied_ids, supplied_weights=supplied_weights)
            if self._ordered_mode:
                ordered_combine([12, self.b], [256], target.data_ptr(), output.data_ptr())
            return output
        finally:
            self._ordered_mode = False

    def _stage(self, inp, scale, out, first):
        if first or not self._ordered_mode:
            return super()._stage(inp, scale, out, first)
        c, p, b = self.cc, self.p, self.b
        ordered_projection([6144 // c.down_n, self.grid], [64 * c.down_waves],
            256, 6144, c.down_n, False, 1, self.fp32_middle, c.down_waves,
            'merge8', True, c.non_temporal, c.down_depth or 2, 'ordered',
            inp.data_ptr(), scale, self.owner.w2.data_ptr(), self.owner.weights.w2_scale.data_ptr(),
            out.data_ptr(), self.mid_scale.data_ptr(), p['ids'].data_ptr(),
            p['weights'].data_ptr(), p['ids'].data_ptr(), p['ids'].data_ptr(), b)
