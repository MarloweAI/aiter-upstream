"""Port-EW launch sequence with fixed, per-instance scratch allocations."""
import math
import torch
from .configs import CONFIGS
from .prepare import phase1, phase23
from .quant import middle
from . import experts as emitters


class Program:
    def __init__(self, owner, batch):
        self.owner, self.b, self.c = owner, batch, CONFIGS[batch]
        b, d, c, device = batch, 6144, self.c, owner.device
        maximum = b*9+257*16-9
        blocks = (maximum+15)//16
        def empty(shape, dtype):
            return torch.empty(shape, device=device, dtype=dtype)
        self.p = dict(
            ids=empty((b,9),torch.int32), weights=empty((b,9),torch.float32),
            sorted_ids=empty(maximum,torch.int32), sorted_weights=empty(maximum,torch.float32),
            experts=empty(blocks,torch.int32), valid=empty(2,torch.int32),
            packed=empty((b,d//2),torch.uint8),
            workspace=torch.zeros(256+b*256,device=device,dtype=torch.uint8),
            output=empty((b,d),torch.bfloat16), qdq=empty((b,d),torch.bfloat16))
        self.fp32_middle = b in (1,4,8,32)
        self.mid = empty((b,9,256),torch.bfloat16)
        self.partial = (empty((c.split_k,b,9,512),torch.float32) if c.split_k>1 else
                        empty((b,9,256),torch.float32 if self.fp32_middle and not c.fuse_middle else torch.bfloat16))
        occupied = math.ceil(257*(1-(1-1/257)**(b*9)))
        self.group_grid = min(max(16,(occupied*16+19)//20),max(16,owner._cu_count//2),owner._cu_count)
        self.grid = b*9 if c.direct else min(blocks,b*9)

    def run(self, x, logits, bias, *, out=None, supplied_ids=None, supplied_weights=None):
        b,c,p = self.b,self.c,self.p
        output = p['output'] if out is None else out
        phase1([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),
            p['ids'].data_ptr(),p['weights'].data_ptr(),p['packed'].data_ptr(),
            p['workspace'].data_ptr(),p['qdq'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),
            0 if supplied_weights is None else supplied_weights.data_ptr(),supplied_ids is not None,True)
        if not c.direct:
            phase23([self.group_grid],[384],p['ids'].data_ptr(),p['weights'].data_ptr(),
                p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),
                p['valid'].data_ptr(),b,self.group_grid,p['sorted_ids'].numel())
        self._stage(p['qdq'],self.partial,True)
        if c.split_k>1 or not c.fuse_middle:
            middle([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),b,c.split_k,
                   self.fp32_middle,self.fp32_middle and c.split_k==1,True)
            mid=self.mid
        else:
            mid=self.partial
        self._stage(mid,output,False)
        return output

    def _stage(self, inp, output, first):
        c,p,b = self.c,self.p,self.b
        ids,weights,experts,valid = ((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
            (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        n,k,bn = (512,6144,c.gate_n) if first else (6144,256,c.down_n)
        sk = c.split_k if first else 1
        schedule = c.gate_schedule if first else c.down_schedule
        custom = first and c.fuse_middle and sk==1
        emitter = (emitters.epilogue_moe_stage if custom else
                   emitters.pipeline_moe_stage if schedule else emitters.tuned_moe_stage)
        weight,scale = ((self.owner.w13,self.owner.weights.w13_scale) if first else
                        (self.owner.w2,self.owner.weights.w2_scale))
        emitter([n//bn,self.grid]+([sk] if sk>1 else []),[256 if first else 64],
                weight.dtype,9,k,n,first,c.bm,bn,inp.data_ptr(),weight.data_ptr(),output.data_ptr(),
                ids.data_ptr(),weights.data_ptr(),experts.data_ptr(),valid.data_ptr(),
                scale.data_ptr(),b,False,c.direct,False,c.non_temporal,c.use_lds,False,sk,False,
                self.fp32_middle and first,*([schedule,True,0] if custom else [schedule] if schedule else []))
