# SPDX-License-Identifier: MIT
"""Direct G2 accumulation for unique routes supplied by native top-k."""
from copy import deepcopy
from .bandwidth_program import BANDWIDTH_CONFIGS


# Keep tuning separate from internal routing and the general supplied API.
NATIVE_COMBINE_CONFIGS = deepcopy(BANDWIDTH_CONFIGS)


def create_native_combine_program(owner, batch, overrides=None):
    entry=NATIVE_COMBINE_CONFIGS[batch]
    config=dict(entry['config'])
    config.update(overrides or {})
    if batch in (1,2,4):
        from .overlap_gate import OverlapG1Program,OverlapG1Config,overlap_gate
        from .overlap_consumer import OverlapProgram

        class NativeOverlapProgram(OverlapG1Program):
            def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
                if supplied_ids is None:
                    return super().run(x,logits,bias,out=out)
                b,c,p=self.b,self.cc,self.p
                output=p['output'] if out is None else out
                shape=dict(x=512//c.gate_n,y=self.grid,z=c.split_k)
                overlap_gate([shape[axis] for axis in self.ic.gate_axis],[64],b,c.gate_n,c.split_k,
                    c.non_temporal,c.depth or 2,True,False,self.ic.route_preload,self.ic.gate_axis,
                    self.ic.reuse_probabilities,self.ic.pair_depth,self.ic.slot_routing,
                    self.oc.pack_overlap,self.oc.prefetch_input,self.oc.drain_before,self.oc.predecode_scales,False,
                    logits.data_ptr(),bias.data_ptr(),x.data_ptr(),supplied_ids.data_ptr(),supplied_weights.data_ptr(),
                    p['ids'].data_ptr(),p['weights'].data_ptr(),output.data_ptr(),
                    self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),
                    self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr())
                OverlapProgram._stage(self,self.partial,self.mid_scale.data_ptr(),output,False)
                return output

        program=NativeOverlapProgram(owner,batch,OverlapG1Config(**config))
        # This path never stores nine private route outputs.
        del program.route_output
    elif batch==8:
        from .pair_program import PairProgram,PairConfig
        program=PairProgram(owner,batch,PairConfig(**config))
    else:
        from .fixed_bins import FixedBinProgram,FixedBinConfig
        config.pop('ordered_supplied',None);config.pop('ordered_all',None)
        program=FixedBinProgram(owner,batch,FixedBinConfig(**config))
    program.info.update(native_routing=True,combine='direct BF16 atomic accumulation',
                        supplied_combination='BF16 direct atomic accumulation',
                        requires_unique_experts_per_token=True)
    return program
