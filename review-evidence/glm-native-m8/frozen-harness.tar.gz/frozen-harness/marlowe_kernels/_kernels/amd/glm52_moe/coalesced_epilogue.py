# SPDX-License-Identifier: MIT
"""Transpose MFMA output ownership within a wave before packed BF16 atomics."""

def emit_coalesced(J,accum,blocks,token,routing,Y,B,N,BN,wave_n,lane,direct=False):
    pair=J.gpr(lane[0]%8)
    source=[];tokens=[]
    halves=1 if direct else 2
    for half in range(halves):
        source_row=0 if direct else lane[0]//8+half*8
        source.append(J.gpr((source_row+(pair[0]//2)*16)*4))
        if direct:
            scalar=J.gpr('su32');J.v_readfirstlane_b32(scalar,token)
            target=J.gpr('vu32',scalar[0])
        else:
            target=J.gpr('vu32');J.ds_bpermute_b32(target,source[-1],token)
        tokens.append(target)
    J.s_waitcnt(mod='lgkmcnt(0)')
    for n in range(blocks):
        packed=J.gpr(2,'vbf16x2')
        for i in range(4):accum[n,i]*=routing[0]
        J.v_cvt_pk_bf16_f32(packed[0],accum[n,0],accum[n,1])
        J.v_cvt_pk_bf16_f32(packed[1],accum[n,2],accum[n,3])
        for half in range(halves):
            words=J.gpr(2,'vu32')
            J.ds_bpermute_b32(words[0],source[half],packed[0])
            J.ds_bpermute_b32(words[1],source[half],packed[1])
            J.s_waitcnt(mod='lgkmcnt(0)')
            J.v_cmp_eq_u32('vcc',pair[0]%2,1)
            J.v_cndmask_b32(words[0],words[0],words[1],'vcc')
            address=J.gpr((tokens[half][0]*N+J.blockIdx.x[0]*BN+wave_n+n*16+pair[0]*2)*2)
            with J.ExecMask(lane[0]<8 if direct else tokens[half][0]<B[0],early_skip=False):
                J.global_atomic_pk_add_bf16(address,words[0],Y)


def emit_lds_coalesced(J,accum,blocks,token,routing,Y,B,N,BN,NW,wave_n,lane,sparse=False):
    """Combine adjacent 16-column fragments into full cache-line writes.

    Every wave owns its LDS slice. Wait for its writes before reading that
    slice; no workgroup barrier or inter-wave dependency is introduced.
    """
    if sparse:
        # Canonical expert tiles pack valid rows before sentinel padding.
        # Every row occurs in four MFMA lane groups.
        J.v_cmp_lt_u32('vcc',token,B)
        valid_mask=J.gpr(2,'su32');J.s_mov_b64(valid_mask,'vcc')
        active_rows=J.gpr('su32');J.s_bcnt1_i32_b64(active_rows,valid_mask)
        active_rows[:]=active_rows[0]//4
    cols=blocks*16
    assert cols in (32,64,128)
    base=J.alloc_lds(NW*16*cols*2,align=16)
    wave=J.gpr(J.threadIdx.x[0]//64)
    row=J.gpr(lane[0]%16);part=J.gpr(lane[0]//16)
    wave_base=J.gpr(wave[0]*(16*cols*2)+base)
    # The non-sparse path emits four setup instructions after the final
    # fragment MFMAs; fill the remainder of the eight-slot result delay.
    if not sparse and blocks < 5:J.s_nop(4-blocks)
    for n in range(blocks):
        packed=J.gpr(2,'vbf16x2')
        for i in range(4):accum[n,i]*=routing[0]
        J.v_cvt_pk_bf16_f32(packed[0],accum[n,0],accum[n,1])
        J.v_cvt_pk_bf16_f32(packed[1],accum[n,2],accum[n,3])
        swizzle=J.gpr((row[0]^(n*4+part[0]))%(cols//4))
        address=J.gpr(wave_base[0]+row[0]*(cols*2)+swizzle[0]*8)
        J.ds_write_b64(address,packed)
    J.s_waitcnt(mod='lgkmcnt(0)')
    pair=J.gpr(lane[0]%(cols//2));rows_per_wave=64//(cols//2)
    def emit_chunk(chunk):
        rdrow=J.gpr(lane[0]//(cols//2)+chunk*rows_per_wave)
        swizzle=J.gpr((rdrow[0]^(pair[0]//2))%(cols//4))
        address=J.gpr(wave_base[0]+rdrow[0]*(cols*2)+swizzle[0]*8+(pair[0]%2)*4)
        word=J.gpr('vu32');target=J.gpr('vu32')
        J.ds_read_b32(word,address)
        J.ds_bpermute_b32(target,rdrow[0]*4,token)
        J.s_waitcnt(mod='lgkmcnt(0)')
        dst=J.gpr((target[0]*N+J.blockIdx.x[0]*BN+wave_n+pair[0]*2)*2)
        with J.ExecMask(target[0]<B[0],early_skip=False):J.global_atomic_pk_add_bf16(dst,word,Y)
    for chunk in range(16//rows_per_wave):
        if sparse:
            with J.If(active_rows[0]>chunk*rows_per_wave):emit_chunk(chunk)
        else:emit_chunk(chunk)
