# SPDX-License-Identifier: MIT
"""Replicate direct routing/input quantization in the parallel G1 producer.

Each CTA only packs its split's input slice, resolves its direct expert in LDS,
and publishes metadata from one designated CTA per token. G1 collectively
zeros the output before the dependent G2 launch. There is no grid barrier.
"""
from dataclasses import dataclass
from marlowe_kernels._runtime import jit
from .block_fused import Coordinates,pointer
from .consumer_program import ConsumerProgram,ConsumerConfig,ConsumerCoordinates
from .native_prefetch import prefetch_projection
from .native_prepare import pack_fp4
from .prepare import topk


@dataclass(frozen=True)
class InlineConfig(ConsumerConfig):
    fuse_middle: bool=True
    overlap_weights: bool=False
    route_preload: bool=False
    gate_axis: str='xyz'
    reuse_probabilities: bool=False
    pair_depth: int=0
    slot_routing: bool=False
    packed_input_scales: bool=False


class InlineCoordinates(ConsumerCoordinates):
    def address(self,kind,offset):
        if kind=='mid':value=self.input_packed_delta[0]+offset
        else:value=self.input_scale_delta[0]+offset
        return self.J.gpr('vu32',value)
    def s_load_dword(self,dst,base,offset,**kw):
        if id(base)==self.expert_pointer:
            return self.J.s_mov_b32(dst,self.expert)
        return self.J.s_load_dword(dst,base,offset,**kw)


class RoutingCoordinates(Coordinates):
    def __init__(self,*args,ids,rw,base,publish,**kw):
        super().__init__(*args,**kw)
        self.ids,self.rw,self.base,self.publish=ids,rw,base,publish
    def global_store_dword(self,offset,value,base,mod=''):
        kind=0 if id(base)==id(self.ids) else 36
        # Top-k stores token*9+lane. Strip token to retain one local route row.
        lane=self.threadIdx.x[0]%64
        address=self.J.gpr('vu32',self.base+kind+lane*4)
        self.J.ds_write_b32(address,value)
        with self.J.ExecMask(self.publish,early_skip=False):
            self.J.global_store_dword(offset,value,base,mod=mod)


@jit()
def inline_gate(J,B,BN,SK,NT,DEPTH,SUPPLIED,DEBUG,PRELOAD,AXIS,REUSE,PAIR_DEPTH,SLOT_ROUTING,PACKED_INPUTS,
    L:'void*',C:'void*',X:'void*',SI:'void*',SW:'void*',
    IDS:'void*',RW:'void*',OUT:'void*',W:'void*',WS:'void*',PART:'void*',MID:'void*',MS:'void*'):
    from pyhip.core.mem_allocator import SimpleMemoryAllocator
    assert J.gfx==950 and BN in (32,64) and SK>1 and 48%SK==0
    J.lds_allocator=SimpleMemoryAllocator(160*1024)
    slice_k=6144//SK
    ng=512//BN;clear_bytes=12288//(ng*SK)
    assert clear_bytes%16==0
    route_base=slice_k//2+slice_k//32
    J.alloc_lds(route_base+80,align=16)
    assert sorted(AXIS)==['x','y','z']
    if AXIS!='xyz':
        axes=dict(zip(AXIS,(J.blockIdx.x,J.blockIdx.y,J.blockIdx.z)))
        J=Coordinates(J,'inline_axis_',axes['x'],axes['y'],axes['z'],J.threadIdx.x)
    lane=J.gpr(J.threadIdx.x[0])
    token=J.gpr('su32',J.blockIdx.y[0]//9)
    slot=J.gpr('su32',J.blockIdx.y[0]-token[0]*9)
    publish_s=J.gpr('su32',J.blockIdx.x[0]|J.blockIdx.z[0]|slot[0])
    publish=J.gpr('vu32',publish_s[0])[0]==0
    slot_v=J.gpr('vu32',slot[0])
    input_base=J.gpr('su32',token[0]*6144+J.blockIdx.z[0]*slice_k)
    output_base=J.gpr('su32',token[0]*12288+(J.blockIdx.z[0]*ng+J.blockIdx.x[0])*clear_bytes)
    input_packed_base=J.gpr('su32',token[0]*3072+J.blockIdx.z[0]*(slice_k//2))
    input_scale_base=J.gpr('su32',token[0]*192+J.blockIdx.z[0]*(slice_k//32))
    shared_offset=J.gpr('su32',(token[0]*9+8)*4)
    # The CTA packs exactly the K slice it will consume.
    for chunk in range((slice_k+1023)//1024):
        index=J.gpr(lane[0]+chunk*64)
        with J.ExecMask(index[0] < slice_k//16,early_skip=False):
            data=J.gpr(8,'vu32')
            offset=J.gpr('vu32',(input_base[0]+index[0]*16)*2)
            for part in (0,4):J.global_load_dwordx4(data[part:part+3],offset[0]+part*4,X)
            J.s_waitcnt(mod='vmcnt(0)')
            values=[]
            for i in range(8):values.extend([J.gpr(data[i]<<16),J.gpr(data[i]&0xffff0000)])
            codes,exponent=pack_fp4(J,values,(1,),False)
            encoded=J.gpr(2,'vu32',0)
            for i,code in enumerate(codes):encoded[i//4]=encoded[i//4]|(code[0]<<(8*(i%4)))
            J.ds_write_b64(J.gpr('vu32',index[0]*8),encoded)
            with J.ExecMask(lane[0]%2==0,early_skip=False):
                J.ds_write_b8(J.gpr('vu32',slice_k//2+index[0]//2),exponent)
    J.Label('inline_routing_begin')
    expert=J.gpr('su32',256)
    if SLOT_ROUTING:
        J.Jump('inline_full_metadata',publish_s[0]==0)
        if SUPPLIED:
            J.Jump('inline_routing_complete',slot[0]==8)
            J.s_load_dword(expert,SI,(token[0]*8+slot[0])*4)
            J.s_waitcnt(mod='lgkmcnt(0)')
        else:
            from .slot_topk import select_slot
            selected=select_slot(J,L,C,token[0],slot,preload=PRELOAD)
            expert[:]=selected[0]
        J.Jump('inline_routing_complete')
        J.Label('inline_full_metadata')
    route=RoutingCoordinates(J,'route_',J.blockIdx.x,J.blockIdx.y,J.blockIdx.z,J.threadIdx.x,
        ids=IDS,rw=RW,base=route_base,publish=publish)
    if SUPPLIED:
        with J.ExecMask(lane[0]<8,early_skip=False):
            ids=J.gpr('vu32');rw=J.gpr('vf32')
            J.global_load_dword(ids,J.gpr('vu32',(token[0]*8+lane[0])*4),SI)
            J.global_load_dword(rw,J.gpr('vu32',(token[0]*8+lane[0])*4),SW)
            J.s_waitcnt(mod='vmcnt(0)')
            route.global_store_dword(J.gpr('vu32',(token[0]*9+lane[0])*4),ids,IDS)
            route.global_store_dword(J.gpr('vu32',(token[0]*9+lane[0])*4),rw,RW)
    elif REUSE:
        from .reuse_topk import reuse_topk
        reuse_topk(route,L,C,IDS,RW,token[0],preload=PRELOAD)
    else:topk(route,L,C,IDS,RW,token[0],preload=PRELOAD)
    # Use lane zero and explicit addresses. The emitter's common-expression
    # cache is not ExecMask-aware, so reusing top-k's lane<8 addresses in lane8
    # would read undefined registers.
    with J.ExecMask(lane[0]==0,early_skip=False):
        shared_id=J.gpr('vu32',256);shared_weight=J.gpr('vf32',1.)
        J.ds_write_b32(J.gpr('vu32',route_base+32),shared_id)
        J.ds_write_b32(J.gpr('vu32',route_base+68),shared_weight)
        with J.ExecMask(publish,early_skip=False):
            dst=J.gpr('vu32',shared_offset[0])
            J.global_store_dword(dst,shared_id,IDS)
            J.global_store_dword(dst,shared_weight,RW)
    J.s_waitcnt(mod='lgkmcnt(0) vmcnt(0)')
    expert_v=J.gpr('vu32')
    J.ds_read_b32(expert_v,J.gpr('vu32',route_base+slot[0]*4))
    J.s_waitcnt(mod='lgkmcnt(0)')
    J.v_readfirstlane_b32(expert,expert_v)
    if SLOT_ROUTING:J.Label('inline_routing_complete')
    # Every split/feature CTA for slot zero participates in output clearing,
    # including those taking the shortened routing path.
    with J.ExecMask((slot_v[0]==0)&(lane[0] < clear_bytes//16),early_skip=False):
        offset=J.gpr('vu32',output_base[0]+lane[0]*16)
        J.global_store_dwordx4(offset,J.gpr(4,'vu32',0),OUT)
    if DEBUG:
        with J.ExecMask(lane[0]==0,early_skip=False):
            dst=J.gpr('vu32',((J.blockIdx.z[0]*B*9+J.blockIdx.y[0])*ng+J.blockIdx.x[0])*4)
            J.global_store_dword(dst,J.gpr('vu32',expert[0]),PART)
        return
    # End the routing basic block so the pinned emitter cannot reuse an
    # address computed under lane<8 for all-lane matrix weight loads.
    J.Label('inline_matrix_begin')
    xp,xs,ep=pointer(J,MID),pointer(J,MS),pointer(J,IDS)
    ctx=InlineCoordinates(J,'gate_',J.blockIdx.x,J.blockIdx.y,J.blockIdx.z,J.threadIdx.x,
        mapping=[(xp,'mid'),(xs,'scale')],B=B,rows=1,partial_base=0,mid_base=0,scale_base=slice_k//2)
    ctx.slice_k=slice_k;ctx.expert_pointer=id(ep);ctx.expert=expert;ctx.vmem_per_stage=2+2*(BN//16)
    ctx.input_packed_delta=J.gpr('su32',0-input_packed_base[0])
    ctx.input_scale_delta=J.gpr('su32',slice_k//2-input_scale_base[0])
    if PAIR_DEPTH:
        from .native_pairprefetch import paired_projection
        ctx.packed_input_scales=PACKED_INPUTS
        ctx.vmem_inputs_per_stage=3 if PACKED_INPUTS else 4
        ctx.vmem_per_stage=ctx.vmem_inputs_per_stage+3*(BN//16)
        paired_projection.gen_func(ctx,6144,512,BN,True,SK,B in (1,4,8,32),1,True,True,NT,PAIR_DEPTH,'wave',
            xp,xs,pointer(J,W),pointer(J,WS),pointer(J,PART),pointer(J,MS),
            pointer(J,IDS),pointer(J,RW),ep,pointer(J,IDS),J.gpr('su32',B))
    else:
        prefetch_projection.gen_func(ctx,6144,512,BN,True,SK,B in (1,4,8,32),1,True,True,NT,DEPTH,
            xp,xs,pointer(J,W),pointer(J,WS),pointer(J,PART),pointer(J,MS),
            pointer(J,IDS),pointer(J,RW),ep,pointer(J,IDS),J.gpr('su32',B))


class InlineProgram(ConsumerProgram):
    def __init__(self,owner,batch,config=InlineConfig()):
        # Extra policy fields are not emitter configuration.
        self.ic=config
        super().__init__(owner,batch,ConsumerConfig(**{k:v for k,v in config.__dict__.items() if k not in ('fuse_middle','overlap_weights','route_preload','gate_axis','reuse_probabilities','pair_depth','slot_routing','packed_input_scales')}))
        assert config.gate_n in (32,64) and config.gate_waves==1 and config.split_k>1 and 48%config.split_k==0
        assert not config.packed_input_scales or config.pair_depth>0
        self.info.update(algorithm='inline direct route/input pack G1 + local split-reduce G2')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        from .consumer_program import consumer_down
        from .native_prepare import middle_packed
        b,c,p=self.b,self.cc,self.p
        output=p['output'] if out is None else out
        shape=dict(x=512//c.gate_n,y=self.grid,z=c.split_k)
        inline_gate([shape[axis] for axis in self.ic.gate_axis],[64],b,c.gate_n,c.split_k,c.non_temporal,c.depth or 2,supplied_ids is not None,False,self.ic.route_preload,self.ic.gate_axis,self.ic.reuse_probabilities,self.ic.pair_depth,self.ic.slot_routing,self.ic.packed_input_scales,
            logits.data_ptr(),bias.data_ptr(),x.data_ptr(),0 if supplied_ids is None else supplied_ids.data_ptr(),
            0 if supplied_weights is None else supplied_weights.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
            output.data_ptr(),self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),
            self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr())
        if self.ic.overlap_weights:
            from .overlap_consumer import OverlapProgram
            assert self.ic.fuse_middle
            OverlapProgram._stage(self,self.partial,self.mid_scale.data_ptr(),output,False)
        elif self.ic.fuse_middle:
            consumer_down([6144//c.down_n,self.grid],[64*c.down_waves],b,c.down_n,c.down_waves,c.split_k,
                self.fp32_middle,c.non_temporal,c.down_depth or 2,c.combine,self.partial.data_ptr(),
                self.mid.data_ptr(),self.mid_scale.data_ptr(),self.owner.w2.data_ptr(),
                self.owner.weights.w2_scale.data_ptr(),output.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr())
        else:
            from .coalesced_program import CoalescedProgram
            middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
            CoalescedProgram._stage(self,self.mid,self.mid_scale.data_ptr(),output,False)
        return output
