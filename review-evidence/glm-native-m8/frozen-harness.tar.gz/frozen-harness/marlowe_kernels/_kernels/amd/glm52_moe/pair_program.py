# SPDX-License-Identifier: MIT
"""Opt-in paired-K load pipeline for the B8 route-merged program."""
from dataclasses import dataclass
from .coalesced_program import CoalescedProgram,CoalescedConfig
from .native_pairprefetch import paired_projection

@dataclass(frozen=True)
class PairConfig(CoalescedConfig):
    direct: str='merge8'
    dispatch: bool=False
    pair_depth: int=3
    pair_g2: bool=False
    route_preload: bool=False
    share_n_scales: bool=False
    stream_weights: bool=False
    packed_input_scales: bool=False

class PairProgram(CoalescedProgram):
    def __init__(self,owner,batch,config=PairConfig()):
        assert config.direct and not config.dispatch and (48//config.split_k)%2==0
        self.pc=config
        super().__init__(owner,batch,CoalescedConfig(**{k:v for k,v in config.__dict__.items() if k not in ('pair_depth','pair_g2','route_preload','share_n_scales','stream_weights','packed_input_scales')}))
        self.info.update(config=config.__dict__,algorithm='paired K128 weight-scale loads')
    def _stage(self,inp,scale,out,first):
        if (first and self.pc.pair_depth==0) or (not first and not self.pc.pair_g2):return super()._stage(inp,scale,out,first)
        c,p,b=self.c,self.p,self.b
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1
        w,s=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        emit=paired_projection
        if self.pc.share_n_scales:
            from .native_pairprefetch_n import paired_n_projection
            emit=paired_n_projection
        if self.pc.stream_weights:
            assert not self.pc.share_n_scales
            from .native_pairprefetch_stream import streamed_projection
            emit=streamed_projection
        if self.pc.packed_input_scales:
            assert not self.pc.share_n_scales and not self.pc.stream_weights
            from .native_pairprefetch import packed_input_projection
            emit=packed_input_projection
        emit([n//bn,self.grid,sk],[64*nw],k,n,bn,first,sk,self.fp32_middle,nw,c.direct,True,c.non_temporal,self.pc.pair_depth,c.combine if hasattr(c,'combine') else self.cc.combine,
            inp.data_ptr(),scale,w.data_ptr(),s.data_ptr(),out.data_ptr(),self.mid_scale.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),p['ids'].data_ptr(),p['ids'].data_ptr(),b)

    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        if not self.pc.route_preload:
            return super().run(x,logits,bias,out=out,supplied_ids=supplied_ids,supplied_weights=supplied_weights)
        from .preloaded_prepare import preloaded_phase1
        from .native_prepare import middle_packed
        b,c,p=self.b,self.cc,self.p;output=p['output'] if out is None else out
        preloaded_phase1([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
            p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),0 if supplied_ids is None else supplied_ids.data_ptr(),
            0 if supplied_weights is None else supplied_weights.data_ptr(),supplied_ids is not None,getattr(self,'router_fp32',False))
        self._stage(p['packed'],p['workspace'].data_ptr()+256,self.partial,True)
        if c.split_k>1:middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
        self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
        return output
