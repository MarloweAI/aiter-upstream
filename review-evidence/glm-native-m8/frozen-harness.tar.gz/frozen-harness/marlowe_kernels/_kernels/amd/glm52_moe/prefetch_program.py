# SPDX-License-Identifier: MIT
"""Isolate deep prefetch from fusion/scheduling overhead."""
from dataclasses import dataclass
from .native_program import NativeProgram,NativeConfig
from .native_prefetch import prefetch_projection

@dataclass(frozen=True)
class PrefetchConfig:
    direct: bool=False
    gate_n: int=64
    gate_waves: int=1
    down_n: int=128
    down_waves: int=2
    split_k: int=2
    non_temporal: bool=True
    depth: int=4
    down_depth: int=0

class PrefetchProgram(NativeProgram):
    def __init__(self,owner,batch,config=PrefetchConfig()):
        self.pc=config
        d={k:v for k,v in config.__dict__.items() if k not in ('depth','down_depth')}
        super().__init__(owner,batch,NativeConfig(**d))
        self.info=dict(config=config.__dict__)
    def _stage(self,inp,inp_scale,out,first):
        depth=self.pc.depth if first else self.pc.down_depth
        if not depth:return super()._stage(inp,inp_scale,out,first)
        p,c,b=self.p,self.c,self.b
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                        (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1
        w,ws=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        prefetch_projection([n//bn,self.grid,sk],[64*nw],
            k,n,bn,first,sk,self.fp32_middle,nw,c.direct,True,c.non_temporal,depth,
            inp.data_ptr(),inp_scale,w.data_ptr(),ws.data_ptr(),out.data_ptr(),
            self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b)
