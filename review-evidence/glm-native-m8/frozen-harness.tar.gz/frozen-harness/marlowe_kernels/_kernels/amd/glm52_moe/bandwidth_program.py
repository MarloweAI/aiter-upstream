# SPDX-License-Identifier: MIT
"""Default Port-EW selections from the September20 bandwidth investigation.

The percentage target names the investigation, not an achieved utilization.
Each entry preserves the existing batch's intermediate rounding contract.
B1 passes its own references; the historical AITER comparison remains diagnostic.
"""

BANDWIDTH_REVISION = 'bw75-20260920-isa-safe-overlap'

INLINE_COMMON = dict(direct=True, gate_n=64, gate_waves=1, split_k=6,
    depth=4, down_depth=2, non_temporal=True, fuse_middle=True,
    overlap_weights=True, route_preload=True, gate_axis='xyz',
    slot_routing=True, pair_depth=4)

OVERLAP_COMMON = dict(INLINE_COMMON, dispatch=False, combine='wave',
    reuse_probabilities=False, pack_overlap=True, prefetch_input=False,
    drain_before=False, predecode_scales=True)

BANDWIDTH_CONFIGS = {
    1: dict(family='overlap_g1', config=dict(OVERLAP_COMMON, down_n=256, down_waves=4)),
    2: dict(family='overlap_g1', config=dict(OVERLAP_COMMON, down_n=512, down_waves=8)),
    4: dict(family='overlap_g1', config=dict(OVERLAP_COMMON, down_n=256, down_waves=4)),
    8: dict(family='pair', config=dict(direct='merge8', dispatch=False,
        gate_n=64, gate_waves=1, split_k=1, depth=6,
        down_n=64, down_waves=1, down_depth=2, non_temporal=True,
        combine='lds_sparse', pair_depth=3, pair_g2=False, route_preload=True)),
    16: dict(family='safe_fixed', config=dict(direct=False, dispatch=True,
        gate_n=64, gate_waves=1, split_k=1, depth=6,
        down_n=64, down_waves=1, down_depth=2, non_temporal=True,
        combine='lds_sparse', pair_depth=2, pair_g2=False, route_preload=True,
        ordered_supplied=True, ordered_all=False)),
    32: dict(family='safe_fixed', config=dict(direct=False, dispatch=True,
        gate_n=64, gate_waves=1, split_k=1, depth=6,
        down_n=64, down_waves=1, down_depth=2, non_temporal=True,
        combine='lds_sparse', pair_depth=4, pair_g2=False, route_preload=True,
        ordered_supplied=True, ordered_all=False)),
    64: dict(family='safe_fixed', config=dict(direct=False, dispatch=True,
        gate_n=64, gate_waves=1, split_k=1, depth=6,
        down_n=64, down_waves=1, down_depth=2, non_temporal=True,
        combine='lds_sparse', pair_depth=4, pair_g2=True, route_preload=True,
        packed_input_scales=True, ordered_supplied=True, ordered_all=False)),
    128: dict(family='safe_fixed', config=dict(direct=False, dispatch=True,
        gate_n=64, gate_waves=1, split_k=1, depth=6,
        down_n=64, down_waves=1, down_depth=2, non_temporal=True,
        combine='lds_sparse', pair_depth=4, pair_g2=True, route_preload=True,
        packed_input_scales=True, ordered_supplied=True, ordered_all=False)),
}


def create_bandwidth_program(owner, batch):
    if batch not in BANDWIDTH_CONFIGS:
        from .selected_program import create_selected_program
        return create_selected_program(owner, batch)
    entry=BANDWIDTH_CONFIGS[batch]
    if entry['family']=='overlap_g1':
        from .overlap_gate import OverlapG1Program,OverlapG1Config
        return OverlapG1Program(owner,batch,OverlapG1Config(**entry['config']))
    if entry['family']=='inline':
        from .safe_inline_program import SafeInlineProgram,InlineConfig
        return SafeInlineProgram(owner,batch,InlineConfig(**entry['config']))
    if entry['family']=='pair':
        from .safe_pair_program import SafePairProgram,PairConfig
        return SafePairProgram(owner,batch,PairConfig(**entry['config']))
    if entry['family']=='safe_fixed':
        from .safe_fixed_program import SafeFixedProgram,SafeFixedConfig
        return SafeFixedProgram(owner,batch,SafeFixedConfig(**entry['config']))
    raise ValueError(f"Unknown bandwidth experiment family {entry['family']}")


def create_fp32_bandwidth_program(owner, batch):
    """Use the selected expert kernels with FP32 logits and correction bias."""
    program=create_bandwidth_program(owner,batch)
    program.router_fp32=True
    program.info['router_logits_dtype']='float32'
    return program
