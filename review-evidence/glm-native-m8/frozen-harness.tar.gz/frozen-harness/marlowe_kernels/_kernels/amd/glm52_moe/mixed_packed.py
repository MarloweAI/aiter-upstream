# SPDX-License-Identifier: MIT
"""Existing BF16 G1 arithmetic with packed epilogue and native FP4 G2."""
from dataclasses import dataclass,replace
import torch
from marlowe_kernels._runtime import jit
from .program import Program
from .native_program import NATIVE_CONFIGS
from .native_fp4 import native_projection
from .native_prefetch import prefetch_projection
from .native_prepare import middle_packed
from .prepare import phase1,phase23
from .experts import emit_moe_stage
from .block_fused import pointer
from .fused_dispatch import DispatchProgram,DispatchConfig,dispatch_prepare,valid_pointer,clear_next

@dataclass(frozen=True)
class MixedConfig:
    direct: bool=False
    dispatch: bool=True
    down_n: int=128
    down_waves: int=2
    down_depth: int=2
    gate_split: int=0
    gate_schedule: int=-1
    gate_n: int=0

@jit()
def packed_gate(J,WD,K,N,BN,SK,SCHEDULE,FP32,NT,DIRECT,DISPATCH,MAXIMUM,
                X:'void*',W:'void*',Y:'void*',YS:'void*',IDS:'void*',RW:'float*',EXP:'void*',STATE:'void*',WS:'float*',B:'int'):
    if DISPATCH:
        valid,which=valid_pointer(J,STATE)
        ids=pointer(J,IDS,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    else:valid,ids,rw=STATE,IDS,RW
    emit_moe_stage(J,WD,9,K,N,True,16,BN,X,W,Y,ids,rw,EXP,valid,WS,B,
        False,DIRECT,False,NT,True,False,SK,False,schedule=SCHEDULE,fp32_activation=FP32,
        packed_output_scale=YS if SK==1 else None)

@jit()
def packed_down(J,BN,NW,DIRECT,DISPATCH,DEPTH,BATCH,MAXIMUM,
                X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    if DISPATCH:
        valid,which=valid_pointer(J,STATE)
        ids=pointer(J,IDS,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    else:valid,ids,rw=STATE,IDS,RW
    if DEPTH:prefetch_projection.gen_func(J,256,6144,BN,False,1,False,NW,DIRECT,True,True,DEPTH,X,XS,W,WS,Y,XS,ids,rw,EXP,valid,B)
    else:native_projection.gen_func(J,256,6144,BN,False,1,False,NW,DIRECT,True,True,X,XS,W,WS,Y,XS,ids,rw,EXP,valid,B)
    if DISPATCH:clear_next(J,STATE,IDS,RW,BATCH,64*NW,6144//BN,MAXIMUM)

class MixedProgram(DispatchProgram):
    def __init__(self,owner,batch,config=MixedConfig()):
        self.mc=config
        if config.dispatch:super().__init__(owner,batch,DispatchConfig(bf16=True))
        else:
            Program.__init__(self,owner,batch)
            self.maximum=self.p['sorted_ids'].numel()
            self.state=self.p['valid']
        self.c=replace(self.c,split_k=config.gate_split or self.c.split_k,
                       gate_schedule=self.c.gate_schedule if config.gate_schedule<0 else config.gate_schedule,
                       gate_n=config.gate_n or self.c.gate_n)
        assert self.c.split_k in (1,2,3,6)
        self.mid=torch.empty((batch,9,128),device=owner.device,dtype=torch.uint8)
        self.mid_scale=torch.empty((batch,9,8),device=owner.device,dtype=torch.uint8)
        self.partial=(self.mid if self.c.split_k==1 else
                      torch.empty((self.c.split_k,batch,9,512),device=owner.device,dtype=torch.float32))
        self.info=dict(config=config.__dict__,gate_config=self.c.__dict__,arithmetic='BF16 G1 -> exact packed MXFP4 -> native FP4 G2')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.c,self.p;mc=self.mc;output=p['output'] if out is None else out
        si=0 if supplied_ids is None else supplied_ids.data_ptr();sw=0 if supplied_weights is None else supplied_weights.data_ptr()
        if mc.dispatch:
            dispatch_prepare([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
                p['packed'].data_ptr(),p['workspace'].data_ptr(),p['qdq'].data_ptr(),output.data_ptr(),si,sw,
                self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),0,b,True,self.maximum,False,True,supplied_ids is not None)
        else:
            phase1([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
                p['packed'].data_ptr(),p['workspace'].data_ptr(),p['qdq'].data_ptr(),output.data_ptr(),si,sw,supplied_ids is not None,True)
            if not c.direct:
                phase23([self.group_grid],[384],p['ids'].data_ptr(),p['weights'].data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),
                    p['experts'].data_ptr(),p['valid'].data_ptr(),b,self.group_grid,p['sorted_ids'].numel())
        ids,rw,exp=((p['ids'],p['weights'],p['ids']) if c.direct else (p['sorted_ids'],p['sorted_weights'],p['experts']))
        packed_gate([512//c.gate_n,self.grid,c.split_k],[256],self.owner.w13.dtype,6144,512,c.gate_n,c.split_k,c.gate_schedule,
            self.fp32_middle,c.non_temporal,c.direct,mc.dispatch,self.maximum,p['qdq'].data_ptr(),self.owner.w13.data_ptr(),self.partial.data_ptr(),
            self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),self.state.data_ptr(),self.owner.weights.w13_scale.data_ptr(),b)
        if c.split_k>1:middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
        packed_down([6144//mc.down_n,self.grid],[64*mc.down_waves],mc.down_n,mc.down_waves,c.direct,mc.dispatch,mc.down_depth,b,self.maximum,
            self.mid.data_ptr(),self.mid_scale.data_ptr(),self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),output.data_ptr(),
            ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),self.state.data_ptr(),b)
        return output
