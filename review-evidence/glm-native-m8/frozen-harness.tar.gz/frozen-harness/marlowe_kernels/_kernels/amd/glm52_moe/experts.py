# Derived from PyHIP 270225149dec3436923959554f50f363bf7057cf, MIT; see PYHIP-LICENSE.
from pyhip import JIT
from marlowe_kernels._runtime import jit
import torch
from pyhip.contrib.moe import get_lane_id_mod, get_lane_id_div, div_up, USE_FP4_SHUFFLE_WEIGHT
from .gemm import gemm_splitk

def emit_moe_stage(J:JIT,
                      wd,
                      tk,
                      K,            # compile-time args
                      N,            # compile-time args
                      act,    # compile-time args
                      bm,
                      bn,
                      p_input:"void*",
                      p_weight:"void*",
                      p_output:"void*",
                      # sorted_ids, sorted_weights, sorted_expert_ids, num_valid_ids
                      p_sorted_ids:"void*",
                      p_sorted_weights:"float*",
                      p_sorted_expert_ids:"void*",
                      p_num_valid_ids:"void*",
                      p_w_scale:"float*",
                      M:"int",
                      pt,
                      dr,
                      em,
                      nt,
                      lds,
                      fc,
                      sk,
                      sw, queued=False, task_stride=0, prefix="", schedule=0, fp32_activation=False,
                      fuse_middle=False, row_count_queue=False, packed_output_scale=None):
    # PyHIP embeds compile-time parameter names in compiler filenames.
    weight_dtype, TOPK, with_silu = wd, tk, act
    BLOCK_TILE_SIZE_M, BLOCK_TILE_SIZE_N = bm, bn
    fp8_ptpc, direct, expert_major, non_temporal = pt, dr, em, nt
    use_lds, fp32_combine, split_k = lds, fc, sk
    fp4_split = with_silu and weight_dtype == torch.float4_e2m1fn_x2 and split_k > 1
    fp4_k_work = K // split_k if fp4_split else K
    if fp4_split:
        assert K % split_k == 0 and fp4_k_work % 1024 == 0
    assert weight_dtype == torch.bfloat16 or weight_dtype == torch.float4_e2m1fn_x2 or weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz
    if weight_dtype == torch.float4_e2m1fn_x2:
        if with_silu:
            assert BLOCK_TILE_SIZE_N % 64 == 0, f'due to scale is packed with [2*16, 8*32], gate/up each needs 2*16 rows; current BLOCK_TILE_SIZE_N={BLOCK_TILE_SIZE_N} is not supported'
            assert K % 1024 == 0, f'will read (16*4)*4(wave) bytes once in main loop, aka 256*2=512 elements; to use packed scale in K dimension, will double read; current K={K} is not supported'
        else:
            assert BLOCK_TILE_SIZE_N % 32 == 0, f'due to scale is packed with [2*16, 8*32], current BLOCK_TILE_SIZE_N={BLOCK_TILE_SIZE_N} is not supported'
            assert K % 32 == 0, f'will read 16*4 bytes once in main loop, aka 64*2=128 elements; tails support K%32==0; current K={K} is not supported'
    elif weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz:
        if fp8_ptpc:
            assert K % 64 == 0, f'will read 16*4 bytes once in main loop, aka 64 elements; current K={K} is not supported'
        else:
            assert K % (256 if with_silu else 64) == 0, f'fp8 blockwise K{K} should be multiple of {256 if with_silu else 64}, {with_silu=}'
    else:
        assert K % 32 == 0, f'will read 16*4 bytes once in main loop, aka 64/2=32 elements; current K={K} is not supported'
    assert BLOCK_TILE_SIZE_M % 16 == 0
    assert BLOCK_TILE_SIZE_N % 32 == 0
    assert N % BLOCK_TILE_SIZE_N == 0

    use_split_k = with_silu
    num_split_k = 4 if use_split_k else 1
    BLOCK_TILE_SIZE_N_HALF = BLOCK_TILE_SIZE_N // 2

    sizeof_bf16 = 2
    sizeof_f32 = 4
    def get_k_bytes(k_in_elements):
        if weight_dtype == torch.bfloat16:
            return k_in_elements * sizeof_bf16
        elif weight_dtype == torch.float4_e2m1fn_x2:
            return k_in_elements // 2
        elif weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz:
            return k_in_elements
    stride_A = K * sizeof_bf16
    stride_B = get_k_bytes(K)

    A_vert = BLOCK_TILE_SIZE_M // 16
    B_horz = BLOCK_TILE_SIZE_N // 16
    # Default down-projection result would be atomic_add into global GPU memory without LDS without memory coalescing opt.
    down_proj_with_lds = False
    # optimize down-projection store with limited BLOCK_TILE_SIZE_N for easiness.
    if use_lds and (BLOCK_TILE_SIZE_N ==64 or BLOCK_TILE_SIZE_N ==128):
        down_proj_with_lds = True

    C_reg = J.gpr(B_horz, A_vert, 4, "vf32")


    # Optional expert-major launch ordering, compile-time constant.
    if expert_major:
        block_n = J.blockIdx.y
        block_e = J.blockIdx.x
    else:
        block_n = J.blockIdx.x
        block_e = J.blockIdx.y
    # expert index in p_sorted_expert_ids
    e_idx = J.gpr(block_e[0]) if queued else block_e
    if queued:
        # Fixed-size grid traverses compact GPU-generated queues; no host count read.
        task_count = J.gpr(1, 'su32')
        J.s_load_dword(task_count, p_num_valid_ids, 0)
        J.s_waitcnt(mod="lgkmcnt(0)")
        if row_count_queue:
            task_count[:] = task_count[0] // BLOCK_TILE_SIZE_M
        J.Jump(prefix + "queue_active", e_idx < task_count)
        J.s_endpgm()
        J.Label(prefix + "queue_active")
        pointers = [p_sorted_ids, p_sorted_weights, p_w_scale, p_output, p_weight]
        bases = [J.gpr(2, 'su32') for _ in pointers]
        for base, pointer in zip(bases, pointers):
            J.s_mov_b64(base, pointer)
        J.Label(prefix + "queue_task")
        for pointer, base in zip(pointers, bases):
            J.s_mov_b64(pointer, base)

    def finish_task():
        if queued and task_stride:
            # Keep the back edge in a distinct basic block: PyHIP's register
            # allocator extends loop-carried lifetimes across this edge.
            J.Label(prefix + "queue_next")
            J.s_waitcnt(mod="vmcnt(0) lgkmcnt(0)")
            J.s_barrier()
            e_idx[:] += task_stride
            J.Jump(prefix + "queue_task", e_idx < task_count)

    C_reg[:] = 0
    s_e_id = J.gpr(1, 'su32')
    J.s_load_dword(s_e_id, p_sorted_expert_ids, e_idx[0] * 4)
    if not direct and not queued:
        max_id = J.gpr(1, 'su32')
        J.s_load_dword(max_id, p_num_valid_ids, 0)
        J.s_waitcnt(mod="lgkmcnt(0)")
        J.Jump(prefix + "continue_following", e_idx * BLOCK_TILE_SIZE_M < max_id)
        J.s_endpgm()
        J.Label(prefix + "continue_following")
    else:
        if direct:
            assert BLOCK_TILE_SIZE_M == 16
        J.s_waitcnt(mod="lgkmcnt(0)")

    # hide following initialization into s_waitcnt
    p_sorted_ids[:] += e_idx * (4 if queued and direct else BLOCK_TILE_SIZE_M * 4)
    # one WG per CU,  4 waves split on K
    lane_mod_16 = get_lane_id_mod(J, 16)
    lane_div_16 = get_lane_id_div(J, 16)
    warp_id = J.gpr("su32")
    J.v_readfirstlane_b32(warp_id, J.threadIdx.x[0] // 64)
    if weight_dtype == torch.float4_e2m1fn_x2 and with_silu:
        # Generic vector-expression lowering rejects these non-inline literals.
        # The offsets are uniform across a wave: emit scalar multiplies explicitly.
        fp4_warp_b = J.gpr(1, 'su32')
        fp4_warp_a = J.gpr(1, 'su32')
        fp4_warp_s = J.gpr(1, 'su32')
        J.s_mul_i32(fp4_warp_b, warp_id, 16 * get_k_bytes(fp4_k_work) // 4)
        J.s_mul_i32(fp4_warp_a, warp_id, fp4_k_work // 4 * sizeof_bf16)
        J.s_mul_i32(fp4_warp_s, warp_id, fp4_k_work // 32 // 8 // 4 * 64 * sizeof_f32)

    v_sorted_id = J.gpr(A_vert, 'vu32')
    if direct:
        assert TOPK == 9
        # PyHIP's integer // accepts powers of two only. Exact unsigned /9.
        if queued:
            packed_id = J.gpr(1, 'su32')
            J.s_load_dword(packed_id, p_sorted_ids, 0)
            J.s_waitcnt(mod="lgkmcnt(0)")
            v_sorted_id[0] = packed_id[0]
        else:
            token = J.gpr(1, 'su32')
            J.s_mul_hi_u32(token, e_idx, 0x38E38E39)
            token[0] = token[0] >> 1
            slot = J.gpr(e_idx - token * 9)
            v_sorted_id[0] = (slot << 24) | token
        invalid_id = J.gpr(1, 'su32')
        invalid_id[0] = (TOPK << 24) | M[0]
        # PyHIP lacks __ne__; != would become Python True instead of a mask.
        with J.ExecMask(lane_mod_16 > 0):
            v_sorted_id[0] = invalid_id[0]
    else:
        J.global_load_dword(v_sorted_id[0], lane_mod_16 << 2, p_sorted_ids)
        for n in range(1, A_vert):
            p_sorted_ids[:] += 16 * 4
            J.global_load_dword(v_sorted_id[n], lane_mod_16 << 2, p_sorted_ids)
    voffset_b = J.gpr(B_horz, 'vu32')
    if with_silu:
        if weight_dtype == torch.float4_e2m1fn_x2:
            if USE_FP4_SHUFFLE_WEIGHT:
                # shffled
                voffset_b[0] = (BLOCK_TILE_SIZE_N_HALF * block_n) * stride_B + J.lane_id * 16 + fp4_warp_b
            else:
                # not shuffled
                voffset_b[0] = (BLOCK_TILE_SIZE_N_HALF * block_n + lane_mod_16) * stride_B + lane_div_16 * 16 + J.warp_id * get_k_bytes(K // 4)
        else:
            # shffled
            voffset_b[0] = BLOCK_TILE_SIZE_N_HALF * block_n * stride_B + J.threadIdx.x * 16
        voffset_b[B_horz // 2] = voffset_b[0] + (N // 2) * get_k_bytes(K)
        for m in range(1, B_horz // 2):
            voffset_b[m] = voffset_b[0] + get_k_bytes(K) * 16 * m
            voffset_b[B_horz // 2 + m] = voffset_b[B_horz // 2] + get_k_bytes(K) * 16 * m
    else:
        p_sorted_weights[:] += e_idx * (4 if direct else BLOCK_TILE_SIZE_M * 4)
        if (weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz or weight_dtype == torch.bfloat16) and fp8_ptpc:
            v_weight = J.gpr(A_vert, 2, 'vf32')
            is_v_weight_2d = True
        else:
            is_v_weight_2d = False
            v_weight = J.gpr(A_vert, 'vf32')
        if weight_dtype == torch.float4_e2m1fn_x2:
            if USE_FP4_SHUFFLE_WEIGHT:
                # shffled
                voffset_b[0] = (BLOCK_TILE_SIZE_N * block_n) * stride_B + J.lane_id * 16
            else:
                # not shuffled
                voffset_b[0] = (BLOCK_TILE_SIZE_N * block_n + lane_mod_16) * stride_B + lane_div_16 * 16
        else:
            # shffled
            voffset_b[0] = BLOCK_TILE_SIZE_N * block_n * stride_B + J.threadIdx.x * 16
        if is_v_weight_2d:
            J.global_load_dword(v_weight[0, 0], lane_mod_16 << 2, p_sorted_weights)
        else:
            if direct:
                zero_offset=J.gpr(1,'vu32')
                zero_offset[0]=0
                J.global_load_dword(v_weight[0], zero_offset, p_sorted_weights)
            else:
                J.global_load_dword(v_weight[0], lane_mod_16 << 2, p_sorted_weights)
        for m in range(1, B_horz):
            voffset_b[m] = voffset_b[0] + get_k_bytes(K) * 16 * m
        for m in range(1, A_vert):
            p_sorted_weights[:] += 16 * 4
            if is_v_weight_2d:
                J.global_load_dword(v_weight[m, 0], lane_mod_16 << 2, p_sorted_weights)
            else:
                J.global_load_dword(v_weight[m], lane_mod_16 << 2, p_sorted_weights)

    if packed_output_scale is not None:
        assert with_silu and split_k==1
        p_output[:] += BLOCK_TILE_SIZE_N_HALF*block_n//2
    else:
        p_output[:] = p_output[:] + (BLOCK_TILE_SIZE_N_HALF if with_silu else BLOCK_TILE_SIZE_N) * block_n * (sizeof_f32 if (fp32_combine and not with_silu) or (with_silu and (split_k>1 or (fp32_activation and not fuse_middle))) else sizeof_bf16)

    buff_a = J.Buffer(p_input, M * (K * sizeof_bf16) if with_silu else M * (TOPK * K * sizeof_bf16))

    # wait for v_sorted_id
    J.s_waitcnt(mod=f"vmcnt(0)")
    voffset_a = J.gpr(A_vert, 'vu32')
    v_topk_id = J.gpr(A_vert, 'vu32')
    v_token_id = J.gpr(A_vert, 'vu32')
    # a elements number:
    # bf16: 8 elements
    # fp8: 16 elements
    # fp4: 32 elements
    if weight_dtype == torch.bfloat16:
        a_element_num_per_thread = 8
    elif weight_dtype == torch.float4_e2m1fn_x2:
        a_element_num_per_thread = 32
    elif weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz:
        a_element_num_per_thread = 16
    else:
        raise ValueError(f"Unsupported weight dtype: {weight_dtype}")
    for m in range(A_vert):
        v_token_id[m] = v_sorted_id[m] & 0xffffff
        if with_silu:
            if weight_dtype != torch.float4_e2m1fn_x2:
                voffset_a[m] = J.gpr(v_token_id[m] * stride_A + (J.threadIdx.x // 16) * (a_element_num_per_thread * sizeof_bf16))
            else:
                voffset_a[m] = J.gpr(v_token_id[m] * stride_A + (lane_div_16) * (a_element_num_per_thread * sizeof_bf16) + fp4_warp_a)
        else:
            v_topk_id[m] = v_sorted_id[m] >> 24
            # input layout: [B, TOPK, INTER_MEDIA]
            voffset_a[m] = J.gpr(v_token_id[m] * TOPK * K * sizeof_bf16 + v_topk_id[m] * (K * sizeof_bf16) + (J.threadIdx.x // 16) * (a_element_num_per_thread * sizeof_bf16))

    voffset_scale = None
    if weight_dtype == torch.float4_e2m1fn_x2:
        # 32 rows shared in a uint32
        voffset_scale = J.gpr(B_horz // 2, 'vu32')
        # the group of fp4 is 32 elements, and scale will align to 8 groups
        k_scale_stride = div_up(div_up(K, 32), 8) * 8
        p_w_scale[:] += (BLOCK_TILE_SIZE_N_HALF if with_silu else BLOCK_TILE_SIZE_N) * k_scale_stride * block_n
        if with_silu:
            voffset_scale[0] = J.gpr(s_e_id * (N * k_scale_stride)) + J.lane_id * sizeof_f32 + fp4_warp_s
            voffset_scale[B_horz // 4] = voffset_scale[0] + N // 2 * k_scale_stride
            for m in range(1, B_horz // 4):
                voffset_scale[m] = voffset_scale[0] + 32 * k_scale_stride * m
                voffset_scale[B_horz // 4 + m] = voffset_scale[B_horz // 4] + 32 * k_scale_stride * m
        else:
            voffset_scale[0] = J.gpr(s_e_id * (N * k_scale_stride)) + J.threadIdx.x * sizeof_f32
            for m in range(1, B_horz // 2):
                voffset_scale[m] = voffset_scale[0] + 32 * k_scale_stride * m
    elif (weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz) and fp8_ptpc:
        voffset_scale = J.gpr(B_horz, 'vu32')
        p_w_scale[:] += (BLOCK_TILE_SIZE_N_HALF if with_silu else BLOCK_TILE_SIZE_N) * sizeof_f32 * block_n
        voffset_scale[0] = J.gpr(s_e_id * (N * sizeof_f32)) + lane_div_16 * (4 * sizeof_f32)
        if with_silu:
            voffset_scale[B_horz // 2] = voffset_scale[0] + N // 2 * sizeof_f32
            for m in range(1, B_horz // 2):
                voffset_scale[m] = voffset_scale[0] + 16 * sizeof_f32 * m
                voffset_scale[B_horz // 2 + m] = voffset_scale[B_horz // 2] + 16 * sizeof_f32 * m
        else:
            for m in range(1, B_horz):
                voffset_scale[m] = voffset_scale[0] + 16 * sizeof_f32 * m
    elif (weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz) and not fp8_ptpc:
        assert K %(num_split_k*128) == 0 ,f' K %(num_split_k*128) must be 0'
        # the scale layout is [E, N//128, K//128]
        k_scale_stride = K // 128 * sizeof_f32
        # would need BLOCK_TILE_SIZE_N//128 *2 scale offset register for 1st stage.
        voffset_scale = J.gpr(2, 'vu32')
        # N_wg scale offset on expert wg and N wg.
        if with_silu:
            p_w_scale[:] +=  BLOCK_TILE_SIZE_N_HALF* block_n // 128 * k_scale_stride + s_e_id * (N//128 * k_scale_stride)
        else:
            p_w_scale[:] +=  BLOCK_TILE_SIZE_N * block_n //128 * k_scale_stride + s_e_id * (N//128 * k_scale_stride )
        if with_silu:
            #[E, INTER_SIZE_TP*2//128, HIDDEN_SIZE//128]
            voffset_scale[0] = J.threadIdx.x //128 * sizeof_f32
            # N tile offset within wave offset
            voffset_scale[1] = voffset_scale[0] + (N//2//128 * k_scale_stride )
        else:
            #  64 lane offset
            voffset_scale[0] = 0
            voffset_scale[1] = 0
    if (weight_dtype == torch.bfloat16 or weight_dtype == torch.float8_e4m3fn or weight_dtype == torch.float8_e4m3fnuz) and fp8_ptpc and not with_silu:
        for m in range(A_vert):
            v_weight[m, 1] = v_weight[m, 0]

    offset_64bit = J.gpr(2,"su32")
    offset_64bit = J.s_mul_u32_u64(s_e_id, (N * get_k_bytes(K)))
    # J.s_mul_hi_u32(offset_64bit[1], s_e_id, (N * get_k_bytes(K)))
    # J.s_mul_i32(offset_64bit[0], s_e_id, (N * get_k_bytes(K)))
    p_weight[:] += offset_64bit
    buff_b = J.Buffer(p_weight, N * get_k_bytes(K))

    if with_silu and split_k>1:
        if fp4_split:
            assert USE_FP4_SHUFFLE_WEIGHT
            k_work=fp4_k_work
            soffset_a=J.blockIdx.z * (k_work*sizeof_bf16)
            soffset_b=J.blockIdx.z * (k_work//2*16)
            p_w_scale[:] += J.blockIdx.z * (k_work//256*256)
        else:
            assert weight_dtype==torch.float8_e4m3fn and not fp8_ptpc
            assert K % split_k == 0 and (K//split_k) % 256 == 0
            k_work=K//split_k
            soffset_a=J.blockIdx.z * (k_work*sizeof_bf16)
            soffset_b=J.blockIdx.z * (k_work*16)
            p_w_scale[:] += J.blockIdx.z * (k_work//128*sizeof_f32)
    else:
        k_work=K
        soffset_a=soffset_b=0
    gemm_splitk(J, weight_dtype, k_work, N, num_split_k,
                buff_a, buff_b, p_w_scale,
                voffset_a, voffset_b, voffset_scale, C_reg, soffset_a=soffset_a, soffset_b=soffset_b, BLOCK_TILE_SIZE_N=BLOCK_TILE_SIZE_N, BLOCK_TILE_SIZE_M=BLOCK_TILE_SIZE_M, USE_FP4_SHUFFLE_WEIGHT=USE_FP4_SHUFFLE_WEIGHT, fp8_ptpc=fp8_ptpc, non_temporal=non_temporal, scale_weights=sw, schedule=schedule)

    s_cvt_bf16_bias = J.gpr(1, "su32")
    s_cvt_bf16_bias[0] = 0x00008000
    s_cvt_bf16_bias_dup = J.gpr(2, "su32")
    s_cvt_bf16_bias_dup[0] = 0x00008000
    s_cvt_bf16_bias_dup[1] = 0x00008000

    ###############################################
    if with_silu and BLOCK_TILE_SIZE_N % 64 == 0 and"gfx950" in J.arch:
        # use more lds
        lds_buff = J.LDSTensor([4 * BLOCK_TILE_SIZE_M, 64], torch.float32)
        # each 32 N as a group to compute gate*up
        n_groups = BLOCK_TILE_SIZE_N // 32
        n_half0 = 0
        n_half1 = B_horz // 2
        # each wave holds [4, 16, A_vert] floats
        vouts = J.gpr(A_vert, "vf32")
        vrow = J.gpr(lane_div_16 + J.warp_id * 4)
        for n in range(n_groups // 2):
            vaddr = J.gpr("vu32")
            for m in range(A_vert):
                lds_buff.write("b128", C_reg[n * 2 + 0 + n_half0, m], lane_mod_16 + J.warp_id * 16 + m * 64, lane_div_16 * 4)
                lds_buff.write("b128", C_reg[n * 2 + 1 + n_half0, m], lane_mod_16 + J.warp_id * 16 + m * 64, lane_div_16 * 4 + 16)
                lds_buff.write("b128", C_reg[n * 2 + 0 + n_half1, m], lane_mod_16 + J.warp_id * 16 + m * 64, lane_div_16 * 4 + 32)
                lds_buff.write("b128", C_reg[n * 2 + 1 + n_half1, m], lane_mod_16 + J.warp_id * 16 + m * 64, lane_div_16 * 4 + 48)

            J.s_waitcnt(mod=f"lgkmcnt(0)")
            J.s_barrier()
            v_sorted_id_permute = J.gpr("vu32")
            for m in range(A_vert):
                J.ds_bpermute_b32(v_sorted_id_permute, vrow * 4, v_sorted_id[m])
                gate_up = J.gpr(4, 2, 2, "vf32")
                # interleave
                lds_buff.read("b64", gate_up[0], vrow + (0 * 16 + m * 64), lane_mod_16 * 2, offset1 = 16)
                lds_buff.read("b64", gate_up[1], vrow + (1 * 16 + m * 64), lane_mod_16 * 2, offset1 = 16)
                lds_buff.read("b64", gate_up[2], vrow + (2 * 16 + m * 64), lane_mod_16 * 2, offset1 = 16)
                lds_buff.read("b64", gate_up[3], vrow + (3 * 16 + m * 64), lane_mod_16 * 2, offset1 = 16)

                J.s_waitcnt(mod=f"lgkmcnt(2)")
                J.v_pk_add_f32(gate_up[0, 0], gate_up[0, 0], gate_up[1, 0])
                J.v_pk_add_f32(gate_up[0, 1], gate_up[0, 1], gate_up[1, 1])
                J.s_waitcnt(mod=f"lgkmcnt(0)")
                J.v_pk_add_f32(gate_up[2, 0], gate_up[2, 0], gate_up[3, 0])
                J.v_pk_add_f32(gate_up[2, 1], gate_up[2, 1], gate_up[3, 1])
                J.v_pk_add_f32(gate_up[0, 0], gate_up[0, 0], gate_up[2, 0])
                J.v_pk_add_f32(gate_up[0, 1], gate_up[0, 1], gate_up[2, 1])

                if split_k>1:
                    token=J.gpr(v_sorted_id_permute[0] & 0xffffff)
                    slot=J.gpr(v_sorted_id_permute[0] >> 24)
                    split_base=J.gpr(1,'su32')
                    J.s_mul_i32(split_base, J.blockIdx.z, M[0])
                    split_base[0] *= TOPK*N*sizeof_f32
                    vaddr=J.gpr((token*TOPK+slot)*N*sizeof_f32
                                +split_base[0]
                                +lane_mod_16*2*sizeof_f32+n*32*sizeof_f32)
                    with J.ExecMask(token<M[0],early_skip=False):
                        J.global_store_dwordx2(vaddr,gate_up[0,0],p_output)
                        J.global_store_dwordx2(vaddr+N//2*sizeof_f32,gate_up[0,1],p_output)
                else:
                    out0 = J.gpr(gate_up[0, 1, 0] * J.silu(gate_up[0, 0, 0]))
                    out1 = J.gpr(gate_up[0, 1, 1] * J.silu(gate_up[0, 0, 1]))
                    v_token_id = J.gpr(v_sorted_id_permute[0] & 0xffffff)
                    v_topk_id = J.gpr(v_sorted_id_permute[0] >> 24)
                    if packed_output_scale is not None:
                        from .native_prepare import pack_fp4
                        values=[out0,out1]
                        if not fp32_activation:
                            # Preserve this producer's original BF16 storage
                            # rounding before selecting the MXFP4 block scale.
                            values=[]
                            for value in (out0,out1):
                                bits=J.gpr('vu32');rounded=J.gpr('vf32')
                                J.v_add_u32(bits,value,s_cvt_bf16_bias)
                                J.v_and_b32(rounded,bits,J.gpr('su32',0xffff0000))
                                values.append(rounded)
                        codes,exponent=pack_fp4(J,values,(1,2,4,8),fp32_activation)
                        route=J.gpr(v_token_id*TOPK+v_topk_id)
                        vaddr=J.gpr(route*(N//4)+lane_mod_16+n*16)
                        scale_addr=J.gpr(route*(N//64)+(BLOCK_TILE_SIZE_N_HALF*block_n)//32+n)
                        with J.ExecMask(v_token_id<M[0],early_skip=False):
                            J.global_store_byte(vaddr,codes[0],p_output)
                        with J.ExecMask((v_token_id<M[0])&(lane_mod_16[0]==0),early_skip=False):
                            J.global_store_byte(scale_addr,exponent,packed_output_scale)
                    elif fuse_middle:
                        from .epilogue_quant import emit_roundtrip_pair
                        packed=emit_roundtrip_pair(J,out0,out1)
                        vaddr=J.gpr((v_token_id*TOPK+v_topk_id)*(N//2*sizeof_bf16)
                                    +lane_mod_16*2*sizeof_bf16+n*32*sizeof_bf16)
                        with J.ExecMask(v_token_id < M[0], early_skip=False):
                            J.global_store_dword(vaddr,packed,p_output)
                    elif fp32_activation:
                        vaddr = J.gpr((v_token_id * TOPK + v_topk_id) * (N // 2 * sizeof_f32)
                                     + lane_mod_16 * 2 * sizeof_f32 + n * 32 * sizeof_f32)
                        with J.ExecMask(v_token_id < M[0], early_skip=False):
                            J.global_store_dword(vaddr, out0, p_output)
                            J.global_store_dword(vaddr + sizeof_f32, out1, p_output)
                    else:
                        J.v_add_u32(out0[0], out0[0], s_cvt_bf16_bias)
                        J.v_add_u32(out1[0], out1[0], s_cvt_bf16_bias)
                        J.pk_f32_to_bf16(vouts[m], out0[0], out1[0])
                        vaddr = J.gpr(v_token_id * (N // 2 * J.sizeof_bf16 * TOPK) + v_topk_id * (N // 2 * J.sizeof_bf16) + lane_mod_16 * sizeof_f32 + n * 16 * sizeof_f32)
                        with J.ExecMask(v_token_id < M[0], early_skip=False):
                            J.global_store_dword(vaddr, vouts[m], p_output)

            J.s_barrier()

        finish_task()
        return
    ###############################################
    if use_split_k:
        # split K
        lds_buff = J.LDSTensor([4 * BLOCK_TILE_SIZE_M, 32], torch.float)
        # each 32 N as a group to compute gate*up
        n_groups = BLOCK_TILE_SIZE_N // 32
        n_half0 = 0
        n_half1 = B_horz // 2
        for n in range(n_groups):
            vaddr = J.gpr("vu32")
            for m in range(A_vert):
                lds_buff.write("b128", C_reg[n + n_half0, m], lane_mod_16 + warp_id * 16 + m * 64, lane_div_16 * 4)
                lds_buff.write("b128", C_reg[n + n_half1, m], lane_mod_16 + warp_id * 16 + m * 64, lane_div_16 * 4 + 16)

            J.s_waitcnt(mod=f"lgkmcnt(0)")
            J.s_barrier()
            v_sorted_id_permute = J.gpr("vu32")
            # each wave reduce 4 rows once
            vrow = J.gpr(lane_div_16 + warp_id * 4)
            for m in range(A_vert):
                J.ds_bpermute_b32(v_sorted_id_permute, vrow * 4, v_sorted_id[m])
                gate_up = J.gpr(4, 2, "vf32")
                # interleave
                lds_buff.read("b32", gate_up[0], vrow + (0 * 16 + m * 64), lane_mod_16, offset1 = 16)
                lds_buff.read("b32", gate_up[1], vrow + (1 * 16 + m * 64), lane_mod_16, offset1 = 16)
                lds_buff.read("b32", gate_up[2], vrow + (2 * 16 + m * 64), lane_mod_16, offset1 = 16)
                lds_buff.read("b32", gate_up[3], vrow + (3 * 16 + m * 64), lane_mod_16, offset1 = 16)

                J.s_waitcnt(mod=f"lgkmcnt(2)")
                J.v_pk_add_f32(gate_up[0], gate_up[0], gate_up[1])
                J.s_waitcnt(mod=f"lgkmcnt(0)")
                J.v_pk_add_f32(gate_up[2], gate_up[2], gate_up[3])
                J.v_pk_add_f32(gate_up[0], gate_up[0], gate_up[2])

                out = J.gpr(gate_up[0, 1] * J.silu(gate_up[0, 0]))
                # output: [B, TOPK, N]
                v_token_id = J.gpr(v_sorted_id_permute[0] & 0xffffff)
                v_topk_id = J.gpr(v_sorted_id_permute[0] >> 24)
                J.v_add_u32(out[0], out[0], s_cvt_bf16_bias)
                vaddr = J.gpr(v_token_id * (N // 2 * sizeof_bf16 * TOPK) + v_topk_id * (N // 2 * sizeof_bf16) + lane_mod_16 * sizeof_bf16 + n * 16 * sizeof_bf16)
                with J.ExecMask(v_token_id < M[0], early_skip=False):
                    J.global_store_short_d16_hi(vaddr, out[0], p_output)
            J.s_barrier()
    elif fp32_combine:
        # Every (token, route slot, output column) has exactly one writer.
        if down_proj_with_lds:
            # Transpose route-major MFMA registers through LDS so neighboring
            # lanes store neighboring output columns, rather than different rows.
            lds_buff = J.LDSTensor([BLOCK_TILE_SIZE_M, BLOCK_TILE_SIZE_N], torch.float32)
            route_buff = J.alloc_lds(BLOCK_TILE_SIZE_M * 4)
            for m in range(A_vert):
                J.ds_write_b32(lane_mod_16 * 4 + m * 64, v_sorted_id[m], mod=f"offset:{route_buff}")
            for n in range(B_horz):
                for m in range(A_vert):
                    for j in range(4):
                        C_reg[n, m, j] *= v_weight[m]
                    column = ((lane_mod_16 + m * 16) ^ (n * 4 + lane_div_16)) % (BLOCK_TILE_SIZE_N // 4)
                    lds_buff.write("b128", C_reg[n, m], lane_mod_16 + m * 16, column * 4)
            J.s_waitcnt(mod="lgkmcnt(0)")
            J.s_barrier()
            columns = BLOCK_TILE_SIZE_N // 2
            rows = 64 // columns
            row_lane = get_lane_id_div(J, columns)
            col_group = get_lane_id_mod(J, columns) // 2
            col_pair = get_lane_id_mod(J, columns) % 2
            for m in range(BLOCK_TILE_SIZE_M // rows):
                row = row_lane + m * rows
                column = (row ^ col_group) % (BLOCK_TILE_SIZE_N // 4)
                values = J.gpr(2, "vf32", align=2)
                packed = J.gpr(1, "vu32")
                lds_buff.read("b64", values, row, column * 4 + col_pair * 2)
                J.ds_read_b32(packed[0], row * 4, mod=f"offset:{route_buff}")
                J.s_waitcnt(mod="lgkmcnt(0)")
                token = J.gpr(packed[0] & 0xffffff)
                slot = J.gpr(packed[0] >> 24)
                address = J.gpr((token * TOPK + slot) * N * sizeof_f32
                                + (col_group * 4 + col_pair * 2) * sizeof_f32)
                with J.ExecMask(token < M[0], early_skip=False):
                    J.global_store_dwordx2(address, values, p_output)
        else:
            for m in range(A_vert):
                with J.ExecMask(v_token_id[m] < M[0], early_skip=False):
                    for n in range(B_horz):
                        for j in range(4):
                            C_reg[n, m, j] = C_reg[n, m, j] * v_weight[m]
                        vaddr = J.gpr((v_token_id[m] * TOPK + v_topk_id[m]) * N * sizeof_f32
                                      + lane_div_16 * 4 * sizeof_f32 + n * 16 * sizeof_f32)
                        J.global_store_dwordx4(vaddr, C_reg[n, m], p_output)
    else:
        assert not with_silu
        # Optimize the down-projection store and LDS is needed.
        if not fp8_ptpc and down_proj_with_lds:
            # can only support rd_elements_per_lane = 2, 4
            rd_elements_per_lane = 2
            # save BF16 into LDS
            lds_buff = J.LDSTensor([BLOCK_TILE_SIZE_M, BLOCK_TILE_SIZE_N], torch.bfloat16)
            toke_id_buff = J.alloc_lds(BLOCK_TILE_SIZE_M*4)
            for m in range(A_vert):
                voffset_tokenid = J.gpr(lane_mod_16*4+m*64)
                J.ds_write_b32(voffset_tokenid, v_token_id[m], mod=f"offset:{toke_id_buff}")
            for n in range(B_horz):
                # split N
                assert not with_silu
                for m in range(A_vert):
                    creg_low = J.gpr(2, "vbf16x2", align=2)
                    for j in range(4):
                        C_reg[n, m, j] = C_reg[n, m, j] * v_weight[m]
                        J.v_add_u32(C_reg[n, m, j], C_reg[n, m, j], s_cvt_bf16_bias)
                    creg_low[0] = (C_reg[n, m, 0] >> 16) | (C_reg[n, m, 1] & 0xFFFF0000)
                    creg_low[1] = (C_reg[n, m, 2] >> 16) | (C_reg[n, m, 3] & 0xFFFF0000)
                    swizzle_col = ((lane_mod_16 + m * 16))^(n*4+lane_div_16) % (BLOCK_TILE_SIZE_N // 4)
                    lds_buff.write("b64", creg_low, lane_mod_16 + m * 16, swizzle_col*4)
            J.s_waitcnt(mod=f"lgkmcnt(0)")
            J.s_barrier()
            if rd_elements_per_lane == 4:
                rd_column_lanes = BLOCK_TILE_SIZE_N // 4
                rd_row_lanes = 64 // rd_column_lanes
                rd_row_idx = get_lane_id_div(J, rd_column_lanes)
                #LDS write:one lane write 64 bits. So one column is 128 bits width.
                #LDS read: one  lane read 64 bits. So one read column is 128 bits width.
                rd_col_idx = get_lane_id_mod(J, rd_column_lanes)
            elif rd_elements_per_lane == 2:
                rd_column_lanes = BLOCK_TILE_SIZE_N // 2
                rd_row_lanes = 64 // rd_column_lanes
                rd_row_idx = get_lane_id_div(J, rd_column_lanes)
                #LDS write: one lane write 64 bits. So one column is 128 bits width.
                #LDS read:  one  lane read 32 bits. so 2 lanes would be in one column.
                rd_col_idx = get_lane_id_mod(J, rd_column_lanes) // 2
                rd_col_b32_offset = get_lane_id_mod(J, rd_column_lanes) % 2
            else:
                assert 0, f'rd_elements_per_lane should be 2 or 4. Others not supported'

            v_token_id_tr = J.gpr(1, 'vu32')
            for m in range(BLOCK_TILE_SIZE_M//rd_row_lanes):
                if rd_elements_per_lane == 4:
                    creg_low_rd = J.gpr(2, "vbf16x2", align=2)
                    swizzle_col = (((rd_row_idx + m*rd_row_lanes))^(rd_col_idx)) % (BLOCK_TILE_SIZE_N // 4)
                    lds_buff.read("b64", creg_low_rd, rd_row_idx + m*rd_row_lanes, swizzle_col*4)
                    voffset_tokenid = J.gpr(m*rd_row_lanes*4 + rd_row_idx*4)
                    J.ds_read_b32(v_token_id_tr[0], voffset_tokenid, mod=f"offset:{toke_id_buff}")

                    J.s_waitcnt(mod=f"lgkmcnt(0)")
                    vaddr = J.gpr(v_token_id_tr[0] * (N * sizeof_bf16) + (rd_col_idx) * (4 * sizeof_bf16))
                    with J.ExecMask(v_token_id_tr[0] < M[0], early_skip=False):
                            J.global_atomic_pk_add_bf16(vaddr    , creg_low_rd[0], p_output)
                            J.global_atomic_pk_add_bf16(vaddr + 4, creg_low_rd[1], p_output)
                elif rd_elements_per_lane == 2:
                    creg_low_rd = J.gpr(1, "vbf16x2", align=2)
                    swizzle_col = (((rd_row_idx + m*rd_row_lanes))^(rd_col_idx)) % (BLOCK_TILE_SIZE_N // 4)
                    lds_buff.read("b32", creg_low_rd[0], rd_row_idx + m*rd_row_lanes, swizzle_col*4+rd_col_b32_offset*2)
                    voffset_tokenid = J.gpr(m*rd_row_lanes*4 + rd_row_idx*4)
                    J.ds_read_b32(v_token_id_tr[0], voffset_tokenid, mod=f"offset:{toke_id_buff}")

                    J.s_waitcnt(mod=f"lgkmcnt(0)")
                    vaddr = J.gpr(v_token_id_tr[0] * (N * sizeof_bf16) + (rd_col_idx*4+rd_col_b32_offset*2)*(sizeof_bf16))
                    with J.ExecMask(v_token_id_tr[0] < M[0], early_skip=False):
                            J.global_atomic_pk_add_bf16(vaddr    , creg_low_rd[0], p_output)
                else:
                    assert 0, f'rd_elements_per_lane should be 2 or 4. Others not supported'
            finish_task()
            return
        else:
            for m in range(A_vert):
                with J.ExecMask(v_token_id[m] < M[0], early_skip=False):
                    for n in range(B_horz):
                    # output layout: [B, N]
                        vaddr = J.gpr(v_token_id[m] * (N * sizeof_bf16) + lane_div_16 * (4 * sizeof_bf16) + n * 4 * (4 * sizeof_bf16))
                        creg_low = J.gpr(2, "vbf16x2", align=2)
                        for j in range(4):
                            C_reg[n, m, j] *= v_weight[m]
                            J.v_add_u32(C_reg[n, m, j], C_reg[n, m, j], s_cvt_bf16_bias)
                        J.pk_f32_to_bf16(creg_low[0], C_reg[n, m, 0], C_reg[n, m, 1])
                        J.pk_f32_to_bf16(creg_low[1], C_reg[n, m, 2], C_reg[n, m, 3])
                        J.global_atomic_pk_add_bf16(vaddr, creg_low[0], p_output)
                        J.global_atomic_pk_add_bf16(vaddr, creg_low[1], p_output, mod='offset:4')

    finish_task()


@jit()
def tuned_moe_stage(J: JIT, wd, tk, K, N, act, bm, bn,
                    p_input: "void*", p_weight: "void*", p_output: "void*",
                    p_sorted_ids: "void*", p_sorted_weights: "float*",
                    p_sorted_expert_ids: "void*", p_num_valid_ids: "void*",
                    p_w_scale: "float*", M: "int", pt, dr, em, nt, lds, fc, sk, sw, fo):
    emit_moe_stage(J, wd, tk, K, N, act, bm, bn, p_input, p_weight, p_output,
                   p_sorted_ids, p_sorted_weights, p_sorted_expert_ids,
                   p_num_valid_ids, p_w_scale, M, pt, dr, em, nt, lds, fc, sk, sw, fp32_activation=fo)


@jit()
def pipeline_moe_stage(J: JIT, wd, tk, K, N, act, bm, bn,
                       p_input: "void*", p_weight: "void*", p_output: "void*",
                       p_sorted_ids: "void*", p_sorted_weights: "float*",
                       p_sorted_expert_ids: "void*", p_num_valid_ids: "void*",
                       p_w_scale: "float*", M: "int", pt, dr, em, nt, lds, fc, sk, sw, fo, ps):
    assert ps in (1, 2, 3, 4)
    emit_moe_stage(J, wd, tk, K, N, act, bm, bn, p_input, p_weight, p_output,
                   p_sorted_ids, p_sorted_weights, p_sorted_expert_ids,
                   p_num_valid_ids, p_w_scale, M, pt, dr, em, nt, lds, fc, sk, sw,
                   schedule=ps, fp32_activation=fo)


@jit()
def epilogue_moe_stage(J: JIT, wd, tk, K, N, act, bm, bn,
                       p_input: "void*", p_weight: "void*", p_output: "void*",
                       p_sorted_ids: "void*", p_sorted_weights: "float*",
                       p_sorted_expert_ids: "void*", p_num_valid_ids: "void*",
                       p_w_scale: "float*", M: "int", pt, dr, em, nt, lds, fc, sk, sw, fo, ps, fq, qs):
    assert not fq or (act and sk==1 and fo and wd==torch.float4_e2m1fn_x2)
    assert not qs or not dr
    emit_moe_stage(J,wd,tk,K,N,act,bm,bn,p_input,p_weight,p_output,
                   p_sorted_ids,p_sorted_weights,p_sorted_expert_ids,p_num_valid_ids,
                   p_w_scale,M,pt,dr,em,nt,lds,fc,sk,sw,queued=bool(qs),task_stride=qs,
                   schedule=ps,fp32_activation=fo,fuse_middle=fq,row_count_queue=bool(qs))
