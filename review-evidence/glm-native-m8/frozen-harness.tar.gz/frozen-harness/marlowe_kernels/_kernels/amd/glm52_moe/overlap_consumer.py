# SPDX-License-Identifier: MIT
"""Prefetch G2 weights while its consumer reduces and packs G1 partials."""
from .consumer_program import ConsumerProgram, ConsumerConfig, ConsumerCoordinates
from .block_fused import pointer
from .native_prepare import middle_packed
from .coalesced_epilogue import emit_coalesced
from marlowe_kernels._runtime import jit


@jit()
def overlap_down(J,B,BN,NW,SK,FP32,NT,
    PART:'void*',MID:'void*',MS:'void*',W:'void*',WS:'void*',OUT:'void*',IDS:'void*',RW:'void*'):
    from pyhip.core.mem_allocator import SimpleMemoryAllocator
    assert J.gfx==950 and NW>=2 and BN%NW==0
    J.lds_allocator=SimpleMemoryAllocator(160*1024);J.alloc_lds(160,align=16)
    lane=J.gpr(J.threadIdx.x[0]%64);wave=J.gpr(J.threadIdx.x[0]//64)
    swave=J.gpr('su32');J.v_readfirstlane_b32(swave,wave)
    expert=J.gpr('su32');routing=J.gpr('vf32')
    J.s_load_dword(expert,IDS,J.blockIdx.y[0]*4)
    J.global_load_dword(routing,J.gpr('vu32',J.blockIdx.y[0]*4),RW)
    J.s_waitcnt(mod='lgkmcnt(0)')
    wp,sp=pointer(J,W),pointer(J,WS)
    wp[:]+=J.s_mul_u32_u64(expert,6144*256//2);sp[:]+=expert*(6144*8)
    blocks=BN//NW//16;wave_n=wave[0]*(BN//NW)
    bv=J.gpr(2,blocks,4,'vu32');bs=J.gpr(2,blocks,'vu32')
    for n in range(blocks):
        col=J.gpr('vu32',J.blockIdx.x[0]*BN+wave_n+n*16)
        qbase=J.gpr(col*128+lane*16)
        sbase=J.gpr((col//32)*256+lane*4+(col%32)//16)
        for step in range(2):
            J.global_load_dwordx4(bv[step,n],qbase[0]+step*1024,wp,mod='sc0 nt' if NT else '')
            J.global_load_ubyte(bs[step,n],sbase[0]+step*2,sp)
    with J.ExecMask(wave[0]<2):
        mid,scale=pointer(J,MID),pointer(J,MS)
        c=ConsumerCoordinates(J,'middle_',J.blockIdx.y,swave,J.gpr('su32',0),lane,
            mapping=[(mid,'mid'),(scale,'scale')],B=B,rows=1,partial_base=0,mid_base=0,scale_base=144)
        middle_packed.gen_func(c,pointer(J,PART),mid,scale,B,SK,FP32)
    J.s_waitcnt(mod='vmcnt(0) lgkmcnt(0)');J.s_barrier()
    av=J.gpr(2,4,'vu32',0);asc=J.gpr(2,'vu32',127)
    part=J.gpr(lane[0]//16)
    with J.ExecMask(lane[0]%16==0,early_skip=False):
        for step in range(2):
            J.ds_read_b128(av[step],J.gpr('vu32',part[0]*16+step*64))
            J.ds_read_u8(asc[step],J.gpr('vu32',144+part[0]+step*4))
    J.s_waitcnt(mod='lgkmcnt(0)')
    accum=J.gpr(blocks,4,'vf32',0.)
    for step in range(2):
        for n in range(blocks):
            J.v_mfma_scale_f32_16x16x128_f8f6f4(accum[n],bv[step,n],av[step],accum[n],bs[step,n],asc[step],
                mod='op_sel:[0,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4')
    token=J.gpr('vu32',J.gpr('su32',J.blockIdx.y[0]//9)[0])
    with J.ExecMask(lane[0]%16!=0,early_skip=False):token[:]=B
    emit_coalesced(J,accum,blocks,token,routing,OUT,J.gpr('su32',B),6144,BN,wave_n,lane,True)


class OverlapProgram(ConsumerProgram):
    def __init__(self,owner,batch,config=ConsumerConfig()):
        assert config.down_waves>=2
        super().__init__(owner,batch,config)
        self.info.update(algorithm='G2 weights prefetch overlaps local G1 split reduction/packing')
    def _stage(self,inp,scale,out,first):
        if first:return super()._stage(inp,scale,out,first)
        b,c,p=self.b,self.cc,self.p
        overlap_down([6144//c.down_n,self.grid],[64*c.down_waves],b,c.down_n,c.down_waves,c.split_k,
            self.fp32_middle,c.non_temporal,self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),
            self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),out.data_ptr(),
            p['ids'].data_ptr(),p['weights'].data_ptr())
