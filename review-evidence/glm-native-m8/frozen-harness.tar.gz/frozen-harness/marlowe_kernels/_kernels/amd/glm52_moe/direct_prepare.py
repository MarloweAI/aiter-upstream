# SPDX-License-Identifier: MIT
"""No route grouping: top-k writes expert-per-tile metadata directly.

The top-k arithmetic below is copied from prepare.topk; only its final stores
are replaced with returned registers. Static token/padding rows are prepared
once, outside inference. Shared-expert placement is also static.
"""
from marlowe_kernels._runtime import jit
from .prepare import sigmoid, key, select_max
from .native_prepare import pack_fp4


def direct_topk(J, L, C, token):
    lane = J.threadIdx.x[0] % 64
    keys = []
    for j in range(4):
        expert = J.gpr(lane + j*64)
        logit, bias = J.gpr('vu32'), J.gpr('vu32')
        J.global_load_ushort(logit, (token*256+expert[0])*2, L)
        J.global_load_ushort(bias, expert[0]*2, C)
        J.s_waitcnt(mod='vmcnt(0)')
        logit[:] = logit[0] << 16; bias[:] = bias[0] << 16
        score = sigmoid(J, logit)
        J.v_add_f32(score, score, bias)
        keys.append(key(J, score, expert))
    # The native per-lane sorting network and six DPP reductions. Only lane
    # 63 is defined after the row broadcasts; broadcast its winning key.
    for i in range(4):
        for j in range(i+1,4):
            left = J.gpr(2,'vu32')
            for part in range(2):left[part]=keys[i][part]
            J.v_cmp_gt_u64('vcc',keys[j],left)
            for part in range(2):
                J.v_cndmask_b32(keys[i][part],left[part],keys[j][part],'vcc')
                J.v_cndmask_b32(keys[j][part],keys[j][part],left[part],'vcc')
    winner_id = J.gpr('vu32', 0)
    controls=('quad_perm:[1,0,3,2]','quad_perm:[2,3,0,1]',
              'row_half_mirror','row_mirror','row_bcast:15','row_bcast:31')
    for k in range(8):
        winner = J.gpr(2, 'vu32')
        for i in range(2):winner[i]=keys[0][i]
        for control in controls:
            # CDNA4 ISA Table 11: a DPP source needs two wait states
            # after a VALU write; the pinned JIT does not insert these.
            J.s_nop(1)
            other=J.gpr(2,'vu32')
            for part in range(2):
                J.v_mov_b32_dpp(other[part],winner[part],mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
            select_max(J,winner,other)
        broadcast=J.gpr(2,'su32')
        J.s_nop(0)
        for part in range(2):J.v_readlane_b32(broadcast[part],winner[part],63)
        J.s_nop(1)  # VALU-produced SGPR -> VALU constant source
        expert=J.gpr('vu32',(broadcast[0]^0xffffffff)&511)
        J.v_cmp_eq_u32('vcc',J.gpr(lane),k)
        J.v_cndmask_b32(winner_id,winner_id,expert,'vcc')
        J.v_cmp_eq_u64('vcc',keys[0],broadcast)
        for j in range(3):
            for part in range(2):J.v_cndmask_b32(keys[j][part],keys[j][part],keys[j+1][part],'vcc')
        for part in range(2):J.v_cndmask_b32(keys[3][part],keys[3][part],0,'vcc')
    value = J.gpr('vu32', 0)
    with J.ExecMask(lane < 8, early_skip=False):
        J.global_load_ushort(value, (token*256+winner_id[0])*2, L)
    J.s_waitcnt(mod='vmcnt(0)')
    value[:] = value[0] << 16
    probability = sigmoid(J, value)
    J.v_cmp_lt_u32('vcc', J.gpr(lane), 8)
    J.v_cndmask_b32(probability, 0, probability, 'vcc')
    total = J.gpr('vf32'); total[:] = probability
    for control in controls:
        J.s_nop(1)
        J.v_add_f32_dpp(total,total,total,mod=control+' row_mask:0xf bank_mask:0xf bound_ctrl:1')
    sum_scalar=J.gpr('sf32')
    J.s_nop(0)
    J.v_readlane_b32(sum_scalar,total,63)
    J.s_nop(1)
    J.v_rcp_f32(total,sum_scalar)
    J.v_mul_f32(total,J.gpr('sf32',2.5),total)
    J.v_mul_f32(probability, probability, total)
    return winner_id, probability


@jit()
def direct_front(J, L:'void*', C:'void*', X:'void*', IDS:'void*', W:'void*',
                 EXP:'void*', SW:'void*', Q:'void*', QS:'void*', O:'void*',
                 SI:'void*', RW:'void*', B, BM, SHARE, PREQUANT, SUPPLIED, RAW_SCALE=False):
    token, tid = J.blockIdx.x[0], J.threadIdx.x[0]
    stride = 8 if SHARE else 9
    zero = J.gpr(4,'vu32',0)
    for part in (0,16):
        J.global_store_dwordx4((token*3*2048+tid*16)*2+part,zero,O)
    if PREQUANT:
        assert BM==32 or RAW_SCALE
        data=J.gpr(8,'vu32')
        for part in (0,4):
            J.global_load_dwordx4(data[part:part+3],(token*3*2048+tid*16)*2+part*4,X)
        J.s_waitcnt(mod='vmcnt(0)')
        values=[]
        for i in range(8):
            values.extend([J.gpr(data[i]<<16),J.gpr(data[i]&0xffff0000)])
        codes,exponent=pack_fp4(J,values,(1,),False)
        encoded=J.gpr(2,'vu32',0)
        for i,code in enumerate(codes):encoded[i//4]=encoded[i//4] | (code[0]<<(8*(i%4)))
        J.global_store_dwordx2(token*3*1024+tid*8,encoded,Q)
        # AITER scale layout: [rows/32, K/256, 4, 16, 4]. With fixed
        # direct tiles there is no need to read IDs or sort scales afterward.
        col=J.gpr(tid//2)
        col_offset=J.gpr((col[0]//8)*256+(col[0]%4)*64+((col[0]%8)//4)*2)
        with J.ExecMask(tid%2==0,early_skip=False):
            if RAW_SCALE:
                J.global_store_byte(token*3*64+col[0],exponent,QS)
            else:
                for slot in range(8):
                    row_group=token*stride+slot
                    J.global_store_byte(row_group*3*2048+col_offset[0],exponent,QS)
                if SHARE:
                    row=J.gpr('su32',B*8*BM+token)
                    offset=J.gpr((row[0]//32)*3*2048+(row[0]%16)*4+(row[0]%32)//16)
                    J.global_store_byte(offset[0]+col_offset[0],exponent,QS)
                else:
                    J.global_store_byte((token*9+8)*3*2048+col_offset[0],exponent,QS)
    with J.ExecMask(tid<64):
        if SUPPLIED:
            expert,weight=J.gpr('vu32'),J.gpr('vf32')
            with J.ExecMask(tid<8,early_skip=False):
                J.global_load_dword(expert,(token*8+tid)*4,SI)
                J.global_load_dword(weight,(token*8+tid)*4,RW)
                J.s_waitcnt(mod='vmcnt(0)')
        else:
            expert,weight=direct_topk(J,L,C,token)
        with J.ExecMask(tid<8,early_skip=False):
            J.global_store_dword((token*9+tid)*4,expert,IDS)
            J.global_store_dword((token*9+tid)*4,weight,W)
            J.global_store_dword((token*stride+tid)*4,expert,EXP)
            J.global_store_dword((token*stride+tid)*BM*4,weight,SW)
        with J.ExecMask(tid==0,early_skip=False):
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vu32',256),IDS)
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vf32',1.),W)
