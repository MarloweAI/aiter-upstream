# SPDX-License-Identifier: MIT
"""Hardware-counter-driven native G2 output coalescing experiment."""
from dataclasses import dataclass
from .prefetch_program import PrefetchConfig
from .native_program import NativeProgram,NativeConfig
from .native_prefetch import prefetch_projection
from .fused_dispatch import DispatchProgram,DispatchConfig,valid_pointer,clear_next
from .block_fused import pointer
from .native_coalesced import coalesced_projection
from marlowe_kernels._runtime import jit

@dataclass(frozen=True)
class CoalescedConfig(PrefetchConfig):
    dispatch: bool=False
    combine: str="wave"

@jit()
def coalesced_down(J,BN,NW,DIRECT,NT,DEPTH,COMBINE,DISPATCH,BATCH,MAXIMUM,
                   X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                   IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    if DISPATCH:
        valid,bank=valid_pointer(J,STATE)
        ids=pointer(J,IDS,bank[0]*(MAXIMUM*4));rw=pointer(J,RW,bank[0]*(MAXIMUM*4))
    else:valid,ids,rw=STATE,IDS,RW
    coalesced_projection.gen_func(J,256,6144,BN,False,1,False,NW,DIRECT,True,NT,DEPTH,COMBINE,
                                 X,XS,W,WS,Y,YS,ids,rw,EXP,valid,B)
    if DISPATCH:clear_next(J,STATE,IDS,RW,BATCH,64*NW,6144//BN,MAXIMUM)

class CoalescedProgram(DispatchProgram):
    def __init__(self,owner,batch,config=CoalescedConfig()):
        self.cc=config
        d={k:v for k,v in config.__dict__.items() if k not in ('dispatch','combine')}
        if config.dispatch:DispatchProgram.__init__(self,owner,batch,DispatchConfig(**d))
        else:NativeProgram.__init__(self,owner,batch,NativeConfig(**{k:v for k,v in d.items() if k not in ('depth','down_depth')}))
        self.info=dict(config=config.__dict__,epilogue=config.combine+' transpose -> coalesced BF16 atomics')
    def run(self,*a,**kw):
        if self.cc.dispatch:return DispatchProgram.run(self,*a,**kw)
        return NativeProgram.run(self,*a,**kw)
    def _stage(self,inp,scale,out,first):
        if first:
            if self.cc.dispatch:return DispatchProgram._stage(self,inp,scale,out,first)
            if not self.cc.depth:return NativeProgram._stage(self,inp,scale,out,first)
            c,p,b=self.c,self.p,self.b
            ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                             (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
            return prefetch_projection([512//c.gate_n,self.grid,c.split_k],[64*c.gate_waves],
                6144,512,c.gate_n,True,c.split_k,self.fp32_middle,c.gate_waves,c.direct,True,c.non_temporal,self.cc.depth,
                inp.data_ptr(),scale,self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),out.data_ptr(),
                self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b)
        c,p,b=self.c,self.p,self.b
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                         (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        if self.cc.dispatch:valid=self.state
        coalesced_down([6144//c.down_n,self.grid],[64*c.down_waves],c.down_n,c.down_waves,c.direct,
            c.non_temporal,self.cc.down_depth or 2,self.cc.combine,self.cc.dispatch,b,self.maximum if self.cc.dispatch else 0,
            inp.data_ptr(),scale,self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),out.data_ptr(),
            self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b)
