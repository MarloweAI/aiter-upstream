# SPDX-License-Identifier: MIT
"""Experimental native scaled-FP4 program; no BF16 GEMM or weight repacking."""
from dataclasses import dataclass
import math
import torch
from .native_prepare import native_phase1, middle_packed
from .prepare import phase23
from .native_fp4 import native_projection


@dataclass(frozen=True)
class NativeConfig:
    direct: bool = False
    gate_n: int = 128
    gate_waves: int = 2
    down_n: int = 128
    down_waves: int = 2
    split_k: int = 1
    gate_pipeline: bool = True
    down_pipeline: bool = True
    non_temporal: bool = False


# Screened on 30 distinct real-layer weight sets; qualify in the full replay.
NATIVE_CONFIGS = {
    1: NativeConfig(direct=True, gate_n=64, gate_waves=1, down_n=128, down_waves=2, split_k=24, gate_pipeline=True, down_pipeline=True, non_temporal=True),
    2: NativeConfig(direct=True, gate_n=128, gate_waves=2, down_n=64, down_waves=1, split_k=12, gate_pipeline=True, down_pipeline=True, non_temporal=True),
    4: NativeConfig(direct=True, gate_n=64, gate_waves=1, down_n=128, down_waves=1, split_k=8, gate_pipeline=True, down_pipeline=True, non_temporal=True),
    8: NativeConfig(direct=True, gate_n=64, gate_waves=1, down_n=128, down_waves=2, split_k=3, gate_pipeline=True, down_pipeline=True, non_temporal=True),
    16: NativeConfig(direct=False, gate_n=128, gate_waves=1, down_n=64, down_waves=1, split_k=8, gate_pipeline=True, down_pipeline=True, non_temporal=True),
    32: NativeConfig(direct=False, gate_n=64, gate_waves=1, down_n=128, down_waves=2, split_k=2, gate_pipeline=True, down_pipeline=True, non_temporal=True),
    64: NativeConfig(direct=False, gate_n=128, gate_waves=1, down_n=256, down_waves=4, split_k=2, gate_pipeline=True, down_pipeline=True, non_temporal=True),
}


class NativeProgram:
    def __init__(self, owner, batch, config=None):
        self.owner,self.b=owner,batch
        self.c=config or NATIVE_CONFIGS[batch]
        c,b,d=self.c,batch,6144
        if c.direct=="merge8":assert b==8
        assert 48%c.split_k==0
        device=owner.device
        def empty(shape,dtype):return torch.empty(shape,device=device,dtype=dtype)
        maximum=b*9+257*16-9
        blocks=(maximum+15)//16
        self.p=dict(ids=empty((b,9),torch.int32),weights=empty((b,9),torch.float32),
                    sorted_ids=empty(maximum,torch.int32),sorted_weights=empty(maximum,torch.float32),
                    experts=empty(blocks,torch.int32),valid=empty(2,torch.int32),
                    packed=empty((b,d//2),torch.uint8),workspace=empty(256+b*256,torch.uint8),
                    output=empty((b,d),torch.bfloat16))
        self.mid=empty((b,9,128),torch.uint8)
        self.mid_scale=empty((b,9,8),torch.uint8)
        self.partial=empty((c.split_k,b,9,512),torch.float32) if c.split_k>1 else self.mid
        self.fp32_middle=b in (1,4,8,32)
        occupied=math.ceil(257*(1-(1-1/257)**(b*9)))
        self.group_grid=min(max(16,(occupied*16+19)//20),max(16,owner._cu_count//2),owner._cu_count)
        self.grid=(65 if c.direct=="merge8" else b*9) if c.direct else min(blocks,b*9)

    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.c,self.p
        output=p['output'] if out is None else out
        native_phase1([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),
               p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),
               output.data_ptr(),0 if supplied_ids is None else supplied_ids.data_ptr(),
               0 if supplied_weights is None else supplied_weights.data_ptr(),supplied_ids is not None)
        if not c.direct:
            phase23([self.group_grid],[384],p['ids'].data_ptr(),p['weights'].data_ptr(),
                    p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),
                    p['valid'].data_ptr(),b,self.group_grid,p['sorted_ids'].numel())
        self._stage(p['packed'],p['workspace'].data_ptr()+256,self.partial,True)
        if c.split_k>1:
            middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),
                          self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
        self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
        return output

    def _stage(self,inp,inp_scale,out,first):
        p,c,b=self.p,self.c,self.b
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                          (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1
        w,s=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        native_projection([n//bn,self.grid]+([sk] if sk>1 else []),[64*nw],
                          k,n,bn,first,sk,self.fp32_middle,nw,c.direct,c.gate_pipeline if first else c.down_pipeline,c.non_temporal,
                          inp.data_ptr(),inp_scale,w.data_ptr(),s.data_ptr(),out.data_ptr(),
                          self.mid_scale.data_ptr(),ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr(),b)
