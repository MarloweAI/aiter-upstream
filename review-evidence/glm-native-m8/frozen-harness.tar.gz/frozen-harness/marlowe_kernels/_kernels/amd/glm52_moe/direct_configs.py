# SPDX-License-Identifier: MIT
"""Frozen direct-dispatch screen choices on the pinned GLM-5.2 TP8 stack.

All choices retain direct routed tiles. kernel_batch selects an existing AITER
configuration family, never a runtime route-statistics pass. B1 shares the same
layout in both modes; prefer the common shared-tile policy within a 1% tie.
"""
PURE_CONFIGS = {1: {'share': True, 'kernel_batch': None}, 2: {'share': True, 'kernel_batch': 1}, 4: {'share': True, 'kernel_batch': None}, 8: {'share': True, 'kernel_batch': None}, 16: {'share': True, 'kernel_batch': 2}, 32: {'share': True, 'kernel_batch': 2}, 64: {'share': True, 'kernel_batch': 2}}

MIXED_CONFIGS = {1: {'share': True, 'kernel_batch': None, 'native_g1': True}, 2: {'share': True, 'kernel_batch': None, 'native_g1': True}, 4: {'share': True, 'kernel_batch': 1, 'native_g1': True}, 8: {'share': True, 'kernel_batch': None, 'native_g1': True}, 16: {'share': True, 'kernel_batch': None, 'native_g1': True}, 32: {'share': True, 'kernel_batch': None, 'native_g1': True}, 64: {'share': True, 'kernel_batch': None, 'native_g1': True}}
