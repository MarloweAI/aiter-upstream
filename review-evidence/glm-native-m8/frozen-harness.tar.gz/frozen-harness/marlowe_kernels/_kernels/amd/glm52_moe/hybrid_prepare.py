# SPDX-License-Identifier: MIT
"""Port-EW preparation emitting the pinned AITER BM16/BM32 dispatch ABI.

Adapted from prepare.phase23: grouping also writes AITER's plain token index
array, avoiding a separate metadata conversion kernel. No CPU route analysis.
"""
from marlowe_kernels._runtime import jit
from .prepare import topk


@jit()
def hybrid_front(J, L:'void*', C:'void*', IDS:'void*', W:'void*', O:'void*',
                 SI:'void*', SW:'void*', SUPPLIED):
    token, tid = J.blockIdx.x[0], J.threadIdx.x[0]
    zero = J.gpr(4, 'vu32', 0)
    for part in (0,16):
        J.global_store_dwordx4((token*3*2048+tid*16)*2+part, zero, O)
    with J.ExecMask(tid < 64):
        if SUPPLIED:
            ids, weights = J.gpr('vu32'), J.gpr('vf32')
            with J.ExecMask(tid < 8, early_skip=False):
                J.global_load_dword(ids, (token*8+tid)*4, SI)
                J.global_load_dword(weights, (token*8+tid)*4, SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4, ids, IDS)
                J.global_store_dword((token*9+tid)*4, weights, W)
        else:
            topk(J, L, C, IDS, W, token)
        with J.ExecMask(tid == 0, early_skip=False):
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4), J.gpr('vu32',256), IDS)
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4), J.gpr('vf32',1.), W)


@jit()
def hybrid_group(J, IDS:'void*', W:'void*', SORT:'void*', WEIGHTS:'void*',
            EXPERTS:'void*', VALID:'void*', MIND:'void*', B, GRID, MAXIMUM, BM):
    tid, lane = J.threadIdx.x[0], J.threadIdx.x[0] % 64
    # Materialize across the full EXEC mask: PyHIP expression CSE must not
    # first define this value inside the lane-63 wave-total store.
    wave_id = J.gpr(tid//64)[0]
    hist = J.alloc_lds(384*4)
    scans = J.alloc_lds(384*4)
    waves = J.alloc_lds(6*4)
    zero = J.gpr('vu32',0)
    J.ds_write_b32(hist+tid*4, zero)
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    for start in range(0,B*9,384):
        expert = J.gpr('vu32')
        with J.ExecMask(tid+start < B*9):
            J.global_load_dword(expert, (tid+start)*4, IDS)
            J.s_waitcnt(mod='vmcnt(0)')
            J.ds_add_u32(hist+expert[0]*4, J.gpr('vu32',1))
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    count = J.gpr('vu32')
    J.ds_read_b32(count, hist+tid*4)
    J.s_waitcnt(mod='lgkmcnt(0)')
    rows = J.gpr(((count[0]+BM-1)//BM)*BM)
    prefix = J.gpr(rows[0])
    for distance in (1,2,4,8,16,32):
        other = J.gpr('vu32')
        J.ds_bpermute_b32(other, ((lane-distance)%64)*4, prefix)
        J.s_waitcnt(mod='lgkmcnt(0)')
        with J.ExecMask(lane >= distance, early_skip=False):
            J.v_add_u32(prefix, prefix, other)
    with J.ExecMask(lane == 63, early_skip=False):
        J.ds_write_b32(waves+wave_id*4, prefix)
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    for wave in range(5):
        other = J.gpr('vu32')
        J.ds_read_b32(other, J.gpr('vu32',waves+wave*4))
        J.s_waitcnt(mod='lgkmcnt(0)')
        with J.ExecMask(wave_id > wave, early_skip=False):
            J.v_add_u32(prefix, prefix, other)
    J.ds_write_b32(scans+tid*4, prefix)
    J.s_waitcnt(mod='lgkmcnt(0)'); J.s_barrier()
    total = J.gpr('vu32')
    J.ds_read_b32(total, J.gpr('vu32',scans+256*4))
    J.s_waitcnt(mod='lgkmcnt(0)')
    sentinel = J.gpr('vu32', (9<<24)|B)
    global_tid = J.blockIdx.x[0]*3*128+tid
    with J.If(J.blockIdx.x[0] == 0):
        with J.ExecMask(tid == 0, early_skip=False):
            J.global_store_dword(J.gpr('vu32',0), total, VALID)
            J.global_store_dword(J.gpr('vu32',4), J.gpr('vu32',B), VALID)
    for start in range(0,MAXIMUM,GRID*384):
        index = total[0]+global_tid+start
        with J.ExecMask(index < MAXIMUM):
            J.global_store_dword(index*4, sentinel, SORT)
            J.global_store_dword(index*4, J.gpr("vu32",B), MIND)
            J.global_store_dword(index*4, zero, WEIGHTS)
    index = total[0]//BM+global_tid
    with J.ExecMask(index < (MAXIMUM+BM-1)//BM):
        J.global_store_dword(index*4, zero, EXPERTS)
    # All workgroup barriers precede expert-dependent wave exits.
    for base in range(0,257,GRID*6):
        expert_v = J.gpr(J.blockIdx.x[0]*6+wave_id+base)
        expert = J.gpr('su32')
        J.v_readfirstlane_b32(expert, expert_v)
        with J.If(expert[0] < 257):
            end, count = J.gpr('vu32'), J.gpr('vu32')
            J.ds_read_b32(end, J.gpr('vu32',scans+expert[0]*4))
            J.ds_read_b32(count, J.gpr('vu32',hist+expert[0]*4))
            J.s_waitcnt(mod='lgkmcnt(0)')
            count_scalar = J.gpr('su32')
            J.v_readfirstlane_b32(count_scalar,count)
            with J.If(count_scalar[0] > 0):
                begin = J.gpr(end[0]-((count[0]+BM-1)//BM)*BM)
                offset = J.gpr('su32',0)
                for start in range(0,B*9,64):
                    route = J.gpr('vu32',0xffffffff)
                    weight = J.gpr('vf32',0.)
                    with J.ExecMask(lane+start < B*9, early_skip=False):
                        J.global_load_dword(route, (lane+start)*4, IDS)
                        J.global_load_dword(weight, (lane+start)*4, W)
                    J.s_waitcnt(mod='vmcnt(0)')
                    J.v_cmp_eq_u32('vcc', route, expert)
                    mask = J.gpr(2,'su32')
                    J.s_mov_b64(mask, 'vcc')
                    rank = J.gpr('vu32')
                    J.v_mbcnt_lo_u32_b32(rank, mask[0], 0)
                    J.v_mbcnt_hi_u32_b32(rank, mask[1], rank)
                    with J.ExecMask(route[0] == expert[0], early_skip=False):
                        token = J.gpr("vu32")
                        J.v_mul_hi_u32(token, J.gpr("su32",0x38e38e39), J.gpr(lane+start))
                        token[:] = token[0] >> 1
                        packed = J.gpr(token[0] | ((lane+start-token[0]*9)<<24))
                        J.global_store_dword((begin[0]+offset[0]+rank[0])*4, packed, SORT)
                        J.global_store_dword((begin[0]+offset[0]+rank[0])*4, token, MIND)
                        J.global_store_dword((begin[0]+offset[0]+rank[0])*4, weight, WEIGHTS)
                    hits = J.gpr('su32')
                    J.s_bcnt1_i32_b64(hits, mask)
                    offset[0] += hits[0]
                with J.ExecMask(begin[0]+count[0]+lane < end[0], early_skip=False):
                    J.global_store_dword((begin[0]+count[0]+lane)*4, sentinel, SORT)
                    J.global_store_dword((begin[0]+count[0]+lane)*4, J.gpr("vu32",B), MIND)
                    J.global_store_dword((begin[0]+count[0]+lane)*4, zero, WEIGHTS)
                with J.ExecMask(lane < (count[0]+BM-1)//BM, early_skip=False):
                    J.global_store_dword((begin[0]//BM+lane)*4, expert_v, EXPERTS)


