# SPDX-License-Identifier: MIT
"""Counter-free fused experts: one workgroup owns a complete intermediate.

Replicas optionally recompute G1 while partitioning G2 output columns. Each
replica has private intermediate storage, avoiding identical-value races.
This measures the parallelism/recomputation tradeoff against persistent tasks.
"""
from dataclasses import dataclass
from types import SimpleNamespace
import torch
from marlowe_kernels._runtime import jit
from .native_fp4 import native_projection
from .native_prepare import middle_packed,native_phase1
from .persistent_middle import grouped_middle
from .native_program import NativeProgram,NativeConfig
from .prepare import phase23


class Coordinates:
    def __init__(self,J,name,x,y,z,thread):
        self.J,self.name=J,name
        self.blockIdx=SimpleNamespace(x=x,y=y,z=z)
        self.threadIdx=SimpleNamespace(x=thread)
    def __getattr__(self,name):return getattr(self.J,name)
    def Label(self,name=''):return self.J.Label(self.name+name)
    def Jump(self,label,*a,**kw):return self.J.Jump(self.name+label,*a,**kw)


class LocalCoordinates(Coordinates):
    """Retarget only intermediate loads/stores to workgroup-private LDS."""
    def __init__(self,*args,mapping,B,rows,partial_base,mid_base,scale_base,**kw):
        super().__init__(*args,**kw)
        self.mapping={id(p):kind for p,kind in mapping}
        self.B,self.rows=B,rows
        self.bases=dict(partial=partial_base,mid=mid_base,scale=scale_base)
    def address(self,kind,offset):
        row=0 if self.rows==1 else self.threadIdx.x[0]%16
        if kind=='partial':
            # B is a power of two; PyHIP's arbitrary integer division emitter
            # is scalar-only. Exact unsigned /9 after removing powers of two.
            whole=self.J.gpr(offset>>(11+self.B.bit_length()-1))
            split=self.J.gpr('vu32')
            self.J.v_mul_hi_u32(split,whole,self.J.gpr('su32',0x38e38e39))
            split[:]=split[0]>>1
            addr=self.bases[kind]+(split*self.rows+row)*self.J.gpr('su32',2064)[0]+(offset%2048)
        elif kind=='mid':addr=self.bases[kind]+row*self.J.gpr('su32',144)[0]+offset%128
        else:addr=self.bases[kind]+row*16+offset%8
        return self.J.gpr('vu32',addr)
    def __getattr__(self,name):
        if name.startswith('global_load_'):
            def load(dst,offset,base,mod=''):
                kind=self.mapping.get(id(base))
                if kind is None:return getattr(self.J,name)(dst,offset,base,mod=mod)
                op={'global_load_dwordx4':'ds_read_b128','global_load_dwordx2':'ds_read_b64',
                    'global_load_ubyte':'ds_read_u8'}[name]
                return getattr(self.J,op)(dst,self.address(kind,offset))
            return load
        if name.startswith('global_store_'):
            def store(offset,value,base,mod=''):
                kind=self.mapping.get(id(base))
                if kind is None:return getattr(self.J,name)(offset,value,base,mod=mod)
                op={'global_store_dwordx4':'ds_write_b128','global_store_short':'ds_write_b16',
                    'global_store_byte':'ds_write_b8'}[name]
                return getattr(self.J,op)(self.address(kind,offset),value)
            return store
        return super().__getattr__(name)
    def s_waitcnt(self,mod=''):
        if 'vmcnt(0)' in mod and 'lgkmcnt(0)' not in mod:mod+=' lgkmcnt(0)'
        return self.J.s_waitcnt(mod=mod)


def pointer(J,base,offset=0):
    p=J.gpr(2,'su32',align=2)
    J.s_mov_b64(p,base)
    if not isinstance(offset,int) or offset:p[:]+=offset
    return p


@dataclass(frozen=True)
class BlockConfig:
    direct: bool=False
    gate_n: int=128
    down_n: int=64
    split_k: int=1
    replicas: int=1
    non_temporal: bool=True
    lds: bool=False
    gate_pipeline: bool=True
    replica_stride: int=1


@jit()
def block_fused(J,B,GN,DN,SK,REPLICAS,DIRECT,FUSED,NT,LDS,PIPE,REPLICA_STRIDE,
                X:'void*',XS:'void*',W1:'void*',S1:'void*',W2:'void*',S2:'void*',
                PART:'void*',MID:'void*',MS:'void*',OUT:'void*',
                IDS:'void*',RW:'void*',EXP:'void*',VALID:'void*'):
    ng=512//GN;waves=ng*SK;nd=6144//DN
    assert waves<=16 and nd%REPLICAS==0
    lane=J.gpr(J.threadIdx.x[0]%64)
    wv=J.gpr(J.threadIdx.x[0]//64);wave=J.gpr('su32')
    J.v_readfirstlane_b32(wave,wv)
    # Test launch ordering; actual XCD placement is hardware-scheduled. Do not
    # assume adjacent blocks share the same cache (counters show duplication).
    if REPLICA_STRIDE==1:
        tile=J.gpr('su32',J.blockIdx.x[0]//REPLICAS)
        replica=J.gpr('su32',J.blockIdx.x[0]%REPLICAS)
    else:
        assert REPLICA_STRIDE==8
        tile=J.gpr('su32',J.blockIdx.x[0]%8+(J.blockIdx.x[0]//(8*REPLICAS))*8)
        replica=J.gpr('su32',(J.blockIdx.x[0]//8)%REPLICAS)
        maximum=B*9+257*16-9
        cap=B*9 if DIRECT else min((maximum+15)//16,B*9)
        J.Jump('block_tile_live',tile[0]<cap)
        J.s_endpgm();J.Label('block_tile_live')
    b=J.gpr('su32',B)
    rows=1 if DIRECT else 16
    if LDS:
        # The pinned PyHIP lookup does not strip :sramecc/:xnack suffixes.
        # Set this emitter's allocator from the already-validated gfx950 ISA.
        from pyhip.core.mem_allocator import SimpleMemoryAllocator
        assert J.gfx==950
        J.lds_allocator=SimpleMemoryAllocator(160*1024)
        pbase=0;mbase=(SK*rows*2064 if SK>1 else 0);sbase=mbase+rows*144
        J.alloc_lds(sbase+rows*16,align=16)
    def coords(name,x,y,z,thread,mapping):
        if not LDS:return Coordinates(J,name,x,y,z,thread)
        return LocalCoordinates(J,name,x,y,z,thread,mapping=mapping,B=B,rows=rows,
                                partial_base=pbase,mid_base=mbase,scale_base=sbase)
    partial=pointer(J,PART,replica[0]*(SK*B*9*512*4))
    mid=pointer(J,MID,replica[0]*(B*9*128))
    scale=pointer(J,MS,replica[0]*(B*9*8))
    g=coords('gate_',J.gpr('su32',wave[0]%ng),tile,J.gpr('su32',wave[0]//ng),lane,
             [(partial,'partial'),(mid,'mid'),(scale,'scale')])
    native_projection.gen_func(g,6144,512,GN,True,SK,FUSED,1,DIRECT,PIPE,NT,
        pointer(J,X),pointer(J,XS),pointer(J,W1),pointer(J,S1),partial if SK>1 else mid,scale,
        pointer(J,IDS),pointer(J,RW),pointer(J,EXP),pointer(J,VALID),b)
    J.s_waitcnt(mod='vmcnt(0) lgkmcnt(0)')
    J.s_barrier()
    if SK>1:
        with J.ExecMask(wv[0]==0):
            if DIRECT:
                for col in range(2):
                    m=coords(f'middle{col}_',tile,J.gpr('su32',col),J.gpr('su32',0),lane,
                             [(partial,'partial'),(mid,'mid'),(scale,'scale')])
                    middle_packed.gen_func(m,partial,mid,scale,B,SK,FUSED)
            else:
                m=coords('middle_',tile,J.gpr('su32',0),J.gpr('su32',0),lane,
                         [(partial,'partial'),(mid,'mid'),(scale,'scale')])
                grouped_middle.gen_func(m,partial,mid,scale,pointer(J,IDS),B,SK,FUSED)
        J.s_waitcnt(mod='vmcnt(0) lgkmcnt(0)')
        J.s_barrier()
    if not LDS:J.buffer_inv(mod='sc1')
    col=J.gpr('su32',replica[0]*(nd//REPLICAS)+wave[0])
    stop=J.gpr('su32',(replica[0]+1)*(nd//REPLICAS))
    with J.While(col[0]<stop[0]):
        dx,ds=pointer(J,mid),pointer(J,scale)
        d=coords('down_',col,tile,J.gpr('su32',0),lane,[(dx,'mid'),(ds,'scale')])
        native_projection.gen_func(d,256,6144,DN,False,1,FUSED,1,DIRECT,True,NT,
            dx,ds,pointer(J,W2),pointer(J,S2),pointer(J,OUT),pointer(J,scale),
            pointer(J,IDS),pointer(J,RW),pointer(J,EXP),pointer(J,VALID),b)
        col[:]+=waves


class BlockProgram(NativeProgram):
    def __init__(self,owner,batch,config=BlockConfig()):
        self.bc=config
        super().__init__(owner,batch,NativeConfig(direct=config.direct,gate_n=config.gate_n,gate_waves=1,
            down_n=config.down_n,down_waves=1,split_k=config.split_k,non_temporal=config.non_temporal))
        c=config;b=batch;r=c.replicas
        self.mid=torch.empty((r,b,9,128),device=owner.device,dtype=torch.uint8)
        self.mid_scale=torch.empty((r,b,9,8),device=owner.device,dtype=torch.uint8)
        self.partial=torch.empty((r,c.split_k,b,9,512),device=owner.device,dtype=torch.float32) if c.split_k>1 else self.mid
        self.info=dict(config=c.__dict__,threads=64*(512//c.gate_n)*c.split_k)
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.bc,self.p;output=p['output'] if out is None else out
        native_phase1([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),
            p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),
            0 if supplied_weights is None else supplied_weights.data_ptr(),supplied_ids is not None)
        if not c.direct:
            phase23([self.group_grid],[384],p['ids'].data_ptr(),p['weights'].data_ptr(),p['sorted_ids'].data_ptr(),
                p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),p['valid'].data_ptr(),b,self.group_grid,p['sorted_ids'].numel())
        ids,rw,exp,valid=((p['ids'],p['weights'],p['ids'],p['ids']) if c.direct else
                         (p['sorted_ids'],p['sorted_weights'],p['experts'],p['valid']))
        blocks=((self.grid+c.replica_stride-1)//c.replica_stride)*c.replica_stride*c.replicas
        block_fused([blocks],[self.info['threads']],b,c.gate_n,c.down_n,c.split_k,c.replicas,c.direct,
            self.fp32_middle,c.non_temporal,c.lds,c.gate_pipeline,c.replica_stride,p['packed'].data_ptr(),p['workspace'].data_ptr()+256,
            self.owner.w13.data_ptr(),self.owner.weights.w13_scale.data_ptr(),self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),
            self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),output.data_ptr(),
            ids.data_ptr(),rw.data_ptr(),exp.data_ptr(),valid.data_ptr())
        return output
