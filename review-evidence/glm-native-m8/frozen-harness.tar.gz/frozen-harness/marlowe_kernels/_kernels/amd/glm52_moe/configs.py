"""Frozen Port-EW scheduling; change only with paired correctness/performance evidence."""
from dataclasses import dataclass

@dataclass(frozen=True)
class KernelConfig:
    direct: bool
    bm: int
    gate_n: int
    down_n: int
    split_k: int
    non_temporal: bool
    use_lds: bool
    gate_schedule: int
    down_schedule: int
    fuse_middle: bool

CONFIGS = {
    1: KernelConfig(**{'direct': True, 'bm': 16, 'gate_n': 64, 'down_n': 64, 'split_k': 3, 'non_temporal': True, 'use_lds': True, 'gate_schedule': 0, 'down_schedule': 0, 'fuse_middle': True}),
    2: KernelConfig(**{'direct': True, 'bm': 16, 'gate_n': 64, 'down_n': 64, 'split_k': 1, 'non_temporal': True, 'use_lds': True, 'gate_schedule': 0, 'down_schedule': 0, 'fuse_middle': False}),
    4: KernelConfig(**{'direct': True, 'bm': 16, 'gate_n': 64, 'down_n': 64, 'split_k': 6, 'non_temporal': True, 'use_lds': True, 'gate_schedule': 0, 'down_schedule': 0, 'fuse_middle': True}),
    8: KernelConfig(**{'direct': False, 'bm': 16, 'gate_n': 64, 'down_n': 64, 'split_k': 2, 'non_temporal': True, 'use_lds': True, 'gate_schedule': 0, 'down_schedule': 0, 'fuse_middle': True}),
    16: KernelConfig(**{'direct': False, 'bm': 16, 'gate_n': 64, 'down_n': 64, 'split_k': 1, 'non_temporal': True, 'use_lds': True, 'gate_schedule': 0, 'down_schedule': 0, 'fuse_middle': False}),
    32: KernelConfig(**{'direct': False, 'bm': 16, 'gate_n': 64, 'down_n': 64, 'split_k': 1, 'non_temporal': True, 'use_lds': True, 'gate_schedule': 1, 'down_schedule': 0, 'fuse_middle': True}),
    64: KernelConfig(**{'direct': False, 'bm': 16, 'gate_n': 64, 'down_n': 64, 'split_k': 2, 'non_temporal': True, 'use_lds': True, 'gate_schedule': 1, 'down_schedule': 0, 'fuse_middle': True}),
}
