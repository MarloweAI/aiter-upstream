# SPDX-License-Identifier: MIT
"""Finish a routed 16-row G1 tile with one wave; no per-token worker loop."""
from marlowe_kernels._runtime import jit
from .native_prepare import pack_fp4
from .quant import bf16,silu

@jit()
def grouped_middle(J,P:'void*',Y:'void*',YS:'void*',IDS:'void*',B,SK,FUSED):
    lane=J.threadIdx.x[0];row=J.gpr(lane%16);part=J.gpr(lane//16)
    identity=J.gpr('vu32')
    J.global_load_dword(identity,J.blockIdx.x[0]*64+row*4,IDS)
    J.s_waitcnt(mod='vmcnt(0)')
    token=J.gpr(identity[0]&0xffffff)
    route=J.gpr(token*9+(identity[0]>>24))
    for group in range(8):
        pairs=[]
        for offset in (0,256):
            cols=[]
            for n in range(2):
                parts=[]
                for split in range(1<<(SK-1).bit_length()):
                    value=J.gpr(4,'vf32',0.)
                    if split<SK:
                        with J.ExecMask(token<B,early_skip=False):
                            J.global_load_dwordx4(value,((split*B*9+route)*512+group*32+n*16+part*4+offset)*4,P)
                    parts.append(value)
                J.s_waitcnt(mod='vmcnt(0)')
                stride=len(parts)//2
                while stride:
                    for i in range(stride):
                        for j in range(4):J.v_add_f32(parts[i][j],parts[i][j],parts[i+stride][j])
                    stride//=2
                cols.extend(parts[0][i] for i in range(4))
            pairs.append(cols)
        values=[silu(J,pairs[0][i],pairs[1][i]) for i in range(8)]
        if not FUSED:values=[bf16(J,v) for v in values]
        codes,scale=pack_fp4(J,values,(16,32),FUSED)
        for n in range(2):
            word=J.gpr(codes[2*n][0]|(codes[2*n+1][0]<<8))
            with J.ExecMask(token<B,early_skip=False):
                J.global_store_short(route*128+group*16+n*8+part*2,word,Y)
        with J.ExecMask((token<B)&(part[0]==0),early_skip=False):
            J.global_store_byte(route*8+group,scale,YS)
