# SPDX-License-Identifier: MIT
"""Route-merged G1 with an independently selected direct or merged G2 grid."""
from dataclasses import dataclass
from .coalesced_program import CoalescedConfig,CoalescedProgram,coalesced_down

@dataclass(frozen=True)
class Merge8Config(CoalescedConfig):
    direct: str='merge8'
    dispatch: bool=False
    down_direct: bool=True

class Merge8Program(CoalescedProgram):
    def __init__(self,owner,batch,config=Merge8Config()):
        assert batch==8 and config.direct=='merge8' and not config.dispatch
        self.mc8=config
        super().__init__(owner,batch,CoalescedConfig(**{k:v for k,v in config.__dict__.items() if k!='down_direct'}))
        self.info.update(config=config.__dict__,algorithm='merged G1 / independently direct G2')
    def _stage(self,inp,scale,out,first):
        if first or not self.mc8.down_direct:return super()._stage(inp,scale,out,first)
        c,p,b=self.c,self.p,self.b
        coalesced_down([6144//c.down_n,b*9],[64*c.down_waves],c.down_n,c.down_waves,True,
            c.non_temporal,self.cc.down_depth or 2,self.cc.combine,False,b,0,
            inp.data_ptr(),scale,self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),out.data_ptr(),
            self.mid_scale.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),p['ids'].data_ptr(),p['ids'].data_ptr(),b)
