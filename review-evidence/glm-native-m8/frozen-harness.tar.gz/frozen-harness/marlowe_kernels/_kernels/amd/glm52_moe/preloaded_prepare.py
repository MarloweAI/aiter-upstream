# SPDX-License-Identifier: MIT
"""Native preparation with overlapped router-logit/bias loads."""
from marlowe_kernels._runtime import jit
from .native_prepare import pack_fp4
from .prepare import topk

@jit()
def preloaded_phase1(J, L:'void*', C:'void*', X:'void*', IDS:'void*', W:'void*',
           Q:'void*', S:'void*', O:'void*', SI:'void*', SW:'void*', SUPPLIED, FP32_ROUTING):
    token, tid = J.blockIdx.x[0], J.threadIdx.x[0]
    zero = J.gpr(4, 'vu32', 0)
    for part in (0,16):
        J.global_store_dwordx4((token*3*2048+tid*16)*2+part, zero, O)
    data = J.gpr(8, 'vu32')
    for part in (0,4):
        J.global_load_dwordx4(data[part:part+3], (token*3*2048+tid*16)*2+part*4, X)
    J.s_waitcnt(mod='vmcnt(0)')
    values = []
    for i in range(8):
        values.extend([J.gpr(data[i] << 16), J.gpr(data[i] & 0xffff0000)])
    encoded = J.gpr(2, 'vu32', 0)
    codes, exponent = pack_fp4(J, values, (1,), False)
    for i, code in enumerate(codes):
        encoded[i//4] = encoded[i//4] | (code[0] << (8*(i%4)))
    J.global_store_dwordx2(token*3*1024+tid*8, encoded, Q)
    with J.ExecMask(tid%2 == 0, early_skip=False):
        J.global_store_byte(256+token*3*64+tid//2, exponent, S)
    with J.ExecMask(tid < 64):
        if SUPPLIED:
            ids, weights = J.gpr('vu32'), J.gpr('vf32')
            with J.ExecMask(tid < 8, early_skip=False):
                J.global_load_dword(ids, (token*8+tid)*4, SI)
                J.global_load_dword(weights, (token*8+tid)*4, SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4, ids, IDS)
                J.global_store_dword((token*9+tid)*4, weights, W)
        else:
            if FP32_ROUTING:
                from .prepare_fp32 import topk_fp32
                topk_fp32(J,L,C,IDS,W,token,preload=True)
            else:topk(J,L,C,IDS,W,token,preload=True)
        with J.ExecMask(tid == 0, early_skip=False):
            J.global_store_dword(J.gpr("vu32",(token*9+8)*4), J.gpr('vu32',256), IDS)
            J.global_store_dword(J.gpr("vu32",(token*9+8)*4), J.gpr('vf32',1.), W)
