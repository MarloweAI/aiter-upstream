# SPDX-License-Identifier: MIT
# AITER E2M1/scale arithmetic; see ../legacy_pyhip/fused_qdq.py provenance.
"""Reusable assembly emitters for the two pinned MXFP4 rounding boundaries."""
from marlowe_kernels._runtime import jit


def shuffle(J, value, distance):
    other = J.gpr('vu32')
    J.ds_bpermute_b32(other, ((J.threadIdx.x[0] % 64) ^ distance) * 4, value)
    J.s_waitcnt(mod='lgkmcnt(0)')
    return other


def block_scale(J, values, distances, fused=False):
    """The two pinned scale expressions; reduction spans exactly 32 values."""
    absolute = J.gpr('su32', 0x7fffffff)
    maximum = J.gpr('vf32', 0. if fused else 1.e-10)
    for value in values:
        temp = J.gpr('vf32')
        J.v_and_b32(temp, absolute, value)
        J.v_max_f32(maximum, maximum, temp)
    for distance in distances:
        J.v_max_f32(maximum, maximum, shuffle(J, maximum, distance))
    exponent = J.gpr('vu32')
    if fused:
        J.v_add_u32(exponent, maximum, J.gpr('su32', 0x400000))
        J.v_lshrrev_b32(exponent, 23, exponent)
        J.v_sub_u32(exponent, exponent, 2)
        J.v_max_i32(exponent, exponent, 0)
    else:
        scaled = J.gpr('vf32')
        J.v_mul_f32(scaled, maximum, J.gpr('sf32', 1. / 6.))
        exponent[:] = scaled[0] >> 23
        mantissa = J.gpr(scaled[0] & 0x7fffff)
        inc = J.gpr('vu32', 0)
        J.v_cmp_ne_u32('vcc', mantissa, 0)
        J.v_cndmask_b32(inc, 0, 1, 'vcc')
        J.v_add_u32(exponent, exponent, inc)
    scale = J.gpr(exponent[0] << 23)
    J.v_cmp_eq_u32('vcc', exponent, 0)
    J.v_cndmask_b32(scale, scale, J.gpr('vu32', 0x00400000), 'vcc')
    return exponent, scale


def round_packed(J, values, distances, fused=False):
    """gfx950 RNE FP4 conversion and BF16 decode, still entirely PyHIP.

    AMD CDNA4 ISA, V_CVT_SCALEF32_PK_FP4_F32 and
    V_CVT_SCALEF32_PK_BF16_FP4 (https://gpuopen.com/machine-readable-isa/).
    Use a fresh low-byte destination for every pair: PyHIP's DSE does not
    model the hardware's partial-destination updates for other OPSEL bytes.
    """
    exponent, scale = block_scale(J, values, distances, fused)
    codes, packed = [], []
    for i in range(0,len(values),2):
        code = J.gpr('vu32')
        J.v_cvt_scalef32_pk_fp4_f32(code, values[i], values[i+1], scale, mod='op_sel:[0,0,0,0]')
        code[:] = code[0] & 255
        bf = J.gpr('vbf16x2')
        J.v_cvt_scalef32_pk_bf16_fp4(bf, code, scale, mod='op_sel:[0,0,0]')
        codes.append(code);packed.append(bf)
    return codes, exponent, packed


def round_values(J, values, distances, fused=False):
    """Scalar E2M1 emitter retained as an explicit diagnostic variant."""
    absolute = J.gpr('su32', 0x7fffffff)
    exponent, scale = block_scale(J, values, distances, fused)
    inverse = J.gpr((254 - exponent[0]) << 23)
    codes, rounded = [], []
    for value in values:
        magnitude = J.gpr('vf32')
        J.v_and_b32(magnitude, absolute, value)
        J.v_mul_f32(magnitude, magnitude, inverse)
        code = J.gpr('vu32', 0)
        result = J.gpr('vf32', 0.)
        for c, (threshold, level, inclusive) in enumerate(
                ((.25,.5,False),(.75,1.,True),(1.25,1.5,False),
                 (1.75,2.,True),(2.5,3.,False),(3.5,4.,True),(5.,6.,False)), 1):
            compare = J.v_cmp_ge_f32 if inclusive else J.v_cmp_gt_f32
            compare('vcc', magnitude, J.gpr('sf32', threshold))
            J.v_cndmask_b32(result, result, J.gpr('vf32', level), 'vcc')
            J.v_cndmask_b32(code, code, c, 'vcc')
        sign = J.gpr(value[0] & 0x80000000)
        code[:] = code[0] | (sign[0] >> 28)
        J.v_mul_f32(result, result, scale)
        J.v_or_b32(result, result, sign)
        codes.append(code); rounded.append(result)
    return codes, exponent, rounded


def bf16(J, value):
    packed = J.gpr('vbf16x2')
    # The pinned pk_f32_to_bf16 helper only extracts the upper bits.
    # B64 explicitly stores BF16 (RNE) before estimating its MXFP4 scale.
    J.v_cvt_pk_bf16_f32(packed, value, value)
    result = J.gpr('vf32')
    J.v_lshlrev_b32(result, 16, packed)
    return result


def silu(J, gate, up):
    exp = J.gpr('vf32')
    J.v_mul_f32(exp, gate, J.gpr('sf32', -1.4426950408889634))
    J.v_exp_f32(exp, exp)
    J.v_add_f32(exp, 1., exp)
    J.v_rcp_f32(exp, exp)
    J.v_mul_f32(exp, gate, exp)
    J.v_mul_f32(exp, exp, up)
    return exp


@jit()
def middle(J, P:'void*', Y:'void*', B, SK, FUSED, INPUT_FP32, HW):
    """Match the accepted split reduction tree and activation/storage rounding."""
    row = J.gpr("vu32", J.blockIdx.x[0])[0]
    col = J.blockIdx.y[0] * 128 + J.threadIdx.x[0] * 2
    if SK > 1:
        pairs = []
        for offset in (0, 256):
            parts = []
            for split in range(1 << (SK - 1).bit_length()):
                value = J.gpr(2, 'vf32', 0.)
                if split < SK:
                    J.global_load_dwordx2(value, ((split*B*9+row)*512+col+offset)*4, P)
                parts.append(value)
            J.s_waitcnt(mod='vmcnt(0)')
            # tl.sum over the padded split dimension: halves, then quarters.
            stride = len(parts)//2
            while stride:
                for i in range(stride):
                    for j in range(2):
                        J.v_add_f32(parts[i][j], parts[i][j], parts[i+stride][j])
                stride //= 2
            pairs.append(parts[0])
        values = [silu(J, pairs[0][i], pairs[1][i]) for i in range(2)]
        if not FUSED:
            values = [bf16(J, x) for x in values]
    elif INPUT_FP32:
        data = J.gpr(2, 'vf32')
        J.global_load_dwordx2(data, (row*256+col)*4, P)
        J.s_waitcnt(mod='vmcnt(0)')
        values = [data[i] for i in range(2)]
    else:
        data = J.gpr('vu32')
        J.global_load_dword(data, (row*256+col)*2, P)
        J.s_waitcnt(mod='vmcnt(0)')
        values = [J.gpr(data[0] << 16), J.gpr(data[0] & 0xffff0000)]
    if HW:
        _, _, pairs = round_packed(J, values, (1,2,4,8), FUSED)
        packed = pairs[0]
    else:
        _, _, rounded = round_values(J, values, (1,2,4,8), FUSED)
        packed = J.gpr('vbf16x2')
        J.pk_f32_to_bf16(packed, rounded[0], rounded[1])
    J.global_store_dword((row*256+col)*2, packed, Y)
