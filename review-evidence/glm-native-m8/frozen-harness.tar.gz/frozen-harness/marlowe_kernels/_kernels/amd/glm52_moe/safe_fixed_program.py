# SPDX-License-Identifier: MIT
"""Fixed routing with an ordered supplied-route combination option.

Arbitrary supplied slots may repeat an expert. Sum the unchanged BF16-rounded
expert contributions in FP32 for that mode; internally selected unique top-k
routes retain the faster atomic path unless ordered_all is explicitly chosen.
"""
from dataclasses import dataclass,fields
import torch
from marlowe_kernels._runtime import jit
from .fixed_bins import FixedBinProgram,FixedBinConfig,clear_fixed_next
from .native_ordered import ordered_projection
from .ordered_program import ordered_combine

@dataclass(frozen=True)
class SafeFixedConfig(FixedBinConfig):
    ordered_supplied: bool=True
    ordered_all: bool=False

@jit()
def ordered_fixed_down(J,BN,NW,NT,DEPTH,BATCH,
                       X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                       IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    ordered_projection.gen_func(J,256,6144,BN,False,1,False,NW,'fixed',True,NT,DEPTH,'ordered',
        X,XS,W,WS,Y,YS,IDS,RW,EXP,STATE,B)
    clear_fixed_next(J,STATE,BATCH,64*NW)

class SafeFixedProgram(FixedBinProgram):
    def __init__(self,owner,batch,config=SafeFixedConfig()):
        self.sc=config;self._ordered_mode=False
        super().__init__(owner,batch,FixedBinConfig(**{f.name:getattr(config,f.name) for f in fields(FixedBinConfig)}))
        self.route_output=torch.empty((batch,9,6144),device=owner.device,dtype=torch.bfloat16)
        self.info.update(config=config.__dict__,supplied_combination='BF16 operand rounding, ordered FP32 sum')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        self._ordered_mode=self.sc.ordered_all or (self.sc.ordered_supplied and supplied_ids is not None)
        output=self.p['output'] if out is None else out
        try:
            target=self.route_output if self._ordered_mode else output
            super().run(x,logits,bias,out=target,supplied_ids=supplied_ids,supplied_weights=supplied_weights)
            if self._ordered_mode:ordered_combine([12,self.b],[256],target.data_ptr(),output.data_ptr())
            return output
        finally:self._ordered_mode=False
    def _stage(self,inp,scale,out,first):
        if first or not self._ordered_mode:return super()._stage(inp,scale,out,first)
        c,p,b=self.fc,self.p,self.b
        ordered_fixed_down([6144//c.down_n,self.grid],[64*c.down_waves],c.down_n,c.down_waves,c.non_temporal,c.down_depth or 2,b,
            inp.data_ptr(),scale,self.owner.w2.data_ptr(),self.owner.weights.w2_scale.data_ptr(),out.data_ptr(),self.mid_scale.data_ptr(),
            p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.state.data_ptr(),b)
