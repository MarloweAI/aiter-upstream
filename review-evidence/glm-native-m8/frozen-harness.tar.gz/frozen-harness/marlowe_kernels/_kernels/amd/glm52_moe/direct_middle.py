# SPDX-License-Identifier: MIT
"""Port-EW split reduction/SwiGLU, packing directly into AITER tile layout.

Uses AITER-compatible FP32 activation and fused scale rounding at every batch.
Adapted from native_prepare.middle_packed; no expert GEMM is changed.
"""
from marlowe_kernels._runtime import jit
from .native_prepare import pack_fp4
from .quant import silu


@jit()
def middle_direct(J, P:'void*', Y:'void*', YS:'void*', B, SK, BM, SHARE):
    """Match the accepted split reduction tree and activation/storage rounding."""
    row = J.gpr("vu32", J.blockIdx.x[0])[0]
    col = J.blockIdx.y[0] * 128 + J.threadIdx.x[0] * 2
    assert SK > 1
    pairs = []
    for offset in (0, 256):
        parts = []
        for split in range(1 << (SK - 1).bit_length()):
            value = J.gpr(2, 'vf32', 0.)
            if split < SK:
                J.global_load_dwordx2(value, ((split*B*9+row)*512+col+offset)*4, P)
            parts.append(value)
        J.s_waitcnt(mod='vmcnt(0)')
        # tl.sum over the padded split dimension: halves, then quarters.
        stride = len(parts)//2
        while stride:
            for i in range(stride):
                for j in range(2):
                    J.v_add_f32(parts[i][j], parts[i][j], parts[i+stride][j])
            stride //= 2
        pairs.append(parts[0])
    values = [silu(J, pairs[0][i], pairs[1][i]) for i in range(2)]
    codes,exponent=pack_fp4(J,values,(1,2,4,8),True)
    token=J.gpr('vu32')
    J.v_mul_hi_u32(token,J.gpr('su32',0x38e38e39),J.gpr('vu32',row))
    token[:]=token[0]>>1
    slot=J.gpr(row-token[0]*9)
    if SHARE:
        dest=J.gpr((token[0]*8+slot[0])*BM)
        shared=J.gpr(B*8*BM+token[0])
        J.v_cmp_eq_u32('vcc',slot,8)
        J.v_cndmask_b32(dest,dest,shared,'vcc')
    else:
        dest=J.gpr(row*BM)
    J.global_store_byte(dest[0]*128+col//2,codes[0],Y)
    with J.ExecMask(J.threadIdx.x[0]%16==0,early_skip=False):
        scale_col=col//32
        offset=(dest[0]//BM)*256+(scale_col%4)*64+(dest[0]%16)*4+(scale_col//4)*2+(dest[0]%BM)//16
        J.global_store_byte(offset,exponent,YS)
