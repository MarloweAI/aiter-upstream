# SPDX-License-Identifier: MIT
"""Fixed expert route segments avoid chunk-map publication and polling.

Routed counters and valid-row allocators are double buffered. Consumers mask
padding using the current counters; G2 clears only the next counters. Route
storage need not be padded or cleared between calls. Segments allow all 8*B
supplied slots to select one expert, not only unique top-k selections.
"""
from dataclasses import dataclass,fields
import torch
from marlowe_kernels._runtime import jit
from .block_fused import pointer
from .fused_dispatch import valid_pointer,TopkBins
from .prepare import topk
from .native_prepare import pack_fp4,middle_packed
from .coalesced_program import CoalescedProgram,CoalescedConfig
from .native_prefetch import prefetch_projection
from .native_pairprefetch import paired_projection
from .native_coalesced import coalesced_projection


def fixed_bin_routes(J,expert,weight,token,B,counts,valid,SORT,RW,EXP):
    lane=J.threadIdx.x[0]%64
    position=J.gpr('vu32')
    J.global_atomic_add(position,expert[0]*4,J.gpr('vu32',1),counts,mod='sc0')
    J.s_waitcnt(mod='vmcnt(0)')
    J.v_cmp_eq_u32('vcc',position[0]&15,0)
    mask=J.gpr(2,'su32');J.s_and_b64(mask,'vcc','exec')
    number=J.gpr('su32');J.s_bcnt1_i32_b64(number,mask)
    J.Jump('fixed_no_new',number[0]==0)
    base=J.gpr('vu32',0)
    with J.ExecMask(lane==0,early_skip=False):
        J.global_atomic_add(base,J.gpr('vu32',0),J.gpr('vu32',number[0]*16),valid,mod='sc0')
    J.s_waitcnt(mod='vmcnt(0)')
    scalar=J.gpr('su32');J.v_readfirstlane_b32(scalar,base)
    prefix=J.gpr('vu32');lower=J.gpr('vu32')
    J.v_lshlrev_b32(lower,J.gpr(lane),1);lower[:]-=1
    J.v_bcnt_u32_b32(prefix,mask[0]&lower[0],0)
    row=J.gpr(scalar[0]+prefix*16)
    encoded=J.gpr(expert[0]|((position[0]//16)<<9))
    with J.ExecMask((position[0]&15)==0,early_skip=False):
        J.global_store_dword((row[0]//16)*4,encoded,EXP)
    J.Label('fixed_no_new')
    destination=J.gpr(expert[0]*(B*8)+position[0])
    packed=J.gpr(token|(lane<<24))
    J.global_store_dword(destination[0]*4,packed,SORT)
    J.global_store_dword(destination[0]*4,weight,RW)


@jit()
def fixed_prepare(J,B,MAXIMUM,PRELOAD,L:'void*',C:'void*',X:'void*',IDS:'void*',W:'void*',
                  Q:'void*',S:'void*',O:'void*',SI:'void*',SW:'void*',STATE:'void*',
                  SORT:'void*',RW:'void*',EXP:'void*',SUPPLIED,FP32_ROUTING):
    token,tid=J.blockIdx.x[0],J.threadIdx.x[0]
    valid,which=valid_pointer(J,STATE,False)
    sort=pointer(J,SORT,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    counts=pointer(J,STATE,16+which[0]*(257*4))
    J.Jump('fixed_snapshot_done',token!=0)
    with J.ExecMask(tid==0,early_skip=False):
        J.global_store_dword(J.gpr('vu32',4),J.gpr('vu32',which[0]),STATE)
    J.Label('fixed_snapshot_done')
    zero=J.gpr(4,'vu32',0)
    for part in (0,16):J.global_store_dwordx4((token*3*2048+tid*16)*2+part,zero,O)
    data=J.gpr(8,'vu32')
    for part in (0,4):J.global_load_dwordx4(data[part:part+3],(token*3*2048+tid*16)*2+part*4,X)
    J.s_waitcnt(mod='vmcnt(0)')
    values=[]
    for i in range(8):values.extend([J.gpr(data[i]<<16),J.gpr(data[i]&0xffff0000)])
    codes,exponent=pack_fp4(J,values,(1,),False)
    encoded=J.gpr(2,'vu32',0)
    for i,code in enumerate(codes):encoded[i//4]=encoded[i//4]|(code[0]<<(8*(i%4)))
    J.global_store_dwordx2(token*3*1024+tid*8,encoded,Q)
    with J.ExecMask(tid%2==0,early_skip=False):J.global_store_byte(256+token*3*64+tid//2,exponent,S)
    def bins(expert,weight):fixed_bin_routes(J,expert,weight,token,B,counts,valid,sort,rw,EXP)
    with J.ExecMask(tid<64):
        if SUPPLIED:
            expert=J.gpr('vu32');weight=J.gpr('vf32')
            with J.ExecMask(tid<8,early_skip=False):
                J.global_load_dword(expert,(token*8+tid)*4,SI)
                J.global_load_dword(weight,(token*8+tid)*4,SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4,expert,IDS)
                J.global_store_dword((token*9+tid)*4,weight,W)
                bins(expert,weight)
        elif FP32_ROUTING:
            from .prepare_fp32 import topk_fp32
            topk_fp32(TopkBins(J,IDS,W,bins),L,C,IDS,W,token,preload=PRELOAD)
        else:topk(TopkBins(J,IDS,W,bins),L,C,IDS,W,token,preload=PRELOAD)
        with J.ExecMask(tid==0,early_skip=False):
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vu32',256),IDS)
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vf32',1.),W)


def resolve_fixed_routes(J,IDS,RW,EXP,STATE,B,FIRST):
    valid,bank=valid_pointer(J,STATE)
    encoded=J.gpr('su32');rows=J.gpr('su32')
    J.s_load_dword(encoded,EXP,J.blockIdx.y[0]*4);J.s_load_dword(rows,valid,0)
    J.s_waitcnt(mod='lgkmcnt(0)')
    J.Jump('fixed_active',J.blockIdx.y[0]*16<rows[0])
    J.s_endpgm();J.Label('fixed_active')
    expert=J.gpr('su32',encoded[0]&511);chunk=J.gpr('su32',encoded[0]>>9)
    counts=pointer(J,STATE,16+bank[0]*(257*4));count=J.gpr('su32')
    J.s_load_dword(count,counts,expert[0]*4);J.s_waitcnt(mod='lgkmcnt(0)')
    offset=J.gpr('su32',((bank[0]*257+expert[0])*(B[0]*8)+chunk[0]*16)*4)
    ids=pointer(J,IDS,offset[0]);weights=pointer(J,RW,offset[0])
    row=J.gpr(J.threadIdx.x[0]%16)
    sentinel=J.gpr('su32',(9<<24)|B[0]);packed=J.gpr('vu32',sentinel[0]);routing=J.gpr('vf32',0.)
    with J.ExecMask(row[0]<(count[0]-chunk[0]*16),early_skip=False):
        J.global_load_dword(packed,row[0]*4,ids)
        if not FIRST:J.global_load_dword(routing,row[0]*4,weights)
    J.s_waitcnt(mod='vmcnt(0)')
    J.Label('fixed_matrix_ready')
    return expert,J.gpr(packed[0]&0xffffff),J.gpr(packed[0]>>24),routing


def clear_fixed_next(J,STATE,B,THREADS):
    J.Jump('fixed_reset_done',J.blockIdx.y[0]!=0)
    _,bank=valid_pointer(J,STATE);nxt=J.gpr('su32',bank[0]^1)
    counts=pointer(J,STATE,16+nxt[0]*(257*4))
    base=J.gpr('su32',J.blockIdx.x[0]*THREADS)
    tid=J.gpr(base[0]+J.threadIdx.x[0])
    with J.ExecMask(tid[0]<256,early_skip=False):
        J.global_store_dword(tid[0]*4,J.gpr('vu32',0),counts)
    J.Jump('fixed_reset_done',J.blockIdx.x[0]!=0)
    with J.ExecMask(J.threadIdx.x[0]==0,early_skip=False):
        J.global_store_dword(J.gpr('vu32',8+nxt[0]*4),J.gpr('vu32',((B+15)//16)*16),STATE)
        J.global_store_dword(J.gpr('vu32',0),J.gpr('vu32',nxt[0]),STATE)
    J.Label('fixed_reset_done')


@jit()
def fixed_projection(J,K,N,BN,FIRST,SK,FP32,NW,NT,DEPTH,PAIR,COMBINE,BATCH,
                     X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                     IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    pointers=(X,XS,W,WS,Y,YS,IDS,RW,EXP,STATE,B)
    common=(K,N,BN,FIRST,SK,FP32,NW,'fixed',True,NT)
    if PAIR:paired_projection.gen_func(J,*common,DEPTH,COMBINE,*pointers)
    elif FIRST:prefetch_projection.gen_func(J,*common,DEPTH,*pointers)
    else:coalesced_projection.gen_func(J,*common,DEPTH,COMBINE,*pointers)
    if not FIRST:clear_fixed_next(J,STATE,BATCH,64*NW)


@jit()
def packed_fixed_projection(J,K,N,BN,FIRST,SK,FP32,NW,NT,DEPTH,PAIR,COMBINE,BATCH,
                     X:'void*',XS:'void*',W:'void*',WS:'void*',Y:'void*',YS:'void*',
                     IDS:'void*',RW:'void*',EXP:'void*',STATE:'void*',B:'int'):
    previous=J.__dict__.get('packed_input_scales',False)
    J.packed_input_scales=True
    fixed_projection.gen_func(J,K,N,BN,FIRST,SK,FP32,NW,NT,DEPTH,PAIR,COMBINE,BATCH,
        X,XS,W,WS,Y,YS,IDS,RW,EXP,STATE,B)
    J.packed_input_scales=previous


@dataclass(frozen=True)
class FixedBinConfig(CoalescedConfig):
    direct: bool=False
    dispatch: bool=True
    route_preload: bool=True
    pair_depth: int=3
    pair_g2: bool=False
    packed_input_scales: bool=False


class FixedBinProgram(CoalescedProgram):
    def __init__(self,owner,batch,config=FixedBinConfig()):
        assert batch in (16,32,64,128,256) and config.dispatch and not config.direct
        self.fc=config
        assert not config.packed_input_scales or config.pair_depth>0
        super().__init__(owner,batch,CoalescedConfig(**{f.name:getattr(config,f.name) for f in fields(CoalescedConfig)}))
        self.maximum=257*batch*8
        self.p['sorted_ids']=torch.empty(self.maximum*2,device=owner.device,dtype=torch.int32)
        self.p['sorted_weights']=torch.empty(self.maximum*2,device=owner.device,dtype=torch.float32)
        self.state=torch.zeros(4+257*2+1,device=owner.device,dtype=torch.int32)
        shared=(batch+15)//16;self.state[2:4]=shared*16
        for bank in range(2):
            self.state[4+bank*257+256]=batch
            offset=bank*self.maximum+256*batch*8
            self.p['sorted_ids'][offset:offset+batch]=torch.arange(batch,device=owner.device,dtype=torch.int32)|(8<<24)
            self.p['sorted_weights'][offset:offset+batch]=1.
        for chunk in range(shared):self.p['experts'][chunk]=256|(chunk<<9)
        routed=batch*8;experts=min(256,routed)
        self.grid=min(self.grid,experts+(routed-experts)//16+shared)
        self.info.update(config=config.__dict__,grid=self.grid,algorithm='fixed expert storage / double-buffered counts / no chunk publication')

    def state_check(self):
        state=self.state.cpu();nxt,current=int(state[0]),int(state[1])
        pending=state[4+nxt*257:4+nxt*257+256]
        counts=state[4+current*257:4+current*257+256]
        result=dict(next_bank=nxt,current_bank=current,next_counts_zero=not bool(pending.any()),
            current_route_count=int(counts.sum()),error=int(state[-1]))
        result['passed']=nxt!=current and result['next_counts_zero'] and result['current_route_count']==self.b*8 and result['error']==0
        return result

    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        b,c,p=self.b,self.fc,self.p;output=p['output'] if out is None else out
        fixed_prepare([b],[384],b,self.maximum,c.route_preload,logits.data_ptr(),bias.data_ptr(),x.data_ptr(),
            p['ids'].data_ptr(),p['weights'].data_ptr(),p['packed'].data_ptr(),p['workspace'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),0 if supplied_weights is None else supplied_weights.data_ptr(),
            self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),supplied_ids is not None,getattr(self,'router_fp32',False))
        self._stage(p['packed'],p['workspace'].data_ptr()+256,self.partial,True)
        if c.split_k>1:middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
        self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
        return output

    def _stage(self,inp,scale,out,first):
        c,p,b=self.fc,self.p,self.b
        n,k,bn,nw=(512,6144,c.gate_n,c.gate_waves) if first else (6144,256,c.down_n,c.down_waves)
        sk=c.split_k if first else 1;pair=bool(c.pair_depth) if first else c.pair_g2
        depth=c.pair_depth if first and pair else c.depth if first else 1 if pair else c.down_depth or 2
        weight,scales=(self.owner.w13,self.owner.weights.w13_scale) if first else (self.owner.w2,self.owner.weights.w2_scale)
        emit=packed_fixed_projection if pair and c.packed_input_scales else fixed_projection
        emit([n//bn,self.grid,sk],[64*nw],k,n,bn,first,sk,self.fp32_middle,nw,c.non_temporal,depth,pair,c.combine,b,
            inp.data_ptr(),scale,weight.data_ptr(),scales.data_ptr(),out.data_ptr(),self.mid_scale.data_ptr(),
            p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),self.state.data_ptr(),b)
