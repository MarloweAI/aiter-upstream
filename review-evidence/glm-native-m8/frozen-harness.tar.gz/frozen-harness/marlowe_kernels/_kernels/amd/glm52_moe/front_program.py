# SPDX-License-Identifier: MIT
"""Dispatch preparation with router loads overlapped before key computation.

The bin publication/reset protocol is unchanged from fused_dispatch.py.
"""
from dataclasses import dataclass
from marlowe_kernels._runtime import jit
from .block_fused import pointer
from .fused_dispatch import valid_pointer,bin_routes,TopkBins
from .prepare import topk
from .quant import round_packed
from .coalesced_program import CoalescedProgram,CoalescedConfig
from .native_prepare import middle_packed

@jit()
def preloaded_dispatch_prepare(J,L:'void*',C:'void*',X:'void*',IDS:'void*',W:'void*',
                     Q:'void*',S:'void*',QDQ:'void*',O:'void*',SI:'void*',SW:'void*',
                     STATE:'void*',SORT:'void*',RW:'void*',EXP:'void*',MIND:'void*',B,BF16,MAXIMUM,AUX,QUANT,SUPPLIED):
    token,tid=J.blockIdx.x[0],J.threadIdx.x[0]
    valid,which=valid_pointer(J,STATE,False)
    sort=pointer(J,SORT,which[0]*(MAXIMUM*4));rw=pointer(J,RW,which[0]*(MAXIMUM*4))
    J.Jump('snapshot_done',token!=0)
    with J.ExecMask(tid==0,early_skip=False):
        J.global_store_dword(J.gpr('vu32',4),J.gpr('vu32',which[0]),STATE)
    J.Label('snapshot_done')
    mind=pointer(J,MIND,which[0]*(MAXIMUM*4)) if AUX else None
    counts=pointer(J,STATE,16);maps=pointer(J,STATE,16+256*4)
    error=pointer(J,STATE,(4+256+256*((B+15)//16))*4)
    zero=J.gpr(4,'vu32',0)
    for offset in (0,16):J.global_store_dwordx4((token*3*2048+tid*16)*2+offset,zero,O)
    if QUANT:
        data=J.gpr(8,'vu32')
        for part in (0,4):J.global_load_dwordx4(data[part:part+3],(token*3*2048+tid*16)*2+part*4,X)
        J.s_waitcnt(mod='vmcnt(0)')
        values=[]
        for i in range(8):values.extend([J.gpr(data[i]<<16),J.gpr(data[i]&0xffff0000)])
        codes,exponent,pairs=round_packed(J,values,(1,),False)
        encoded=J.gpr(2,'vu32',0)
        for i,code in enumerate(codes):encoded[i//4]=encoded[i//4]|(code[0]<<(8*(i%4)))
        J.global_store_dwordx2(token*3*1024+tid*8,encoded,Q)
        with J.ExecMask(tid%2==0,early_skip=False):J.global_store_byte(256+token*3*64+tid//2,exponent,S)
        if BF16:
            for i,pair in enumerate(pairs):J.global_store_dword((token*3*2048+tid*16+i*2)*2,pair,QDQ)
    def bins(expert,weight):bin_routes(J,expert,weight,token,B,counts,maps,valid,sort,rw,EXP,mind,error)
    with J.ExecMask(tid<64):
        if SUPPLIED:
            expert,weight=J.gpr('vu32'),J.gpr('vf32')
            with J.ExecMask(tid<8,early_skip=False):
                J.global_load_dword(expert,(token*8+tid)*4,SI)
                J.global_load_dword(weight,(token*8+tid)*4,SW)
                J.s_waitcnt(mod='vmcnt(0)')
                J.global_store_dword((token*9+tid)*4,expert,IDS)
                J.global_store_dword((token*9+tid)*4,weight,W)
                bins(expert,weight)
        else:topk(TopkBins(J,IDS,W,bins),L,C,IDS,W,token,preload=True)
        with J.ExecMask(tid==0,early_skip=False):
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vu32',256),IDS)
            J.global_store_dword(J.gpr('vu32',(token*9+8)*4),J.gpr('vf32',1.),W)

@dataclass(frozen=True)
class FrontConfig(CoalescedConfig):
    dispatch: bool=True
    route_preload: bool=True
    grid_cap: bool=True

class FrontProgram(CoalescedProgram):
    def __init__(self,owner,batch,config=FrontConfig()):
        assert config.dispatch and not config.direct
        self.fc=config
        super().__init__(owner,batch,CoalescedConfig(**{k:v for k,v in config.__dict__.items() if k not in ('route_preload','grid_cap')}))
        if config.grid_cap:
            # Each occupied expert costs one routed row; every additional
            # BM16 tile requires sixteen more rows. Shared tiles are separate.
            routed=batch*8;experts=min(256,routed)
            upper=experts+(routed-experts)//16+(batch+15)//16
            self.grid=min(self.grid,upper)
        self.info.update(config=config.__dict__,grid=self.grid,algorithm='preloaded routing with bounded expert grid')
    def run(self,x,logits,bias,*,out=None,supplied_ids=None,supplied_weights=None):
        if not self.fc.route_preload:
            return super().run(x,logits,bias,out=out,supplied_ids=supplied_ids,supplied_weights=supplied_weights)
        b,c,p=self.b,self.c,self.p;output=p['output'] if out is None else out
        preloaded_dispatch_prepare([b],[384],logits.data_ptr(),bias.data_ptr(),x.data_ptr(),p['ids'].data_ptr(),p['weights'].data_ptr(),
            p['packed'].data_ptr(),p['workspace'].data_ptr(),p['qdq'].data_ptr(),output.data_ptr(),
            0 if supplied_ids is None else supplied_ids.data_ptr(),0 if supplied_weights is None else supplied_weights.data_ptr(),
            self.state.data_ptr(),p['sorted_ids'].data_ptr(),p['sorted_weights'].data_ptr(),p['experts'].data_ptr(),0,b,False,self.maximum,False,True,supplied_ids is not None)
        self._stage(p['packed'],p['workspace'].data_ptr()+256,self.partial,True)
        if c.split_k>1:middle_packed([b*9,2],[64],self.partial.data_ptr(),self.mid.data_ptr(),self.mid_scale.data_ptr(),b,c.split_k,self.fp32_middle)
        self._stage(self.mid,self.mid_scale.data_ptr(),output,False)
        return output
