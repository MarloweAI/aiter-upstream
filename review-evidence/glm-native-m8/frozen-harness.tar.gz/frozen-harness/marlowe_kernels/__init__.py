"""Marlowe Kernels. Importing the public API does not initialize a GPU."""
from .moe import MoEConfig, MoEWeights, UnsupportedConfiguration, create_moe, supports

__version__ = "0.1.0.dev0"
__all__ = ["MoEConfig", "MoEWeights", "UnsupportedConfiguration", "create_moe", "supports"]
