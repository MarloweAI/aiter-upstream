"""Prepared GLM-5.2 local MoE: router logits to BF16 output, before TP reduction."""
from dataclasses import dataclass
from typing import Any

SUPPORTED_BATCHES = (1, 2, 4, 8, 16, 32, 64, 128)
WEIGHT_LAYOUT = "aiter_mxfp4_16x16_e8m0_separated"


class UnsupportedConfiguration(ValueError):
    """The caller should select its native backend before executing this call."""


@dataclass(frozen=True)
class MoEConfig:
    model: str = "glm5.2"
    tp: int = 8
    ep: int = 1
    precision: str = "mxfp4"
    hidden_size: int = 6144
    intermediate_size: int = 256  # Per TP rank.
    routed_experts: int = 256
    top_k: int = 8
    shared_experts: int = 1
    routed_scale: float = 2.5


@dataclass(frozen=True)
class MoEWeights:
    w13: Any
    w2: Any
    w13_scale: Any
    w2_scale: Any
    layout: str = WEIGHT_LAYOUT


def supports(config: MoEConfig, batch_size: int | None = None) -> bool:
    return config == MoEConfig() and (
        batch_size is None or type(batch_size) is int and batch_size in SUPPORTED_BATCHES
    )


def _require(condition, message):
    if not condition:
        raise UnsupportedConfiguration(message)


def _canonical_implementation(implementation):
    if implementation == "port_ew_bw":
        implementation = "port_ew"
    _require(implementation in ("port_ew", "bf16", "native_fp4"), "Unknown implementation")
    return implementation


def _program_factory(implementation):
    if implementation == "port_ew":
        from ._kernels.amd.glm52_moe.bandwidth_program import create_bandwidth_program
        return create_bandwidth_program
    if implementation == "native_fp4":
        from ._kernels.amd.glm52_moe.native_program import NativeProgram
        return NativeProgram
    from ._kernels.amd.glm52_moe.program import Program
    return Program


def create_moe(config: MoEConfig, weights: MoEWeights, *, implementation="port_ew"):
    """Prepare the latest qualified Port-EW kernels by default.

    ``bf16`` and ``native_fp4`` retain historical regression implementations.
    ``port_ew_bw`` is a compatibility alias for ``port_ew``, not a separate path.
    """
    implementation = _canonical_implementation(implementation)
    _require(supports(config), "Only GLM-5.2 MXFP4 TP8/EP1 is qualified")
    return PreparedMoE(config, weights, implementation=implementation)


class PreparedMoE:
    """Owns scratch for one layer/stream. Separate instances for concurrent calls.

    Warm up requested token counts outside graph capture. ``out`` may override
    the reusable output; otherwise the returned view is overwritten on reuse.
    Weights remain caller-owned, with no unpacked copies or routing decisions
    baked into generated code. Training/backward is unsupported.
    """

    def __init__(self, config, weights, *, implementation="port_ew"):
        self.implementation = _canonical_implementation(implementation)
        import torch
        self.config, self.weights = config, weights
        _require(weights.layout == WEIGHT_LAYOUT, "Unsupported packed weight layout")
        _require(torch.version.hip is not None, "This implementation requires ROCm")
        self.device = weights.w13.device
        _require(self.device.type == "cuda", "Weights must be on an allocated MI355X")
        props = torch.cuda.get_device_properties(self.device)
        _require(props.gcnArchName.split(":")[0] == "gfx950" and props.multi_processor_count == 256,
                 "Port-EW is qualified for MI355X gfx950 with 256 CUs")
        _require(not torch.cuda.is_current_stream_capturing(), "Create the handle before graph capture")
        tensors = (weights.w13, weights.w2, weights.w13_scale, weights.w2_scale)
        for tensor in tensors:
            _require(tensor.device == self.device and tensor.is_contiguous(), "Weights/scales must be contiguous on one device")
        _require(tuple(weights.w13.shape) == (257, 512, 3072), "Invalid packed gate/up shape")
        _require(tuple(weights.w2.shape) == (257, 6144, 128), "Invalid packed down shape")
        for tensor in tensors[:2]:
            _require(tensor.dtype in (torch.uint8, torch.float4_e2m1fn_x2), "Expected packed MXFP4 weights")
        for tensor, count in zip(tensors[2:], (257*512*192, 257*6144*8)):
            _require(tensor.numel() == count and tensor.element_size() == 1 and
                     str(tensor.dtype) in ("torch.uint8", "torch.float8_e8m0fnu"), "Invalid E8M0 scale storage")
        from ._runtime import bind_process_device
        _require(bind_process_device(self.device.index), "Use one GPU per process (one SGLang worker per TP rank)")
        # dtype views preserve storage; the device kernels consume packed bytes.
        self.w13 = weights.w13.view(torch.float4_e2m1fn_x2)
        self.w2 = weights.w2.view(torch.float4_e2m1fn_x2)
        self._programs = {}
        self._fp32_programs = {}
        self._native_programs = {}
        self._prepared_modes = set()
        self._cu_count = props.multi_processor_count

    @property
    def prepared_batches(self):
        return tuple(sorted(self._programs.keys() | self._fp32_programs.keys() | self._native_programs.keys()))

    def warmup(self, batch_sizes=SUPPORTED_BATCHES, *, routing="internal"):
        import torch
        Program = _program_factory(self.implementation)
        _require(not torch.cuda.is_current_stream_capturing(), "Warmup cannot run inside graph capture")
        sizes = tuple(batch_sizes)
        _require(routing in ("internal", "internal_fp32", "supplied", "native"), "Unknown routing mode")
        if routing == "internal_fp32":
            _require(self.implementation == "port_ew", "FP32 internal routing requires Port-EW")
            from ._kernels.amd.glm52_moe.bandwidth_program import create_fp32_bandwidth_program
            Program = create_fp32_bandwidth_program
        if routing == "native":
            _require(self.implementation == "port_ew", "Native routing requires Port-EW")
        if routing in ("supplied", "native") and self.implementation == "port_ew":
            from ._kernels.amd.glm52_moe.native_combine import create_native_combine_program
            Program = create_native_combine_program
        _require(all(supports(self.config, b) for b in sizes), "Unsupported token count")
        with torch.cuda.device(self.device), torch.no_grad():
            for b in sizes:
                if (b,routing) in self._prepared_modes:
                    continue
                programs = (self._fp32_programs if routing == "internal_fp32" else
                            self._native_programs if routing in ("supplied", "native") and self.implementation == "port_ew" else self._programs)
                program = programs.get(b) or Program(self, b)
                x = torch.zeros((b, 6144), dtype=torch.bfloat16, device=self.device)
                router_dtype=torch.float32 if routing == "internal_fp32" else torch.bfloat16
                logits = torch.zeros((b, 256), dtype=router_dtype, device=self.device)
                bias = torch.zeros(256, dtype=router_dtype, device=self.device)
                if routing in ("supplied", "native") and self.implementation == "port_ew":
                    ids=torch.arange(8,device=self.device,dtype=torch.int32).expand(b,8).contiguous()
                    weights=torch.full((b,8),2.5/8,device=self.device,dtype=torch.float32)
                    program.run(x,logits,bias,supplied_ids=ids,supplied_weights=weights)
                else:
                    program.run(x, logits, bias)
                programs[b] = program
                if routing in ("supplied", "native"):
                    self._prepared_modes.update(((b,"supplied"),(b,"native")))
                else:
                    self._prepared_modes.add((b,routing))
            torch.cuda.synchronize(self.device)
        return self

    def _validate_inputs(self, x, logits, bias, out, *, program=None, router_dtype=None):
        import torch
        router_dtype=torch.bfloat16 if router_dtype is None else router_dtype
        _require(torch.cuda.current_device()==self.device.index, "Set the current device to the handle's GPU before calling")
        b = x.shape[0]
        program=self._programs.get(b) if program is None else program
        _require(program is not None, f"Token count {b} is not warmed; select native execution or call warmup first")
        for t, shape, dtype in ((x, (b,6144),torch.bfloat16),
                                (logits, (b,256),router_dtype),(bias, (256,),router_dtype)):
            _require(tuple(t.shape) == shape and t.dtype == dtype and t.device == self.device
                     and t.is_contiguous(), "Port-EW requires contiguous BF16 input and matching router dtype on the weights' device")
            _require(not t.requires_grad, "Inference only; gradients are unsupported")
        checked_out = program.p["output"] if out is None else out
        _require(tuple(checked_out.shape) == (b,6144) and checked_out.dtype == torch.bfloat16
                 and checked_out.device == self.device and checked_out.is_contiguous()
                 and not checked_out.requires_grad, "Invalid output buffer")
        start = checked_out.data_ptr()
        end = start + checked_out.numel()*checked_out.element_size()
        for t in (x,logits,bias,self.w13,self.w2,self.weights.w13_scale,self.weights.w2_scale):
            a, z = t.data_ptr(), t.data_ptr()+t.numel()*t.element_size()
            _require(end <= a or z <= start, "Output must not overlap inputs or weights")
        return program

    def __call__(self, x, router_logits, correction_bias, *, out=None):
        _require((len(x),"internal") in self._prepared_modes, "Warm up internal routing first")
        program = self._validate_inputs(x, router_logits, correction_bias, out)
        return program.run(x, router_logits, correction_bias, out=out)

    def forward_fp32(self, x, router_logits, correction_bias, *, out=None):
        """Run FP32 top-k inside Port-EW without rounding router operands to BF16."""
        import torch
        b=len(x)
        _require((b,"internal_fp32") in self._prepared_modes, "Warm up internal_fp32 routing first")
        program=self._validate_inputs(x,router_logits,correction_bias,out,
                                      program=self._fp32_programs[b],router_dtype=torch.float32)
        return program.run(x,router_logits,correction_bias,out=out)

    def forward_routed(self, x, expert_ids, expert_weights, *, out=None):
        """Consume eight distinct caller-selected routes; append shared once.

        This preserves newer routers' FP32 semantics without rounding their
        logits/bias to the BF16 contract of the extracted fused router.
        IDs must be distinct per token and in [0,256); weights must be finite.
        Native top-k provides these guarantees. G2 accumulates BF16-rounded
        contributions directly into the output with BF16 atomics.
        """
        return self._forward_routed(x, expert_ids, expert_weights, out=out, routing="supplied")

    def forward_native_routed(self, x, expert_ids, expert_weights, *, out=None):
        """Compatibility alias for forward_routed; native and supplied are one mode."""
        _require(self.implementation == "port_ew", "Native routing requires Port-EW")
        return self._forward_routed(x, expert_ids, expert_weights, out=out, routing="native")

    def _forward_routed(self, x, expert_ids, expert_weights, *, out, routing):
        import torch
        b=len(x)
        _require(torch.cuda.current_device()==self.device.index, "Set the current device to the handle's GPU before calling")
        _require((b,routing) in self._prepared_modes, f"Warm up {routing} routing first")
        programs = self._native_programs if self.implementation == "port_ew" else self._programs
        program = programs[b]
        _require(tuple(x.shape)==(b,6144) and x.dtype==torch.bfloat16 and x.device==self.device
                 and x.is_contiguous() and not x.requires_grad,"Invalid hidden states")
        for t,dtype in ((expert_ids,torch.int32),(expert_weights,torch.float32)):
            _require(tuple(t.shape)==(b,8) and t.dtype==dtype and t.device==self.device and
                     t.is_contiguous() and not t.requires_grad,"Expected contiguous [M,8] IDs/weights")
        checked_out = program.p["output"] if out is None else out
        _require(tuple(checked_out.shape)==(b,6144) and checked_out.dtype==torch.bfloat16
                 and checked_out.device==self.device and checked_out.is_contiguous()
                 and not checked_out.requires_grad,"Invalid output")
        start=checked_out.data_ptr()
        end=start+checked_out.numel()*checked_out.element_size()
        for t in (x,expert_ids,expert_weights,self.w13,self.w2,self.weights.w13_scale,self.weights.w2_scale):
            a,z=t.data_ptr(),t.data_ptr()+t.numel()*t.element_size()
            _require(end<=a or z<=start,"Output overlaps input")
        # phase1 does not read L/C in its SUPPLIED specialization.
        return program.run(x,x,x,out=out,supplied_ids=expert_ids,supplied_weights=expert_weights)

    def routing(self, batch_size, *, routing="internal"):
        """Borrow runtime route buffers for SGLang's expert recorder; no copies."""
        _require(routing in ("internal", "internal_fp32", "supplied", "native"), "Unknown routing mode")
        programs = (self._fp32_programs if routing == "internal_fp32" else
                    self._native_programs if routing in ("supplied", "native") and self.implementation == "port_ew" else self._programs)
        p = programs[batch_size].p
        return p["ids"], p["weights"]
